/* PIC remap, ISR/IRQ installation, and exception reporting. */

#include "interrupts.h"
#include "descriptors.h"
#include "serial.h"
#include "io.h"
#include "aidebug.h"

#define PIC1_CMD  0x20
#define PIC1_DATA 0x21
#define PIC2_CMD  0xA0
#define PIC2_DATA 0xA1
#define PIC_EOI   0x20

#define IRQ_BASE 0x20

static irq_handler_t irq_handlers[16];

static const char *exception_names[32] = {
    "divide by zero", "debug", "non-maskable interrupt", "breakpoint",
    "overflow", "bound range exceeded", "invalid opcode", "device not available",
    "double fault", "coprocessor segment overrun", "invalid TSS",
    "segment not present", "stack-segment fault", "general protection fault",
    "page fault", "reserved", "x87 floating-point", "alignment check",
    "machine check", "SIMD floating-point", "virtualization", "control protection",
    "reserved", "reserved", "reserved", "reserved", "reserved", "reserved",
    "hypervisor injection", "VMM communication", "security", "reserved",
};

/* Provided by boot/isr.asm. */
#define ISR_STUB(n) extern void isr##n(void);
ISR_STUB(0)  ISR_STUB(1)  ISR_STUB(2)  ISR_STUB(3)
ISR_STUB(4)  ISR_STUB(5)  ISR_STUB(6)  ISR_STUB(7)
ISR_STUB(8)  ISR_STUB(9)  ISR_STUB(10) ISR_STUB(11)
ISR_STUB(12) ISR_STUB(13) ISR_STUB(14) ISR_STUB(15)
ISR_STUB(16) ISR_STUB(17) ISR_STUB(18) ISR_STUB(19)
ISR_STUB(20) ISR_STUB(21) ISR_STUB(22) ISR_STUB(23)
ISR_STUB(24) ISR_STUB(25) ISR_STUB(26) ISR_STUB(27)
ISR_STUB(28) ISR_STUB(29) ISR_STUB(30) ISR_STUB(31)

extern void irq0(void);
extern void irq1(void);
extern void irq14(void);

static void pic_remap(void)
{
    u8 mask1 = inb(PIC1_DATA);
    u8 mask2 = inb(PIC2_DATA);

    outb(PIC1_CMD, 0x11);   /* ICW1: init + expect ICW4 */
    io_wait();
    outb(PIC2_CMD, 0x11);
    io_wait();
    outb(PIC1_DATA, IRQ_BASE);      /* ICW2: master vector offset */
    io_wait();
    outb(PIC2_DATA, IRQ_BASE + 8);  /* ICW2: slave vector offset */
    io_wait();
    outb(PIC1_DATA, 0x04);  /* ICW3: slave on IRQ2 */
    io_wait();
    outb(PIC2_DATA, 0x02);  /* ICW3: slave cascade identity */
    io_wait();
    outb(PIC1_DATA, 0x01);  /* ICW4: 8086 mode */
    io_wait();
    outb(PIC2_DATA, 0x01);
    io_wait();

    (void)mask1;
    (void)mask2;

    /* Mask everything, then open only the lines we service. Leaving a line
     * unmasked but ungated in the IDT turns any spurious assertion into a
     * general protection fault, which is far harder to diagnose. */
    outb(PIC1_DATA, 0xFF);
    outb(PIC2_DATA, 0xFF);
}

void irq_install_handler(int irq, irq_handler_t handler)
{
    if (irq >= 0 && irq < 16) {
        irq_handlers[irq] = handler;
    }
}

/* Unmask a single IRQ line on the master PIC. */
static void irq_unmask(int irq)
{
    if (irq < 8) {
        u8 mask = inb(PIC1_DATA);
        outb(PIC1_DATA, (u8)(mask & ~(1 << irq)));
    } else {
        u8 mask = inb(PIC2_DATA);
        outb(PIC2_DATA, (u8)(mask & ~(1 << (irq - 8))));
        /* Ensure the cascade line (IRQ2) is open too. */
        u8 m1 = inb(PIC1_DATA);
        outb(PIC1_DATA, (u8)(m1 & ~(1 << 2)));
    }
}

void isr_dispatch(struct regs *r)
{
    const char *name = r->int_no < 32 ? exception_names[r->int_no] : "unknown";

    klog("FAULT", "exception %u (%s) err=0x%x eip=0x%x",
         r->int_no, name, r->err_code, r->eip);

    /* Hand the frame to the auto-debugger: it classifies the fault, reports a
     * repair, and resumes when the fault is survivable. */
    if (aidebug_handle_fault(r)) {
        return;
    }

    for (;;) {
        hlt();
    }
}

void irq_dispatch(struct regs *r)
{
    int irq = (int)r->int_no - IRQ_BASE;

    if (irq >= 0 && irq < 16 && irq_handlers[irq]) {
        irq_handlers[irq](r);
    }

    /* Acknowledge the interrupt(s). */
    if (irq >= 8) {
        outb(PIC2_CMD, PIC_EOI);
    }
    outb(PIC1_CMD, PIC_EOI);
}

void interrupts_init(void)
{
    pic_remap();

    idt_set_gate(0,  (u32)isr0,  0x08, 0x8E);
    idt_set_gate(1,  (u32)isr1,  0x08, 0x8E);
    idt_set_gate(2,  (u32)isr2,  0x08, 0x8E);
    idt_set_gate(3,  (u32)isr3,  0x08, 0x8E);
    idt_set_gate(4,  (u32)isr4,  0x08, 0x8E);
    idt_set_gate(5,  (u32)isr5,  0x08, 0x8E);
    idt_set_gate(6,  (u32)isr6,  0x08, 0x8E);
    idt_set_gate(7,  (u32)isr7,  0x08, 0x8E);
    idt_set_gate(8,  (u32)isr8,  0x08, 0x8E);
    idt_set_gate(9,  (u32)isr9,  0x08, 0x8E);
    idt_set_gate(10, (u32)isr10, 0x08, 0x8E);
    idt_set_gate(11, (u32)isr11, 0x08, 0x8E);
    idt_set_gate(12, (u32)isr12, 0x08, 0x8E);
    idt_set_gate(13, (u32)isr13, 0x08, 0x8E);
    idt_set_gate(14, (u32)isr14, 0x08, 0x8E);
    idt_set_gate(15, (u32)isr15, 0x08, 0x8E);
    idt_set_gate(16, (u32)isr16, 0x08, 0x8E);
    idt_set_gate(17, (u32)isr17, 0x08, 0x8E);
    idt_set_gate(18, (u32)isr18, 0x08, 0x8E);
    idt_set_gate(19, (u32)isr19, 0x08, 0x8E);
    idt_set_gate(20, (u32)isr20, 0x08, 0x8E);
    idt_set_gate(21, (u32)isr21, 0x08, 0x8E);
    idt_set_gate(22, (u32)isr22, 0x08, 0x8E);
    idt_set_gate(23, (u32)isr23, 0x08, 0x8E);
    idt_set_gate(24, (u32)isr24, 0x08, 0x8E);
    idt_set_gate(25, (u32)isr25, 0x08, 0x8E);
    idt_set_gate(26, (u32)isr26, 0x08, 0x8E);
    idt_set_gate(27, (u32)isr27, 0x08, 0x8E);
    idt_set_gate(28, (u32)isr28, 0x08, 0x8E);
    idt_set_gate(29, (u32)isr29, 0x08, 0x8E);
    idt_set_gate(30, (u32)isr30, 0x08, 0x8E);
    idt_set_gate(31, (u32)isr31, 0x08, 0x8E);

    idt_set_gate(IRQ_BASE + 0,  (u32)irq0,  0x08, 0x8E);  /* PIT */
    idt_set_gate(IRQ_BASE + 1,  (u32)irq1,  0x08, 0x8E);  /* keyboard */
    idt_set_gate(IRQ_BASE + 14, (u32)irq14, 0x08, 0x8E);  /* primary ATA */

    irq_unmask(0);
    irq_unmask(1);
    irq_unmask(14);
}
