; Interrupt service routine stubs.
;
; Vectors 8, 10-14 and 17 push their own error code; every other vector does
; not. The stubs below account for that difference -- pushing a dummy code for
; the latter only -- so the C dispatcher always sees one uniform frame:
;
;     int_no, err_code, eip, cs, eflags [, useresp, ss]
;
; Getting this wrong shifts the frame and the dispatcher reads garbage, so the
; ISR_ERR and ISR_NOERR macros are kept strictly separate.
bits 32

section .text

extern isr_dispatch
extern irq_dispatch

; --- Exceptions that push an error code -------------------------------------
%macro ISR_ERR 1
global isr%1
isr%1:
    cli
    push dword %1           ; CPU already pushed the error code
    jmp isr_common
%endmacro

; --- Exceptions that do not push an error code ------------------------------
%macro ISR_NOERR 1
global isr%1
isr%1:
    cli
    push dword 0            ; dummy error code
    push dword %1
    jmp isr_common
%endmacro

; --- Hardware IRQs ----------------------------------------------------------
%macro IRQ 2
global irq%1
irq%1:
    cli
    push dword 0            ; dummy error code
    push dword %2           ; vector number
    jmp irq_common
%endmacro

ISR_NOERR 0
ISR_NOERR 1
ISR_NOERR 2
ISR_NOERR 3
ISR_NOERR 4
ISR_NOERR 5
ISR_NOERR 6
ISR_NOERR 7
ISR_ERR   8             ; double fault
ISR_NOERR 9
ISR_ERR   10            ; invalid TSS
ISR_ERR   11            ; segment not present
ISR_ERR   12            ; stack-segment fault
ISR_ERR   13            ; general protection fault
ISR_ERR   14            ; page fault
ISR_NOERR 15
ISR_NOERR 16
ISR_ERR   17            ; alignment check
ISR_NOERR 18
ISR_NOERR 19
ISR_NOERR 20
ISR_NOERR 21
ISR_NOERR 22
ISR_NOERR 23
ISR_NOERR 24
ISR_NOERR 25
ISR_NOERR 26
ISR_NOERR 27
ISR_NOERR 28
ISR_NOERR 29
ISR_NOERR 30
ISR_NOERR 31

IRQ 0, 32               ; PIT
IRQ 1, 33               ; keyboard
IRQ 14, 46              ; primary ATA

isr_common:
    pusha
    push ds
    push es
    push fs
    push gs
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    push esp                ; pointer to struct regs
    call isr_dispatch
    add esp, 4
    pop gs
    pop fs
    pop es
    pop ds
    popa
    add esp, 8              ; drop int_no and err_code
    iret

irq_common:
    pusha
    push ds
    push es
    push fs
    push gs
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    push esp
    call irq_dispatch
    add esp, 4
    pop gs
    pop fs
    pop es
    pop ds
    popa
    add esp, 8
    iret
