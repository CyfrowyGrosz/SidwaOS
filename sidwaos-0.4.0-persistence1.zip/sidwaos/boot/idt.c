/* GDT and IDT construction. */

#include "descriptors.h"
#include "string.h"
#include "serial.h"

#define GDT_ENTRIES 3
#define IDT_ENTRIES 256

static struct gdt_entry gdt[GDT_ENTRIES];
static struct gdt_ptr   gdt_ptr;
static struct idt_entry idt[IDT_ENTRIES];
static struct idt_ptr   idt_ptr;

static void gdt_set(int i, u32 base, u32 limit, u8 access, u8 gran)
{
    gdt[i].base_low    = (u16)(base & 0xFFFF);
    gdt[i].base_mid    = (u8)((base >> 16) & 0xFF);
    gdt[i].base_high   = (u8)((base >> 24) & 0xFF);
    gdt[i].limit_low   = (u16)(limit & 0xFFFF);
    gdt[i].granularity = (u8)(((limit >> 16) & 0x0F) | (gran & 0xF0));
    gdt[i].access      = access;
}

void gdt_init(void)
{
    gdt_set(0, 0, 0, 0, 0);                                  /* null */
    gdt_set(1, 0, 0xFFFFF, 0x9A, 0xCF);                      /* code: ring0 */
    gdt_set(2, 0, 0xFFFFF, 0x92, 0xCF);                      /* data: ring0 */

    gdt_ptr.limit = (u16)(sizeof(gdt) - 1);
    gdt_ptr.base  = (u32)&gdt;
    gdt_load((u32)&gdt_ptr);
}

void idt_set_gate(int index, u32 handler, u16 selector, u8 flags)
{
    if (index < 0 || index >= IDT_ENTRIES) {
        return;
    }
    idt[index].base_low    = (u16)(handler & 0xFFFF);
    idt[index].base_high   = (u16)((handler >> 16) & 0xFFFF);
    idt[index].selector    = selector;
    idt[index].always_zero = 0;
    idt[index].flags       = flags;
}

/* Provided by boot/idt.asm. */
extern void idt_load(u32 idt_ptr_addr);

void idt_init(void)
{
    memset(&idt, 0, sizeof(idt));

    idt_ptr.limit = (u16)(sizeof(idt) - 1);
    idt_ptr.base  = (u32)&idt;

    idt_load((u32)&idt_ptr);
}
