; SidwaOS stage 2 loader.
;
; Stage 1 jumps here at 0x8000 in real mode with dl = boot drive, so the entry
; point is the very first byte. This does the part GRUB used to do, but only the
; part the kernel actually needs:
;
;   1. read the kernel ELF image from a fixed LBA into low memory
;   2. ask the BIOS how much memory there is
;   3. enter 32-bit protected mode with flat segments
;   4. walk the ELF program headers, copy each PT_LOAD segment to its physical
;      address, and zero the .bss tail
;   5. build a Multiboot information structure and jump to the ELF entry point
;      with eax = 0x2BADB002 and ebx = the structure, the contract boot.asm
;      already expects
;
; mkboot.py patches kernel_lba, kernel_sectors and base_lba after assembling, so
; the loader never needs to know where the kernel was placed. Those fields are
; data, kept out of the instruction stream below the entry point.
bits 16
org 0x8000

KERNEL_BUF  equ 0x10000             ; the kernel file is read here
; The hand-off structures live in low conventional memory, clear of stage 2's
; own 16 KiB at 0x8000..0xC000. Writing them inside that range would overwrite
; the running loader.
MBI_ADDR      equ 0x600             ; the Multiboot info structure
BOOTINFO_ADDR equ 0x700             ; where the kernel finds the disk base
STAGE2_STK    equ 0x7C00            ; stage 2 stack, grows down
MB_MAGIC      equ 0x2BADB002
BOOTINFO_MAGIC equ 0x5344424F       ; "SDBO"

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, STAGE2_STK
    sti

    mov [boot_drive], dl

    call read_kernel
    call query_memory

    cli
    lgdt [gdt_desc]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp dword 0x08:pm_start         ; far jump into the 32-bit code selector

; --- real mode: read the kernel image ---------------------------------------

read_kernel:
    mov edi, KERNEL_BUF
    mov eax, [kernel_lba]
    mov ecx, [kernel_sectors]
.read_loop:
    push eax
    push ecx
    push edi
    mov dword [dap_lba], eax
    mov eax, edi
    shr eax, 4                      ; segment = linear >> 4
    mov [dap_seg], ax
    mov eax, edi
    and eax, 0x0F                   ; offset = linear & 0xF
    mov [dap_off], ax
    mov word [dap_count], 1
    mov si, dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    pop edi
    pop ecx
    pop eax
    jc .read_fail
    inc eax
    add edi, 512
    loop .read_loop
    ret
.read_fail:
    mov si, msg_read
    call puts
    jmp halt16

; --- real mode: ask the BIOS how much memory there is -----------------------

query_memory:
    int 0x12                        ; ax = KiB below 1 MiB
    mov [mem_lower], ax

    mov ax, 0xE801                  ; ax/cx KiB above 1 MiB, bx/dx 64 KiB blocks
    int 0x15
    jc .legacy
    test ax, ax
    jnz .have
    mov ax, cx
.have:
    mov [mem_upper_kb], ax
    ret

.legacy:
    mov ah, 0x88                    ; fall back: ax = KiB above 1 MiB
    int 0x15
    jc .none
    mov [mem_upper_kb], ax
    ret
.none:
    mov word [mem_upper_kb], 0
    ret

puts:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp puts
.done:
    ret

halt16:
    cli
    hlt
    jmp halt16

msg_read db "SidwaOS: kernel read failed", 0

; --- 32-bit protected mode ---------------------------------------------------

bits 32
pm_start:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, STAGE2_STK

    call load_elf
    call build_mbi

    mov eax, MB_MAGIC
    mov ebx, MBI_ADDR
    push dword 0x08                 ; far return into the kernel entry point
    push dword [entry]
    retf

; Place every PT_LOAD segment at its physical address and zero the .bss tail.
load_elf:
    mov ebp, KERNEL_BUF             ; ebp: ELF base, kept for the whole walk
    mov eax, [ebp + 24]             ; e_entry
    mov [entry], eax

    mov ebx, [ebp + 28]             ; e_phoff
    add ebx, ebp
    movzx ecx, word [ebp + 44]      ; e_phnum

.ph_loop:
    test ecx, ecx
    jz .done
    cmp dword [ebx], 1              ; PT_LOAD only
    jne .next

    mov esi, [ebx + 4]              ; p_offset
    add esi, ebp
    mov edi, [ebx + 12]             ; p_paddr
    mov ecx, [ebx + 16]             ; p_filesz
    call memcpy

    mov ecx, [ebx + 20]             ; p_memsz
    sub ecx, [ebx + 16]             ; minus p_filesz = the .bss tail
    xor al, al
    rep stosb

    movzx ecx, word [ebp + 44]      ; memcpy and stosb used ecx
.next:
    movzx eax, word [ebp + 42]      ; e_phentsize
    add ebx, eax
    dec ecx
    jmp .ph_loop
.done:
    ret

; Copy ecx bytes from esi to edi. Clobbers esi, edi, ecx, al only.
memcpy:
    test ecx, ecx
    jz .done
.copy:
    mov al, [esi]
    mov [edi], al
    inc esi
    inc edi
    dec ecx
    jnz .copy
.done:
    ret

build_mbi:
    mov edi, MBI_ADDR
    mov dword [edi + 0], 0x00000003  ; mem_* valid, boot_device valid
    movzx eax, word [mem_lower]
    mov [edi + 4], eax
    movzx eax, word [mem_upper_kb]
    mov [edi + 8], eax
    movzx eax, byte [boot_drive]
    mov [edi + 12], eax
    mov dword [edi + 16], 0          ; no command line

    ; Tell the kernel where its disk region starts, so it addresses the right
    ; partition instead of the front of the disk.
    mov edi, BOOTINFO_ADDR
    mov dword [edi], BOOTINFO_MAGIC
    mov eax, [base_lba]
    mov [edi + 4], eax
    ret

halt32:
    cli
    hlt
    jmp halt32

; --- shared data -------------------------------------------------------------

; Patched by mkboot.py: where the kernel ELF sits and how long it is, and where
; the SidwaOS region begins.
align 8
signature:
    dd 0x53444232                   ; "SDB2", the patch tool looks for this
kernel_lba:
    dd 0
kernel_sectors:
    dd 0
base_lba:
    dd 0

boot_drive   db 0
mem_lower    dw 0
mem_upper_kb dw 0

align 4
dap:
    db 0x10
    db 0
dap_count:
    dw 1
dap_off:
    dw 0
dap_seg:
    dw 0
dap_lba:
    dq 0

align 8
gdt:
    dq 0                            ; null
    dq 0x00CF9A000000FFFF           ; code: base 0, limit 4 GiB, 32-bit
    dq 0x00CF92000000FFFF           ; data: base 0, limit 4 GiB, 32-bit
gdt_desc:
    dw gdt_desc - gdt - 1
    dd gdt

align 8
entry:
    dd 0

times 16384-($-$$) db 0
