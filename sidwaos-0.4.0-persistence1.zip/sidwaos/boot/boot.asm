; Multiboot entry stub.
; GRUB loads this ELF in 32-bit protected mode and jumps to _start with
; eax = 0x2BADB002 and ebx = multiboot_info pointer.
bits 32

MB_MAGIC    equ 0x1BADB002
MB_FLAGS    equ 0x00000003          ; align modules + provide memory info
MB_CHECKSUM equ -(MB_MAGIC + MB_FLAGS)

section .multiboot
align 4
    dd MB_MAGIC
    dd MB_FLAGS
    dd MB_CHECKSUM

section .bss
align 16
stack_bottom:
    resb 16384
stack_top:

section .text
global _start
extern kmain

_start:
    mov esp, stack_top              ; set up our own stack
    push ebx                        ; multiboot_info pointer
    push eax                        ; multiboot magic
    call kmain

.hang:
    cli
    hlt
    jmp .hang
