; Global Descriptor Table setup.
bits 32

section .text
global gdt_load

; void gdt_load(uint32_t gdt_ptr_addr)
; Loads the GDT via lgdt, then reloads the data segment registers and far-jumps
; into the kernel code selector so CS is refreshed.
gdt_load:
    mov eax, [esp + 4]
    lgdt [eax]

    mov ax, 0x10                    ; kernel data selector
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    jmp 0x08:.reload                ; far jump to refresh CS
.reload:
    ret
