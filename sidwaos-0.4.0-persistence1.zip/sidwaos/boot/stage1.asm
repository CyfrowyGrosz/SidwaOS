; SidwaOS stage 1 boot sector (MBR).
;
; The BIOS loads this at 0x7C00. It reads stage 2 into 0x8000 with the INT 13h
; LBA extensions and jumps to it. It does no ELF parsing and no protected-mode
; switch, so it stays inside 446 bytes next to the partition table. Everything
; else belongs to stage 2.
;
; The entry point is at the very start of the sector: the BIOS jumps to offset 0,
; so the first instruction has to be there. The patch field below it is data the
; build tools overwrite.
bits 16
org 0x7C00

STAGE2_OFF  equ 0x8000
STAGE2_SEG  equ 0x0000
STAGE2_SECT equ 32                  ; 16 KiB is room for stage 2

start:
    jmp short entry                 ; keep the patch field out of the way
    nop

; Patched by the build tools: where stage 2 begins. On a whole-disk install that
; is LBA 1; inside a partition it is the partition start plus one.
align 8
signature:
    dd 0x53444231                   ; "SDB1"
stage2_lba:
    dd 1

entry:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [0x0500], dl                ; the BIOS boot drive

    mov eax, [stage2_lba]           ; fold the patch field into the DAP
    mov [dap_lba], eax
    mov dword [dap_lba + 4], 0

    mov byte [retries], 3
.retry:
    mov ah, 0x42                    ; extended read
    mov dl, [0x0500]
    mov si, dap
    int 0x13
    jnc .loaded

    xor ah, ah                      ; reset the disk, then try again
    mov dl, [0x0500]
    int 0x13
    dec byte [retries]
    jnz .retry

    mov si, msg_err
    call puts
    jmp halt

.loaded:
    mov dl, [0x0500]
    jmp STAGE2_SEG:STAGE2_OFF

puts:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp puts
.done:
    ret

halt:
    cli
    hlt
    jmp halt

msg_err db "SidwaOS: cannot read stage 2", 0
retries db 0

align 4
dap:
    db 0x10                         ; packet size
    db 0
    dw STAGE2_SECT
    dw STAGE2_OFF
    dw STAGE2_SEG
dap_lba:
    dq 1

times 446-($-$$) db 0               ; the partition table is written by mkboot.py
times 510-($-$$) db 0
dw 0xAA55
