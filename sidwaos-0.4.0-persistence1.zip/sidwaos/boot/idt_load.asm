; IDT loader.
bits 32

section .text
global idt_load

; void idt_load(uint32_t idt_ptr_addr)
idt_load:
    mov eax, [esp + 4]
    lidt [eax]
    ret
