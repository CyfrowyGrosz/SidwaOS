/* Binary encoding for assembled programs. See include/codec.h.
 *
 * The packed stream is a five-byte header (format, then the instruction count)
 * followed by one record per instruction:
 *
 *     u16 descriptor, little-endian
 *         bits 0-3   op
 *         bits 4-6   mode
 *         bits 7-8   dst
 *         bits 9-10  src
 *         bit  11    an immediate follows
 *         bits 12-15 unused, always zero
 *     u32 immediate, little-endian, present only when bit 11 is set
 *
 * Eleven of the twelve descriptor bits are used, so the four small fields pack
 * into one word with the immediate omitted whenever it is zero, which it is for
 * most instructions in a real program.
 *
 * The two encoders below produce byte-identical output. The first is the
 * obvious one: a bit accumulator that pushes each field one bit at a time, five
 * iterations for a five-bit field. The second exploits the fact that the fields
 * total twelve bits, so the whole descriptor can be assembled with shifts and
 * stored once. The naive version is kept because it defines what the format
 * means -- it is the reference the fast one is checked against -- and because
 * the gap between them is the measurement codec_opt() reports.
 */

#include "codec.h"
#include "serial.h"
#include "string.h"
#include "cache.h"

/* --- Header ---------------------------------------------------------------- */

static u32 put_header(u8 *out, u32 max, u8 fmt, u32 count)
{
    if (max < 5) {
        return 0;
    }
    out[0] = fmt;
    out[1] = (u8)(count & 0xFF);
    out[2] = (u8)((count >> 8) & 0xFF);
    out[3] = (u8)((count >> 16) & 0xFF);
    out[4] = (u8)((count >> 24) & 0xFF);
    return 5;
}

static int read_header(const u8 *in, u32 len, u8 *fmt, u32 *count)
{
    if (len < 5) {
        return 0;
    }
    *fmt = in[0];
    *count = (u32)in[1] | ((u32)in[2] << 8) | ((u32)in[3] << 16)
           | ((u32)in[4] << 24);
    return 1;
}

/* --- Raw ------------------------------------------------------------------- */

static u32 encode_raw(const struct sasm_insn *code, u32 count, u8 *out,
                      u32 max, u8 fmt)
{
    u32 n = put_header(out, max, fmt, count);
    if (!n) {
        return 0;
    }
    for (u32 i = 0; i < count; i++) {
        if (n + CODEC_RAW_BYTES_PER_INSN > max) {
            return 0;
        }
        out[n++] = code[i].op;
        out[n++] = code[i].dst;
        out[n++] = code[i].src;
        out[n++] = code[i].mode;
        out[n++] = (u8)(code[i].imm & 0xFF);
        out[n++] = (u8)((code[i].imm >> 8) & 0xFF);
        out[n++] = (u8)((code[i].imm >> 16) & 0xFF);
        out[n++] = (u8)((code[i].imm >> 24) & 0xFF);
    }
    return n;
}

/* --- Packed, the obvious way: one bit at a time ---------------------------- */

/* Little-endian bit accumulator. Fields are pushed low bit first, so the bytes
 * it produces are exactly the little-endian words the fast encoder stores. */
struct bitw {
    u8 *buf;
    u32 cap;
    u32 nbits;
};

static void bw_put(struct bitw *b, u32 value, u32 bits)
{
    for (u32 i = 0; i < bits; i++) {
        u32 byte = b->nbits >> 3;
        u32 off = b->nbits & 7;
        if (byte < b->cap) {
            if (off == 0) {
                b->buf[byte] = 0;
            }
            if ((value >> i) & 1u) {
                b->buf[byte] |= (u8)(1u << off);
            }
        }
        b->nbits++;
    }
}

static u32 encode_packed_naive(const struct sasm_insn *code, u32 count,
                               u8 *out, u32 max, u8 fmt)
{
    u32 n = put_header(out, max, fmt, count);
    if (!n) {
        return 0;
    }

    struct bitw b = { out + n, max - n, 0 };

    for (u32 i = 0; i < count; i++) {
        u32 imm = code[i].imm;

        bw_put(&b, code[i].op & 0xF, 4);
        bw_put(&b, code[i].mode & 0x7, 3);
        bw_put(&b, code[i].dst & 0x3, 2);
        bw_put(&b, code[i].src & 0x3, 2);
        bw_put(&b, imm ? 1u : 0u, 1);
        bw_put(&b, 0, 4);               /* the unused high nibble */
        if (imm) {
            bw_put(&b, imm, 32);
        }
    }

    u32 bytes = (b.nbits + 7) >> 3;
    if (n + bytes > max) {
        return 0;
    }
    return n + bytes;
}

/* --- Packed, the fast way: build the word and store it --------------------- */

/* Assemble the twelve-bit descriptor. The fields sit on fixed boundaries, so
 * this is four shifts and four ORs with no loop. */
static u32 pack_descriptor(const struct sasm_insn *insn)
{
    u32 imm = insn->imm;
    return ((u32)insn->op & 0xF)
         | (((u32)insn->mode & 0x7) << 4)
         | (((u32)insn->dst & 0x3) << 7)
         | (((u32)insn->src & 0x3) << 9)
         | (imm ? (1u << 11) : 0u);
}

static u32 encode_packed_fast(const struct sasm_insn *code, u32 count,
                              u8 *out, u32 max, u8 fmt)
{
    u32 n = put_header(out, max, fmt, count);
    if (!n) {
        return 0;
    }

    for (u32 i = 0; i < count; i++) {
        u32 d = pack_descriptor(&code[i]);
        u32 imm = code[i].imm;

        if (n + 2 > max) {
            return 0;
        }
        out[n++] = (u8)(d & 0xFF);
        out[n++] = (u8)((d >> 8) & 0xFF);

        if (imm) {
            if (n + 4 > max) {
                return 0;
            }
            out[n++] = (u8)(imm & 0xFF);
            out[n++] = (u8)((imm >> 8) & 0xFF);
            out[n++] = (u8)((imm >> 16) & 0xFF);
            out[n++] = (u8)((imm >> 24) & 0xFF);
        }
    }
    return n;
}

/* --- Encoding and decoding ------------------------------------------------- */

u32 codec_encode(const struct sasm_insn *code, u32 count, u8 *out, u32 max,
                 u8 fmt)
{
    if (!code || !out) {
        return 0;
    }
    if (fmt == CODEC_FMT_RAW) {
        return encode_raw(code, count, out, max, fmt);
    }
    return encode_packed_fast(code, count, out, max, fmt);
}

static u32 decode_raw(const u8 *in, u32 len, struct sasm_insn *code, u32 max,
                      u32 count)
{
    u32 n = 5;
    u32 got = 0;

    while (got < count && got < max) {
        if (n + CODEC_RAW_BYTES_PER_INSN > len) {
            return 0;
        }
        code[got].op = in[n];
        code[got].dst = in[n + 1];
        code[got].src = in[n + 2];
        code[got].mode = in[n + 3];
        code[got].imm = (u32)in[n + 4] | ((u32)in[n + 5] << 8)
                      | ((u32)in[n + 6] << 16) | ((u32)in[n + 7] << 24);
        n += CODEC_RAW_BYTES_PER_INSN;
        got++;
    }
    return got;
}

static u32 decode_packed(const u8 *in, u32 len, struct sasm_insn *code, u32 max,
                         u32 count)
{
    u32 n = 5;
    u32 got = 0;

    while (got < count && got < max) {
        if (n + 2 > len) {
            return 0;
        }
        u32 d = (u32)in[n] | ((u32)in[n + 1] << 8);
        n += 2;

        code[got].op = (u8)(d & 0xF);
        code[got].mode = (u8)((d >> 4) & 0x7);
        code[got].dst = (u8)((d >> 7) & 0x3);
        code[got].src = (u8)((d >> 9) & 0x3);

        if (d & (1u << 11)) {
            if (n + 4 > len) {
                return 0;
            }
            code[got].imm = (u32)in[n] | ((u32)in[n + 1] << 8)
                          | ((u32)in[n + 2] << 16) | ((u32)in[n + 3] << 24);
            n += 4;
        } else {
            code[got].imm = 0;
        }
        got++;
    }
    return got;
}

u32 codec_decode(const u8 *in, u32 len, struct sasm_insn *code, u32 max, u8 fmt)
{
    u8 hfmt;
    u32 count;

    if (!in || !code || !read_header(in, len, &hfmt, &count)) {
        return 0;
    }
    if (hfmt != fmt) {
        return 0;       /* the caller asked for a format this stream is not */
    }
    if (fmt == CODEC_FMT_RAW) {
        return decode_raw(in, len, code, max, count);
    }
    return decode_packed(in, len, code, max, count);
}

const char *codec_format_name(u8 fmt)
{
    return fmt == CODEC_FMT_RAW ? "raw" : "packed";
}

/* --- Reporting and optimisation -------------------------------------------- */

/* Encode the program both ways and compare the sizes. */
void codec_report(const struct sasm_program *prog)
{
    static u8 raw[CODEC_MAX_BYTES];
    static u8 packed[CODEC_MAX_BYTES];

    if (!prog || prog->count == 0) {
        klog("CODEC", "nothing to encode");
        return;
    }

    u32 nr = codec_encode(prog->code, prog->count, raw, sizeof(raw),
                          CODEC_FMT_RAW);
    u32 np = codec_encode(prog->code, prog->count, packed, sizeof(packed),
                          CODEC_FMT_PACKED);

    klog("CODEC", "program: %u instructions", prog->count);
    klog("CODEC", "raw: %u bytes, packed: %u bytes", nr, np);
    if (np) {
        /* Ratio with integer maths, as the other benchmarks do. */
        u32 r100 = (nr * 100u) / np;
        klog("CODEC", "packed is %u.%ux smaller", r100 / 100,
             (r100 % 100) / 10);
    }
}

int codec_opt(const struct sasm_program *prog)
{
    static u8 a[CODEC_MAX_BYTES];
    static u8 b[CODEC_MAX_BYTES];

    if (!prog || prog->count == 0) {
        return 0;
    }

    /* Enough repetitions that the clock reading is well above its own noise. */
    u32 reps = 200;

    u64 t0 = tsc_read();
    u32 na = 0;
    for (u32 r = 0; r < reps; r++) {
        na = encode_packed_naive(prog->code, prog->count, a, sizeof(a),
                                 CODEC_FMT_PACKED);
    }
    u64 t1 = tsc_read();

    u32 nb = 0;
    for (u32 r = 0; r < reps; r++) {
        nb = encode_packed_fast(prog->code, prog->count, b, sizeof(b),
                                CODEC_FMT_PACKED);
    }
    u64 t2 = tsc_read();

    /* Same length is necessary but not sufficient: compare the bytes, or the
     * speed means nothing. */
    int same = (na == nb && na > 0);
    if (same) {
        for (u32 i = 0; i < na; i++) {
            if (a[i] != b[i]) {
                same = 0;
                break;
            }
        }
    }

    u32 slow_c = (u32)((t1 - t0) / reps);
    u32 fast_c = (u32)((t2 - t1) / reps);

    klog("CODEC", "encode %u instructions: bitwise %u cycles, word %u cycles",
         prog->count, slow_c, fast_c);
    if (fast_c) {
        u64 x = slow_c, y = fast_c;
        while (x > 0xFFFFFFull || y > 0xFFFFFFull) {
            x >>= 1;
            y >>= 1;
        }
        u32 r100 = ((u32)x * 100u) / (u32)y;
        klog("CODEC", "the word encoder is %u.%ux faster, same bytes: %s",
             r100 / 100, (r100 % 100) / 10, same ? "yes" : "no");
    }
    return same;
}

int codec_selftest(void)
{
    static struct sasm_program prog;
    static struct sasm_insn back[SASM_MAX_CODE];
    static u8 buf[CODEC_MAX_BYTES];
    char err[SASM_ERROR_MAX];

    if (!sasm_assemble(sasm_example_source(), &prog, err, sizeof(err))
        || prog.count == 0) {
        return 0;
    }

    /* Every format must survive a round trip with the instructions intact. */
    for (u8 fmt = 0; fmt < CODEC_FMT_COUNT; fmt++) {
        u32 n = codec_encode(prog.code, prog.count, buf, sizeof(buf), fmt);
        if (n == 0) {
            return 0;
        }
        u32 got = codec_decode(buf, n, back, SASM_MAX_CODE, fmt);
        if (got != prog.count) {
            return 0;
        }
        for (u32 i = 0; i < got; i++) {
            if (back[i].op != prog.code[i].op
                || back[i].mode != prog.code[i].mode
                || back[i].dst != prog.code[i].dst
                || back[i].src != prog.code[i].src
                || back[i].imm != prog.code[i].imm) {
                return 0;
            }
        }
    }

    /* The packed form is the point of the exercise: it must actually be
     * smaller than the straight copy, or the format is not doing its job. */
    u32 nr = codec_encode(prog.code, prog.count, buf, sizeof(buf),
                          CODEC_FMT_RAW);
    u32 np = codec_encode(prog.code, prog.count, buf, sizeof(buf),
                          CODEC_FMT_PACKED);
    if (np == 0 || np >= nr) {
        return 0;
    }

    /* And the optimised encoder must agree with the obvious one. */
    return codec_opt(&prog);
}
