/* AI bridge implementation. See include/ai.h. */

#include "ai.h"
#include "actions.h"
#include "serial.h"
#include "string.h"
#include "timer.h"
#include "localai.h"
#include "know.h"
#include "outcome.h"
#include "pedant.h"

#define AI_MARK   '\x01'
#define AI_WAIT_MS 6000
#define AI_LINE_MAX 320

static int enabled = 0;

void ai_set_mode(int on) { enabled = on ? 1 : 0; }
int  ai_mode(void) { return enabled; }

/* Local answer path.
 *
 * Order matters, and it is the whole point of the local model:
 *
 *   1. ask the learned model; if it recognises the request, run that action
 *   2. otherwise fall back to the built-in keyword rules
 *   3. and train the model on whatever the rules chose, so the same request is
 *      recognised from the model next time
 *
 * So the machine teaches itself from its own rules, and every request it has
 * seen once becomes one it knows. Weights live in RAM and are persisted to the
 * .sidwa partition by `learn save`.
 */
/* Rules that map a request onto an action.
 *
 * Every matching rule is collected, not just the first, so the caller can choose
 * between them using the record of which methods have actually achieved results
 * (see outcome_best). The order here is the default priority and the tie-break,
 * so the list must stay most-specific first.
 */
#define RULE_MAX 6

u32 ai_rule_actions(const char *text, const char **out, u32 max);

static u32 keyword_actions(const char *text, const char **out, u32 max)
{
    u32 n = 0;

#define ADD(action)                                    \
    do {                                               \
        if (n < max) {                                 \
            out[n++] = (action);                       \
        }                                              \
    } while (0)

    if (strstr(text, "cache") || strstr(text, "l1")) {
        ADD("cache");
    }
    if (strstr(text, "run") || strstr(text, "cpu")) {
        ADD("run");
    }
    if (strstr(text, "hold") || strstr(text, "logic") || strstr(text, "test")) {
        ADD("hold");
    }
    if (strstr(text, "store") || strstr(text, "disk") || strstr(text, "save")) {
        ADD("store");
    }
    if (strstr(text, "status") || strstr(text, "state")) {
        ADD("status");
    }
    if (strstr(text, "cycle") || strstr(text, "all")) {
        ADD("cycle");
    }
    if (strstr(text, "bitflow") || strstr(text, "bit")) {
        ADD("bitflow");
    }
    if (strstr(text, "version") || strstr(text, "name")) {
        ADD("version");
    }
    if (strstr(text, "debug") || strstr(text, "fault")) {
        ADD("debug");
    }
    /* The programming method, checked before the general teaching words so
     * "teach me the method" lands on the ladder, not the C course list. */
    if (strstr(text, "method") || strstr(text, "pseudo")
        || strstr(text, "how do i write") || strstr(text, "where to start")) {
        ADD("method");
    }
    /* Reverse engineering, checked before the general teaching words so that
     * "teach me reverse engineering" lands on that course, not the C one. */
    if (strstr(text, "reverse") || strstr(text, "disassembl")
        || strstr(text, "assembly") || strstr(text, "asm")
        || strstr(text, "machine code") || strstr(text, "rev ")) {
        ADD("rev");
    }
    /* The optimisation course, checked before the general teaching words so
     * "teach me optimisation" lands on that course, not the C one. */
    if (strstr(text, "optimi") || strstr(text, "faster")
        || strstr(text, "slow") || strstr(text, "speed")
        || strstr(text, "benchmark")) {
        ADD("optim");
    }
    /* Teaching requests. These map onto the lesson commands, so a plain-language
     * "teach me C" or "show me hello world" lands on the course. */
    /* "hello" teaches the first program rather than opening the GUI: an AI
     * request should answer, not take over the screen. The CLI's own `hello`
     * verb does both. */
    if (strstr(text, "hello world") || strstr(text, "hello")) {
        ADD("lesson 2");
    }
    if (strstr(text, "lesson") || strstr(text, "teach")
        || strstr(text, "learn c") || strstr(text, "course")) {
        ADD("lesson");
    }
    if (strstr(text, "gui") || strstr(text, "window")) {
        ADD("gui");
    }
    /* Fetch-and-learn, before the general teaching words so "fetch and learn
     * from a page" lands on the fetch flow, not the C course. */
    if (strstr(text, "fetch") || strstr(text, "download")
        || strstr(text, "web page") || strstr(text, "learn from")) {
        ADD("fetch");
    }
#undef ADD

    return n;
}

/* The built-in rules, exposed so the thinking algorithm can weigh them against
 * the model and the machine's record instead of treating them as the only
 * truth. The order is the priority, most specific first. */
u32 ai_rule_actions(const char *text, const char **out, u32 max)
{
    return keyword_actions(text, out, max);
}

static void ai_local_answer(const char *text)
{
    const char *rules[RULE_MAX];
    u32 rule_count = keyword_actions(text, rules, RULE_MAX);
    const char *model = localai_predict(text);

    /* The rules are ground truth for the vocabulary they cover; the model is the
     * fast path that generalises beyond them. So the model answers when it agrees
     * with the rules or when the rules are silent, and is corrected when it
     * disagrees. Without this the model can be confidently wrong at a coarse
     * grade and never be fixed, because a confident answer skips learning. */
    if (model) {
        int known = 0;
        for (u32 i = 0; i < rule_count; i++) {
            if (strcmp(rules[i], model) == 0) {
                known = 1;
                break;
            }
        }
        if (rule_count == 0 || known) {
            if (actions_dispatch(model, 0) != ACTION_UNKNOWN) {
                outcome_record(model, 1);
                localai_train(text, model);
                klog("AI", "local model chose '%s'", model);
                return;
            }
        }
    }

    if (rule_count == 0) {
        klog("AI", "no action matched and the model has not learned one");
        return;
    }

    /* Several rules can match one request. Pick the method with the best record
     * of achieved results, falling back to rule order when none has a history.
     * This is how the machine learns from what worked: an action that has
     * produced results before is preferred over one that has not. */
    const char *rule = rule_count == 1
        ? rules[0]
        : outcome_best(rules, rule_count);

    if (model && strcmp(model, rule) != 0) {
        klog("AI", "model guessed '%s', correcting to '%s'", model, rule);
    }

    if (actions_dispatch(rule, 0) == ACTION_UNKNOWN) {
        outcome_record(rule, 0);
        klog("AI", "no action matched");
        return;
    }
    outcome_record(rule, 1);
    localai_train(text, rule);
    klog("AI", "ran and learned '%s'", rule);
}

/* Collect one host line. Returns length, or -1 on timeout. */
static int read_host_line(char *buf, u32 max)
{
    u32 waited = 0;
    u32 n = 0;

    while (!serial_rx_ready()) {
        if (waited >= AI_WAIT_MS) {
            return -1;
        }
        timer_sleep_ms(5);
        waited += 5;
    }

    for (;;) {
        while (serial_rx_ready()) {
            char c = (char)serial_getc();
            if (c == '\n' || c == '\r') {
                buf[n] = '\0';
                return (int)n;
            }
            if (n + 1 < max) {
                buf[n++] = c;
            }
        }
        /* After the first byte, allow a short gap for the rest of the line. */
        u32 idle = 0;
        while (!serial_rx_ready() && idle < 400) {
            timer_sleep_ms(2);
            idle += 2;
        }
        if (!serial_rx_ready() && idle >= 400) {
            buf[n] = '\0';
            return (int)n;
        }
    }
}

/* Split "command arg" into the action name and the rest. */
static void split_action(char *s, char **cmd, char **arg)
{
    while (*s == ' ') {
        s++;
    }
    *cmd = s;
    while (*s && *s != ' ') {
        s++;
    }
    if (*s) {
        *s++ = '\0';
        while (*s == ' ') {
            s++;
        }
    }
    *arg = s;
}

static void ai_remote(const char *text)
{
    char buf[AI_LINE_MAX];
    int acted = 0;

    serial_putc(AI_MARK);
    serial_puts("AI ");
    serial_puts(text);
    serial_putc('\n');

    for (;;) {
        int len = read_host_line(buf, sizeof(buf));
        if (len < 0) {
            if (!acted) {
                klog("AI", "agent timeout");
                ai_local_answer(text);
            }
            return;
        }
        if (len == 0) {
            continue;
        }

        if (buf[0] != AI_MARK) {
            klog("AI", "%s", buf);       /* agent prose */
            continue;
        }

        char *p = buf + 1;
        if (strncmp(p, "ACT ", 4) == 0) {
            char *cmd, *arg;
            split_action(p + 4, &cmd, &arg);
            if (actions_dispatch(cmd, arg) == ACTION_UNKNOWN) {
                klog("AI", "agent asked for unknown action: %s", cmd);
            } else {
                acted = 1;
            }
        } else if (strncmp(p, "SAY ", 4) == 0) {
            klog("AI", "%s", p + 4);
        } else if (strcmp(p, "END") == 0) {
            if (!acted) {
                ai_local_answer(text);
            }
            return;
        }
    }
}

void ai_ask(const char *text)
{
    if (!text || !*text) {
        return;
    }
    if (enabled) {
        ai_remote(text);
    } else {
        ai_local_answer(text);
    }
}

/* Bounded copy into the caller's buffer. */
static void copy_str_out(char *dst, u32 max, const char *src)
{
    u32 i = 0;
    for (; src && src[i] && i + 1 < max; i++) {
        dst[i] = src[i];
    }
    dst[i] = '\0';
}

/* Ask the host agent for a fact. Returns the answer length, or -1 if the host
 * did not answer with one. */
static int ai_remote_lookup(const char *query, char *out, u32 max)
{
    char buf[AI_LINE_MAX];
    int got = -1;

    serial_putc(AI_MARK);
    serial_puts("LOOKUP ");
    serial_puts(query);
    serial_putc('\n');

    for (;;) {
        int len = read_host_line(buf, sizeof(buf));
        if (len < 0) {
            return got;             /* timeout: keep whatever we got */
        }
        if (len == 0) {
            continue;
        }
        if (buf[0] != AI_MARK) {
            klog("AI", "%s", buf);
            continue;
        }

        char *p = buf + 1;
        if (strncmp(p, "KNOW ", 5) == 0) {
            u32 n = 0;
            for (const char *s = p + 5; *s && n + 1 < max; s++) {
                out[n++] = *s;
            }
            out[n] = '\0';
            got = (int)n;
        } else if (strcmp(p, "NONE") == 0) {
            return -1;
        } else if (strcmp(p, "END") == 0) {
            return got;
        }
    }
}

int ai_lookup(const char *query, char *out, u32 max)
{
    if (!query || !*query || !out || max == 0) {
        return -1;
    }

    /* Tiers 1 and 2: RAM, then the .sidwa partition. */
    int n = know_recall(query, out, max);
    if (n >= 0) {
        klog("KNOW", "served from cache: %s", query);
        /* Answered, so any gap recorded for this question is now closed. */
        pedant_resolve(query);
        return n;
    }

    /* Tier 3: the host agent, which may search the web. Only when the bridge is
     * on; with nothing attached the machine answers from what it knows. */
    if (!enabled) {
        klog("KNOW", "no local copy of '%s' and the bridge is off", query);
        pedant_note(query);
        return -1;
    }

    char fetched[KNOW_VALUE_MAX];
    n = ai_remote_lookup(query, fetched, sizeof(fetched));
    if (n < 0) {
        klog("KNOW", "no answer for '%s' from any tier", query);
        /* The one place a real gap is found: the machine tried every tier and
         * still has nothing. Recording it here is what turns a silent miss into
         * a work item the host tool can pick up and teach. */
        pedant_note(query);
        return -1;
    }

    /* An answer from outside is not knowledge yet. It is held in RAM only, and
     * reaches the disk only if an earlier answer agrees with it -- a single
     * unconfirmed reply, right or wrong, must not become durable. */
    char held[KNOW_VALUE_MAX];
    if (know_peek_ram(query, held, sizeof(held)) >= 0
        && strcmp(held, fetched) == 0) {
        know_verify(query);
        klog("KNOW", "corroborated '%s' and stored it on .sidwa", query);
        /* Only now is the gap really closed. Resolving it on the unverified
         * path would drop the work item while the fact lived in RAM alone, so
         * a reboot before corroboration would lose the answer and the record
         * that it was ever missing. */
        pedant_resolve(query);
    } else {
        know_remember(query, fetched);
        klog("KNOW", "held '%s' in RAM, unverified (ask again to confirm)",
             query);
    }

    copy_str_out(out, max, fetched);
    return (int)strlen(out);
}
