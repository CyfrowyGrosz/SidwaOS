/* Fetch a page and learn from it. See include/fetch.h.
 *
 * Three steps, and only the first needs the network:
 *
 *   clean      HTML to plain text: drop tags and the blocks whose contents are
 *              code, decode the entities a page actually uses, collapse space
 *   extract    split the text into sentences and score each against the words
 *              of the question
 *   learn      offer the winner to the knowledge cache
 *
 * The cleaner is deliberately small and rule-based. A real browser needs a
 * parser, a document tree and a CSS cascade; none of that is here, and for
 * pulling a sentence out of a page it is not needed. What matters is that the
 * output is plain text with the markup gone, because everything downstream
 * scores sentences and markup would score as words.
 *
 * The extractor is a bag-of-words comparison. It counts how many distinct words
 * of the question appear in each sentence and picks the highest, preferring
 * earlier sentences on a tie so the answer is stable. That is enough to answer
 * "what is X" from a page whose first paragraph defines X, which is the shape of
 * most reference pages, and it makes no attempt at anything harder.
 */

#include "fetch.h"
#include "net.h"
#include "know.h"
#include "serial.h"
#include "string.h"

/* --- Counters -------------------------------------------------------------- */

static u32 pages;
static u32 bytes;
static u32 learned;
static u32 corroborated;
static char last_answer[FETCH_ANSWER_MAX];

u32 fetch_pages(void) { return pages; }
u32 fetch_bytes(void) { return bytes; }
u32 fetch_learned(void) { return learned; }
u32 fetch_corroborated(void) { return corroborated; }

/* --- HTML cleaning --------------------------------------------------------- */

/* The entities worth handling: the ones that actually appear in prose. Anything
 * else is left as written rather than guessed at. */
static char entity_char(const char *name, u32 len)
{
    struct { const char *name; u32 len; char c; } table[] = {
        { "amp", 3, '&' },  { "lt", 2, '<' },   { "gt", 2, '>' },
        { "quot", 4, '"' }, { "apos", 4, '\'' },{ "nbsp", 4, ' ' },
        { "mdash", 5, '-' },{ "ndash", 5, '-' },
    };

    for (u32 i = 0; i < sizeof(table) / sizeof(table[0]); i++) {
        if (table[i].len == len && strncmp(name, table[i].name, len) == 0) {
            return table[i].c;
        }
    }
    return 0;
}

/* Copy the entity at `p` ("&...;") to `out`, advancing *used by its length.
 * Returns 1 when it was an entity and was consumed. */
static int decode_entity(const char *p, char *out, u32 *used)
{
    const char *semi = 0;
    for (const char *q = p + 1; *q && q < p + 12; q++) {
        if (*q == ';') {
            semi = q;
            break;
        }
    }
    if (!semi) {
        return 0;
    }

    u32 len = (u32)(semi - (p + 1));
    if (len == 0) {
        return 0;
    }

    /* Numeric form, decimal or hex. */
    if (p[1] == '#') {
        u32 value = 0;
        const char *d = p + 2;
        int hex = (*d == 'x' || *d == 'X');
        if (hex) {
            d++;
        }
        for (; d < semi; d++) {
            u32 digit;
            if (*d >= '0' && *d <= '9') {
                digit = (u32)(*d - '0');
            } else if (hex && *d >= 'a' && *d <= 'f') {
                digit = (u32)(*d - 'a' + 10);
            } else if (hex && *d >= 'A' && *d <= 'F') {
                digit = (u32)(*d - 'A' + 10);
            } else {
                return 0;
            }
            value = value * (hex ? 16u : 10u) + digit;
        }
        *out = value < 128 ? (char)value : ' ';
        *used = len + 2;
        return 1;
    }

    char c = entity_char(p + 1, len);
    if (!c) {
        return 0;
    }
    *out = c;
    *used = len + 2;
    return 1;
}

/* Case-insensitive test for whether the tag starting at `p` (just past '<') is
 * `name`. Used to spot script/style so their contents can be skipped. */
static int tag_is(const char *p, const char *name)
{
    u32 n = 0;
    while (name[n] && p[n]
           && (p[n] == name[n]
               || (p[n] >= 'A' && p[n] <= 'Z' && p[n] + 32 == name[n]))) {
        n++;
    }
    if (name[n]) {
        return 0;
    }
    char after = p[n];
    return after == '>' || after == ' ' || after == '\t' || after == '\n';
}

/* Skip to just past "</name>". Returns the position after it, or the end of the
 * string when the close tag is missing. */
static const char *skip_block(const char *p, const char *name)
{
    u32 nl = strlen(name);

    for (const char *q = p; *q; q++) {
        if (*q != '<' || q[1] != '/') {
            continue;
        }
        u32 i = 0;
        while (i < nl && q[2 + i]
               && (q[2 + i] == name[i]
                   || (q[2 + i] >= 'A' && q[2 + i] <= 'Z'
                       && q[2 + i] + 32 == name[i]))) {
            i++;
        }
        if (i == nl && q[2 + nl] == '>') {
            return q + 2 + nl + 1;
        }
    }
    return 0;
}

u32 fetch_clean(const char *html, char *out, u32 max)
{
    if (!html || !out || max < 2) {
        return 0;
    }

    u32 n = 0;
    int in_tag = 0;
    int last_space = 1;     /* leading space is dropped */

    for (const char *p = html; *p; p++) {
        if (in_tag) {
            if (*p == '>') {
                in_tag = 0;
            }
            continue;
        }

        if (*p == '<') {
            /* A block whose contents are code, not prose. */
            if (tag_is(p + 1, "script")) {
                const char *after = skip_block(p, "script");
                if (!after) {
                    break;
                }
                p = after - 1;
                continue;
            }
            if (tag_is(p + 1, "style")) {
                const char *after = skip_block(p, "style");
                if (!after) {
                    break;
                }
                p = after - 1;
                continue;
            }
            in_tag = 1;
            /* A tag is a word boundary, so it becomes one space. */
            if (!last_space && n + 1 < max) {
                out[n++] = ' ';
                last_space = 1;
            }
            continue;
        }

        if (*p == '&') {
            char c;
            u32 used = 0;
            if (decode_entity(p, &c, &used) && n + 1 < max) {
                if (c == ' ') {
                    if (!last_space) {
                        out[n++] = ' ';
                        last_space = 1;
                    }
                } else {
                    out[n++] = c;
                    last_space = 0;
                }
                p += used - 1;
                continue;
            }
            /* Not an entity we know: keep the character as written. */
        }

        char c = *p;
        if (c == '\n' || c == '\r' || c == '\t' || c == ' ') {
            if (!last_space && n + 1 < max) {
                out[n++] = ' ';
                last_space = 1;
            }
            continue;
        }
        if (n + 1 < max) {
            out[n++] = c;
            last_space = 0;
        }
    }

    out[n] = '\0';
    return n;
}

/* --- Sentence extraction --------------------------------------------------- */

/* Lower-case a word into `out`, keeping letters and digits, up to `max`. Returns
 * the length. Used so "World" and "world" compare equal. */
static u32 fold_word(const char *s, u32 len, char *out, u32 max)
{
    u32 n = 0;
    for (u32 i = 0; i < len && n + 1 < max; i++) {
        char c = s[i];
        if (c >= 'A' && c <= 'Z') {
            c = (char)(c + 32);
        }
        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
            out[n++] = c;
        }
    }
    out[n] = '\0';
    return n;
}

/* True when `word` appears as a whole word in `sentence`. */
static int contains_word(const char *sentence, const char *word, u32 wlen)
{
    if (wlen == 0) {
        return 0;
    }

    for (const char *p = sentence; *p; p++) {
        /* Only start a match on a word boundary. */
        if (p != sentence) {
            char prev = p[-1];
            if ((prev >= 'a' && prev <= 'z') || (prev >= '0' && prev <= '9')) {
                continue;
            }
        }
        u32 i = 0;
        while (i < wlen && p[i]) {
            char c = p[i];
            if (c >= 'A' && c <= 'Z') {
                c = (char)(c + 32);
            }
            if (c != word[i]) {
                break;
            }
            i++;
        }
        if (i == wlen) {
            /* The match must end on a boundary too. */
            char after = p[wlen];
            if (!((after >= 'a' && after <= 'z')
                  || (after >= '0' && after <= '9'))) {
                return 1;
            }
        }
    }
    return 0;
}

u32 fetch_extract(const char *text, const char *question, char *out, u32 max)
{
    if (!text || !question || !out || max < 2) {
        return 0;
    }

    u32 best_score = 0;
    u32 best_len = 0;
    const char *best = 0;

    /* Walk the text sentence by sentence. A sentence ends at '.', '!' or '?',
     * or at a blank line. */
    const char *start = text;
    for (const char *p = text; ; p++) {
        int end = (*p == '\0');
        int stop = (*p == '.' || *p == '!' || *p == '?');

        if (!end && !stop) {
            continue;
        }

        u32 len = (u32)(p - start);
        if (len > 0) {
            /* Score: how many distinct question words this sentence contains. */
            u32 score = 0;
            const char *q = question;
            while (*q) {
                while (*q && !((*q >= 'a' && *q <= 'z')
                               || (*q >= 'A' && *q <= 'Z')
                               || (*q >= '0' && *q <= '9'))) {
                    q++;
                }
                const char *ws = q;
                while (*q && ((*q >= 'a' && *q <= 'z')
                              || (*q >= 'A' && *q <= 'Z')
                              || (*q >= '0' && *q <= '9'))) {
                    q++;
                }
                u32 wl = (u32)(q - ws);
                if (wl == 0) {
                    continue;
                }

                char word[32];
                u32 fn = fold_word(ws, wl, word, sizeof(word));

                /* Skip very short words: they match everything. */
                if (fn >= 3 && contains_word(start, word, fn)) {
                    score++;
                }
            }

            if (score > best_score) {
                best_score = score;
                best = start;
                best_len = len;
            }
        }

        if (end) {
            break;
        }
        start = p + 1;
    }

    if (!best || best_score == 0) {
        return 0;
    }

    /* Trim leading and trailing spaces. */
    while (best_len > 0 && (*best == ' ')) {
        best++;
        best_len--;
    }
    while (best_len > 0 && (best[best_len - 1] == ' ')) {
        best_len--;
    }
    if (best_len == 0) {
        return 0;
    }

    u32 n = best_len < max - 1 ? best_len : max - 1;
    for (u32 i = 0; i < n; i++) {
        out[i] = best[i];
    }
    out[n] = '\0';
    return n;
}

/* --- Fetching and learning ------------------------------------------------- */

/* Body buffer is static because the kernel stack is small and a page is large.
 * Everything in this module is single-threaded and polled, so one buffer is
 * enough and it never has to be freed. */
static char page_body[FETCH_TEXT_MAX * 2];
static char page_text[FETCH_TEXT_MAX];

int fetch_text(const char *url, char *out, u32 max)
{
    if (!url || !out) {
        return -1;
    }

    int len = net_http_get(url, page_body, sizeof(page_body), 0, 0);
    if (len <= 0) {
        return -1;
    }

    u32 n = fetch_clean(page_body, page_text, sizeof(page_text));
    pages++;
    bytes += n;

    u32 copy = n < max - 1 ? n : max - 1;
    for (u32 i = 0; i < copy; i++) {
        out[i] = page_text[i];
    }
    out[copy] = '\0';
    return (int)copy;
}

int fetch_learn(const char *url, const char *question, char *answer,
                u32 answer_max)
{
    if (!url || !question || !answer) {
        return -1;
    }

    if (fetch_text(url, page_text, sizeof(page_text)) < 0) {
        klog("FETCH", "could not fetch %s", url);
        return -1;
    }

    u32 n = fetch_extract(page_text, question, answer, answer_max);
    if (n == 0) {
        klog("FETCH", "no sentence in %s answers '%s'", url, question);
        return -1;
    }

    /* Held in RAM as unverified. One page cannot corroborate itself, so this
     * does not reach the partition. */
    know_remember(question, answer);
    learned++;

    for (u32 i = 0; i < n && i + 1 < sizeof(last_answer); i++) {
        last_answer[i] = answer[i];
    }
    last_answer[n < sizeof(last_answer) ? n : sizeof(last_answer) - 1] = '\0';

    klog("FETCH", "learned from %s (%u bytes of text)", url, bytes);
    return (int)n;
}

/* Whether two extracted answers corroborate each other. Compared folded, so
 * case and punctuation do not decide whether the machine believes something,
 * and only when both are non-empty: agreement on nothing is not agreement.
 * Network-free, so the selftest can check both outcomes directly. */
int fetch_answers_agree(const char *a, u32 alen, const char *b, u32 blen)
{
    char fa[FETCH_ANSWER_MAX];
    char fb[FETCH_ANSWER_MAX];

    u32 la = fold_word(a, alen, fa, sizeof(fa));
    u32 lb = fold_word(b, blen, fb, sizeof(fb));

    return la > 0 && la == lb && strcmp(fa, fb) == 0;
}

int fetch_corroborate(const char *url_a, const char *url_b,
                      const char *question, char *answer, u32 answer_max)
{
    static char first[FETCH_ANSWER_MAX];
    static char second[FETCH_ANSWER_MAX];

    if (!url_a || !url_b || !question || !answer) {
        return -1;
    }

    if (fetch_text(url_a, page_text, sizeof(page_text)) < 0) {
        klog("FETCH", "could not fetch the first source");
        return -1;
    }
    u32 na = fetch_extract(page_text, question, first, sizeof(first));
    if (na == 0) {
        klog("FETCH", "the first source says nothing about '%s'", question);
        return -1;
    }

    if (fetch_text(url_b, page_text, sizeof(page_text)) < 0) {
        klog("FETCH", "could not fetch the second source");
        return -1;
    }
    u32 nb = fetch_extract(page_text, question, second, sizeof(second));
    if (nb == 0) {
        klog("FETCH", "the second source says nothing about '%s'", question);
        return -1;
    }

    /* Two sources agreeing is corroboration. */
    if (!fetch_answers_agree(first, na, second, nb)) {
        /* Disagreement: keep the first answer, but unverified. The machine has
         * not earned the right to write either one down. */
        know_remember(question, first);
        learned++;
        klog("FETCH", "the two sources disagree; '%s' stays unverified",
             question);
        return 0;
    }

    know_remember(question, first);
    learned++;
    if (!know_verify(question)) {
        return 0;
    }
    corroborated++;

    u32 n = na < answer_max - 1 ? na : answer_max - 1;
    for (u32 i = 0; i < n; i++) {
        answer[i] = first[i];
    }
    answer[n] = '\0';

    klog("FETCH", "both sources agree; '%s' verified and stored on .sidwa",
         question);
    return 1;
}

/* --- Reporting and selftest ------------------------------------------------ */

void fetch_report(void)
{
    klog("FETCH", "pages=%u bytes=%u learned=%u corroborated=%u",
         pages, bytes, learned, corroborated);
    if (last_answer[0]) {
        klog("FETCH", "last answer: %s", last_answer);
    }
}

int fetch_selftest(void)
{
    char text[FETCH_TEXT_MAX];
    char answer[FETCH_ANSWER_MAX];

    /* Cleaning must remove markup, drop script contents, and decode entities. */
    const char *html =
        "<html><head><title>T</title>"
        "<script>var x = 'not prose';</script>"
        "<style>body { color: red; }</style></head>"
        "<body><p>The RTL8139 is a network card made by Realtek &amp; "
        "friends.</p><p>Other text.</p></body></html>";

    u32 n = fetch_clean(html, text, sizeof(text));
    if (n == 0) {
        return 0;
    }
    if (strstr(text, "<") || strstr(text, ">")) {
        return 0;                       /* a tag survived */
    }
    if (strstr(text, "not prose") || strstr(text, "color: red")) {
        return 0;                       /* script or style content survived */
    }
    if (!strstr(text, "Realtek & friends")) {
        return 0;                       /* the entity was not decoded */
    }

    /* Extraction must find the sentence that answers the question, and not the
     * one that merely shares a word. */
    n = fetch_extract(text, "what is the RTL8139 network card",
                      answer, sizeof(answer));
    if (n == 0 || !strstr(answer, "network card")) {
        return 0;
    }
    if (strstr(answer, "Other text")) {
        return 0;
    }

    /* A question whose words appear nowhere must yield nothing, rather than a
     * random sentence. */
    if (fetch_extract(text, "quantum chromodynamics", answer,
                      sizeof(answer)) != 0) {
        return 0;
    }

    /* Extraction must be case-insensitive. */
    if (fetch_extract(text, "REALTEK", answer, sizeof(answer)) == 0) {
        return 0;
    }

    /* A single page must never count as corroboration, so holding a fact in
     * RAM must not persist it. This is the module's whole contract with the
     * knowledge cache, checked directly: remember a test fact, confirm nothing
     * became verified, then take it back. */
    {
        u32 verified_before = know_verified_count();
        know_remember("selftest: one page is not corroboration",
                      "held in RAM only");
        if (know_verified_count() != verified_before) {
            return 0;                   /* a lone page reached the disk */
        }
        know_forget("selftest: one page is not corroboration");
    }

    /* Corroboration must turn on the answers, not on their spelling. Two
     * sources that say the same thing in different case agree; two that say
     * different things do not, and that is the case that protects the disk. */
    if (!fetch_answers_agree("The Domain Is Example", 20,
                             "the domain is example", 20)) {
        return 0;                       /* same answer, different case */
    }
    if (fetch_answers_agree("The domain is example", 20,
                            "an entirely different sentence", 29)) {
        return 0;                       /* disagreement must not corroborate */
    }
    if (fetch_answers_agree("", 0, "", 0)) {
        return 0;                       /* agreeing on nothing is not agreeing */
    }

    return 1;
}
