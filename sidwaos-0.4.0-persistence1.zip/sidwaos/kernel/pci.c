/* Minimal PCI configuration-space access. See include/pci.h.
 *
 * Configuration space is reached through the 0xCF8/0xCFC pair. A write to 0xCF8
 * selects a device and register; a read or write of 0xCFC then moves the data.
 * The enable bit (0x80000000) must be set in the address word or the access is
 * ignored.
 */

#include "pci.h"
#include "io.h"
#include "serial.h"

#define PCI_CONFIG_ADDR 0xCF8
#define PCI_CONFIG_DATA 0xCFC

#define PCI_ADDR_ENABLE 0x80000000u

static u32 config_address(u8 bus, u8 slot, u8 func, u8 offset)
{
    return PCI_ADDR_ENABLE
         | ((u32)bus << 16)
         | ((u32)slot << 11)
         | ((u32)func << 8)
         | (offset & 0xFC);
}

u32 pci_read_config(u8 bus, u8 slot, u8 func, u8 offset)
{
    outl(PCI_CONFIG_ADDR, config_address(bus, slot, func, offset));
    return inl(PCI_CONFIG_DATA);
}

void pci_write_config(u8 bus, u8 slot, u8 func, u8 offset, u32 value)
{
    outl(PCI_CONFIG_ADDR, config_address(bus, slot, func, offset));
    outl(PCI_CONFIG_DATA, value);
}

/* Read one device's identity and BARs. Returns 0 when nothing is there. */
static int read_device(u8 bus, u8 slot, u8 func, struct pci_device *d)
{
    u32 id = pci_read_config(bus, slot, func, 0x00);
    u16 vendor = (u16)(id & 0xFFFF);
    if (vendor == PCI_VENDOR_INVALID) {
        return 0;
    }

    d->bus = bus;
    d->slot = slot;
    d->func = func;
    d->vendor = vendor;
    d->device = (u16)(id >> 16);

    u32 classreg = pci_read_config(bus, slot, func, 0x08);
    d->class_code = (u8)(classreg >> 24);
    d->subclass = (u8)(classreg >> 16);
    d->prog_if = (u8)(classreg >> 8);

    /* The interrupt line is in the low byte of register 0x3C. The kernel polls,
     * so this is reported but not used to install a handler. */
    u32 irqreg = pci_read_config(bus, slot, func, 0x3C);
    d->irq = (u8)(irqreg & 0xFF);

    for (u32 i = 0; i < 6; i++) {
        d->bar[i] = pci_read_config(bus, slot, func, (u8)(0x10 + i * 4));
    }
    return 1;
}

int pci_find_device(u16 vendor, u16 device, struct pci_device *out)
{
    for (u32 bus = 0; bus < 256; bus++) {
        for (u32 slot = 0; slot < 32; slot++) {
            struct pci_device d;
            if (!read_device((u8)bus, (u8)slot, 0, &d)) {
                continue;
            }
            if (d.vendor == vendor && d.device == device) {
                *out = d;
                return 1;
            }

            /* A multi-function device has bit 7 of the header type set. Walk
             * the other functions too, so a NIC on function 1 is not missed. */
            u32 header = pci_read_config((u8)bus, (u8)slot, 0, 0x0C);
            if (header & 0x00800000) {
                for (u32 func = 1; func < 8; func++) {
                    struct pci_device f;
                    if (!read_device((u8)bus, (u8)slot, (u8)func, &f)) {
                        continue;
                    }
                    if (f.vendor == vendor && f.device == device) {
                        *out = f;
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

int pci_find_class(u8 class_code, u8 subclass, struct pci_device *out)
{
    for (u32 bus = 0; bus < 256; bus++) {
        for (u32 slot = 0; slot < 32; slot++) {
            struct pci_device d;
            if (!read_device((u8)bus, (u8)slot, 0, &d)) {
                continue;
            }
            if (d.class_code == class_code && d.subclass == subclass) {
                *out = d;
                return 1;
            }
        }
    }
    return 0;
}

void pci_list(void)
{
    u32 found = 0;
    for (u32 bus = 0; bus < 256; bus++) {
        for (u32 slot = 0; slot < 32; slot++) {
            for (u32 func = 0; func < 8; func++) {
                struct pci_device d;
                if (!read_device((u8)bus, (u8)slot, (u8)func, &d)) {
                    continue;
                }
                if (func == 0) {
                    found++;
                    klog("PCI", "%x:%x.%x vendor %x device %x class %x:%x",
                         d.bus, d.slot, d.func, d.vendor, d.device,
                         d.class_code, d.subclass);
                }
                if (func == 0) {
                    u32 header = pci_read_config((u8)bus, (u8)slot, 0, 0x0C);
                    if (!(header & 0x00800000)) {
                        break;      /* single-function device */
                    }
                }
            }
        }
    }
    klog("PCI", "%u device(s) on the bus", found);
}

int pci_bar_is_mmio(u32 bar)
{
    return (bar & 0x1) == 0;
}

u32 pci_bar_addr(u32 bar)
{
    /* Mask off the low flag bits: 4 for memory BARs, 2 for I/O BARs. */
    if (pci_bar_is_mmio(bar)) {
        return bar & 0xFFFFFFF0u;
    }
    return bar & 0xFFFFFFFCu;
}
