/* VGA text-mode console. See include/vga.h.
 *
 * Cells are written straight into the 0xB8000 window, which is ordinary
 * memory-mapped RAM as far as the CPU is concerned, so no I/O ports are needed
 * beyond moving the hardware cursor.
 *
 * The hardware cursor position is the only piece of state kept here; every other
 * call takes explicit coordinates. The GUI draws itself from its model on each
 * repaint, so there is no retained screen buffer to keep in sync.
 */

#include "vga.h"
#include "io.h"
#include "types.h"
#include <stdarg.h>

#define VGA_CRTC_INDEX 0x3D4
#define VGA_CRTC_DATA  0x3D5

static volatile u16 *const cells = (volatile u16 *)VGA_BASE;
static u8 attr = VGA_ATTR(VGA_LIGHTGRAY, VGA_BLACK);
static u32 cur_x;
static u32 cur_y;

static u16 cell(u8 c, u8 a)
{
    return (u16)c | ((u16)a << 8);
}

static void cursor_update(void)
{
    u16 pos = (u16)(cur_y * VGA_COLS + cur_x);

    outb(VGA_CRTC_INDEX, 0x0F);
    outb(VGA_CRTC_DATA, (u8)(pos & 0xFF));
    outb(VGA_CRTC_INDEX, 0x0E);
    outb(VGA_CRTC_DATA, (u8)(pos >> 8));
}

void vga_init(void)
{
    cur_x = 0;
    cur_y = 0;
    vga_clear(attr);
    cursor_update();
}

void vga_set_attr(u8 a) { attr = a; }

void vga_clear(u8 a)
{
    for (u32 i = 0; i < VGA_COLS * VGA_ROWS; i++) {
        cells[i] = cell(' ', a);
    }
    cur_x = 0;
    cur_y = 0;
    cursor_update();
}

void vga_putc_at(u32 x, u32 y, char c, u8 a)
{
    if (x >= VGA_COLS || y >= VGA_ROWS) {
        return;
    }
    cells[y * VGA_COLS + x] = cell((u8)c, a);
}

void vga_puts_at(u32 x, u32 y, const char *s, u8 a)
{
    for (u32 i = 0; s[i]; i++) {
        if (x + i >= VGA_COLS) {
            break;
        }
        vga_putc_at(x + i, y, s[i], a);
    }
}

void vga_puts_clipped(u32 x, u32 y, u32 w, const char *s, u8 a)
{
    u32 i = 0;

    for (; s[i] && i < w; i++) {
        vga_putc_at(x + i, y, s[i], a);
    }
    for (; i < w; i++) {
        vga_putc_at(x + i, y, ' ', a);
    }
}

void vga_fill(u32 x, u32 y, u32 w, u32 h, u8 a)
{
    for (u32 r = 0; r < h; r++) {
        for (u32 c = 0; c < w; c++) {
            vga_putc_at(x + c, y + r, ' ', a);
        }
    }
}

void vga_box(u32 x, u32 y, u32 w, u32 h, u8 a)
{
    if (w < 2 || h < 2) {
        return;
    }

    vga_putc_at(x, y, '+', a);
    vga_putc_at(x + w - 1, y, '+', a);
    vga_putc_at(x, y + h - 1, '+', a);
    vga_putc_at(x + w - 1, y + h - 1, '+', a);

    for (u32 i = 1; i + 1 < w; i++) {
        vga_putc_at(x + i, y, '-', a);
        vga_putc_at(x + i, y + h - 1, '-', a);
    }
    for (u32 i = 1; i + 1 < h; i++) {
        vga_putc_at(x, y + i, '|', a);
        vga_putc_at(x + w - 1, y + i, '|', a);
    }
}

void vga_gotoxy(u32 x, u32 y)
{
    cur_x = x < VGA_COLS ? x : VGA_COLS - 1;
    cur_y = y < VGA_ROWS ? y : VGA_ROWS - 1;
    cursor_update();
}

static void scroll(void)
{
    for (u32 r = 1; r < VGA_ROWS; r++) {
        for (u32 c = 0; c < VGA_COLS; c++) {
            cells[(r - 1) * VGA_COLS + c] = cells[r * VGA_COLS + c];
        }
    }
    for (u32 c = 0; c < VGA_COLS; c++) {
        cells[(VGA_ROWS - 1) * VGA_COLS + c] = cell(' ', attr);
    }
    cur_y = VGA_ROWS - 1;
}

void vga_putc(char c)
{
    if (c == '\n') {
        cur_x = 0;
        cur_y++;
    } else if (c == '\r') {
        cur_x = 0;
    } else if (c == '\t') {
        cur_x = (cur_x + 4) & ~3u;
    } else {
        vga_putc_at(cur_x, cur_y, c, attr);
        cur_x++;
    }

    if (cur_x >= VGA_COLS) {
        cur_x = 0;
        cur_y++;
    }
    if (cur_y >= VGA_ROWS) {
        scroll();
    }
    cursor_update();
}

void vga_puts(const char *s)
{
    for (; *s; s++) {
        vga_putc(*s);
    }
}

static void put_uint(u32 value, u32 base, int pad, char padc)
{
    char buf[32];
    int n = 0;

    if (value == 0) {
        buf[n++] = '0';
    }
    while (value > 0) {
        u32 digit = value % base;
        buf[n++] = (char)(digit < 10 ? '0' + digit : 'a' + (digit - 10));
        value /= base;
    }
    while (pad-- > n) {
        vga_putc(padc);
    }
    while (n > 0) {
        vga_putc(buf[--n]);
    }
}

void vga_printf(const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') {
            vga_putc(*p);
            continue;
        }
        p++;
        int pad = 0;
        char padc = ' ';
        if (*p == '0') {
            padc = '0';
            p++;
        }
        while (*p >= '0' && *p <= '9') {
            pad = pad * 10 + (*p - '0');
            p++;
        }
        switch (*p) {
        case 'd': {
            i32 v = va_arg(ap, i32);
            if (v < 0) {
                vga_putc('-');
                put_uint((u32)(-v), 10, pad, padc);
            } else {
                put_uint((u32)v, 10, pad, padc);
            }
            break;
        }
        case 'u':
            put_uint(va_arg(ap, u32), 10, pad, padc);
            break;
        case 'x':
            put_uint(va_arg(ap, u32), 16, pad, padc);
            break;
        case 'c':
            vga_putc((char)va_arg(ap, int));
            break;
        case 's':
            vga_puts(va_arg(ap, const char *));
            break;
        case '%':
            vga_putc('%');
            break;
        default:
            vga_putc('%');
            vga_putc(*p);
            break;
        }
    }
    va_end(ap);
}
