/* 4+4 bit flow combiner implementation. See include/bitflow.h. */

#include "bitflow.h"

void bitflow_combine(const u8 *a, const u8 *b, u8 *dst, u32 count)
{
    for (u32 i = 0; i < count; i++) {
        dst[i] = (u8)(((a[i] & 0x0F) << 4) | (b[i] & 0x0F));
    }
}

void bitflow_combine_inplace(u8 *a, const u8 *b, u32 count)
{
    /* Read a[i] before writing dst[i], so aliasing a == dst is safe. */
    for (u32 i = 0; i < count; i++) {
        a[i] = (u8)(((a[i] & 0x0F) << 4) | (b[i] & 0x0F));
    }
}

void bitflow_combine_carry(const u8 *a, const u8 *b, u8 *dst, u32 count)
{
    u8 carry = 0;
    for (u32 i = 0; i < count; i++) {
        u8 sum = (u8)((a[i] & 0x0F) + (b[i] & 0x0F) + carry);
        dst[i] = (u8)(sum & 0x0F);
        carry  = (u8)((sum >> 4) & 0x0F);
    }
}

void bitflow_extract(const u8 *src, u8 *a, u8 *b, u32 count)
{
    for (u32 i = 0; i < count; i++) {
        a[i] = (u8)((src[i] >> 4) & 0x0F);
        b[i] = (u8)(src[i] & 0x0F);
    }
}

int bitflow_combine_selftest(const u8 *a, const u8 *b, u32 count)
{
    static u8 merged[256];
    static u8 back_a[256];
    static u8 back_b[256];

    if (count > sizeof(merged)) {
        return 0;
    }

    bitflow_combine(a, b, merged, count);
    bitflow_extract(merged, back_a, back_b, count);

    for (u32 i = 0; i < count; i++) {
        if (back_a[i] != (a[i] & 0x0F) || back_b[i] != (b[i] & 0x0F)) {
            return 0;
        }
    }
    return 1;
}

/* --- Process combination ---------------------------------------------------
 *
 * Two operations of arbitrary width are packed into one flow, A in the high
 * bits and B in the low bits, as long as the total fits in 64 bits.
 */

/* The built-in operation set. Widths deliberately vary, from a 4-bit nibble to a
 * full 64-bit word, to exercise the combiner across its whole range. */
static const struct bitflow_process builtin_processes[] = {
    { 0x0A,               4,  "nibble"  },
    { 0x5A,               8,  "byte"    },
    { 0xBEEF,            16,  "word"    },
    { 0xDEADBEEF,        32,  "dword"   },
    { 0x0123456789ABCDEF, 64, "qword"   },
};
#define BUILTIN_PROCESS_COUNT \
    (sizeof(builtin_processes) / sizeof(builtin_processes[0]))

int bitflow_combine_processes(const struct bitflow_process *a,
                              const struct bitflow_process *b, u64 *dst)
{
    if (!a || !b || !dst) {
        return 0;
    }
    if (a->width == 0 || b->width == 0) {
        return 0;
    }
    if ((u32)a->width + (u32)b->width > BITFLOW_MAX_BITS) {
        return 0;
    }

    /* Mask each code to its declared width so stray high bits cannot bleed into
     * the other operation's field. */
    u64 mask_a = (a->width >= 64) ? ~0ull : ((1ull << a->width) - 1);
    u64 mask_b = (b->width >= 64) ? ~0ull : ((1ull << b->width) - 1);

    u64 hi = (a->code & mask_a) << b->width;
    u64 lo = (b->code & mask_b);

    *dst = hi | lo;
    return 1;
}

void bitflow_split_process(u64 flow, u8 width_a, u8 width_b,
                           u64 *a, u64 *b)
{
    u64 mask_b = (width_b >= 64) ? ~0ull : ((1ull << width_b) - 1);
    u64 mask_a = (width_a >= 64) ? ~0ull : ((1ull << width_a) - 1);

    if (b) {
        *b = flow & mask_b;
    }
    if (a) {
        *a = (flow >> width_b) & mask_a;
    }
}

int bitflow_process_selftest(void)
{
    for (u32 i = 0; i < BUILTIN_PROCESS_COUNT; i++) {
        for (u32 j = 0; j < BUILTIN_PROCESS_COUNT; j++) {
            const struct bitflow_process *pa = &builtin_processes[i];
            const struct bitflow_process *pb = &builtin_processes[j];
            u64 flow = 0, back_a = 0, back_b = 0;

            /* Pairs wider than 64 bits are expected to be rejected. */
            if ((u32)pa->width + (u32)pb->width > BITFLOW_MAX_BITS) {
                if (bitflow_combine_processes(pa, pb, &flow)) {
                    return 0;
                }
                continue;
            }

            if (!bitflow_combine_processes(pa, pb, &flow)) {
                return 0;
            }
            bitflow_split_process(flow, pa->width, pb->width, &back_a, &back_b);

            u64 mask_a = (pa->width >= 64) ? ~0ull : ((1ull << pa->width) - 1);
            u64 mask_b = (pb->width >= 64) ? ~0ull : ((1ull << pb->width) - 1);

            if (back_a != (pa->code & mask_a) || back_b != (pb->code & mask_b)) {
                return 0;
            }
        }
    }
    return 1;
}

/* --- Multi-process combination ---------------------------------------------
 *
 * The 64-bit limit is a budget, not a process count. Any number of operations
 * can share one flow as long as their widths sum to at most 64 bits. Ten 6-bit
 * operations fit in 60 bits; ten 8-bit operations need 80 and are rejected.
 */

/* procs[0] occupies the highest bits, procs[count-1] the lowest. */
int bitflow_combine_many(const struct bitflow_process *procs, u32 count,
                         u64 *dst)
{
    if (!procs || !dst || count == 0) {
        return 0;
    }

    u32 total = 0;
    for (u32 i = 0; i < count; i++) {
        if (procs[i].width == 0) {
            return 0;
        }
        total += procs[i].width;
    }
    if (total > BITFLOW_MAX_BITS) {
        return 0;
    }

    /* Fill from the low end upwards so the first process lands in the high bits. */
    u64 flow = 0;
    u32 shift = 0;
    for (u32 i = count; i-- > 0; ) {
        u8 w = procs[i].width;
        u64 mask = (w >= 64) ? ~0ull : ((1ull << w) - 1);
        flow |= (procs[i].code & mask) << shift;
        shift += w;
    }

    *dst = flow;
    return 1;
}

int bitflow_split_many(u64 flow, const u8 *widths, u32 count, u64 *out)
{
    if (!widths || !out || count == 0) {
        return 0;
    }

    u32 total = 0;
    for (u32 i = 0; i < count; i++) {
        if (widths[i] == 0) {
            return 0;
        }
        total += widths[i];
    }
    if (total > BITFLOW_MAX_BITS) {
        return 0;
    }

    u32 shift = 0;
    for (u32 i = count; i-- > 0; ) {
        u8 w = widths[i];
        u64 mask = (w >= 64) ? ~0ull : ((1ull << w) - 1);
        out[i] = (flow >> shift) & mask;
        shift += w;
    }
    return 1;
}

int bitflow_selftest_many(u32 count, u8 width, u64 *dst)
{
    struct bitflow_process procs[16];
    u8 widths[16];
    u64 back[16];

    if (count == 0 || count > 16 || width == 0) {
        return 0;
    }
    /* Only flows that fit the 64-bit budget are expected to succeed. */
    if ((u32)count * width > BITFLOW_MAX_BITS) {
        return 0;
    }

    for (u32 i = 0; i < count; i++) {
        u64 mask = (width >= 64) ? ~0ull : ((1ull << width) - 1);
        procs[i].code = ((u64)(i + 1) * 7u) & mask;
        procs[i].width = width;
        procs[i].name = "auto";
        widths[i] = width;
    }

    u64 flow = 0;
    if (!bitflow_combine_many(procs, count, &flow)) {
        return 0;
    }
    if (!bitflow_split_many(flow, widths, count, back)) {
        return 0;
    }
    for (u32 i = 0; i < count; i++) {
        if (back[i] != procs[i].code) {
            return 0;
        }
    }
    if (dst) {
        *dst = flow;
    }
    return 1;
}
