/* Machine report. See include/sysinfo.h.
 *
 * Everything here is read from a source the machine can actually see: CPUID for
 * the CPU, the multiboot info for memory, the ATA IDENTIFY for the disk, and the
 * model's own geometry for its size. Nothing is hard-coded, so the report stays
 * true on a different machine.
 */

#include "sysinfo.h"
#include "ata.h"
#include "cache.h"
#include "localai.h"
#include "layout.h"
#include "kb.h"
#include "serial.h"
#include "string.h"

/* Read a CPUID leaf. Returns 0 when CPUID is unavailable, so the caller can say
 * so instead of printing garbage. */
static int cpuid(u32 leaf, u32 *eax, u32 *ebx, u32 *ecx, u32 *edx)
{
    u32 max_leaf;

    __asm__ volatile("cpuid" : "=a"(max_leaf) : "a"(0) : "ebx", "ecx", "edx");
    if (max_leaf == 0) {
        return 0;
    }
    if (leaf > max_leaf) {
        return 0;
    }

    u32 a, b, c, d;
    __asm__ volatile("cpuid"
                     : "=a"(a), "=b"(b), "=c"(c), "=d"(d)
                     : "a"(leaf));
    if (eax) { *eax = a; }
    if (ebx) { *ebx = b; }
    if (ecx) { *ecx = c; }
    if (edx) { *edx = d; }
    return 1;
}

/* Print the 12-character vendor string from CPUID leaf 0. */
static void report_vendor(void)
{
    u32 ebx, ecx, edx;
    if (!cpuid(0, 0, &ebx, &ecx, &edx)) {
        klog("SYS", "CPU: cpuid unavailable");
        return;
    }

    char v[13];
    u32 n = 0;
    u32 regs[3];
    regs[0] = ebx;
    regs[1] = edx;
    regs[2] = ecx;
    for (u32 r = 0; r < 3; r++) {
        for (u32 b = 0; b < 4; b++) {
            v[n++] = (char)((regs[r] >> (b * 8)) & 0xFF);
        }
    }
    v[n] = '\0';

    u32 eax = 0;
    u32 family, model;
    if (!cpuid(1, &eax, 0, 0, 0)) {
        klog("SYS", "CPU: %s (family/model unavailable)", v);
        return;
    }
    family = (eax >> 8) & 0x0F;
    model = (eax >> 4) & 0x0F;
    if (family == 0x0F) {
        family += (eax >> 20) & 0xFF;
    }
    if (family == 0x06 || family == 0x0F) {
        model += ((eax >> 16) & 0x0F) << 4;
    }

    klog("SYS", "CPU: %s family %u model %u", v, family, model);
}

/* Report the CPU features the kernel actually relies on. Bits are from CPUID
 * leaf 1 EDX: 4 TSC, 0 FPU, 25 SSE, 26 SSE2, 9 APIC. */
static void report_features(void)
{
    u32 edx;
    if (!cpuid(1, 0, 0, 0, &edx)) {
        return;
    }

    klog("SYS", "CPU features: tsc=%s fpu=%s sse=%s sse2=%s apic=%s",
         (edx & (1u << 4)) ? "yes" : "no",
         (edx & (1u << 0)) ? "yes" : "no",
         (edx & (1u << 25)) ? "yes" : "no",
         (edx & (1u << 26)) ? "yes" : "no",
         (edx & (1u << 9)) ? "yes" : "no");
}

/* Report RAM from the multiboot memory map. mem_upper counts KiB above 1 MiB;
 * the first megabyte is not reported there, so it is added back. */
static void report_memory(u32 mbi)
{
    if (mbi == 0) {
        klog("SYS", "RAM: no multiboot info, size unknown");
        return;
    }

    u32 flags = *(const u32 *)(mbi + 0);
    if (!(flags & (1u << 0))) {
        klog("SYS", "RAM: bootloader supplied no memory fields");
        return;
    }

    u32 lower_kb = *(const u32 *)(mbi + 4);
    u32 upper_kb = *(const u32 *)(mbi + 8);
    u32 total_mb = 1 + upper_kb / 1024;

    klog("SYS", "RAM: %u MiB total (%u KiB low, %u KiB high)",
         total_mb, lower_kb, upper_kb);
}

static void report_disk(void)
{
    if (ata_sectors() == 0) {
        klog("SYS", "HDD: none detected on the primary bus");
        return;
    }

    u32 mb = ata_size_mb();
    u32 kb = ata_sectors() * 512 / 1024;
    if (mb > 0) {
        klog("SYS", "HDD: %u MiB (%u sectors)", mb, ata_sectors());
    } else {
        klog("SYS", "HDD: %u KiB (%u sectors)", kb, ata_sectors());
    }

    /* The .sidwa partition is the part of that disk the kernel owns. */
    klog("SYS", "HDD: .sidwa partition at LBA %u, %u sectors, grade %u",
         layout_kb_lba(), LAYOUT_KB_SECTORS, kb_grade());
}

static void report_ai(void)
{
    klog("SYS", "AI: %u actions, %u features, %u-bit weights, %u bytes",
         LAI_ACTIONS, localai_feature_count(), localai_weight_bits(),
         localai_model_bytes());
}

/* The boot multiboot pointer, kept so a later `sysinfo` command reports the
 * same memory map the boot report did. */
static u32 boot_mbi;

void sysinfo_set_mbi(u32 mbi) { boot_mbi = mbi; }

u32 sysinfo_ram_bytes(void)
{
    if (boot_mbi == 0) {
        return 0;
    }
    u32 flags = *(const u32 *)(boot_mbi + 0);
    if (!(flags & (1u << 0))) {
        return 0;
    }
    u32 upper_kb = *(const u32 *)(boot_mbi + 8);
    /* mem_upper counts KiB above 1 MiB; add the first megabyte back. */
    return (1u + upper_kb / 1024u) * 1024u * 1024u;
}

void sysinfo_report(u32 mbi)
{
    if (mbi == 0) {
        mbi = boot_mbi;     /* a later call reuses the boot map */
    }
    report_vendor();
    report_features();
    report_memory(mbi);
    report_disk();
    report_ai();
}

/* CPU and RAM are known before any driver runs, so they are reported first.
 * Disk and model size need the ATA IDENTIFY and the partition grade, so they
 * follow once those have come up. Both halves together are the machine report. */
void sysinfo_report_cpu(u32 mbi)
{
    if (mbi == 0) {
        mbi = boot_mbi;
    }
    report_vendor();
    report_features();
    report_memory(mbi);
}

void sysinfo_report_storage(void)
{
    report_disk();
    report_ai();
}
