/* Machine statistics: memory, processor load, disk speed, link speed.
 * See include/stats.h for what each number means and why it is sampled.
 *
 * Three of the four are measurements, not readings:
 *
 *   disk   times a run of sector reads and writes against the ATA port
 *   link   times a ping to the gateway, then converts the round trip to a rate
 *   cpu    busy-waits a fixed window and counts how many timer ticks passed
 *
 * The fourth, memory, is a subtraction: the bootloader says how much RAM there
 * is, and _kernel_end minus the load address says how much of it the image
 * occupies.
 *
 * The CPU figure is the one that needs a word of explanation. There is no idle
 * task and no scheduler, so "load" cannot mean queue depth. What it can mean
 * honestly is the fraction of a fixed window during which the processor did not
 * halt. The window is a spin of a known number of iterations; each iteration
 * reads the tick counter, and the ticks that pass during the spin are compared
 * with the ticks the same spin would take with the processor halted. If the
 * spin finishes in far fewer ticks than the halted baseline, the CPU was busy;
 * if it takes the same ticks, it was waiting.
 *
 * The baseline is not guessed. timer_sleep_ms() halts for a known time, so
 * measuring a halt of the same wall-clock duration as the spin gives the tick
 * count that means "not busy". The two are measured back to back so a change in
 * host speed moves both.
 */

#include "stats.h"
#include "timer.h"
#include "io.h"
#include "serial.h"
#include "sysinfo.h"
#include "ata.h"
#include "layout.h"
#include "net.h"

extern char _kernel_end[];      /* from linker.ld */

/* How much disk the speed test moves. 32 sectors is 16 KiB, which is over the
 * point where per-command overhead dominates and under the point where the test
 * writes anything the kernel cares about. */
#define STATS_DISK_SECTORS 32

/* Where the disk test reads and writes: the Loop 3 scratch region, which the
 * kernel already owns and rewrites, so a benchmark cannot corrupt anything that
 * is meant to persist. The absolute LBA comes from layout, because the kernel
 * may be running from a partition rather than a whole disk. */
#define STATS_SCRATCH_SECT LAYOUT_STORE_SECT

static struct stats_sample last;

const struct stats_sample *stats_last(void) { return &last; }

/* --- Memory ---------------------------------------------------------------- */

static u32 image_bytes(void)
{
    /* The kernel is linked at 1 MiB; _kernel_end is the first byte past it. */
    u32 start = 0x100000u;
    u32 end = (u32)(unsigned long)_kernel_end;
    return end > start ? end - start : 0;
}

/* --- Processor load -------------------------------------------------------- */

/* Idle accounting.
 *
 * "Load" cannot mean queue depth here: there is no scheduler and no run queue.
 * What it can mean honestly is the fraction of a window the processor spent
 * doing something rather than halted waiting for work.
 *
 * The one place the machine genuinely has nothing to do is the command line
 * waiting for a key. The input loop calls stats_idle_wait(), which halts and
 * adds the ticks that passed to an idle counter. Every other path -- a command,
 * a boot selftest, a benchmark -- leaves the counter alone and therefore counts
 * as busy.
 *
 * The load is then measured over the interval since the previous sample, which
 * is what a monitoring chart wants: "how busy has this machine been since you
 * last asked". The interval is taken from the same tick counter, so the two
 * sides of the fraction always cover the same span.
 */
static volatile u32 idle_ticks;
static u32 ref_ticks;
static u32 ref_idle;

void stats_idle_wait(void)
{
    u32 t0 = timer_ticks();
    hlt();
    u32 dt = timer_ticks() - t0;
    /* A halt returns on the next interrupt, which is a timer tick, so at least
     * one tick has passed even when the counter has not visibly moved. */
    idle_ticks += dt ? dt : 1u;
}

/* Busy fraction of the interval since the previous call, in tenths of a percent.
 * Kept separate from the sampling so the selftest can check it with fixed
 * numbers. */
static u32 load_tenths(u32 dt, u32 di)
{
    if (dt == 0) {
        return 0;               /* no window has passed yet */
    }
    if (di >= dt) {
        return 0;               /* fully idle */
    }
    return ((dt - di) * 1000u) / dt;
}

/* --- Disk ------------------------------------------------------------------ */

/* Time `sectors` reads and writes of the scratch region. Returns the rate in
 * KiB/s, or 0 when the disk refused or the timer is too coarse to measure.
 *
 * The timer runs at 100 Hz, so a 10 ms tick is the resolution. 32 sectors in PIO
 * mode take on the order of a millisecond, which is under one tick, so a single
 * transfer would time as zero. The transfer is repeated until at least one tick
 * has passed and the total is divided by the ticks observed. */
static u32 disk_rate_kbps(int writing)
{
    static u8 buf[STATS_DISK_SECTORS * ATA_SECTOR_SIZE];

    /* Run transfers until at least one tick has passed, so the rate is
     * measured rather than rounded to zero, with a hard bound so a very slow
     * disk cannot hang the console. */
    const u32 max_rounds = 64;
    u32 t0 = timer_ticks();
    u32 rounds = 0;

    while (rounds < max_rounds) {
        int ok;
        if (writing) {
            ok = ata_write_sectors(layout_store_lba(), STATS_DISK_SECTORS, buf);
        } else {
            ok = ata_read_sectors(layout_store_lba(), STATS_DISK_SECTORS, buf);
        }
        if (!ok) {
            return 0;
        }
        rounds++;
        if (timer_ticks() - t0 > 0) {
            break;
        }
    }

    u32 ticks = timer_ticks() - t0;
    if (ticks == 0 || rounds == 0) {
        return 0;
    }

    /* KiB moved, divided by the seconds it took. ticks/PIT_HZ is seconds, so
     * KiB/s is KiB * PIT_HZ / ticks. */
    u32 kib = rounds * STATS_DISK_SECTORS * (ATA_SECTOR_SIZE / 1024);
    if (kib == 0) {
        kib = rounds;              /* 512-byte sectors: count half-KiB as KiB */
    }
    return (kib * PIT_HZ) / ticks;
}

/* --- Link ------------------------------------------------------------------ */

/* Ping the gateway and report the round trip in microseconds.
 *
 * Returns -1 when the gateway did not answer, and otherwise the round trip in
 * whole 10 ms timer ticks, converted to microseconds. That is coarse -- the PIT
 * runs at 100 Hz and there is no calibrated cycle counter to do better -- but it
 * is the resolution the machine actually has, and a reply inside one tick
 * honestly reports as 0 us ("under 10 ms") rather than as a made-up figure.
 *
 * The first ping also pays for ARP resolution, so the cache is warmed with a
 * throwaway ping before the one that is timed. */
static int link_rtt_us(void)
{
    if (!net_ready() && !net_init()) {
        return -1;
    }
    const struct net_config *cfg = net_config_get();
    if (!cfg) {
        return -1;
    }

    (void)net_ping(cfg->gateway, 1000);     /* warm the ARP cache */

    int ms = net_ping(cfg->gateway, 1000);
    if (ms < 0) {
        return -1;
    }
    return ms * 1000;
}

/* --- Sampling --------------------------------------------------------------- */

void stats_sample(struct stats_sample *out)
{
    if (!out) {
        return;
    }

    out->ram_bytes = sysinfo_ram_bytes();
    out->kernel_bytes = image_bytes();

    /* Processor load over the interval since the previous sample. The interval
     * starts before the disk and link tests below, so the time they spend is
     * counted as busy, which it is. */
    u32 now = timer_ticks();
    u32 dt = now - ref_ticks;
    u32 di = idle_ticks - ref_idle;
    ref_ticks = now;
    ref_idle = idle_ticks;

    /* Disk: only when there is a disk to time. */
    if (ata_sectors() == 0 || STATS_SCRATCH_SECT < STATS_DISK_SECTORS) {
        out->disk_read_kbps = 0;
        out->disk_write_kbps = 0;
    } else {
        out->disk_read_kbps = disk_rate_kbps(0);
        out->disk_write_kbps = disk_rate_kbps(1);
    }

    /* Link: only when the stack is up. The rate is derived from the round trip
     * of a 32-byte echo, so it measures the link's latency, not its bandwidth:
     * a reply inside one 10 ms tick gives 1000000 / (10000 * 32) = 3 KiB/s. Low
     * and honest beats a big number that means nothing. */
    int rtt = link_rtt_us();
    if (rtt < 0) {
        out->link_rtt_us = 0;
        out->link_kbps = 0;
    } else {
        out->link_rtt_us = (u32)rtt;
        /* A reply inside one tick reads as 0 us. Treat it as one tick, which is
         * the finest the timer can resolve: the rate is then the lower bound the
         * resolution supports, and the division stays off zero. */
        u32 r = (u32)rtt ? (u32)rtt : 10000u;
        out->link_kbps = 1000000u / (r * 32u);
    }

    /* The load fraction, now that the window is closed. */
    out->cpu_load_tenths = load_tenths(dt, di);

    last = *out;
}

/* --- Reporting -------------------------------------------------------------- */

void stats_report(void)
{
    struct stats_sample s;
    stats_sample(&s);

    if (s.ram_bytes) {
        klog("STATS", "memory: kernel %u KiB of %u MiB RAM",
             s.kernel_bytes / 1024u, s.ram_bytes / (1024u * 1024u));
    } else {
        klog("STATS", "memory: kernel %u KiB (total RAM unknown)",
             s.kernel_bytes / 1024u);
    }

    klog("STATS", "cpu load: %u.%u%%",
         s.cpu_load_tenths / 10u, s.cpu_load_tenths % 10u);

    if (s.disk_read_kbps || s.disk_write_kbps) {
        klog("STATS", "disk .sidwa: read %u KiB/s, write %u KiB/s",
             s.disk_read_kbps, s.disk_write_kbps);
    } else {
        klog("STATS", "disk .sidwa: not measured (no disk)");
    }

    if (s.link_kbps) {
        if (s.link_rtt_us) {
            klog("STATS", "link: %u KiB/s (gateway round trip %u us)",
                 s.link_kbps, s.link_rtt_us);
        } else {
            /* A reply inside one 10 ms tick: the timer cannot say more. */
            klog("STATS", "link: %u KiB/s (gateway round trip under 10 ms)",
                 s.link_kbps);
        }
    } else {
        klog("STATS", "link: not measured (gateway did not answer)");
    }
}

/* --- Selftest --------------------------------------------------------------- */

int stats_selftest(void)
{
    int ok = 1;

    /* Memory: the image must be non-empty and start below _kernel_end. */
    u32 img = image_bytes();
    if (img == 0 || img > 8u * 1024u * 1024u) {
        klog("STATS", "selftest: image size %u looks wrong", img);
        ok = 0;
    }

    /* Load arithmetic. No window means nothing to report. */
    if (load_tenths(0, 0) != 0) {
        klog("STATS", "selftest: empty window is not zero");
        ok = 0;
    }
    /* Every tick idle is a load of zero. */
    if (load_tenths(10, 10) != 0) {
        klog("STATS", "selftest: fully idle load is not zero");
        ok = 0;
    }
    /* Half the ticks idle is a load of 50%. */
    if (load_tenths(10, 5) != 500) {
        klog("STATS", "selftest: half load is not 500");
        ok = 0;
    }
    /* Idle more ticks than the window cannot happen; clamp rather than wrap. */
    if (load_tenths(10, 20) != 0) {
        klog("STATS", "selftest: over-idle not clamped");
        ok = 0;
    }
    /* No tick passed means no idle time, so the load is full. */
    if (load_tenths(10, 0) != 1000) {
        klog("STATS", "selftest: no-idle load is not 1000");
        ok = 0;
    }

    klog("STATS", "selftest: %s", ok ? "ok" : "bad");
    return ok;
}
