/* The program IDE. See include/ide.h.
 *
 * A text editor for SidwaASM programs, plus the two keys that matter: run and
 * load-example. The buffer is a fixed grid, so every operation is a bounded copy
 * and there is nothing to allocate.
 *
 * The editor owns the whole body of the window: a title row, the source lines,
 * a separator, and the output pane. It draws itself from the model on every
 * repaint, the same way the desktop GUI does, so the screen is always a pure
 * function of the buffer.
 */

#include "ide.h"
#include "sasm.h"
#include "svm.h"
#include "vga.h"
#include "keyboard.h"
#include "serial.h"
#include "string.h"

/* Geometry. These are the IDE's own, so the module does not depend on the
 * desktop GUI's private layout constants. */
#define IDE_X       3
#define IDE_Y       4
#define IDE_W       74
#define IDE_SRC_Y   (IDE_Y + 2)
#define IDE_OUT_Y   (IDE_SRC_Y + IDE_MAX_LINES + 1)

#define COL_FRAME  VGA_ATTR(VGA_WHITE, VGA_BLUE)
#define COL_TEXT   VGA_ATTR(VGA_BLACK, VGA_LIGHTGRAY)
#define COL_CUR    VGA_ATTR(VGA_WHITE, VGA_BLUE)
#define COL_HEAD   VGA_ATTR(VGA_YELLOW, VGA_BLUE)
#define COL_OUT    VGA_ATTR(VGA_BLACK, VGA_CYAN)
#define COL_ERR    VGA_ATTR(VGA_LIGHTRED, VGA_BLUE)

/* --- Model ------------------------------------------------------------------ */

struct ide_model {
    char lines[IDE_MAX_LINES][IDE_LINE_LEN];
    u32 count;                  /* lines in use */
    u32 cx, cy;                 /* cursor: column, line */
    char out[IDE_OUT_LINES][IDE_OUT_LEN];
    u32 out_count;
    int out_is_error;
    u32 example;                /* which built-in was loaded last */
};

static struct ide_model m;

/* --- Small string helpers --------------------------------------------------- */

static u32 slen(const char *s)
{
    u32 n = 0;
    while (s[n]) {
        n++;
    }
    return n;
}

static void scopy(char *dst, u32 max, const char *src)
{
    u32 i = 0;
    for (; i + 1 < max && src[i]; i++) {
        dst[i] = src[i];
    }
    dst[i] = '\0';
}

/* --- Output pane ------------------------------------------------------------ */

static void out_clear(void)
{
    m.out_count = 0;
    m.out_is_error = 0;
    for (u32 i = 0; i < IDE_OUT_LINES; i++) {
        m.out[i][0] = '\0';
    }
}

static void out_line(const char *s)
{
    if (m.out_count >= IDE_OUT_LINES) {
        return;
    }
    scopy(m.out[m.out_count++], IDE_OUT_LEN, s);
}

/* Split a NUL-terminated multi-line string into the output pane. */
static void out_text(const char *s)
{
    const char *p = s;
    while (*p && m.out_count < IDE_OUT_LINES) {
        char line[IDE_OUT_LEN];
        u32 n = 0;
        while (*p && *p != '\n' && n + 1 < sizeof(line)) {
            line[n++] = *p++;
        }
        line[n] = '\0';
        if (*p == '\n') {
            p++;
        }
        out_line(line);
    }
}

/* --- Editing ---------------------------------------------------------------- */

/* Flatten the buffer into one string with newlines, for the assembler. `dst`
 * must hold count*IDE_LINE_LEN + 1 bytes. */
static void flatten(char *dst, u32 max)
{
    u32 o = 0;
    for (u32 i = 0; i < m.count && o + 2 < max; i++) {
        for (const char *p = m.lines[i]; *p && o + 1 < max; p++) {
            dst[o++] = *p;
        }
        dst[o++] = '\n';
    }
    dst[o] = '\0';
}

static void insert_char(char c)
{
    char *line = m.lines[m.cy];
    u32 len = slen(line);
    if (len + 1 >= IDE_LINE_LEN) {
        return;                     /* the line is full */
    }
    /* Shift the tail right, then drop the character in. */
    for (u32 i = len; i > m.cx; i--) {
        line[i] = line[i - 1];
    }
    line[m.cx] = c;
    line[len + 1] = '\0';
    if (m.cx < IDE_LINE_LEN - 1) {
        m.cx++;
    }
}

static void backspace(void)
{
    char *line = m.lines[m.cy];
    if (m.cx > 0) {
        u32 len = slen(line);
        for (u32 i = m.cx - 1; i < len; i++) {
            line[i] = line[i + 1];
        }
        m.cx--;
    } else if (m.cy > 0) {
        /* Join with the previous line, keeping the cursor where the join is. */
        char *prev = m.lines[m.cy - 1];
        u32 plen = slen(prev);
        u32 len = slen(line);
        for (u32 i = 0; i < len && plen + 1 < IDE_LINE_LEN; i++) {
            prev[plen++] = line[i];
        }
        prev[plen] = '\0';
        for (u32 i = m.cy; i + 1 < m.count; i++) {
            scopy(m.lines[i], IDE_LINE_LEN, m.lines[i + 1]);
        }
        m.count--;
        m.cy--;
        m.cx = plen;
    }
}

static void newline(void)
{
    if (m.count >= IDE_MAX_LINES) {
        return;
    }
    /* Split the current line at the cursor into this and the next line. */
    for (u32 i = m.count; i > m.cy + 1; i--) {
        scopy(m.lines[i], IDE_LINE_LEN, m.lines[i - 1]);
    }
    m.count++;

    char tail[IDE_LINE_LEN];
    u32 t = 0;
    char *line = m.lines[m.cy];
    for (u32 i = m.cx; line[i] && t + 1 < sizeof(tail); i++) {
        tail[t++] = line[i];
    }
    tail[t] = '\0';
    line[m.cx] = '\0';
    scopy(m.lines[m.cy + 1], IDE_LINE_LEN, tail);
    m.cy++;
    m.cx = 0;
}

static void ensure_line(void)
{
    if (m.count == 0) {
        m.count = 1;
        m.lines[0][0] = '\0';
    }
}

/* --- Run -------------------------------------------------------------------- */

void ide_run(void)
{
    out_clear();

    static char source[SASM_MAX_SOURCE];
    flatten(source, sizeof(source));

    struct sasm_program prog;
    char err[SASM_ERROR_MAX];
    if (!sasm_assemble(source, &prog, err, sizeof(err))) {
        m.out_is_error = 1;
        out_line("assembly failed:");
        out_line(err);
        return;
    }

    char head[IDE_OUT_LEN];
    {
        /* "assembled: N instructions" without a printf dependency. */
        u32 o = 0;
        const char *p = "assembled: ";
        while (*p && o + 1 < sizeof(head)) {
            head[o++] = *p++;
        }
        char rev[12];
        u32 r = 0, v = prog.count;
        if (v == 0) {
            rev[r++] = '0';
        }
        while (v && r < sizeof(rev)) {
            rev[r++] = (char)('0' + (v % 10));
            v /= 10;
        }
        while (r && o + 1 < sizeof(head)) {
            head[o++] = rev[--r];
        }
        const char *q = " instructions";
        for (const char *s = q; *s && o + 1 < sizeof(head); s++) {
            head[o++] = *s;
        }
        head[o] = '\0';
    }
    out_line(head);

    char out[SVM_OUT_MAX];
    struct svm vm;
    svm_reset(&vm);
    int rc = svm_run(&vm, &prog, out, sizeof(out));
    if (rc != SVM_OK) {
        m.out_is_error = 1;
        out_line(svm_error_text(rc));
        return;
    }
    if (out[0]) {
        out_text(out);
    } else {
        out_line("(program produced no output)");
    }
}

void ide_load_example(u32 which)
{
    u32 n = sasm_example_count();
    if (n == 0) {
        return;
    }
    m.example = which % n;

    const char *src = sasm_example(m.example);
    m.count = 0;
    m.cx = 0;
    m.cy = 0;

    const char *p = src;
    while (*p && m.count < IDE_MAX_LINES) {
        char *line = m.lines[m.count];
        u32 n2 = 0;
        while (*p && *p != '\n' && n2 + 1 < IDE_LINE_LEN) {
            line[n2++] = *p++;
        }
        line[n2] = '\0';
        if (*p == '\n') {
            p++;
        }
        m.count++;
    }
    ensure_line();
    out_clear();
}

/* --- View ------------------------------------------------------------------- */

static void draw_line_number(u32 row, u32 num)
{
    char buf[6];
    u32 o = 0;
    if (num >= 10) {
        buf[o++] = (char)('0' + (num / 10) % 10);
    }
    buf[o++] = (char)('0' + num % 10);
    buf[o++] = ' ';
    buf[o] = '\0';
    vga_puts_at(IDE_X, row, buf, COL_TEXT);
}

void ide_draw(void)
{
    vga_box(IDE_X - 2, IDE_Y - 2, IDE_W + 4, IDE_MAX_LINES + IDE_OUT_LINES + 7,
            COL_FRAME);
    vga_puts_at(IDE_X, IDE_Y - 1, "SidwaASM IDE", COL_HEAD);
    vga_puts_at(IDE_X + 20, IDE_Y - 1,
                "Ctrl-R run  Tab example  Ctrl-L clear  Esc quit", COL_HEAD);

    /* Source lines, with the cursor drawn as a highlighted cell. */
    for (u32 i = 0; i < IDE_MAX_LINES; i++) {
        u32 row = IDE_SRC_Y + i;
        if (i < m.count) {
            vga_puts_clipped(IDE_X + 3, row, IDE_W - 3, m.lines[i], COL_TEXT);
            draw_line_number(row, i + 1);

            if (i == m.cy) {
                char c = m.lines[i][m.cx];
                if (c == '\0') {
                    c = ' ';
                }
                vga_putc_at(IDE_X + 3 + m.cx, row, c, COL_CUR);
            }
        } else {
            vga_fill(IDE_X, row, IDE_W, 1, COL_TEXT);
        }
    }

    /* Output pane. */
    u32 sep = IDE_OUT_Y - 1;
    vga_puts_at(IDE_X, sep, "OUTPUT", COL_HEAD);
    u8 attr = m.out_is_error ? COL_ERR : COL_OUT;
    for (u32 i = 0; i < IDE_OUT_LINES; i++) {
        u32 row = IDE_OUT_Y + i;
        if (i < m.out_count) {
            vga_puts_clipped(IDE_X, row, IDE_W, m.out[i], attr);
        } else {
            vga_fill(IDE_X, row, IDE_W, 1, COL_TEXT);
        }
    }
}

/* --- Controller ------------------------------------------------------------- */

int ide_handle_key(u16 key)
{
    ensure_line();

    switch (key) {
    case KEY_ESC:
        return 0;

    case 0x12:                      /* Ctrl-R */
        ide_run();
        break;

    case 0x0C:                      /* Ctrl-L */
        out_clear();
        break;

    case KEY_TAB:
        ide_load_example(m.example + 1);
        break;

    case KEY_ENTER:
        newline();
        break;

    case KEY_BACKSPACE:
        backspace();
        break;

    case KEY_UP:
        if (m.cy > 0) {
            m.cy--;
            if (m.cx > slen(m.lines[m.cy])) {
                m.cx = slen(m.lines[m.cy]);
            }
        }
        break;

    case KEY_DOWN:
        if (m.cy + 1 < m.count) {
            m.cy++;
            if (m.cx > slen(m.lines[m.cy])) {
                m.cx = slen(m.lines[m.cy]);
            }
        }
        break;

    case KEY_LEFT:
        if (m.cx > 0) {
            m.cx--;
        } else if (m.cy > 0) {
            m.cy--;
            m.cx = slen(m.lines[m.cy]);
        }
        break;

    case KEY_RIGHT:
        if (m.cx < slen(m.lines[m.cy])) {
            m.cx++;
        } else if (m.cy + 1 < m.count) {
            m.cy++;
            m.cx = 0;
        }
        break;

    default:
        /* Printable ASCII goes into the buffer. */
        if (key >= 32 && key < 127) {
            insert_char((char)key);
        }
        break;
    }
    return 1;
}

/* --- Entry points ----------------------------------------------------------- */

void ide_init(void)
{
    m.count = 0;
    m.cx = 0;
    m.cy = 0;
    m.example = 0;
    out_clear();
    ide_load_example(0);
}

const char *ide_source(void)
{
    static char buf[SASM_MAX_SOURCE];
    flatten(buf, sizeof(buf));
    return buf;
}

const char *ide_output(void)
{
    /* The first output line, for the self test. */
    return m.out_count ? m.out[0] : "";
}

u32 ide_line_count(void) { return m.count; }

/* --- Self test -------------------------------------------------------------- */

int ide_selftest(void)
{
    ide_init();
    if (ide_line_count() == 0) {
        return 0;
    }

    /* Type a fresh program through the key handler, exactly as a user would:
     * the source must come back out of the buffer unchanged. */
    for (u32 i = 0; i < IDE_MAX_LINES; i++) {
        m.lines[i][0] = '\0';
    }
    m.count = 1;
    m.cx = 0;
    m.cy = 0;

    const char *prog = "mov r0, 7\nout r0\nhlt";
    for (const char *p = prog; *p; p++) {
        ide_handle_key(*p == '\n' ? KEY_ENTER : (u16)(u8)*p);
    }

    if (strcmp(ide_source(), "mov r0, 7\nout r0\nhlt\n") != 0) {
        return 0;
    }

    /* And it must run to the expected output. */
    ide_run();
    if (m.out_is_error) {
        return 0;
    }
    /* The pane holds "assembled: 3 instructions" then "7". */
    if (m.out_count < 2) {
        return 0;
    }
    return strcmp(m.out[1], "7") == 0;
}
