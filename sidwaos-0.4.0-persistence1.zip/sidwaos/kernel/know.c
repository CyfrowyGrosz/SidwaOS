/* Knowledge cache and lookup. See include/know.h.
 *
 * The RAM tier is a small direct-mapped table keyed by a hash of the query.
 * Collisions simply overwrite, which is acceptable for a cache: the disk tier
 * still holds the fact, so an evicted entry is recovered rather than lost.
 *
 * Facts on disk are stored as records of the form
 *
 *     "KEY\tVALUE"
 *
 * so one record holds a question and its answer. know_recall scans the
 * partition for a matching key; the scan is linear because the partition is
 * small and correctness matters more than speed here.
 */

#include "know.h"
#include "kb.h"
#include "serial.h"
#include "string.h"

#define KNOW_SLOTS 16

struct know_entry {
    u8  used;
    u8  verified;               /* corroborated; only these reach the disk */
    char key[KNOW_KEY_MAX];
    char value[KNOW_VALUE_MAX];
};

static struct know_entry cache[KNOW_SLOTS];
static u32 hits;

u32 know_cache_hits(void) { return hits; }

u32 know_cache_count(void)
{
    u32 n = 0;
    for (u32 i = 0; i < KNOW_SLOTS; i++) {
        if (cache[i].used) {
            n++;
        }
    }
    return n;
}

u32 know_verified_count(void)
{
    u32 n = 0;
    for (u32 i = 0; i < KNOW_SLOTS; i++) {
        if (cache[i].used && cache[i].verified) {
            n++;
        }
    }
    return n;
}

u32 know_unverified_count(void)
{
    return know_cache_count() - know_verified_count();
}

static u32 slot_of(const char *key)
{
    u32 h = 0;
    for (const char *p = key; *p; p++) {
        h = h * 31u + (u8)*p;
    }
    return h % KNOW_SLOTS;
}

/* Case-insensitive comparison, so "Cache" and "cache" hit the same entry. */
static int key_eq(const char *a, const char *b)
{
    for (;; a++, b++) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') {
            ca = (char)(ca + 32);
        }
        if (cb >= 'A' && cb <= 'Z') {
            cb = (char)(cb + 32);
        }
        if (ca != cb) {
            return 0;
        }
        if (!ca) {
            return 1;
        }
    }
}

static void copy_str(char *dst, u32 max, const char *src)
{
    u32 i = 0;
    for (; src && src[i] && i + 1 < max; i++) {
        dst[i] = src[i];
    }
    dst[i] = '\0';
}

/* --- Disk tier -------------------------------------------------------------- */

/* Read a record of the form "key\tvalue" into key/value. Returns 1 on success. */
static int split_record(const char *rec, char *key, u32 key_max,
                        char *value, u32 value_max)
{
    u32 i = 0;
    for (; rec[i] && rec[i] != '\t' && i + 1 < key_max; i++) {
        key[i] = rec[i];
    }
    if (rec[i] != '\t') {
        return 0;       /* not a key/value record */
    }
    key[i] = '\0';

    const char *v = rec + i + 1;
    u32 j = 0;
    for (; v[j] && j + 1 < value_max; j++) {
        value[j] = v[j];
    }
    value[j] = '\0';
    return 1;
}

static int disk_lookup(const char *query, char *out, u32 max)
{
    static char rec[KB_DATA_MAX];
    char key[KNOW_KEY_MAX];
    char value[KNOW_VALUE_MAX];

    u32 cursor = 0, seq = 0;
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (!split_record(rec, key, sizeof(key), value, sizeof(value))) {
            continue;
        }
        if (key_eq(key, query)) {
            copy_str(out, max, value);
            return (int)strlen(out);
        }
    }
    return -1;
}

/* Find the partition record holding `query`. Returns its sequence number, or 0
 * when there is no such record. */
static u32 disk_seq_of(const char *query)
{
    static char rec[KB_DATA_MAX];
    char key[KNOW_KEY_MAX];
    char value[KNOW_VALUE_MAX];

    u32 cursor = 0, seq = 0;
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (!split_record(rec, key, sizeof(key), value, sizeof(value))) {
            continue;
        }
        if (key_eq(key, query)) {
            return seq;
        }
    }
    return 0;
}

/* --- Public API ------------------------------------------------------------- */

int know_peek_ram(const char *query, char *out, u32 max)
{
    if (!query || !*query) {
        return -1;
    }
    struct know_entry *e = &cache[slot_of(query)];
    if (e->used && key_eq(e->key, query)) {
        copy_str(out, max, e->value);
        return (int)strlen(out);
    }
    return -1;
}

int know_recall(const char *query, char *out, u32 max)
{
    if (!query || !*query) {
        return -1;
    }

    /* Tier 1: RAM, but only verified entries. An unverified fact is a candidate,
     * not knowledge, and must not short-circuit the lookup that would confirm
     * it. know_peek_ram() exposes those for comparison. */
    struct know_entry *e = &cache[slot_of(query)];
    if (e->used && e->verified && key_eq(e->key, query)) {
        copy_str(out, max, e->value);
        hits++;
        return (int)strlen(out);
    }

    /* Tier 2: the .sidwa partition. Only verified facts are ever written there,
     * so a disk hit is trustworthy and is promoted into RAM as verified. */
    if (disk_lookup(query, out, max) >= 0) {
        copy_str(e->key, sizeof(e->key), query);
        copy_str(e->value, sizeof(e->value), out);
        e->used = 1;
        e->verified = 1;
        hits++;
        return (int)strlen(out);
    }

    return -1;
}

void know_remember(const char *query, const char *value)
{
    if (!query || !*query) {
        return;
    }

    struct know_entry *e = &cache[slot_of(query)];
    copy_str(e->key, sizeof(e->key), query);
    copy_str(e->value, sizeof(e->value), value ? value : "");
    e->used = 1;
    e->verified = 0;        /* unproven until corroborated */
}

/* Write a fact to the partition as "key\tvalue". */
static int disk_store(const char *query, const char *value)
{
    char rec[KNOW_KEY_MAX + 1 + KNOW_VALUE_MAX];
    u32 n = 0;

    for (const char *p = query; *p && n + 1 < sizeof(rec); p++) {
        rec[n++] = *p;
    }
    if (n + 1 >= sizeof(rec)) {
        return 0;
    }
    rec[n++] = '\t';
    for (const char *p = value ? value : ""; *p && n + 1 < sizeof(rec); p++) {
        rec[n++] = *p;
    }
    rec[n] = '\0';

    return kb_append(rec, n) >= 0;
}

int know_verify(const char *query)
{
    if (!query || !*query) {
        return 0;
    }

    struct know_entry *e = &cache[slot_of(query)];
    if (!e->used || !key_eq(e->key, query)) {
        return 0;       /* nothing to verify: never seen this fact */
    }
    if (e->verified) {
        return 1;
    }

    if (!kb_mount() || !disk_store(e->key, e->value)) {
        return 0;
    }

    e->verified = 1;
    return 1;
}

int know_forget(const char *query)
{
    if (!query || !*query) {
        return 0;
    }

    int removed = 0;

    struct know_entry *e = &cache[slot_of(query)];
    if (e->used && key_eq(e->key, query)) {
        e->used = 0;
        e->verified = 0;
        e->key[0] = '\0';
        e->value[0] = '\0';
        removed = 1;
    }

    if (kb_mount()) {
        u32 seq = disk_seq_of(query);
        if (seq && kb_delete(seq)) {
            removed = 1;
        }
    }
    return removed;
}

void know_report(void)
{
    klog("KNOW", "RAM cache: %u/%u slots used (%u verified, %u unverified), "
         "%u hits",
         know_cache_count(), (u32)KNOW_SLOTS,
         know_verified_count(), know_unverified_count(), hits);

    for (u32 i = 0; i < KNOW_SLOTS; i++) {
        if (!cache[i].used) {
            continue;
        }
        char preview[41];
        u32 n = strlen(cache[i].value);
        if (n > 40) {
            n = 40;
        }
        for (u32 k = 0; k < n; k++) {
            preview[k] = cache[i].value[k];
        }
        preview[n] = '\0';
        klog("KNOW", "  [%s] %s -> %s",
             cache[i].verified ? "verified" : "unverified",
             cache[i].key, preview);
    }

    klog("KNOW", ".sidwa holds %u records total", kb_count());
}

int know_selftest(void)
{
    static const char q[] = "sidwa-selftest-question";
    static const char v[] = "sidwa-selftest-answer";
    char out[KNOW_VALUE_MAX];

    /* An unverified fact must be in RAM but NOT on the partition. */
    know_remember(q, v);
    if (kb_mount() && disk_seq_of(q)) {
        return 0;       /* a logical mistake reached the disk */
    }

    /* Verify, which is the only path to disk. */
    if (!know_verify(q)) {
        return 0;
    }
    if (!disk_seq_of(q)) {
        return 0;
    }

    /* It must now be readable, and a second read served from RAM. */
    int n = know_recall(q, out, sizeof(out));
    if (n < 0 || !key_eq(out, v)) {
        return 0;
    }
    u32 before = hits;
    n = know_recall(q, out, sizeof(out));
    if (n < 0 || !key_eq(out, v) || hits != before + 1) {
        return 0;
    }

    /* And forget must take it back off the disk, leaving no junk behind. */
    return know_forget(q) && !disk_seq_of(q);
}
