/* The 3-state machine: a cooperative scheduler cycling RUN -> HOLD -> STORE.
 *
 * Each loop runs in turn. HOLD is where data is parked and validated; STORE is
 * where a validated program is persisted, gated on its serial key. The machine
 * returns to RUN and repeats until there is no work left, then reports stats.
 */

#include "state.h"
#include "serial.h"

static struct state_stats stats;

/* Programs that passed the logic test, waiting for STORE. */
static struct app_blob valid_queue[8];
static u32 valid_count;
static u32 valid_read;

void hold_submit(const struct app_blob *blob)
{
    if (valid_count < sizeof(valid_queue) / sizeof(valid_queue[0])) {
        valid_queue[valid_count++] = *blob;
    }
}

struct app_blob *hold_next_valid(void)
{
    if (valid_read >= valid_count) {
        return 0;
    }
    return &valid_queue[valid_read++];
}

void state_log_transition(enum state from, enum state to)
{
    static const char *names[] = { "RUN", "HOLD", "STORE", "DONE" };
    klog("STATE", "%s -> %s", names[from], names[to]);
}

static const char *state_name(enum state s)
{
    static const char *names[] = { "RUN", "HOLD", "STORE", "DONE" };
    return names[s];
}

void state_machine_run(void)
{
    enum state current = STATE_RUN;
    klog("STATE", "%s", state_name(current));

    /* Cycle until every stage has drained: HOLD has nothing left to validate
     * and STORE has nothing left to persist. */
    for (int pass = 0; pass < 3; pass++) {
        enum state next;

        switch (current) {
        case STATE_RUN:
            loop_run();
            next = STATE_HOLD;
            break;
        case STATE_HOLD:
            loop_hold();
            next = STATE_STORE;
            break;
        case STATE_STORE:
            loop_store();
            next = STATE_RUN;
            break;
        default:
            next = STATE_DONE;
            break;
        }

        if (next != current) {
            state_log_transition(current, next);
        }
        current = next;
    }

    state_log_transition(current, STATE_DONE);
}

struct state_stats *state_stats_get(void)
{
    return &stats;
}

void state_stats_dump(void)
{
    klog("STATS", "RUN fragments=%u corrupted=%u",
         stats.run_fragments, stats.run_corrupted);
    klog("STATS", "HOLD passed=%u failed=%u",
         stats.hold_passed, stats.hold_failed);
    klog("STATS", "STORE written=%u refused=%u",
         stats.store_written, stats.store_refused);
}
