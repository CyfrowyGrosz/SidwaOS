/* Disk layout. See include/layout.h.
 *
 * The bootloader leaves a small structure at a fixed address saying where the
 * SidwaOS region begins. Reading it here is what lets one kernel image serve
 * both a whole-disk install and a partition install.
 */

#include "layout.h"
#include "serial.h"

/* The bootloader's hand-off: a magic word then the base LBA. boot/stage2.asm
 * writes this; the address is fixed by the same file. */
#define BOOTINFO_ADDR  0x700u
#define BOOTINFO_MAGIC 0x5344424Fu      /* "SDBO" */

static u32 base;

void layout_init(u32 base_lba)
{
    /* Prefer the bootloader's word when it looks valid; the caller's value is a
     * fallback for a loader that does not provide one (for example GRUB). */
    const volatile u32 *info = (const volatile u32 *)BOOTINFO_ADDR;
    if (info[0] == BOOTINFO_MAGIC) {
        base = info[1];
        klog("LAYOUT", "disk base LBA %u (from bootloader)", base);
        return;
    }

    base = base_lba;
    klog("LAYOUT", "disk base LBA %u (whole disk)", base);
}

u32 layout_base(void)      { return base; }
u32 layout_blob_lba(void)  { return base + LAYOUT_BLOB_LBA; }
u32 layout_store_lba(void) { return base + LAYOUT_STORE_LBA; }
u32 layout_kb_lba(void)    { return base + LAYOUT_KB_LBA; }

u32 layout_region_sectors(void)
{
    return LAYOUT_KB_LBA + LAYOUT_KB_SECTORS;
}

void layout_report(void)
{
    klog("LAYOUT", "base LBA %u: blobs at %u, store at %u, .sidwa at %u",
         base, layout_blob_lba(), layout_store_lba(), layout_kb_lba());
}

void layout_install_report(void)
{
    u32 region = layout_region_sectors();
    klog("INSTALL", "SidwaOS needs %u sectors (%u KiB) of contiguous space",
         region, region / 2);
    klog("INSTALL", "on this disk that is LBA %u..%u",
         base, base + region - 1);
    klog("INSTALL", "the wizard in tools/install.py can take the whole disk,");
    klog("INSTALL", "use free space, or shrink a partition to make room");
}
