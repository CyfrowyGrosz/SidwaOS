/* Loop 2 (HOLD): the data loop.
 *
 * Application data is parked in a ring buffer ("hung") until a consumer takes
 * it. Each item then goes through the logic test; failures are dropped and
 * logged, passes are marked LOGIC_OK and queued for Loop 3.
 */

#include "state.h"
#include "serial.h"
#include "string.h"

#define HOLD_CAPACITY 8

struct hold_item {
    struct app_blob blob;
    u8 used;
};

static struct hold_item ring[HOLD_CAPACITY];
static u32 head;
static u32 tail;
static u32 count;

/* Park (hang) a blob in the ring buffer. Returns 0 if the buffer is full. */
int hold_push(const struct app_blob *blob)
{
    if (count == HOLD_CAPACITY) {
        return 0;
    }
    ring[tail].blob = *blob;
    ring[tail].used = 1;
    tail = (tail + 1) % HOLD_CAPACITY;
    count++;
    return 1;
}

u32 hold_count(void) { return count; }

/* Take the next parked blob. Returns 0 when the buffer is empty. */
static int hold_pop(struct app_blob *out)
{
    if (count == 0) {
        return 0;
    }
    *out = ring[head].blob;
    ring[head].used = 0;
    head = (head + 1) % HOLD_CAPACITY;
    count--;
    return 1;
}

void loop_hold(void)
{
    struct state_stats *stats = state_stats_get();
    struct app_blob blob;

    while (hold_pop(&blob)) {
        if (app_logic_test(&blob)) {
            klog("HOLD", "logic test PASS (size=%u checksum=0x%x)",
                 blob.header.size, blob.header.checksum);
            hold_submit(&blob);
            stats->hold_passed++;
        } else {
            klog("HOLD", "logic test FAIL: %s", app_last_error());
            stats->hold_failed++;
        }
    }
}
