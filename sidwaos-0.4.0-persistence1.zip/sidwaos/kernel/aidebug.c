/* AI auto-debug implementation. See include/aidebug.h.
 *
 * A fault handler is the worst possible place to call complex code: the stack
 * may be unusable and memory may be corrupt. Everything here therefore works on
 * fixed static tables and prints through the serial port directly, with no
 * allocation and no reliance on the heap.
 */

#include "aidebug.h"
#include "interrupts.h"
#include "serial.h"
#include "string.h"
#include "actions.h"
#include "ai.h"

struct fault_class {
    u32 int_no;
    const char *cause;
    const char *fix;
    int recoverable;
};

/* Cause and repair for each exception the kernel can raise. `recoverable` marks
 * the faults the kernel knows how to step over. */
static const struct fault_class fault_table[] = {
    { 0,  "divide by zero",
          "guard the divisor; check the operand is non-zero", 1 },
    { 6,  "invalid opcode",
          "the code path is wrong or data was executed as code; verify the "
          "fragment entry pointer", 1 },
    { 8,  "double fault",
          "the first fault could not be handled; check the IDT gates and the "
          "stack pointer", 0 },
    { 13, "general protection fault",
          "a segment or selector is invalid; check the GDT and the data "
          "segment in use", 0 },
    { 14, "page fault",
          "the address is unmapped or the page is not present; check the "
          "faulting address against the identity map", 0 },
    { 16, "x87 floating-point",
          "the FPU is not enabled; set CR0.EM/TS correctly", 0 },
    { 17, "alignment check",
          "an unaligned access reached a 64-bit operand; align the buffer", 1 },
    { 0xFFFFFFFF, "unclassified fault",
          "no known cause; capture the register dump and inspect eip", 0 },
};
#define FAULT_CLASS_COUNT (sizeof(fault_table) / sizeof(fault_table[0]))

/* Counters, indexed to match fault_table. */
static struct fault_record records[FAULT_CLASS_COUNT];
static u32 episodes;
static u32 recovered;
static u32 fatal;

static const struct fault_class *classify(u32 int_no)
{
    for (u32 i = 0; i < FAULT_CLASS_COUNT; i++) {
        if (fault_table[i].int_no == int_no) {
            return &fault_table[i];
        }
    }
    return &fault_table[FAULT_CLASS_COUNT - 1];   /* unclassified */
}

static u32 index_of(const struct fault_class *c)
{
    return (u32)(c - fault_table);
}

/* Recovery. Only faults whose cause is a bad value, not a broken machine, can be
 * resumed: the handler skips the faulting instruction by advancing eip, which is
 * enough for a divide-by-zero or a deliberately trapped opcode. */
static int try_recover(const struct fault_class *c, struct regs *r)
{
    if (!c->recoverable || !r) {
        return 0;
    }

    /* The faulting instruction is not decoded, so the skip length is taken from
     * the exception: a divide-by-zero is a 2-byte `div`, an invalid opcode a
     * 2-byte `ud2`. Both are stepped over the same way. */
    u32 skip = 2;

    klog("AIDBG", "recovery: skipping %u byte(s) at eip=0x%x, resuming",
         skip, r->eip);
    r->eip += skip;
    return 1;
}

int aidebug_handle_fault(void *regs_ptr)
{
    struct regs *r = (struct regs *)regs_ptr;
    u32 int_no = r ? r->int_no : 0xFFFFFFFF;
    const struct fault_class *c = classify(int_no);

    episodes++;
    records[index_of(c)].cause = c->cause;
    records[index_of(c)].fix = c->fix;
    records[index_of(c)].count++;
    records[index_of(c)].last_int_no = int_no;
    records[index_of(c)].last_eip = r ? r->eip : 0;

    /* Raw machine state first: everything after this is interpretation. */
    klog("AIDBG", "fault vector %u at eip=0x%x err=0x%x",
         int_no, r ? r->eip : 0, r ? r->err_code : 0);
    klog("AIDBG", "cause: %s", c->cause);
    klog("AIDBG", "fix:   %s", c->fix);
    if (records[index_of(c)].count > 1) {
        klog("AIDBG", "this fault has occurred %u time(s)",
             records[index_of(c)].count);
    }

    /* Publish on the AI channel so a host agent can see it too. */
    serial_putc('\x01');
    serial_puts("AI fault ");
    serial_puts(c->cause);
    serial_puts(" eip=0x");
    serial_hex(r ? r->eip : 0);
    serial_putc('\n');

    if (try_recover(c, r)) {
        recovered++;
        klog("AIDBG", "recovered, kernel continues");
        return 1;
    }

    fatal++;
    klog("AIDBG", "unrecoverable; kernel halted");
    return 0;
}

void aidebug_dump(void)
{
    u32 seen = 0;

    for (u32 i = 0; i < FAULT_CLASS_COUNT; i++) {
        if (records[i].count > 0) {
            seen++;
        }
    }
    klog("AIDBG", "%u fault class(es) seen", seen);

    for (u32 i = 0; i < FAULT_CLASS_COUNT; i++) {
        if (records[i].count == 0) {
            continue;
        }
        klog("AIDBG", "  cause=%s count=%u last_eip=0x%x",
             records[i].cause, records[i].count, records[i].last_eip);
    }
}

void aidebug_stats(void)
{
    klog("AIDBG", "episodes=%u recovered=%u fatal=%u",
         episodes, recovered, fatal);
}

/* Feed the classifier synthetic faults and check each maps to the intended
 * cause. This runs the real classify() path, not a copy of it. */
int aidebug_selftest(void)
{
    struct {
        u32 int_no;
        const char *cause;
    } cases[] = {
        { 0,  "divide by zero" },
        { 6,  "invalid opcode" },
        { 8,  "double fault" },
        { 13, "general protection fault" },
        { 14, "page fault" },
        { 17, "alignment check" },
        { 200, "unclassified fault" },
    };

    for (u32 i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
        const struct fault_class *c = classify(cases[i].int_no);
        if (strcmp(c->cause, cases[i].cause) != 0) {
            return 0;
        }
    }
    return 1;
}
