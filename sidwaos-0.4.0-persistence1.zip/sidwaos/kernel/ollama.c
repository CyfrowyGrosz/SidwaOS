/* Talk to a language model served by Ollama on the host. See include/ollama.h.
 *
 * Three steps:
 *
 *   build     one JSON object: the model name, the prompt, stream=false
 *   post      it to /api/generate and read the reply body
 *   extract   pull the "response" field out of that reply
 *
 * The POST goes through net_http_post_json(), so the whole of the TCP and HTTP
 * work is in net.c and this module only deals with JSON. That split is why the
 * network-free parts below -- building the body and reading the reply -- are
 * separate functions: they are the parts with the logic worth testing, and they
 * run in the selftest with no network at all.
 *
 * The reply is parsed by hand. A general JSON parser is a lot of code to carry
 * for one field, and the shape of the reply is known: a flat object whose
 * "response" value is a string. So the scanner looks for the key and copies the
 * string that follows, handling the escapes the model actually emits -- newline,
 * quote, backslash -- and stopping at the closing quote.
 *
 * Nothing here writes to disk. An answer becomes knowledge only through
 * know_remember(), which holds it unverified until a second answer agrees.
 */

#include "ollama.h"
#include "net.h"
#include "know.h"
#include "serial.h"
#include "string.h"

/* --- Counters -------------------------------------------------------------- */

static u32 asks;
static u32 ok_count;
static u32 learned_count;
static int last_stored;
static char last_answer[OLLAMA_ANSWER_MAX];

static char endpoint[128] = OLLAMA_DEFAULT_URL;
static char model[64] = OLLAMA_DEFAULT_MODEL;

u32 ollama_asks(void) { return asks; }
u32 ollama_ok(void) { return ok_count; }
u32 ollama_learned(void) { return learned_count; }

/* --- The thinking indicator ------------------------------------------------ */

/* What the wait is for, kept so a tick can name it without the caller passing
 * it again every second. */
static const char *thinking_what;
static u32 thinking_seconds;
static int thinking_open;

void ollama_thinking_begin(const char *what)
{
    thinking_what = what ? what : "the model";
    thinking_seconds = 0;
    thinking_open = 1;

    /* The opening line ends in a newline, so it survives in the log as the
     * record that the machine was asked and started thinking. The per-second
     * updates that follow overwrite themselves on one line instead. */
    klog("OLLAMA", "thinking: %s ...", thinking_what);
}

void ollama_thinking_tick(u32 elapsed_ticks)
{
    if (!thinking_open) {
        return;
    }
    u32 secs = elapsed_ticks / 100;
    if (secs == thinking_seconds) {
        return;
    }
    thinking_seconds = secs;

    /* A carriage return returns to the start of the line without advancing, so
     * each second replaces the last on a terminal and in the GUI log. It goes
     * through kprintf() rather than klog() on purpose: klog() brackets a tag
     * and appends a newline, which is right for an event and wrong for a
     * spinner, and would bury the log in one line per second of waiting. */
    kprintf("\r[OLLAMA] thinking: %s ... %us ", thinking_what, secs);
}

void ollama_thinking_end(void)
{
    if (!thinking_open) {
        return;
    }
    thinking_open = 0;

    /* Clear the spinner line and leave the cursor at its start, so whatever is
     * logged next is not appended to a half-written line of dots. */
    kprintf("\r                                                              \r");
}

/* --- Selftest capture ------------------------------------------------------ */

/* Collects the indicator's bytes so the selftest can assert on them without a
 * terminal. Small on purpose: the indicator writes a few dozen bytes, and a
 * capture that cannot overflow needs no bounds argument. */
static char thinking_buf[256];
static u32 thinking_captured;

static void thinking_capture(char c)
{
    if (thinking_captured + 1 < sizeof(thinking_buf)) {
        thinking_buf[thinking_captured++] = c;
    }
}

void ollama_set_endpoint(const char *url, const char *m)
{
    if (url && *url) {
        u32 i = 0;
        while (url[i] && i + 1 < sizeof(endpoint)) {
            endpoint[i] = url[i];
            i++;
        }
        endpoint[i] = '\0';
    }
    if (m && *m) {
        u32 i = 0;
        while (m[i] && i + 1 < sizeof(model)) {
            model[i] = m[i];
            i++;
        }
        model[i] = '\0';
    }
}

const char *ollama_endpoint(void) { return endpoint; }
const char *ollama_model(void) { return model; }

/* --- Building the request --------------------------------------------------- */

/* Append `s` to `out` at `*n`, escaping what JSON requires inside a string.
 * Returns 0 when the buffer is full, so the caller can stop rather than
 * produce a truncated request the server would reject. */
static int json_append_string(char *out, u32 max, u32 *n, const char *s)
{
    for (const char *p = s; *p; p++) {
        char c = *p;
        if (c == '"' || c == '\\') {
            if (*n + 2 >= max) {
                return 0;
            }
            out[(*n)++] = '\\';
            out[(*n)++] = c;
        } else if (c == '\n') {
            if (*n + 2 >= max) {
                return 0;
            }
            out[(*n)++] = '\\';
            out[(*n)++] = 'n';
        } else if (c == '\r') {
            if (*n + 2 >= max) {
                return 0;
            }
            out[(*n)++] = '\\';
            out[(*n)++] = 'r';
        } else if (c == '\t') {
            if (*n + 2 >= max) {
                return 0;
            }
            out[(*n)++] = '\\';
            out[(*n)++] = 't';
        } else {
            if (*n + 1 >= max) {
                return 0;
            }
            out[(*n)++] = c;
        }
    }
    out[*n] = '\0';
    return 1;
}

/* Build the /api/generate request body for `question` into `out`.
 * Network-free, so the selftest can check it directly. Returns the length, or
 * -1 when the buffer is too small. */
static int build_body(const char *question, char *out, u32 max)
{
    u32 n = 0;
    out[0] = '\0';

#define LIT(s) \
    do { \
        for (const char *q = (s); *q; q++) { \
            if (n + 1 >= max) { return -1; } \
            out[n++] = *q; \
        } \
        out[n] = '\0'; \
    } while (0)

    LIT("{\"model\":\"");
    if (!json_append_string(out, max, &n, model)) {
        return -1;
    }
    /* A short answer is a useful cache record; the models otherwise write a
     * paragraph, and the cache holds 240 characters. Asking for one sentence
     * makes what is stored the definition rather than its first clause. */
    LIT("\",\"system\":\"Answer in one short sentence.\",\"prompt\":\"");
    if (!json_append_string(out, max, &n, question)) {
        return -1;
    }
    /* stream=false is the important one: without it the reply is a sequence of
     * JSON objects, one per token, and the kernel would have to reassemble the
     * text from all of them.
     *
     * temperature=0 is the second. The knowledge cache stores a fact only once
     * two answers agree, so a model that rephrases itself every time can never
     * corroborate anything -- the machine would ask forever and learn nothing.
     * Pinning the sampler makes the same question produce the same answer. */
    LIT("\",\"stream\":false,\"options\":{\"temperature\":0}}");

#undef LIT

    return (int)n;
}

/* --- Reading the reply ------------------------------------------------------ */

/* Find the "response" field in a JSON object and copy its string value into
 * `out`. Returns the length, or -1 when the field is absent or empty.
 *
 * A minimal scanner, deliberately. It assumes the top-level object is flat,
 * which the generate reply is. */
static int extract_response(const char *json, char *out, u32 max)
{
    const char *p = strstr(json, "\"response\"");
    if (!p) {
        return -1;
    }
    p += 10;                    /* past the key */
    while (*p == ' ' || *p == '\t' || *p == ':') {
        p++;
    }
    if (*p != '"') {
        return -1;
    }
    p++;

    u32 n = 0;
    while (*p && *p != '"') {
        char c = *p;
        if (c == '\\') {
            p++;
            switch (*p) {
            case 'n': c = '\n'; break;
            case 'r': c = '\r'; break;
            case 't': c = '\t'; break;
            case '"': c = '"';  break;
            case '\\': c = '\\'; break;
            case '/': c = '/';  break;
            case 'u':
                /* Skip the four hex digits; the models in use answer in ASCII
                 * and a real decoder is not worth carrying for the rare case. */
                for (int k = 0; k < 4 && p[1]; k++) {
                    p++;
                }
                c = '?';
                break;
            default: c = *p; break;
            }
        }
        if (n + 1 < max) {
            out[n++] = c;
        }
        p++;
    }
    out[n] = '\0';
    return n ? (int)n : -1;
}

/* Collapse runs of whitespace and drop a leading "Answer:" style prefix, so the
 * stored value is one clean line. */
static void tidy(char *s)
{
    /* Trim leading space. */
    char *p = s;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') {
        p++;
    }
    if (p != s) {
        char *d = s;
        while (*p) {
            *d++ = *p++;
        }
        *d = '\0';
    }

    /* Collapse internal runs to single spaces and trim the end. */
    char *d = s;
    char *q = s;
    int space = 0;
    while (*q) {
        if (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r') {
            space = 1;
        } else {
            if (space && d != s) {
                *d++ = ' ';
            }
            space = 0;
            *d++ = *q;
        }
        q++;
    }
    *d = '\0';
}

/* --- Asking ----------------------------------------------------------------- */

int ollama_ask(const char *question, char *out, u32 max)
{
    if (!question || !*question) {
        return -1;
    }
    if (!net_ready() && !net_init()) {
        klog("OLLAMA", "no network interface");
        return -1;
    }

    char body[OLLAMA_ANSWER_MAX + 256];
    if (build_body(question, body, sizeof(body)) < 0) {
        klog("OLLAMA", "question too long to encode");
        return -1;
    }

    static char reply[4096];
    asks++;
    klog("OLLAMA", "asking %s about '%s'", model, question);
    int len = net_http_post_json(endpoint, body, reply, sizeof(reply), 0, 0);
    if (len < 0) {
        klog("OLLAMA", "no reply from %s", endpoint);
        return -1;
    }

    static char answer[OLLAMA_ANSWER_MAX];
    int n = extract_response(reply, answer, sizeof(answer));
    if (n < 0) {
        klog("OLLAMA", "reply held no answer (%d bytes)", len);
        return -1;
    }
    tidy(answer);

    /* Trim to the cache's field size before anything else looks at it. The
     * cache stores KNOW_VALUE_MAX characters, so comparing a longer string
     * against a stored one would compare a 862-character answer with a
     * 240-character record and never match -- corroboration would be
     * impossible for any answer that did not happen to fit. */
    if (strlen(answer) >= KNOW_VALUE_MAX) {
        u32 cut = KNOW_VALUE_MAX - 1;
        while (cut > 0 && answer[cut] != ' ') {
            cut--;
        }
        answer[cut ? cut : KNOW_VALUE_MAX - 1] = '\0';
    }

    u32 k = 0;
    while (answer[k] && k + 1 < max) {
        out[k] = answer[k];
        k++;
    }
    out[k] = '\0';

    u32 j = 0;
    while (out[j] && j + 1 < sizeof(last_answer)) {
        last_answer[j] = out[j];
        j++;
    }
    last_answer[j] = '\0';

    ok_count++;
    return (int)k;
}

/* Build the request body for a code request. Same shape as build_body(), but
 * with a system prompt that asks for a program and without the instruction to
 * keep it to one sentence. `max` must be generous: the prompt carries the whole
 * instruction set. */
static int build_code_body(const char *prompt, char *out, u32 max)
{
    u32 n = 0;
    out[0] = '\0';

#define LIT(s) \
    do { \
        for (const char *q = (s); *q; q++) { \
            if (n + 1 >= max) { return -1; } \
            out[n++] = *q; \
        } \
        out[n] = '\0'; \
    } while (0)

    LIT("{\"model\":\"");
    if (!json_append_string(out, max, &n, model)) {
        return -1;
    }
    /* Only the program text, with no commentary: anything else the model adds
     * has to be stripped before assembly, and stripping is guesswork. */
    LIT("\",\"system\":\"You write programs in SidwaASM. Reply with the"
        " program text only, no explanation, no markdown fences.\",\"prompt\":\"");
    if (!json_append_string(out, max, &n, prompt)) {
        return -1;
    }
    /* temperature=0 for the same reason as the fact path, and one more: a
     * program that is only sometimes right is not something the machine can
     * build on. Pinning the sampler makes a task that works keep working. */
    LIT("\",\"stream\":false,\"options\":{\"temperature\":0}}");

#undef LIT

    return (int)n;
}

/* Keep only the program from a model's reply.
 *
 * The system prompt asks for bare program text, but models fence code anyway.
 * Everything before the first fence or the first instruction-looking line is
 * dropped, as is everything from the closing fence. Done in place. */
static void strip_program(char *s)
{
    /* A fenced block: keep what is between the first pair of fences. */
    char *open = strstr(s, "```");
    if (open) {
        open += 3;
        /* Skip a language tag on the same line, e.g. ```asm. */
        while (*open && *open != '\n') {
            open++;
        }
        if (*open == '\n') {
            open++;
        }
        char *close = strstr(open, "```");
        if (close) {
            *close = '\0';
        }
        if (open != s) {
            char *d = s;
            for (char *p = open; *p; p++) {
                *d++ = *p;
            }
            *d = '\0';
        }
    }

    /* Drop any leading blank lines. */
    char *p = s;
    while (*p == '\n' || *p == '\r' || *p == ' ') {
        p++;
    }
    if (p != s) {
        char *d = s;
        while (*p) {
            *d++ = *p++;
        }
        *d = '\0';
    }
}

int ollama_ask_code(const char *prompt, char *out, u32 max)
{
    if (!prompt || !*prompt) {
        return -1;
    }
    if (!net_ready() && !net_init()) {
        klog("OLLAMA", "no network interface");
        return -1;
    }

    /* Static, not automatic: the prompt holds the instruction set and the reply
     * holds a program, and both are far larger than a fact. The kernel stack is
     * small enough that a buffer this size must not go on it. */
    static char body[OLLAMA_CODE_MAX + 512];
    if (build_code_body(prompt, body, sizeof(body)) < 0) {
        klog("OLLAMA", "prompt too long to encode");
        return -1;
    }

    static char reply[OLLAMA_CODE_MAX + 1024];
    asks++;
    klog("OLLAMA", "asking %s to write a program", model);
    /* A language model computes the whole reply before sending the first byte,
     * so with stream:false a working request can sit silent for tens of
     * seconds. A program is also longer than a sentence, which makes it slower
     * again. Measured on qwen2.5:3b, a program request took about 45 s, well
     * past the 30 s ceiling a web request gets by default -- which is why this
     * path asks for its own budget rather than reusing it. The idle window is
     * generous for the same reason: silence here means "still thinking", not
     * "gone away". */
    ollama_thinking_begin("the model");
    int len = net_http_post_json_progress(endpoint, body, reply, sizeof(reply),
                                          0, 0,
                                          OLLAMA_CODE_CEILING_TICKS,
                                          OLLAMA_CODE_IDLE_TICKS,
                                          ollama_thinking_tick);
    ollama_thinking_end();
    if (len < 0) {
        klog("OLLAMA", "no reply from %s", endpoint);
        return -1;
    }

    /* Extracted into `out` directly: unlike the fact path there is no tidying
     * and no trimming to the cache's field size, because the newlines and the
     * length are the program. */
    int n = extract_response(reply, out, max);
    if (n < 0) {
        klog("OLLAMA", "reply held no program (%d bytes)", len);
        return -1;
    }
    strip_program(out);

    if (!*out) {
        return -1;
    }
    ok_count++;
    return (int)strlen(out);
}

int ollama_learn(const char *question, char *out, u32 max)
{
    last_stored = 0;
    int n = ollama_ask(question, out, max);
    if (n < 0) {
        return -1;
    }

    /* The corroboration rule, the same one ai.c applies to an answer from the
     * serial bridge: an answer is not knowledge on its own. If the cache
     * already holds a candidate for this question and it matches what the model
     * just said, that agreement is corroboration and the fact is stored on
     * .sidwa. Otherwise the answer merely replaces the candidate in RAM, still
     * unverified. Without this step `learn` could only ever hold, never store,
     * and the machine could never answer by itself. */
    char held[KNOW_VALUE_MAX];
    if (know_peek_ram(question, held, sizeof(held)) >= 0
        && strcmp(held, out) == 0) {
        know_verify(question);
        last_stored = 1;
        learned_count++;
        return n;
    }

    know_remember(question, out);
    learned_count++;
    return n;
}

int ollama_last_stored(void) { return last_stored; }

/* --- Reporting -------------------------------------------------------------- */

void ollama_report(void)
{
    klog("OLLAMA", "endpoint %s", endpoint);
    klog("OLLAMA", "model %s", model);
    klog("OLLAMA", "asks %u, answered %u, offered to the cache %u",
         asks, ok_count, learned_count);
    if (last_answer[0]) {
        klog("OLLAMA", "last answer: %s", last_answer);
    } else {
        klog("OLLAMA", "no answer yet");
    }
}

/* --- Selftest --------------------------------------------------------------- */

int ollama_selftest(void)
{
    int ok = 1;

    /* The request body must carry the model and the escaped prompt. */
    char body[512];
    if (build_body("what is a syscall?", body, sizeof(body)) < 0) {
        klog("OLLAMA", "selftest: body did not build");
        return 0;
    }
    if (!strstr(body, "\"stream\":false")) {
        klog("OLLAMA", "selftest: stream flag missing");
        ok = 0;
    }
    if (!strstr(body, "what is a syscall?")) {
        klog("OLLAMA", "selftest: prompt missing");
        ok = 0;
    }

    /* A quote in the question must be escaped, or the JSON is broken. */
    if (build_body("say \"hi\"", body, sizeof(body)) < 0
        || !strstr(body, "\\\"hi\\\"")) {
        klog("OLLAMA", "selftest: quote not escaped");
        ok = 0;
    }

    /* The reply scanner must read the field and handle the escapes. */
    char out[128];
    const char *reply = "{\"model\":\"qwen2.5\",\"response\":\"A syscall is "
                        "a request.\\nIt is handled.\",\"done\":true}";
    int n = extract_response(reply, out, sizeof(out));
    if (n < 0 || !strstr(out, "A syscall is a request.")) {
        klog("OLLAMA", "selftest: response not extracted");
        ok = 0;
    }
    tidy(out);
    if (strstr(out, "\\n")) {
        klog("OLLAMA", "selftest: escape not decoded");
        ok = 0;
    }

    /* A reply with no response field must fail rather than return junk. */
    if (extract_response("{\"error\":\"model not found\"}", out,
                         sizeof(out)) >= 0) {
        klog("OLLAMA", "selftest: missing field not detected");
        ok = 0;
    }

    /* tidy() must collapse the model's whitespace into one line. */
    char messy[64];
    const char *src = "  Hello    there \n world  ";
    u32 i = 0;
    while (src[i] && i + 1 < sizeof(messy)) {
        messy[i] = src[i];
        i++;
    }
    messy[i] = '\0';
    tidy(messy);
    if (strcmp(messy, "Hello there world") != 0) {
        klog("OLLAMA", "selftest: tidy produced '%s'", messy);
        ok = 0;
    }

    /* The thinking indicator must rewrite one line rather than append a new one
     * per second, must print the elapsed seconds, and must not emit a newline
     * until it is done -- a newline per tick is exactly the log flood it exists
     * to avoid. Checked by capturing what it writes. */
    console_set_sink(thinking_capture);
    thinking_captured = 0;
    ollama_thinking_begin("the model");
    ollama_thinking_tick(0);
    ollama_thinking_tick(100);
    ollama_thinking_tick(300);
    ollama_thinking_end();
    console_set_sink(0);

    thinking_buf[thinking_captured < sizeof(thinking_buf)
                 ? thinking_captured : sizeof(thinking_buf) - 1] = '\0';
    /* Only the begin line is allowed to end in a newline. */
    if (!strstr(thinking_buf, "\n")) {
        klog("OLLAMA", "selftest: thinking printed no opening line");
        ok = 0;
    }
    if (!strstr(thinking_buf, "3s")) {
        klog("OLLAMA", "selftest: thinking did not show elapsed seconds");
        ok = 0;
    }
    if (!strstr(thinking_buf, "\r")) {
        klog("OLLAMA", "selftest: thinking did not rewrite in place");
        ok = 0;
    }

    klog("OLLAMA", "selftest: %s", ok ? "pass" : "FAIL");
    return ok;
}
