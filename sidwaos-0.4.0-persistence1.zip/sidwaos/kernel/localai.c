/* Local self-learning AI. See include/localai.h.
 *
 * A linear classifier over hashed request tokens. Each action has its own
 * weight vector, and the model learns by the puzzle-weight rule:
 *
 *     for every active feature f:
 *         w[label][f] += lr
 *         w[guessed][f] -= lr
 *
 * where `guessed` is whatever the model predicted. One pass over the training
 * examples therefore fixes any confusion between two actions, because the
 * update pushes the correct action's weights up and the wrong one's down by the
 * same amount. Weights are clamped to the signed range of the current grade's
 * precision, which is what makes the grade a real capacity setting: at 8 bits a
 * weight saturates after a handful of steps, so the model stays coarse.
 *
 * There is no heap and no libgcc, so the weight store is a fixed array and all
 * arithmetic is 32-bit.
 */

#include "localai.h"
#include "kb.h"
#include "serial.h"
#include "string.h"
#include "actions.h"

/* --- Model shape, driven by the partition grade ---------------------------- */

struct grade_shape {
    u32 weight_bits;    /* precision per weight */
    u32 features;       /* feature slots */
    u32 learning_rate;  /* added to / subtracted from a weight per step */
};

static const struct grade_shape shapes[4] = {
    { 0, 0, 0 },                 /* index 0 unused */
    { 8,  8,  4 },               /* grade 1: coarse */
    { 12, 16, 6 },               /* grade 2: medium */
    { 16, 32, 8 },               /* grade 3: fine */
};

/* Weight storage is sized for the finest grade; lower grades use a prefix. */
static i32 weights[LAI_ACTIONS][LAI_FEATURES_MAX];
static const char *labels[LAI_ACTIONS];
static u32 label_count;

static u32 current_grade = 1;
static u32 shape_weight_bits = 8;
static u32 shape_features = 8;
static u32 shape_lr = 4;

static u32 examples;
static u32 mistakes;

u32 localai_examples(void) { return examples; }

u32 localai_mistakes(void) { return mistakes; }
u32 localai_weight_bits(void) { return shape_weight_bits; }
u32 localai_feature_count(void) { return shape_features; }

/* --- Labels ---------------------------------------------------------------- */

static void init_labels(void)
{
    if (label_count) {
        return;
    }
    labels[label_count++] = "run";
    labels[label_count++] = "hold";
    labels[label_count++] = "store";
    labels[label_count++] = "status";
    labels[label_count++] = "cycle";
    labels[label_count++] = "cache";
    labels[label_count++] = "bitflow";
    labels[label_count++] = "combine";
    labels[label_count++] = "pack";
    labels[label_count++] = "debug";
    labels[label_count++] = "version";
    labels[label_count++] = "halt";
}

static int label_index(const char *name)
{
    for (u32 i = 0; i < label_count; i++) {
        if (strcmp(labels[i], name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

/* --- Features --------------------------------------------------------------
 *
 * A token maps to one of `features` slots by summing its bytes. Collisions are
 * expected and harmless: several related words landing in the same slot just
 * means they share a weight, which is what makes a small model work at all.
 */

static u32 feature_of(const char *token)
{
    u32 h = 0;
    for (const char *p = token; *p; p++) {
        h = h * 31u + (u8)*p;
    }
    return h % shape_features;
}

/* Extract up to LAI_FEATURES_MAX distinct feature slots from `text`. */
static u32 features_of(const char *text, u32 *out)
{
    u32 n = 0;
    char token[24];
    u32 tlen = 0;

    for (const char *p = text; ; p++) {
        char c = *p;
        if (c && c != ' ' && c != '\t' && c != '\n') {
            if (tlen + 1 < sizeof(token)) {
                token[tlen++] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
            }
            continue;
        }
        if (tlen) {
            token[tlen] = '\0';
            u32 f = feature_of(token);
            int dup = 0;
            for (u32 i = 0; i < n; i++) {
                if (out[i] == f) {
                    dup = 1;
                    break;
                }
            }
            if (!dup && n < LAI_FEATURES_MAX) {
                out[n++] = f;
            }
            tlen = 0;
        }
        if (!c) {
            break;
        }
    }
    return n;
}

/* --- Scoring and learning --------------------------------------------------- */

static void quantise(i32 *w)
{
    i32 lo = -(1 << (shape_weight_bits - 1));
    i32 hi = (1 << (shape_weight_bits - 1)) - 1;

    if (*w < lo) {
        *w = lo;
    } else if (*w > hi) {
        *w = hi;
    }
}

static int best_label(const u32 *features, u32 n)
{
    int best = 0;
    i32 best_score = 0;

    for (u32 a = 0; a < label_count; a++) {
        i32 score = 0;
        for (u32 i = 0; i < n; i++) {
            score += weights[a][features[i]];
        }
        if (a == 0 || score > best_score) {
            best = (int)a;
            best_score = score;
        }
    }
    return best;
}

static int train_features(const u32 *features, u32 n, int want)
{
    int guess = best_label(features, n);
    if (guess == want) {
        examples++;
        return 1;
    }

    for (u32 i = 0; i < n; i++) {
        u32 f = features[i];
        weights[want][f] += (i32)shape_lr;
        weights[guess][f] -= (i32)shape_lr;
        quantise(&weights[want][f]);
        quantise(&weights[guess][f]);
    }

    examples++;
    mistakes++;
    return 0;
}

int localai_train(const char *text, const char *label)
{
    init_labels();

    int want = label_index(label);
    if (want < 0 || !text) {
        return 0;
    }

    u32 features[LAI_FEATURES_MAX];
    u32 n = features_of(text, features);
    if (n == 0) {
        return 0;
    }
    return train_features(features, n, want);
}

const char *localai_predict(const char *text)
{
    init_labels();

    u32 features[LAI_FEATURES_MAX];
    u32 n = features_of(text, features);
    if (n == 0) {
        return "status";
    }

    /* Only answer from the model when something actually scored. An all-zero
     * model must not silently swallow a request. */
    int best = 0;
    i32 best_score = 0;
    for (u32 a = 0; a < label_count; a++) {
        i32 score = 0;
        for (u32 i = 0; i < n; i++) {
            score += weights[a][features[i]];
        }
        if (score > best_score) {
            best = (int)a;
            best_score = score;
        }
    }
    if (best_score <= 0) {
        return 0;
    }
    return labels[best];
}

u32 localai_action_count(void)
{
    init_labels();
    return label_count;
}

const char *localai_action_name(u32 index)
{
    init_labels();
    return index < label_count ? labels[index] : 0;
}

/* The model's raw score for one action. Positive means the model leans that
 * way, zero means it has no opinion. Exposed so a caller can weigh the model
 * against other evidence instead of taking its single best answer on trust. */
i32 localai_score(const char *text, const char *label)
{
    init_labels();

    int want = label_index(label);
    if (want < 0 || !text) {
        return 0;
    }

    u32 features[LAI_FEATURES_MAX];
    u32 n = features_of(text, features);

    i32 score = 0;
    for (u32 i = 0; i < n; i++) {
        score += weights[want][features[i]];
    }
    return score;
}

int localai_act(const char *text)
{
    const char *action = localai_predict(text);
    if (!action) {
        return 0;
    }

    if (actions_dispatch(action, 0) == ACTION_UNKNOWN) {
        return 0;
    }
    return 1;
}

/* --- Persistence ------------------------------------------------------------ */

/* Serialised model, split across as many records as it needs. The partition
 * grade sets the precision, so the model grows as the grade rises: grade 1
 * needs one record, grade 3 needs two. Each record carries a chunk header, and
 * the parts are appended in order so the loader can stitch them back.
 *
 * Storing 8-bit weights instead would always fit in one record, but then the
 * grade would only affect inference and not what is kept on disk. Splitting
 * keeps the grade meaningful: a finer model really does persist more bits. */
struct model_header {
    char magic[8];
    u32 version;
    u32 grade;           /* the partition grade this model was trained at */
    u32 weight_bits;
    u32 features;
    u32 label_count;
    u32 examples;
    u32 mistakes;
} __attribute__((packed));

struct model_chunk {
    char magic[8];
    u32 version;
    u32 grade;           /* which grade's model this chunk belongs to */
    u32 part;
    u32 parts;
} __attribute__((packed));

#define MODEL_MAGIC    "SIDWAAI1"
#define MODEL_VERSION  1u
#define MODEL_MAX_PARTS 16   /* grade 3 needs 9; leave headroom */

/* Chunk size is fixed at the smallest slot any grade offers, so a model record
 * always fits whichever grade the partition is at. That matters because
 * kb_set_grade() rewrites the partition and drops records too large for the new
 * slot: chunking at the smallest slot keeps the model portable across a grade
 * change instead of losing it. A higher grade still persists more bytes overall,
 * because it stores more features and so more chunks. */
static u32 model_chunk_max(void)
{
    u32 slot = KB_GRADE3_DATA;
    if (slot <= sizeof(struct model_chunk)) {
        return 0;
    }
    return slot - (u32)sizeof(struct model_chunk);
}

int localai_save(void)
{
    struct model_header mh;
    static u8 full[sizeof(struct model_header)
                    + sizeof(i16) * LAI_ACTIONS * LAI_FEATURES_MAX];
    static u8 part[KB_DATA_MAX];

    init_labels();

    for (u32 i = 0; i < 8; i++) {
        mh.magic[i] = MODEL_MAGIC[i];
    }
    mh.version = MODEL_VERSION;
    mh.grade = current_grade;
    mh.weight_bits = shape_weight_bits;
    mh.features = shape_features;
    mh.label_count = label_count;
    mh.examples = examples;
    mh.mistakes = mistakes;

    u32 weight_bytes = sizeof(i16) * label_count * shape_features;
    u32 total = (u32)sizeof(mh) + weight_bytes;

    memcpy(full, &mh, sizeof(mh));
    i16 *dst = (i16 *)(full + sizeof(mh));
    for (u32 a = 0; a < label_count; a++) {
        for (u32 f = 0; f < shape_features; f++) {
            dst[a * shape_features + f] = (i16)weights[a][f];
        }
    }

    u32 chunk = model_chunk_max();
    if (chunk == 0) {
        klog("AI", "partition slot too small for a model record");
        return 0;
    }
    u32 parts = (total + chunk - 1) / chunk;
    if (parts == 0 || parts > MODEL_MAX_PARTS) {
        klog("AI", "model needs %u records, more than one save supports", parts);
        return 0;
    }
    for (u32 p = 0; p < parts; p++) {
        u32 off = p * chunk;
        u32 len = total - off;
        if (len > chunk) {
            len = chunk;
        }

        struct model_chunk ch;
        memcpy(ch.magic, MODEL_MAGIC, 8);
        ch.version = MODEL_VERSION;
        ch.grade = current_grade;
        ch.part = p;
        ch.parts = parts;

        memset(part, 0, sizeof(part));
        memcpy(part, &ch, sizeof(ch));
        memcpy(part + sizeof(ch), full + off, len);

        if (kb_append(part, (u32)sizeof(ch) + len) < 0) {
            klog("AI", "could not save model part %u to .sidwa", p);
            return 0;
        }
    }

    klog("AI", "weights saved to .sidwa: %u part(s), %u bytes, %u-bit",
         parts, total, shape_weight_bits);
    return 1;
}

int localai_load(void)
{
    static u8 blob[KB_DATA_MAX];
    static u8 full[sizeof(struct model_header)
                   + sizeof(i16) * LAI_ACTIONS * LAI_FEATURES_MAX];
    struct model_chunk ch;
    struct model_header mh;

    init_labels();

    /* Find the newest part 0. The scan only remembers the sequence number: the
     * buffer holds whatever was read last, which is not necessarily the model. */
    u32 cursor = 0, seq = 0, first = 0, parts = 0;
    int n;
    while ((n = kb_next(&cursor, &seq, blob, sizeof(blob))) >= 0) {
        if (n < (int)sizeof(ch)) {
            continue;
        }
        memcpy(&ch, blob, sizeof(ch));
        if (memcmp(ch.magic, MODEL_MAGIC, 8) == 0
            && ch.version == MODEL_VERSION
            && ch.grade == current_grade && ch.part == 0) {
            first = seq;
            parts = ch.parts;
        }
    }
    if (!first || parts == 0 || parts > MODEL_MAX_PARTS) {
        return 0;
    }

    /* Parts were appended in order, so their sequence numbers are consecutive. */
    u32 total = 0;
    for (u32 p = 0; p < parts; p++) {
        int len = kb_read(first + p, blob, sizeof(blob));
        if (len < (int)sizeof(ch)) {
            return 0;
        }
        memcpy(&ch, blob, sizeof(ch));
        if (memcmp(ch.magic, MODEL_MAGIC, 8) != 0
            || ch.grade != current_grade || ch.part != p) {
            return 0;
        }
        u32 payload = (u32)len - (u32)sizeof(ch);
        if (total + payload > sizeof(full)) {
            return 0;
        }
        memcpy(full + total, blob + sizeof(ch), payload);
        total += payload;
    }

    if (total < sizeof(mh)) {
        return 0;
    }
    memcpy(&mh, full, sizeof(mh));
    if (memcmp(mh.magic, MODEL_MAGIC, 8) != 0 || mh.version != MODEL_VERSION) {
        return 0;
    }

    u32 stored_features = mh.features;
    if (stored_features == 0 || stored_features > LAI_FEATURES_MAX) {
        return 0;
    }
    u32 stored_bytes = sizeof(i16) * mh.label_count * stored_features;
    if (mh.label_count > LAI_ACTIONS || sizeof(mh) + stored_bytes > total) {
        return 0;
    }

    /* A model saved at another grade has a different precision. Its weights are
     * re-quantised into the current one rather than discarded. */
    memset(weights, 0, sizeof(weights));
    const i16 *src = (const i16 *)(full + sizeof(mh));
    for (u32 a = 0; a < label_count && a < mh.label_count; a++) {
        for (u32 f = 0; f < stored_features && f < shape_features; f++) {
            weights[a][f] = src[a * stored_features + f];
            quantise(&weights[a][f]);
        }
    }

    examples = mh.examples;
    mistakes = mh.mistakes;
    klog("AI", "weights loaded: %u part(s), %u features, %u-bit",
         parts, stored_features, shape_weight_bits);
    return 1;
}

void localai_sync_grade(void)
{
    u32 grade = kb_grade();
    if (grade < 1 || grade > 3) {
        grade = 1;
    }

    current_grade = grade;
    shape_weight_bits = shapes[grade].weight_bits;
    shape_features = shapes[grade].features;
    shape_lr = shapes[grade].learning_rate;

    /* The grade sets the feature count, so a weight vector trained at one grade
     * is meaningless at another: feature 3 covers different words. Start clean
     * and let the caller restore this grade's own saved model. */
    localai_reset();
}

void localai_reset(void)
{
    memset(weights, 0, sizeof(weights));
    examples = 0;
    mistakes = 0;
}

/* --- Batch scoring --------------------------------------------------------- */

/* Score every action on `text` from a single tokenisation, written to `out`
 * in action order. Equivalent to calling localai_score() per action, but the
 * features are derived once instead of once per action, which is the whole cost
 * of scoring when the text is long and the action set is not tiny. */
void localai_scores(const char *text, i32 *out, u32 max)
{
    init_labels();

    u32 features[LAI_FEATURES_MAX];
    u32 n = text ? features_of(text, features) : 0;

    for (u32 a = 0; a < label_count && a < max; a++) {
        i32 score = 0;
        for (u32 i = 0; i < n; i++) {
            score += weights[a][features[i]];
        }
        out[a] = score;
    }
}

/* --- Self test -------------------------------------------------------------- */

/* Built-in examples: one per action, in the words a user would actually type. */
static const struct {
    const char *text;
    const char *label;
} training_set[] = {
    { "run the cpu loop now",              "run" },
    { "execute the fragment",              "run" },
    { "hold the data and test it",         "hold" },
    { "logic test the queued program",     "hold" },
    { "store the program on disk",         "store" },
    { "save it to the hdd",                "store" },
    { "show the state statistics",         "status" },
    { "what is the current status",        "status" },
    { "run all three loops",               "cycle" },
    { "do a full cycle of everything",     "cycle" },
    { "report the cpu cache",              "cache" },
    { "how much l1 is free",               "cache" },
    { "run the bitflow self tests",        "bitflow" },
    { "combine the bit flows",             "bitflow" },
    { "pack ten operations of six bits",   "pack" },
    { "debug the fault record",            "debug" },
    { "show the version",                  "version" },
    { "fetch a web page and learn from it", "fetch" },
    { "download the page and store the fact", "fetch" },
    { "halt the machine",                  "halt" },
};
#define TRAINING_COUNT (sizeof(training_set) / sizeof(training_set[0]))

/* Accuracy floor expected at each grade. A coarser grade genuinely cannot
 * separate every example: 8 features collide unrelated words, so grade 1 tops
 * out below the finer grades. That gap is the point of the grade setting, so
 * the self test asserts the floor rather than a flat 100%. */
static u32 accuracy_floor(void)
{
    switch (shape_features) {
    case 8:  return 15;      /* grade 1 */
    case 16: return 18;      /* grade 2 */
    default: return 18;      /* grade 3 */
    }
}

static u32 accuracy(void)
{
    u32 correct = 0;

    for (u32 i = 0; i < TRAINING_COUNT; i++) {
        const char *p = localai_predict(training_set[i].text);
        if (p && strcmp(p, training_set[i].label) == 0) {
            correct++;
        }
    }
    return correct;
}

int localai_selftest(void)
{
    init_labels();

    /* Train to convergence: each pass corrects whatever the last one got wrong,
     * and the loop is bounded so a non-separable example cannot spin forever.
     * The bound is set above what the finest grade needs so the coarser grades
     * also get their full chance. */
    for (u32 pass = 0; pass < 32; pass++) {
        for (u32 i = 0; i < TRAINING_COUNT; i++) {
            localai_train(training_set[i].text, training_set[i].label);
        }
    }
    return accuracy() >= accuracy_floor();
}

void localai_report(void)
{
    klog("AI", "local model: grade=%u precision=%u-bit features=%u",
         kb_grade(), shape_weight_bits, shape_features);
    klog("AI", "training steps=%u mistakes=%u", examples, mistakes);
    klog("AI", "accuracy on built-in set: %u/%u",
         accuracy(), (u32)TRAINING_COUNT);
}

/* Bytes the model occupies on disk: header plus one i16 per weight. */
u32 localai_model_bytes(void)
{
    init_labels();
    return (u32)sizeof(struct model_header)
         + (u32)sizeof(i16) * label_count * shape_features;
}
