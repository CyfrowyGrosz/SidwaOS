/* Peephole optimisation. See include/peephole.h.
 *
 * One pass builds a "keep" map over the instruction array, deciding per index
 * whether the instruction survives, and folds constants in place. A second
 * phase then rewrites every surviving instruction, mapping old addresses to new
 * through the keep map, so a jump that pointed at a removed instruction lands on
 * the next one that survived.
 *
 * The fold is the one rewrite that changes an instruction rather than dropping
 * it, so it is applied to the first of the pair and the second is dropped. That
 * keeps any jump aimed at the first instruction correct without a special case.
 *
 * A target map is built first: an instruction that any jump lands on is pinned,
 * because removing it would change where that jump goes. Pinning is what keeps
 * the local rules from breaking the global control flow.
 */

#include "peephole.h"
#include "svm.h"
#include "serial.h"
#include "string.h"

#define MAXI SASM_MAX_CODE

/* Whether `imm` is a plausible jump target: inside the program. */
static int is_target(const struct sasm_program *p, u32 addr)
{
    return addr < p->count;
}

/* A fold: MOV rX, a followed by ADD/SUB/MUL rX, b -> MOV rX, a op b.
 * Only the immediate form folds; a register or memory operand has a value that
 * is not known until run time. */
static int try_fold(const struct sasm_program *p, u32 i,
                    struct sasm_insn *merged)
{
    const struct sasm_insn *a = &p->code[i];
    const struct sasm_insn *b = &p->code[i + 1];

    if (a->op != SASM_OP_MOV || a->mode != SASM_MODE_IMM) {
        return 0;
    }
    if (b->op != SASM_OP_ADD && b->op != SASM_OP_SUB
        && b->op != SASM_OP_MUL) {
        return 0;
    }
    if (b->mode != SASM_MODE_IMM || b->dst != a->dst) {
        return 0;
    }

    u32 x = a->imm;
    u32 y = b->imm;
    u32 v;
    switch (b->op) {
    case SASM_OP_ADD: v = x + y; break;
    case SASM_OP_SUB: v = x - y; break;
    default:          v = x * y; break;
    }

    *merged = *a;
    merged->imm = v;
    return 1;
}

/* An instruction that provably does nothing. */
static int is_identity(const struct sasm_insn *in)
{
    switch (in->op) {
    case SASM_OP_ADD:
    case SASM_OP_SUB:
        return in->mode == SASM_MODE_IMM && in->imm == 0;
    case SASM_OP_MUL:
        return in->mode == SASM_MODE_IMM && in->imm == 1;
    case SASM_OP_MOV:
        /* MOV rX, rX copies a register onto itself. Only the plain register
         * form; a load or store moves data between register and memory even
         * when the two register numbers are equal. */
        return in->mode == SASM_MODE_REG && in->dst == in->src;
    default:
        return 0;
    }
}

/* One pass. Returns the number of instructions removed. */
static u32 one_pass(const struct sasm_program *in, struct sasm_program *out,
                    struct peephole_report *rep)
{
    u8 pinned[MAXI];
    u8 drop[MAXI];
    for (u32 i = 0; i < in->count; i++) {
        pinned[i] = 0;
        drop[i] = 0;
    }

    /* Anything a jump lands on is pinned. */
    for (u32 i = 0; i < in->count; i++) {
        const struct sasm_insn *ins = &in->code[i];
        if ((ins->op == SASM_OP_JMP || ins->op == SASM_OP_JZ
             || ins->op == SASM_OP_JNZ) && is_target(in, ins->imm)) {
            pinned[ins->imm] = 1;
        }
    }

    /* Fold, then drop. Fold first so the pair becomes one instruction and the
     * second is dropped in the same pass, rather than taking two. */
    struct sasm_insn folded[MAXI];
    for (u32 i = 0; i < in->count; i++) {
        folded[i] = in->code[i];
    }
    for (u32 i = 0; i + 1 < in->count; i++) {
        if (drop[i]) {
            continue;
        }
        struct sasm_insn merged;
        if (try_fold(in, i, &merged)) {
            folded[i] = merged;
            drop[i + 1] = 1;
            if (rep) {
                rep->fold_imm++;
            }
        }
    }

    /* Drop identities and jumps to the next instruction. */
    for (u32 i = 0; i < in->count; i++) {
        if (drop[i] || pinned[i]) {
            continue;
        }
        const struct sasm_insn *ins = &folded[i];
        if (is_identity(ins)) {
            drop[i] = 1;
            if (rep) {
                rep->identity++;
            }
            continue;
        }
        if (ins->op == SASM_OP_JMP && ins->imm == i + 1) {
            drop[i] = 1;
            if (rep) {
                rep->jmp_next++;
            }
        }
    }

    /* Build the old -> new address map. A dropped index maps to the next index
     * that survives, which is where control would have gone anyway. */
    u32 map[MAXI + 1];
    u32 n = 0;
    for (u32 i = 0; i < in->count; i++) {
        map[i] = n;
        if (!drop[i]) {
            n++;
        }
    }
    map[in->count] = n;

    /* Emit the survivors, rewriting jump targets through the map. */
    out->count = 0;
    out->entry = 0;
    for (u32 i = 0; i < in->count; i++) {
        if (drop[i]) {
            continue;
        }
        struct sasm_insn ins = folded[i];
        if (ins.op == SASM_OP_JMP || ins.op == SASM_OP_JZ
            || ins.op == SASM_OP_JNZ) {
            ins.imm = (ins.imm <= in->count) ? map[ins.imm] : ins.imm;
        }
        out->code[out->count++] = ins;
    }

    u32 removed = in->count - out->count;
    if (rep) {
        rep->removed += removed;
    }
    return removed;
}

u32 peephole_optimise(const struct sasm_program *in, struct sasm_program *out,
                      struct peephole_report *rep)
{
    struct peephole_report local;
    if (!rep) {
        rep = &local;
    }
    rep->fold_imm = 0;
    rep->identity = 0;
    rep->jmp_next = 0;
    rep->removed = 0;
    rep->passes = 0;

    /* Work on a copy: `out` may be `in`. */
    struct sasm_program cur = *in;
    struct sasm_program next;
    u32 total = 0;

    /* Repeat until a pass removes nothing. A fold can expose an identity that
     * was not adjacent before, so one pass is not always enough. The loop is
     * bounded by the instruction count, since every pass that continues removes
     * at least one instruction. */
    for (u32 guard = 0; guard <= in->count; guard++) {
        rep->passes++;
        u32 removed = one_pass(&cur, &next, rep);
        total += removed;
        cur = next;
        if (removed == 0) {
            break;
        }
    }

    *out = cur;
    return total;
}

void peephole_report_text(const struct peephole_report *rep,
                          u32 before, u32 after, char *out, u32 max)
{
    /* Built by hand: this module has no printf, and the line is short. */
    u32 n = 0;
#define APP(s) \
    do { for (const char *q = (s); *q; q++) { if (n + 1 >= max) break; out[n++] = *q; } } while (0)
#define APPNUM(v) \
    do { \
        char d[12]; u32 dn = 0, vv = (v); \
        if (vv == 0) { d[dn++] = '0'; } \
        while (vv) { d[dn++] = (char)('0' + vv % 10); vv /= 10; } \
        while (dn && n + 1 < max) { out[n++] = d[--dn]; } \
    } while (0)

    APP("removed ");
    APPNUM(rep->removed);
    APP(" of ");
    APPNUM(before);
    APP(" (");
    APPNUM(before);
    APP(" -> ");
    APPNUM(after);
    APP(" steps): fold ");
    APPNUM(rep->fold_imm);
    APP(", identity ");
    APPNUM(rep->identity);
    APP(", fall ");
    APPNUM(rep->jmp_next);
    out[n] = '\0';

#undef APP
#undef APPNUM
}

u32 peephole_list(const struct sasm_program *prog, char *out, u32 max)
{
    u32 n = 0;
    u32 lines = 0;
    for (u32 i = 0; i < prog->count; i++) {
        /* The address, then the instruction. */
        char addr[8];
        u32 an = 0;
        u32 v = i;
        if (v == 0) {
            addr[an++] = '0';
        }
        while (v) {
            addr[an++] = (char)('0' + v % 10);
            v /= 10;
        }
        if (n + 2 >= max) {
            break;
        }
        out[n++] = ' ';
        out[n++] = ' ';
        while (an && n + 1 < max) {
            out[n++] = addr[--an];
        }
        if (n + 1 < max) {
            out[n++] = ' ';
        }

        char text[48];
        sasm_disasm_one(&prog->code[i], text, sizeof(text));
        for (const char *p = text; *p && n + 2 < max; p++) {
            out[n++] = *p;
        }
        if (n + 1 < max) {
            out[n++] = '\n';
        }
        lines++;
    }
    out[n] = '\0';
    return lines;
}

/* Append `v` in decimal to `out` at `*n`. */
static void app_num(char *out, u32 max, u32 *n, u32 v)
{
    char d[12];
    u32 dn = 0;
    if (v == 0) {
        d[dn++] = '0';
    }
    while (v) {
        d[dn++] = (char)('0' + v % 10);
        v /= 10;
    }
    while (dn && *n + 1 < max) {
        out[(*n)++] = d[--dn];
    }
    out[*n] = '\0';
}

static void app_str(char *out, u32 max, u32 *n, const char *s)
{
    for (const char *p = s; *p && *n + 1 < max; p++) {
        out[(*n)++] = *p;
    }
    out[*n] = '\0';
}

u32 peephole_render(const struct sasm_program *prog, char *out, u32 max)
{
    /* Which addresses are jump targets, so a label can be emitted there. */
    u8 is_label[SASM_MAX_CODE];
    for (u32 i = 0; i < prog->count; i++) {
        is_label[i] = 0;
    }
    for (u32 i = 0; i < prog->count; i++) {
        const struct sasm_insn *ins = &prog->code[i];
        if ((ins->op == SASM_OP_JMP || ins->op == SASM_OP_JZ
             || ins->op == SASM_OP_JNZ) && ins->imm < prog->count) {
            is_label[ins->imm] = 1;
        }
    }

    u32 n = 0;
    u32 lines = 0;
    for (u32 i = 0; i < prog->count; i++) {
        const struct sasm_insn *ins = &prog->code[i];

        if (is_label[i]) {
            app_str(out, max, &n, "L");
            app_num(out, max, &n, i);
            app_str(out, max, &n, ":\n");
        }

        /* A jump names its label; everything else prints as it would be typed.
         * sasm_disasm_one() gives the instruction text, but a jump's operand is
         * an address there, so the two jump forms are written by hand. */
        if (ins->op == SASM_OP_JMP || ins->op == SASM_OP_JZ
            || ins->op == SASM_OP_JNZ) {
            app_str(out, max, &n, sasm_op_name(ins->op));
            app_str(out, max, &n, " L");
            app_num(out, max, &n, ins->imm);
            app_str(out, max, &n, "\n");
        } else {
            char text[48];
            sasm_disasm_one(ins, text, sizeof(text));
            app_str(out, max, &n, text);
            app_str(out, max, &n, "\n");
        }
        lines++;
    }
    return lines;
}

/* Assemble, optimise, and check the two agree. */
static int check_same(const char *src, char *err, u32 err_max)
{
    struct sasm_program before, after;
    if (!sasm_assemble(src, &before, err, err_max)) {
        return 0;
    }

    struct peephole_report rep;
    u32 removed = peephole_optimise(&before, &after, &rep);

    static char out_before[SVM_OUT_MAX];
    static char out_after[SVM_OUT_MAX];
    struct svm vm;

    svm_reset(&vm);
    if (svm_run(&vm, &before, out_before, sizeof(out_before)) != SVM_OK) {
        return 0;
    }
    svm_reset(&vm);
    if (svm_run(&vm, &after, out_after, sizeof(out_after)) != SVM_OK) {
        return 0;
    }

    if (strcmp(out_before, out_after) != 0) {
        klog("PEEPHOLE", "selftest: output changed by optimisation");
        klog("PEEPHOLE", "  before: %s", out_before);
        klog("PEEPHOLE", "  after:  %s", out_after);
        return 0;
    }
    (void)removed;
    return 1;
}

int peephole_selftest(void)
{
    char err[SASM_ERROR_MAX];

    /* A fold: MOV 6 then ADD 7 must become MOV 13, and print the same 13. */
    if (!check_same("MOV r0, 6\nADD r0, 7\nOUT r0\nHLT\n",
                    err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: fold changed the output");
        return 0;
    }

    /* The fold must actually happen, not just preserve behaviour by doing
     * nothing. */
    struct sasm_program before, after;
    struct peephole_report rep;
    if (!sasm_assemble("MOV r0, 6\nADD r0, 7\nOUT r0\nHLT\n",
                       &before, err, sizeof(err))) {
        return 0;
    }
    u32 removed = peephole_optimise(&before, &after, &rep);
    if (removed != 1 || rep.fold_imm != 1 || after.count != before.count - 1) {
        klog("PEEPHOLE", "selftest: fold did not remove exactly one");
        return 0;
    }
    if (after.code[0].op != SASM_OP_MOV || after.code[0].imm != 13) {
        klog("PEEPHOLE", "selftest: fold produced the wrong constant");
        return 0;
    }

    /* An identity, and a jump to the next instruction. */
    if (!check_same("MOV r0, 5\nADD r0, 0\nOUT r0\nHLT\n",
                    err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: identity removal changed the output");
        return 0;
    }
    if (!check_same("MOV r0, 5\nJMP next\nnext:\nOUT r0\nHLT\n",
                    err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: fall-through removal changed the output");
        return 0;
    }

    /* The dangerous case: a loop whose body is shortened. The jump target moves,
     * so this fails loudly if the addresses are not remapped. */
    if (!check_same(
        "MOV r0, 0\n"
        "MOV r1, 3\n"
        "loop:\n"
        "ADD r0, 0\n"
        "ADD r0, 1\n"
        "SUB r1, 1\n"
        "CMP r1, 0\n"
        "JNZ loop\n"
        "OUT r0\n"
        "HLT\n", err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: a loop was broken by optimisation");
        return 0;
    }

    /* A jump must not be able to land past the end of the program. */
    if (!check_same("MOV r0, 1\nJMP skip\nADD r0, 0\nskip:\nOUT r0\nHLT\n",
                    err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: a skipped instruction broke the jump");
        return 0;
    }

    /* Listing a program is the decode step and must not run off the buffer. */
    char listing[512];
    struct sasm_program prog;
    if (!sasm_assemble("MOV r0, 1\nOUT r0\n", &prog, err, sizeof(err))) {
        return 0;
    }
    u32 lines = peephole_list(&prog, listing, sizeof(listing));
    if (lines == 0 || !strstr(listing, "MOV r0, 1")) {
        klog("PEEPHOLE", "selftest: listing is wrong");
        return 0;
    }

    /* Render back to source, re-assemble, and check the program survives the
     * round trip. This is what makes an optimised program storable: a jump is
     * rendered as a label, and the reassembled program must have the same
     * length and the same jump targets, or the stored text would not be the
     * program that was verified. The loop case is the one that matters, since
     * its target moves during optimisation. */
    const char *loop =
        "MOV r0, 0\nMOV r1, 3\nloop:\nADD r0, 0\nADD r0, 1\nSUB r1, 1\n"
        "CMP r1, 0\nJNZ loop\nOUT r0\nHLT\n";
    struct sasm_program opt;
    struct peephole_report rep2;
    struct sasm_program lprog;
    if (!sasm_assemble(loop, &lprog, err, sizeof(err))) {
        return 0;
    }
    peephole_optimise(&lprog, &opt, &rep2);

    static char rendered[1024];
    peephole_render(&opt, rendered, sizeof(rendered));

    struct sasm_program again;
    if (!sasm_assemble(rendered, &again, err, sizeof(err))) {
        klog("PEEPHOLE", "selftest: rendered source does not assemble: %s", err);
        return 0;
    }
    if (again.count != opt.count) {
        klog("PEEPHOLE", "selftest: render changed the length (%u vs %u)",
             again.count, opt.count);
        return 0;
    }
    /* And it must still do the same thing. */
    static char ob[SVM_OUT_MAX];
    static char oa[SVM_OUT_MAX];
    struct svm vm;
    svm_reset(&vm);
    if (svm_run(&vm, &opt, ob, sizeof(ob)) != SVM_OK) {
        return 0;
    }
    svm_reset(&vm);
    if (svm_run(&vm, &again, oa, sizeof(oa)) != SVM_OK) {
        return 0;
    }
    if (strcmp(ob, oa) != 0) {
        klog("PEEPHOLE", "selftest: rendered source behaves differently");
        return 0;
    }

    return 1;
}
