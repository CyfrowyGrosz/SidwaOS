/* The C curriculum. See include/curriculum.h.
 *
 * The course starts from what a program is and builds up to the first program
 * everyone writes, then to a windowed interface. Each lesson is one idea, so the
 * AI can teach at a steady pace and a learner can stop after any of them.
 *
 * Bodies are kept to plain ASCII and under 64 columns so they render in the
 * kernel's 80x25 text GUI without wrapping.
 */

#include "curriculum.h"
#include "serial.h"
#include "string.h"

/* Counts and indices here are small and fixed, so a plain array is clearer than
 * any lookup structure. */

static const struct lesson lessons[] = {
    { 1, "What a program is", 5, {
        "A program is a list of instructions.",
        "The CPU runs them one at a time.",
        "C is a way to write that list by hand.",
        "Source code is the list you type.",
        "The compiler turns it into machine code.",
    }},
    { 2, "Your first C program", 6, {
        "#include <stdio.h>",
        "int main(void) {",
        "    printf(\"Hello, World!\\n\");",
        "    return 0;",
        "}",
        "main is where every C program starts.",
    }},
    { 3, "Building and running", 5, {
        "Save the file as hello.c",
        "Compile: gcc hello.c -o hello",
        "Run: ./hello",
        "Output: Hello, World!",
        "That is the whole loop: write, build, run.",
    }},
    { 4, "Variables and types", 6, {
        "A variable is a named box for a value.",
        "int count = 3;      whole numbers",
        "float half = 0.5;   fractional numbers",
        "char c = 'A';       one character",
        "Each box has a type, and the type",
        "decides what fits and how it is read.",
    }},
    { 5, "Making decisions", 5, {
        "if (count > 0) {",
        "    printf(\"positive\\n\");",
        "} else {",
        "    printf(\"not positive\\n\");",
        "}",
    }},
    { 6, "Repeating work", 5, {
        "for (int i = 0; i < 3; i++) {",
        "    printf(\"%d\\n\", i);",
        "}",
        "Prints 0, 1, 2.",
        "A loop repeats until its condition fails.",
    }},
    { 7, "Functions", 6, {
        "int add(int a, int b) {",
        "    return a + b;",
        "}",
        "Call it: add(2, 3) gives 5.",
        "Functions name a piece of work so you",
        "can reuse it and test it on its own.",
    }},
    { 8, "Structs: grouping data", 5, {
        "struct point { int x; int y; };",
        "struct point p = { 3, 4 };",
        "p.x is 3 and p.y is 4.",
        "A struct keeps related values together,",
        "which is the seed of every larger design.",
    }},
    { 9, "Model, View, Controller", 6, {
        "Split a program into three parts:",
        "  Model      the data and its rules",
        "  View       draws the data on screen",
        "  Controller turns input into changes",
        "The view never edits data directly;",
        "it asks the model, then redraws.",
    }},
    { 10, "Hello World as a GUI", 7, {
        "The model holds a greeting string.",
        "The view draws a window and the string.",
        "The controller waits for a key.",
        "Press q and the controller asks to quit.",
        "The model changes, the view redraws.",
        "Same three parts as Hello, World!,",
        "only now they paint a window.",
    }},
};

static const u32 lesson_count = sizeof(lessons) / sizeof(lessons[0]);

/* The reverse-engineering course. Where the C course teaches how to write a
 * program, this teaches how to read one that has already been compiled: what
 * the compiler left behind, how to recover the original shape, and what the
 * machine code is actually doing. The goal is better code, because a programmer
 * who can read the output writes input the compiler can turn into less of it.
 *
 * The lessons follow the same path a disassembler does: bytes, then fields,
 * then control flow, then data, then the habits that make the result readable. */

static const struct lesson rev_lessons[] = {
    { 1, "What the compiler leaves", 5, {
        "A C line becomes machine instructions.",
        "The names you chose are gone.",
        "Types are gone; only sizes remain.",
        "What survives: the structure.",
        "Reading it back is reverse engineering.",
    }},
    { 2, "Bytes and instructions", 6, {
        "x86 instructions are variable length.",
        "One opcode byte, then its operands.",
        "mov eax, ebx   is two bytes: 89 d8",
        "add eax, 4     is three:  83 c0 04",
        "You cannot count bytes to find",
        "instructions; you must decode them.",
    }},
    { 3, "The shape of a function", 6, {
        "push ebp",
        "mov ebp, esp",
        "sub esp, 16     reserve locals",
        "...             the body",
        "mov esp, ebp",
        "pop ebp; ret    the exit",
    }},
    { 4, "Calling conventions", 5, {
        "Arguments arrive on the stack.",
        "[ebp+8] is the first argument.",
        "[ebp-4] is the first local.",
        "eax carries the return value.",
        "This is how caller and callee agree.",
    }},
    { 5, "Reading control flow", 6, {
        "cmp sets flags; jmp uses them.",
        "je  equal, jne not equal",
        "jg  greater, jle less or equal",
        "if/else and loops become",
        "compare, then a conditional jump.",
        "Backwards jumps are usually loops.",
    }},
    { 6, "Data and strings", 6, {
        "Constants live in .rodata.",
        "A string is bytes, then a zero.",
        "The compiler hides them in the data",
        "section and passes a pointer.",
        "Look for the pointer, follow it,",
        "and a string literal appears.",
    }},
    { 7, "Telling C from the assembly", 6, {
        "The compiler is predictable.",
        "Optimised code reorders and reuses;",
        "a plain -O0 build mirrors the source.",
        "A loop of adds is often a multiply.",
        "A call to memset is an array clear.",
        "Match the pattern, recover the source.",
    }},
    { 8, "Reading for better code", 6, {
        "Read your own build to find waste:",
        "a copy you did not need,",
        "a bounds check done twice,",
        "a branch the compiler had to guess.",
        "Faster source comes from seeing",
        "what the machine actually runs.",
    }},
    { 9, "Checksums and self-checking code", 6, {
        "A checksum turns bytes into a number.",
        "SidwaOS tests HOLD blobs this way:",
        "sum the words, compare to a field.",
        "A mismatch means corruption,",
        "so the data is refused, not stored.",
        "Verification is reverse engineering.",
    }},
    { 10, "From bytes back to knowledge", 7, {
        "Reverse engineering ends in knowledge:",
        "what this code does, and how you know.",
        "That claim is only worth keeping",
        "once a second reading agrees.",
        "SidwaOS holds it unverified at first",
        "and writes it to .sidwa only when",
        "a confirming pass returns the same.",
    }},
};

static const u32 rev_lesson_count =
    sizeof(rev_lessons) / sizeof(rev_lessons[0]);

static const struct course courses[] = {
    { "C course", lessons, lesson_count },
    { "Reverse engineering", rev_lessons, rev_lesson_count },
};

static const u32 course_count = sizeof(courses) / sizeof(courses[0]);

u32 curriculum_courses(void) { return course_count; }

const struct course *curriculum_course(u32 index)
{
    return index < course_count ? &courses[index] : 0;
}


u32 curriculum_count(void) { return lesson_count; }

const struct lesson *curriculum_get(u32 index)
{
    return index < lesson_count ? &lessons[index] : 0;
}

const struct lesson *curriculum_find(const char *keyword)
{
    if (!keyword || !*keyword) {
        return 0;
    }

    /* Titles first. A keyword like "hello" appears in a title and in the body of
     * an earlier lesson, and the title is the better answer, so the body pass
     * only runs when no title matches. */
    for (u32 i = 0; i < lesson_count; i++) {
        if (stristr(lessons[i].title, keyword)) {
            return &lessons[i];
        }
    }
    for (u32 i = 0; i < lesson_count; i++) {
        for (u32 l = 0; l < lessons[i].lines; l++) {
            if (strstr(lessons[i].body[l], keyword)) {
                return &lessons[i];
            }
        }
    }
    return 0;
}

u32 curriculum_format(const struct lesson *lesson, char *out, u32 max)
{
    if (!lesson || max == 0) {
        return 0;
    }

    u32 n = 0;
    char num[4];
    u32 d = 0;

    /* "N. " -- lessons are numbered 1..10, so at most two digits. */
    if (lesson->number >= 10) {
        num[d++] = (char)('0' + lesson->number / 10);
    }
    num[d++] = (char)('0' + lesson->number % 10);
    num[d++] = '.';
    num[d++] = ' ';

    for (u32 i = 0; i < d && n + 1 < max; i++) {
        out[n++] = num[i];
    }
    for (const char *p = lesson->title; *p && n + 1 < max; p++) {
        out[n++] = *p;
    }

    for (u32 l = 0; l < lesson->lines; l++) {
        if (n + 1 < max) {
            out[n++] = '\n';
        }
        for (const char *p = lesson->body[l]; *p && n + 1 < max; p++) {
            out[n++] = *p;
        }
    }

    out[n] = '\0';
    return n;
}

void curriculum_print(const struct lesson *lesson)
{
    if (!lesson) {
        klog("C", "no such lesson");
        return;
    }

    klog("C", "Lesson %u: %s", lesson->number, lesson->title);
    for (u32 i = 0; i < lesson->lines; i++) {
        klog("C", "  %s", lesson->body[i]);
    }
}

void curriculum_print_all(void)
{
    klog("C", "C course: %u lessons", lesson_count);
    for (u32 i = 0; i < lesson_count; i++) {
        curriculum_print(&lessons[i]);
    }
}

int curriculum_selftest(void)
{
    char buf[512];

    if (curriculum_count() < 10) {
        return 0;
    }

    /* Lesson 2 is the first program everyone writes, and it must actually
     * contain the classic line. */
    const struct lesson *first = curriculum_get(1);
    if (!first) {
        return 0;
    }
    u32 n = curriculum_format(first, buf, sizeof(buf));
    if (n == 0 || !strstr(buf, "printf") || !strstr(buf, "Hello, World!")) {
        return 0;
    }

    /* The course must reach the MVC lesson the GUI is built from. */
    return curriculum_find("Model, View, Controller") != 0;
}

/* --- Reverse-engineering course --------------------------------------------- */

u32 rev_count(void) { return rev_lesson_count; }

const struct lesson *rev_get(u32 index)
{
    return index < rev_lesson_count ? &rev_lessons[index] : 0;
}

const struct lesson *rev_find(const char *keyword)
{
    if (!keyword || !*keyword) {
        return 0;
    }

    for (u32 i = 0; i < rev_lesson_count; i++) {
        if (stristr(rev_lessons[i].title, keyword)) {
            return &rev_lessons[i];
        }
    }
    for (u32 i = 0; i < rev_lesson_count; i++) {
        for (u32 l = 0; l < rev_lessons[i].lines; l++) {
            if (strstr(rev_lessons[i].body[l], keyword)) {
                return &rev_lessons[i];
            }
        }
    }
    return 0;
}

void rev_print(const struct lesson *lesson)
{
    if (!lesson) {
        klog("RE", "no such lesson");
        return;
    }

    klog("RE", "Lesson %u: %s", lesson->number, lesson->title);
    for (u32 i = 0; i < lesson->lines; i++) {
        klog("RE", "  %s", lesson->body[i]);
    }
}

void rev_print_all(void)
{
    klog("RE", "reverse-engineering course: %u lessons", rev_lesson_count);
    for (u32 i = 0; i < rev_lesson_count; i++) {
        rev_print(&rev_lessons[i]);
    }
}

int rev_selftest(void)
{
    char buf[512];

    if (rev_lesson_count < 10) {
        return 0;
    }

    /* The course must cover reading instructions, the stack frame and control
     * flow: the three things a disassembly is read for. */
    if (!rev_find("Bytes and instructions")
        || !rev_find("The shape of a function")
        || !rev_find("Reading control flow")) {
        return 0;
    }

    /* The last lesson must tie reading code back to stored knowledge. */
    const struct lesson *last = rev_get(rev_lesson_count - 1);
    u32 n = curriculum_format(last, buf, sizeof(buf));
    if (n == 0 || !strstr(buf, "sidwa")) {
        return 0;
    }

    /* Both courses must be reachable through the course table. */
    return curriculum_courses() == 2
        && curriculum_course(1)
        && curriculum_course(1)->count == rev_lesson_count;
}
