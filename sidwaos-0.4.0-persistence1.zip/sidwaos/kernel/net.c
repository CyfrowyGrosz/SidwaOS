/* IPv4 network stack and HTTP client. See include/net.h.
 *
 * Everything here is polled and single-threaded. A caller that wants to wait for
 * something pumps net_poll() until a predicate is satisfied or a timeout
 * expires. Nothing blocks inside an interrupt, so the stack may send (itself a
 * polled operation) while it is handling a received frame.
 *
 * Byte order: values on the wire are big-endian. Fields the code compares rather
 * than transmits are converted to host order as soon as they are parsed, so the
 * state machines never have to think about it.
 */

#include "net.h"
#include "rtl8139.h"
#include "serial.h"
#include "string.h"
#include "timer.h"

/* --- Wire constants --------------------------------------------------------- */

#define ETH_ARP  0x0806
#define ETH_IP   0x0800

#define IP_ICMP  1
#define IP_TCP   6
#define IP_UDP   17

#define TCP_FIN  0x01
#define TCP_SYN  0x02
#define TCP_RST  0x04
#define TCP_PSH  0x08
#define TCP_ACK  0x10

#define TCP_SYN_SENT    1
#define TCP_ESTABLISHED 2
#define TCP_CLOSED      3

#define ARP_REQUEST 1
#define ARP_REPLY   2

#define PING_ID 0x1234

/* --- Forward declarations --------------------------------------------------- */

int  ip_send(const u8 dst_ip[4], u8 proto, const u8 *payload, u32 len);
static void tcp_handle(const u8 *seg, u32 len, const u8 src_ip[4]);
static void udp_handle(const u8 *seg, u32 len, const u8 src_ip[4]);

/* --- State ------------------------------------------------------------------ */

struct arp_entry {
    u8 ip[4];
    u8 mac[6];
    int valid;
};

static struct net_config cfg;
static int ready;
static int have_nic;

static struct arp_entry arp_cache[NET_ARP_MAX];
static u32 rx_frames, tx_frames;

static u8 tx_frame[NET_FRAME_MAX];
static u8 rx_frame[NET_FRAME_MAX];

/* Ping state: set while an echo request is outstanding, cleared when the reply
 * bearing the same identifier arrives. */
static volatile int ping_armed;

/* DNS state: one query outstanding at a time. */
static u16 dns_txid;
static u16 dns_local_port;
static int dns_armed;
static u8  dns_answer[4];

/* The single TCP connection the client needs. HTTP is one connection at a time,
 * so a connection table would be unused complexity. */
struct tcp_conn {
    int state;
    u8  remote_ip[4];
    u8  remote_mac[6];
    u16 local_port;
    u16 remote_port;
    u32 seq;                    /* next sequence number to send */
    u32 ack;                    /* next sequence number expected from remote */
    u8 *body;                   /* where received payload is accumulated */
    u32 body_max;
    u32 body_len;
    int remote_closed;
};

static struct tcp_conn conn;
static u16 next_port = 49152;

/* --- Byte order and checksums ----------------------------------------------- */

static u16 rd16(const u8 *p) { return (u16)((p[0] << 8) | p[1]); }
static u32 rd32(const u8 *p)
{
    return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3];
}
static void wr16(u8 *p, u16 v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static void wr32(u8 *p, u32 v)
{
    p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16);
    p[2] = (u8)(v >> 8);  p[3] = (u8)v;
}

/* One's-complement sum, folded to 16 bits. */
static u16 checksum_finish(u32 sum)
{
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (u16)(~sum & 0xFFFF);
}

static u32 checksum_add(u32 sum, const u8 *p, u32 len)
{
    for (u32 i = 0; i + 1 < len; i += 2) {
        sum += (u32)((p[i] << 8) | p[i + 1]);
    }
    if (len & 1) {
        sum += (u32)(p[len - 1] << 8);
    }
    return sum;
}

/* Overlap-safe forward copy, for shifting a body over its headers. */
static void bytes_move(u8 *dst, const u8 *src, u32 n)
{
    if (dst < src) {
        for (u32 i = 0; i < n; i++) {
            dst[i] = src[i];
        }
    } else {
        for (u32 i = n; i > 0; i--) {
            dst[i - 1] = src[i - 1];
        }
    }
}

/* --- Address helpers -------------------------------------------------------- */

static int ip_eq(const u8 a[4], const u8 b[4])
{
    return a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && a[3] == b[3];
}

static void ip_copy(u8 dst[4], const u8 src[4])
{
    for (u32 i = 0; i < 4; i++) {
        dst[i] = src[i];
    }
}

int net_parse_ip(const char *text, u8 out[4])
{
    u32 n = 0, value = 0, digits = 0;

    for (const char *p = text; ; p++) {
        if (*p >= '0' && *p <= '9') {
            value = value * 10 + (u32)(*p - '0');
            digits++;
            if (value > 255) {
                return 0;
            }
        } else if (*p == '.' || *p == '\0') {
            if (!digits || n >= 4) {
                return 0;
            }
            out[n++] = (u8)value;
            value = 0;
            digits = 0;
            if (*p == '\0') {
                break;
            }
        } else {
            return 0;
        }
    }
    return n == 4;
}

void net_format_ip(const u8 ip[4], char *out)
{
    u32 o = 0;
    for (u32 i = 0; i < 4; i++) {
        u32 v = ip[i];
        char rev[4];
        u32 r = 0;
        if (v == 0) {
            rev[r++] = '0';
        }
        while (v) {
            rev[r++] = (char)('0' + v % 10);
            v /= 10;
        }
        while (r) {
            out[o++] = rev[--r];
        }
        if (i < 3) {
            out[o++] = '.';
        }
    }
    out[o] = '\0';
}

int net_ready(void) { return ready; }
const struct net_config *net_config_get(void) { return &cfg; }
u32 net_rx_frames(void) { return rx_frames; }
u32 net_tx_frames(void) { return tx_frames; }

/* --- Ethernet --------------------------------------------------------------- */

static int eth_send(const u8 dst_mac[6], u16 type, const u8 *payload, u32 len)
{
    if (len + 14 > sizeof(tx_frame)) {
        return 0;
    }
    memcpy(tx_frame, dst_mac, 6);
    memcpy(tx_frame + 6, rtl8139_mac(), 6);
    wr16(tx_frame + 12, type);
    memcpy(tx_frame + 14, payload, len);

    if (!rtl8139_send(tx_frame, len + 14)) {
        return 0;
    }
    tx_frames++;
    return 1;
}

/* --- ARP -------------------------------------------------------------------- */

static struct arp_entry *arp_lookup(const u8 ip[4])
{
    for (u32 i = 0; i < NET_ARP_MAX; i++) {
        if (arp_cache[i].valid && ip_eq(arp_cache[i].ip, ip)) {
            return &arp_cache[i];
        }
    }
    return 0;
}

static void arp_store(const u8 ip[4], const u8 mac[6])
{
    struct arp_entry *e = arp_lookup(ip);
    if (!e) {
        for (u32 i = 0; i < NET_ARP_MAX; i++) {
            if (!arp_cache[i].valid) {
                e = &arp_cache[i];
                break;
            }
        }
    }
    if (!e) {
        e = &arp_cache[0];          /* evict the oldest when full */
    }
    ip_copy(e->ip, ip);
    memcpy(e->mac, mac, 6);
    e->valid = 1;
}

static void arp_send(const u8 target_ip[4], u16 oper, const u8 target_mac[6])
{
    u8 packet[28];
    wr16(packet + 0, 1);            /* hardware type: Ethernet */
    wr16(packet + 2, ETH_IP);       /* protocol type */
    packet[4] = 6;                  /* hardware address length */
    packet[5] = 4;                  /* protocol address length */
    wr16(packet + 6, oper);
    memcpy(packet + 8, rtl8139_mac(), 6);
    ip_copy(packet + 14, cfg.ip);
    memcpy(packet + 18, target_mac, 6);
    ip_copy(packet + 24, target_ip);

    static const u8 broadcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    eth_send(oper == ARP_REQUEST ? broadcast : target_mac, ETH_ARP,
             packet, sizeof(packet));
}

static void arp_handle(const u8 *p, u32 len)
{
    if (len < 28) {
        return;
    }
    u16 oper = rd16(p + 6);
    const u8 *sender_ip = p + 14;
    const u8 *sender_mac = p + 8;

    /* Remember the sender whatever the operation: a request tells us as much
     * about the sender as a reply does. */
    arp_store(sender_ip, sender_mac);

    if (oper == ARP_REQUEST && ip_eq(p + 24, cfg.ip)) {
        arp_send(sender_ip, ARP_REPLY, sender_mac);
    }
}

int net_arp_resolve(const u8 ip[4], u8 mac_out[6])
{
    struct arp_entry *e = arp_lookup(ip);
    if (e) {
        memcpy(mac_out, e->mac, 6);
        return 1;
    }

    static const u8 zero[6] = { 0, 0, 0, 0, 0, 0 };
    arp_send(ip, ARP_REQUEST, zero);

    u32 start = timer_ticks();
    while (timer_ticks() - start < 300) {       /* 3 s */
        net_poll();
        e = arp_lookup(ip);
        if (e) {
            memcpy(mac_out, e->mac, 6);
            return 1;
        }
    }
    return 0;
}

/* --- IP --------------------------------------------------------------------- */

/* Which host on the local link should carry a packet to `dst_ip`? A destination
 * inside our own subnet is reached directly; anything else goes through the
 * gateway. This is the whole of the routing decision, and it is what makes an
 * address like 172.66.147.243 reachable from 10.0.2.15. */
static void next_hop(const u8 dst_ip[4], u8 hop_out[4])
{
    int same_subnet = 1;
    for (u32 i = 0; i < 4; i++) {
        if ((dst_ip[i] & cfg.mask[i]) != (cfg.ip[i] & cfg.mask[i])) {
            same_subnet = 0;
        }
    }
    ip_copy(hop_out, same_subnet ? dst_ip : cfg.gateway);
}

static u16 ip_checksum(const u8 *header, u32 len)
{
    return checksum_finish(checksum_add(0, header, len));
}

static void icmp_handle(const u8 *payload, u32 len, const u8 src_ip[4])
{
    if (len < 8 || payload[0] != 8) {
        return;                     /* only echo requests get a reply */
    }
    static u8 reply[NET_MTU];
    if (len > sizeof(reply)) {
        return;
    }
    memcpy(reply, payload, len);
    reply[0] = 0;                   /* echo reply */
    wr16(reply + 2, 0);
    wr16(reply + 2, ip_checksum(reply, len));

    u8 mac[6];
    if (net_arp_resolve(src_ip, mac)) {
        eth_send(mac, ETH_IP, reply, len);
    }
}

static void ip_dispatch(const u8 *packet, u32 len)
{
    if (len < 20) {
        return;
    }
    u32 ihl = (u32)(packet[0] & 0x0F) * 4;
    if (ihl < 20 || ihl > len) {
        return;
    }
    /* A valid header checksums to zero when summed. */
    if (ip_checksum(packet, ihl) != 0) {
        return;
    }
    if (!ip_eq(packet + 16, cfg.ip)) {
        return;                     /* not addressed to us */
    }

    u8 proto = packet[9];
    const u8 *src_ip = packet + 12;
    const u8 *payload = packet + ihl;

    /* Bound the payload by the IP total-length field rather than by the frame
     * length. An Ethernet frame is padded to a 60-byte minimum, so a short
     * segment such as a bare TCP acknowledgement arrives with trailing padding
     * that is not part of any protocol. Using the frame length would feed those
     * padding bytes to the transport layer as payload. */
    u32 plen = len - ihl;
    u16 total_len = rd16(packet + 2);
    if (total_len >= ihl && (u32)total_len <= len) {
        plen = (u32)total_len - ihl;
    }

    if (proto == IP_ICMP) {
        if (plen >= 8 && payload[0] == 0 && rd16(payload + 4) == PING_ID) {
            ping_armed = 0;         /* our echo reply came back */
        }
        icmp_handle(payload, plen, src_ip);
    } else if (proto == IP_UDP) {
        udp_handle(payload, plen, src_ip);
    } else if (proto == IP_TCP) {
        tcp_handle(payload, plen, src_ip);
    }
}

int ip_send(const u8 dst_ip[4], u8 proto, const u8 *payload, u32 len)
{
    if (len > NET_MTU) {
        return 0;
    }

    /* The frame is addressed to the next hop, not necessarily to the final
     * destination: off-subnet traffic goes to the gateway's MAC address while
     * keeping the destination IP in the header. */
    u8 hop[4];
    next_hop(dst_ip, hop);
    u8 mac[6];
    if (!net_arp_resolve(hop, mac)) {
        return 0;
    }

    static u8 packet[NET_MTU];
    memset(packet, 0, 20);
    packet[0] = 0x45;               /* version 4, header length 5 words */
    wr16(packet + 2, (u16)(20 + len));
    wr16(packet + 4, (u16)(timer_ticks() & 0xFFFF));
    wr16(packet + 6, 0x4000);       /* don't fragment */
    packet[8] = 64;                 /* TTL */
    packet[9] = proto;
    ip_copy(packet + 12, cfg.ip);
    ip_copy(packet + 16, dst_ip);
    wr16(packet + 10, 0);
    wr16(packet + 10, ip_checksum(packet, 20));
    memcpy(packet + 20, payload, len);

    return eth_send(mac, ETH_IP, packet, 20 + len);
}

/* --- Ping ------------------------------------------------------------------- */

int net_ping(const u8 ip[4], u32 timeout_ms)
{
    u8 mac[6];
    if (!net_arp_resolve(ip, mac)) {
        return -1;
    }

    u8 packet[8 + 32];
    memset(packet, 0, sizeof(packet));
    packet[0] = 8;                  /* echo request */
    wr16(packet + 4, PING_ID);
    wr16(packet + 6, 1);            /* sequence */
    for (u32 i = 0; i < 32; i++) {
        packet[8 + i] = (u8)('a' + (i % 26));
    }
    wr16(packet + 2, ip_checksum(packet, sizeof(packet)));

    u32 start = timer_ticks();
    ping_armed = 1;
    if (!ip_send(ip, IP_ICMP, packet, sizeof(packet))) {
        ping_armed = 0;
        return -1;
    }
    while (timer_ticks() - start < timeout_ms / 10) {
        net_poll();
        if (!ping_armed) {
            return (int)((timer_ticks() - start) * 10);
        }
    }
    ping_armed = 0;
    return -1;
}

/* --- UDP and DNS ------------------------------------------------------------ */

static void udp_handle(const u8 *seg, u32 len, const u8 src_ip[4])
{
    (void)src_ip;
    if (len < 8) {
        return;
    }
    u16 dst_port = rd16(seg + 2);
    const u8 *data = seg + 8;
    u32 dlen = len - 8;

    if (!dns_armed || dst_port != dns_local_port || dlen < 12) {
        return;
    }
    if (rd16(data) != dns_txid) {
        return;
    }

    /* Walk past the header and the questions, then read the answers. */
    u32 off = 12;
    u32 questions = rd16(data + 4);
    for (u32 q = 0; q < questions && off < dlen; q++) {
        while (off < dlen && data[off] != 0) {
            if ((data[off] & 0xC0) == 0xC0) {   /* compressed pointer */
                off += 2;
                goto question_done;
            }
            off += 1 + data[off];
        }
        off += 1;                   /* the root label */
    question_done:
        off += 4;                   /* QTYPE and QCLASS */
    }

    u32 answers = rd16(data + 6);
    for (u32 a = 0; a < answers && off + 12 <= dlen; a++) {
        if ((data[off] & 0xC0) == 0xC0) {
            off += 2;
        } else {
            while (off < dlen && data[off] != 0) {
                off += 1 + data[off];
            }
            off += 1;
        }
        if (off + 10 > dlen) {
            break;
        }
        u16 type = rd16(data + off);
        u16 rdlength = rd16(data + off + 8);
        off += 10;
        if (type == 1 && rdlength == 4 && off + 4 <= dlen) {
            for (u32 i = 0; i < 4; i++) {
                dns_answer[i] = data[off + i];
            }
            dns_armed = 0;
            return;
        }
        off += rdlength;
    }
}

/* Encode "www.example.com" into the DNS label format. Returns the length, or 0
 * on a malformed name. */
static u32 dns_encode_name(const char *name, u8 *out, u32 max)
{
    u32 o = 0;
    const char *label = name;
    while (*label) {
        const char *dot = label;
        while (*dot && *dot != '.') {
            dot++;
        }
        u32 n = (u32)(dot - label);
        if (n == 0 || n > 63 || o + 1 + n >= max) {
            return 0;
        }
        out[o++] = (u8)n;
        for (u32 i = 0; i < n; i++) {
            out[o++] = (u8)label[i];
        }
        label = (*dot == '.') ? dot + 1 : dot;
    }
    if (o + 1 > max) {
        return 0;
    }
    out[o++] = 0;
    return o;
}

int net_dns_resolve(const char *name, u8 out[4])
{
    if (net_parse_ip(name, out)) {
        return 1;                   /* already a literal address */
    }

    u8 query[512];
    memset(query, 0, 12);
    dns_txid = (u16)(timer_ticks() & 0xFFFF);
    wr16(query + 0, dns_txid);
    wr16(query + 2, 0x0100);        /* standard query, recursion desired */
    wr16(query + 4, 1);             /* one question */

    u32 name_len = dns_encode_name(name, query + 12, sizeof(query) - 16);
    if (name_len == 0) {
        return 0;
    }
    u32 off = 12 + name_len;
    wr16(query + off, 1);           /* QTYPE: A */
    wr16(query + off + 2, 1);       /* QCLASS: IN */
    off += 4;

    dns_local_port = next_port++;
    u8 seg[512];
    wr16(seg + 0, dns_local_port);
    wr16(seg + 2, 53);
    wr16(seg + 4, (u16)(8 + off));
    wr16(seg + 6, 0);               /* checksum is optional for IPv4 UDP */
    memcpy(seg + 8, query, off);

    dns_armed = 1;
    u32 start = timer_ticks();
    if (!ip_send(cfg.dns, IP_UDP, seg, 8 + off)) {
        dns_armed = 0;
        return 0;
    }
    while (timer_ticks() - start < 500) {       /* 5 s */
        net_poll();
        if (!dns_armed) {
            ip_copy(out, dns_answer);
            return 1;
        }
    }
    dns_armed = 0;
    return 0;
}

/* --- TCP -------------------------------------------------------------------- */

static u16 tcp_checksum(const u8 src_ip[4], const u8 dst_ip[4],
                        const u8 *seg, u32 len)
{
    u8 pseudo[12];
    memcpy(pseudo, src_ip, 4);
    memcpy(pseudo + 4, dst_ip, 4);
    pseudo[8] = 0;
    pseudo[9] = IP_TCP;
    wr16(pseudo + 10, (u16)len);

    u32 sum = checksum_add(0, pseudo, 12);
    sum = checksum_add(sum, seg, len);
    return checksum_finish(sum);
}

static int tcp_send_segment(u8 flags, const u8 *payload, u32 len)
{
    static u8 seg[NET_MTU];
    if (20 + len > sizeof(seg)) {
        return 0;
    }
    memset(seg, 0, 20);
    wr16(seg + 0, conn.local_port);
    wr16(seg + 2, conn.remote_port);
    wr32(seg + 4, conn.seq);
    wr32(seg + 8, conn.ack);
    wr16(seg + 12, (u16)((5 << 12) | flags));   /* 5 words of header */
    wr16(seg + 14, NET_TCP_WINDOW);
    if (len) {
        memcpy(seg + 20, payload, len);
    }
    wr16(seg + 16, tcp_checksum(cfg.ip, conn.remote_ip, seg, 20 + len));

    if (!ip_send(conn.remote_ip, IP_TCP, seg, 20 + len)) {
        return 0;
    }
    conn.seq += len;
    if (flags & (TCP_SYN | TCP_FIN)) {
        conn.seq += 1;              /* SYN and FIN each consume a sequence */
    }
    return 1;
}

static void tcp_handle(const u8 *seg, u32 len, const u8 src_ip[4])
{
    if (len < 20 || conn.state == TCP_CLOSED) {
        return;
    }
    if (rd16(seg + 2) != conn.local_port || rd16(seg + 0) != conn.remote_port) {
        return;
    }
    if (!ip_eq(src_ip, conn.remote_ip)) {
        return;
    }

    u32 seq = rd32(seg + 4);
    u8 flags = seg[13];
    u32 data_off = (u32)(seg[12] >> 4) * 4;
    if (data_off < 20 || data_off > len) {
        return;
    }
    u32 payload_len = len - data_off;
    const u8 *payload = seg + data_off;

    if (flags & TCP_RST) {
        conn.state = TCP_CLOSED;
        return;
    }

    if (conn.state == TCP_SYN_SENT) {
        if (flags & TCP_SYN) {
            conn.ack = seq + 1;
            conn.state = TCP_ESTABLISHED;
            tcp_send_segment(TCP_ACK, 0, 0);
        }
        return;
    }

    if (conn.state != TCP_ESTABLISHED) {
        return;
    }

    /* In-order data only. A duplicate or out-of-order segment is acknowledged
     * but not stored, which is enough for a client that sends one small request
     * and reads one response. */
    if (payload_len) {
        if (seq == conn.ack) {
            u32 room = conn.body_max - conn.body_len;
            u32 copy = payload_len < room ? payload_len : room;
            if (copy) {
                memcpy(conn.body + conn.body_len, payload, copy);
                conn.body_len += copy;
            }
            conn.ack += payload_len;
        }
        tcp_send_segment(TCP_ACK, 0, 0);
    }

    if (flags & TCP_FIN) {
        conn.ack += 1;
        tcp_send_segment(TCP_ACK, 0, 0);
        conn.remote_closed = 1;
    }
}

/* --- Receive dispatch ------------------------------------------------------- */

void net_poll(void)
{
    if (!have_nic) {
        return;
    }
    int n;
    while ((n = rtl8139_recv(rx_frame, sizeof(rx_frame))) >= 0) {
        if ((u32)n < 14) {
            continue;
        }
        u16 type = rd16(rx_frame + 12);
        if (type == ETH_ARP) {
            arp_handle(rx_frame + 14, (u32)n - 14);
        } else if (type == ETH_IP) {
            ip_dispatch(rx_frame + 14, (u32)n - 14);
        }
        rx_frames++;
    }
}

/* --- HTTP ------------------------------------------------------------------- */

/* Split "http://host:port/path" into its parts. Returns 0 on a malformed URL. */
static int parse_url(const char *url, char *host, u32 host_max,
                     u16 *port, char *path, u32 path_max)
{
    const char *p = url;
    if (strncmp(p, "http://", 7) == 0) {
        p += 7;
    }

    u32 h = 0;
    while (*p && *p != '/' && *p != ':' && h + 1 < host_max) {
        host[h++] = *p++;
    }
    host[h] = '\0';
    if (h == 0) {
        return 0;
    }

    *port = 80;
    if (*p == ':') {
        p++;
        u32 v = 0;
        while (*p >= '0' && *p <= '9') {
            v = v * 10 + (u32)(*p - '0');
            p++;
        }
        if (v == 0 || v > 65535) {
            return 0;
        }
        *port = (u16)v;
    }

    u32 q = 0;
    if (*p == '\0') {
        path[q++] = '/';
    }
    while (*p && q + 1 < path_max) {
        path[q++] = *p++;
    }
    path[q] = '\0';
    return 1;
}

/* Resolve, ARP, then the three-way handshake. */
static int http_connect(const u8 ip[4], u16 port)
{
    memset(&conn, 0, sizeof(conn));
    ip_copy(conn.remote_ip, ip);
    conn.remote_port = port;
    conn.local_port = next_port++;
    conn.seq = (u32)timer_ticks() * 2654435761u;
    conn.state = TCP_CLOSED;

    /* Resolve the next hop's MAC, which is the gateway for an off-subnet server
     * and the server itself otherwise. The IP header still carries the server's
     * address; only the Ethernet destination changes. */
    u8 hop[4];
    next_hop(ip, hop);
    if (!net_arp_resolve(hop, conn.remote_mac)) {
        klog("NET", "no ARP reply for the server");
        return 0;
    }

    conn.state = TCP_SYN_SENT;
    u32 syn_seq = conn.seq;
    u32 start = timer_ticks();
    u32 last_syn = start;
    if (!tcp_send_segment(TCP_SYN, 0, 0)) {
        return 0;
    }
    while (timer_ticks() - start < 1000) {      /* 10 s */
        net_poll();
        if (conn.state == TCP_ESTABLISHED) {
            return 1;
        }
        if (conn.state == TCP_CLOSED) {
            klog("NET", "connection refused");
            return 0;
        }
        /* A SYN that is lost leaves the connection hanging, so resend it every
         * three seconds. A retransmission must carry the original sequence
         * number, so it is restored before each attempt. */
        if (timer_ticks() - last_syn > 300) {
            conn.seq = syn_seq;
            tcp_send_segment(TCP_SYN, 0, 0);
            last_syn = timer_ticks();
        }
    }
    klog("NET", "no SYN-ACK (timeout)");
    return 0;
}

int net_http_request(const char *method, const char *url,
                     const char *content_type, const char *body_in,
                     char *body, u32 body_max,
                     char *header_out, u32 header_max)
{
    return net_http_request_timed(method, url, content_type, body_in,
                                  body, body_max, header_out, header_max,
                                  3000, 800);
}

int net_http_request_timed(const char *method, const char *url,
                           const char *content_type, const char *body_in,
                           char *body, u32 body_max,
                           char *header_out, u32 header_max,
                           u32 ceiling_ticks, u32 idle_ticks)
{
    return net_http_request_progress(method, url, content_type, body_in,
                                     body, body_max, header_out, header_max,
                                     ceiling_ticks, idle_ticks, 0);
}

int net_http_request_progress(const char *method, const char *url,
                              const char *content_type, const char *body_in,
                              char *body, u32 body_max,
                              char *header_out, u32 header_max,
                              u32 ceiling_ticks, u32 idle_ticks,
                              net_progress_fn progress)
{
    if (!ready) {
        return -1;
    }

    char host[128];
    char path[256];
    u16 port;
    if (!parse_url(url, host, sizeof(host), &port, path, sizeof(path))) {
        klog("HTTP", "bad URL: %s", url);
        return -1;
    }

    u8 ip[4];
    if (!net_dns_resolve(host, ip)) {
        klog("HTTP", "cannot resolve %s", host);
        return -1;
    }
    char ipstr[16];
    net_format_ip(ip, ipstr);
    klog("HTTP", "%s %s%s -> %s:%u", method, host, path, ipstr, port);

    if (!http_connect(ip, port)) {
        return -1;
    }

    /* HTTP/1.0 with Connection: close means the server closes when it is done,
     * so "connection closed" is the end-of-body signal and no chunked decoding
     * is needed. */
    u32 body_len_in = body_in ? strlen(body_in) : 0;

    char req[512];
    u32 o = 0;
#define APPEND(s) \
    do { \
        for (const char *q = (s); *q && o + 1 < sizeof(req); q++) { \
            req[o++] = *q; \
        } \
    } while (0)
    APPEND(method);
    APPEND(" ");
    APPEND(path);
    APPEND(" HTTP/1.0\r\nHost: ");
    APPEND(host);
    APPEND("\r\nUser-Agent: SidwaOS/1.0\r\nAccept: */*\r\n"
           "Connection: close\r\n");
    if (body_len_in > 0) {
        APPEND("Content-Type: ");
        APPEND(content_type ? content_type : "application/octet-stream");
        APPEND("\r\n");
    }
#undef APPEND

    /* Content-Length is written by hand because APPEND only takes strings. */
    if (body_len_in > 0) {
        char cl[48];
        u32 n = 0;
        const char *pre = "Content-Length: ";
        while (*pre && o + 1 < sizeof(req)) {
            req[o++] = *pre++;
        }
        /* Decimal, most significant first. */
        char digits[12];
        u32 d = 0;
        u32 v = body_len_in;
        do {
            digits[d++] = (char)('0' + (v % 10));
            v /= 10;
        } while (v);
        while (d && o + 1 < sizeof(req)) {
            cl[n++] = digits[--d];
        }
        cl[n] = '\0';
        for (u32 i = 0; i < n && o + 1 < sizeof(req); i++) {
            req[o++] = cl[i];
        }
    }
    if (o + 3 < sizeof(req)) {
        req[o++] = '\r';
        req[o++] = '\n';
        req[o++] = '\r';
        req[o++] = '\n';
    }

    /* The connection owns the body buffer from here on. */
    conn.body = (u8 *)body;
    conn.body_max = body_max;
    conn.body_len = 0;

    u32 sent = 0;
    while (sent < o) {
        u32 chunk = o - sent;
        if (chunk > 1024) {
            chunk = 1024;
        }
        if (!tcp_send_segment(TCP_ACK | TCP_PSH,
                              (const u8 *)req + sent, chunk)) {
            return -1;
        }
        sent += chunk;
    }

    /* The request body follows the blank line, sent in the same way. */
    u32 bsent = 0;
    while (bsent < body_len_in) {
        u32 chunk = body_len_in - bsent;
        if (chunk > 1024) {
            chunk = 1024;
        }
        if (!tcp_send_segment(TCP_ACK | TCP_PSH,
                              (const u8 *)body_in + bsent, chunk)) {
            return -1;
        }
        bsent += chunk;
    }

    u32 start = timer_ticks();
    u32 idle_start = start;
    u32 last_len = 0;
    u32 reported = 0;

    /* Announce the wait before entering it. A model can sit silent for most of
     * a minute while it computes, and the first second is the one that decides
     * whether the machine looks busy or frozen, so the report comes before the
     * first poll rather than after the first second has passed. */
    if (progress) {
        progress(0);
    }

    while (timer_ticks() - start < ceiling_ticks) {
        net_poll();
        if (conn.body_len != last_len) {
            last_len = conn.body_len;
            idle_start = timer_ticks();         /* progress: extend the wait */
        }
        if (conn.remote_closed) {
            break;
        }
        /* Once per whole second, not once per poll: the loop spins thousands of
         * times a second and a report per poll would be a flood, which is the
         * opposite of showing that the machine is calm and working. */
        u32 elapsed = timer_ticks() - start;
        if (progress && elapsed / 100 != reported) {
            reported = elapsed / 100;
            progress(elapsed);
        }
        if (timer_ticks() - idle_start > idle_ticks) {
            break;
        }
    }

    if (conn.state == TCP_ESTABLISHED) {
        tcp_send_segment(TCP_FIN | TCP_ACK, 0, 0);
        u32 close_start = timer_ticks();
        while (timer_ticks() - close_start < 100) {
            net_poll();
        }
    }
    conn.state = TCP_CLOSED;

    /* Split the headers from the body at the blank line. */
    u8 *data = (u8 *)body;
    u32 total = conn.body_len;
    u32 split = 0;
    for (u32 i = 0; i + 3 < total; i++) {
        if (data[i] == '\r' && data[i+1] == '\n' &&
            data[i+2] == '\r' && data[i+3] == '\n') {
            split = i + 4;
            break;
        }
    }
    if (split == 0) {
        klog("HTTP", "no header/body separator found");
        return -1;
    }

    if (header_out && header_max) {
        u32 n = split < header_max - 1 ? split : header_max - 1;
        memcpy(header_out, data, n);
        header_out[n] = '\0';
    }

    u32 body_len = total - split;
    bytes_move(data, data + split, body_len);
    if (body_len < body_max) {
        data[body_len] = '\0';
    }
    return (int)body_len;
}

/* GET is the common case, so it keeps its own name and signature. */
int net_http_get(const char *url, char *body, u32 body_max,
                 char *header_out, u32 header_max)
{
    return net_http_request("GET", url, 0, 0, body, body_max,
                            header_out, header_max);
}

/* POST a JSON body and return the response body. Used to talk to a local
 * model server, which takes its prompt in the request rather than the URL. */
int net_http_post_json(const char *url, const char *json,
                       char *body, u32 body_max,
                       char *header_out, u32 header_max)
{
    return net_http_request("POST", url, "application/json", json,
                            body, body_max, header_out, header_max);
}

int net_http_post_json_timed(const char *url, const char *json,
                             char *body, u32 body_max,
                             char *header_out, u32 header_max,
                             u32 ceiling_ticks, u32 idle_ticks)
{
    return net_http_request_progress("POST", url, "application/json", json,
                                     body, body_max, header_out, header_max,
                                     ceiling_ticks, idle_ticks, 0);
}

int net_http_post_json_progress(const char *url, const char *json,
                                char *body, u32 body_max,
                                char *header_out, u32 header_max,
                                u32 ceiling_ticks, u32 idle_ticks,
                                net_progress_fn progress)
{
    return net_http_request_progress("POST", url, "application/json", json,
                                     body, body_max, header_out, header_max,
                                     ceiling_ticks, idle_ticks, progress);
}

/* --- Configuration and reporting -------------------------------------------- */

int net_configure(const char *ip, const char *mask,
                  const char *gateway, const char *dns)
{
    int ok = 1;
    if (ip && !net_parse_ip(ip, cfg.ip)) {
        ok = 0;
    }
    if (mask && !net_parse_ip(mask, cfg.mask)) {
        ok = 0;
    }
    if (gateway && !net_parse_ip(gateway, cfg.gateway)) {
        ok = 0;
    }
    if (dns && !net_parse_ip(dns, cfg.dns)) {
        ok = 0;
    }
    return ok;
}

int net_probe(void)
{
    have_nic = rtl8139_init();
    if (!have_nic) {
        klog("NET", "no network card found");
        return 0;
    }
    return 1;
}

int net_init(void)
{
    if (!have_nic && !net_probe()) {
        return 0;
    }

    /* QEMU's user-mode network hands out this configuration. A different
     * environment overrides it with `net set`. */
    static const u8 def_ip[4]   = { 10, 0, 2, 15 };
    static const u8 def_mask[4] = { 255, 255, 255, 0 };
    static const u8 def_gw[4]   = { 10, 0, 2, 2 };
    static const u8 def_dns[4]  = { 10, 0, 2, 3 };
    ip_copy(cfg.ip, def_ip);
    ip_copy(cfg.mask, def_mask);
    ip_copy(cfg.gateway, def_gw);
    ip_copy(cfg.dns, def_dns);

    memset(arp_cache, 0, sizeof(arp_cache));
    ready = 1;

    char buf[16];
    net_format_ip(cfg.ip, buf);
    klog("NET", "up: ip %s/24 gateway 10.0.2.2 dns 10.0.2.3", buf);
    return 1;
}

void net_report(void)
{
    if (!have_nic) {
        klog("NET", "no network card");
        return;
    }
    char ip[16], mask[16], gw[16], dns[16];
    net_format_ip(cfg.ip, ip);
    net_format_ip(cfg.mask, mask);
    net_format_ip(cfg.gateway, gw);
    net_format_ip(cfg.dns, dns);
    const u8 *mac = rtl8139_mac();
    klog("NET", "MAC %x:%x:%x:%x:%x:%x io 0x%x",
         mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], rtl8139_io_base());
    klog("NET", "ip %s mask %s gateway %s dns %s", ip, mask, gw, dns);

    u32 entries = 0;
    for (u32 i = 0; i < NET_ARP_MAX; i++) {
        if (arp_cache[i].valid) {
            entries++;
        }
    }
    klog("NET", "frames rx %u tx %u, arp cache %u/%u",
         rx_frames, tx_frames, entries, (u32)NET_ARP_MAX);
}

int net_selftest(void)
{
    if (!have_nic) {
        return 0;
    }
    if (!ready && !net_init()) {
        return 0;
    }

    /* The gateway is the one host that must always answer: it is the virtual
     * router QEMU provides. A reply proves the driver, ARP, IP and ICMP work,
     * without depending on the wider network. */
    char gw[16];
    net_format_ip(cfg.gateway, gw);
    int rtt = net_ping(cfg.gateway, 2000);
    if (rtt < 0) {
        klog("NET", "selftest: no ping reply from gateway %s", gw);
        return 0;
    }
    klog("NET", "selftest: gateway %s replied in %d ms", gw, rtt);
    return 1;
}
