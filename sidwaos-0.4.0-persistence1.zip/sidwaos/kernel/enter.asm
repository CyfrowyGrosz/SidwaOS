; Fast-exit trampoline for Loop 1 (RUN).
;
; The kernel deliberately does NOT perform a full context switch to run a
; fragment. It saves only the callee-saved registers, runs the fragment on its
; own stack, then restores. That is the "fast exit": small fragments return to
; the scheduler with minimal overhead.
;
; The canary is planted at the *bottom* of the fragment stack, not the top. The
; `call` itself writes a return address at the top, so a canary placed there
; would be destroyed immediately. Placed at the bottom, it only gets clobbered
; if the fragment runs off the end of its stack -- which is what we want to
; detect.
;
; The scheduler's stack pointer is parked in a static slot because `call` may
; clobber any caller-saved register (eax, ecx, edx), and the fragment is
; arbitrary code that must not be trusted with esp.
bits 32

section .bss
align 4
saved_sp:   resd 1
saved_can:  resd 1
saved_slot: resd 1

section .text

global fast_enter

; int fast_enter(void *stack_top, uint32_t *canary_slot, uint32_t canary,
;                void (*entry)(void))
;   eax = 1 on a clean return, 0 if the canary was clobbered.
fast_enter:
    push ebp
    push ebx
    push esi
    push edi

    mov edi, [esp + 20]             ; stack_top   (4 saved regs + ret addr)
    mov esi, [esp + 24]             ; canary_slot
    mov ebx, [esp + 28]             ; canary
    mov edx, [esp + 32]             ; entry

    mov [esi], ebx                  ; plant the canary at the stack bottom

    mov [saved_sp], esp             ; park the scheduler's stack
    mov [saved_slot], esi
    mov [saved_can], ebx

    mov esp, edi                    ; switch to the fragment stack
    call edx                        ; run the fragment

    mov esp, [saved_sp]             ; back to the scheduler stack

    xor eax, eax                    ; assume success
    mov esi, [saved_slot]
    mov ebx, [saved_can]
    cmp [esi], ebx                  ; canary intact?
    jne .done
    mov eax, 1
.done:
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret
