/* Durable machine settings. See include/config.h.
 *
 * Settings reuse the .sidwa partition and its record format: a record is
 * "cfg:<key>\t<value>". The prefix is what separates a setting from a fact, so
 * the knowledge tier's exact-key matching never confuses the two.
 */

#include "config.h"
#include "kb.h"
#include "serial.h"
#include "string.h"

#define CFG_PREFIX "cfg:"

/* Build the prefixed key "cfg:<key>" used on disk. Returns length, or -1. */
static int build_key(const char *key, char *out, u32 max)
{
    u32 n = 0;

    if (!key || !*key) {
        return -1;
    }
    for (const char *p = CFG_PREFIX; *p; p++) {
        if (n + 1 >= max) {
            return -1;
        }
        out[n++] = *p;
    }
    for (const char *p = key; *p; p++) {
        if (n + 1 >= max) {
            return -1;
        }
        out[n++] = *p;
    }
    out[n] = '\0';
    return (int)n;
}

/* Build the on-disk record for `key`. Returns its length, or -1 if the key or
 * the resulting record would not fit a slot. */
static int build_record(const char *key, const char *value, char *rec, u32 max)
{
    u32 n = 0;

    int k = build_key(key, rec, max);
    if (k < 0) {
        return -1;
    }
    n = (u32)k;
    if (n + 1 >= max) {
        return -1;
    }
    rec[n++] = '\t';
    for (const char *p = value ? value : ""; *p; p++) {
        if (n + 1 >= max) {
            return -1;
        }
        rec[n++] = *p;
    }
    rec[n] = '\0';
    return (int)n;
}

/* Find the sequence number of the record for `key`, or 0 when absent. */
static u32 seq_of(const char *key)
{
    static char rec[KB_DATA_MAX];
    char want[CONFIG_KEY_MAX];
    char have[CONFIG_KEY_MAX];

    if (build_key(key, want, sizeof(want)) < 0) {
        return 0;
    }

    u32 cursor = 0, seq = 0;
    int n;
    while ((n = kb_next(&cursor, &seq, rec, sizeof(rec) - 1)) >= 0) {
        rec[n] = '\0';              /* kb_next copies bytes but does not terminate */
        u32 i = 0;
        for (; rec[i] && rec[i] != '\t' && i + 1 < sizeof(have); i++) {
            have[i] = rec[i];
        }
        have[i] = '\0';
        if (rec[i] != '\t') {
            continue;               /* not a key/value record */
        }
        if (strcmp(have, want) == 0) {
            return seq;
        }
    }
    return 0;
}

int config_set(const char *key, const char *value)
{
    if (!key || !*key) {
        return 0;
    }
    if (!kb_mount()) {
        return 0;
    }

    /* Replace rather than accumulate: a setting has one current value. */
    u32 old = seq_of(key);
    if (old) {
        kb_delete(old);
    }

    char rec[KB_DATA_MAX];
    int n = build_record(key, value, rec, sizeof(rec));
    if (n < 0) {
        klog("CFG", "setting '%s' does not fit a record slot", key);
        return 0;
    }
    if (kb_append(rec, (u32)n) < 0) {
        return 0;
    }
    return 1;
}

int config_get(const char *key, char *out, u32 max)
{
    static char rec[KB_DATA_MAX];
    char want[CONFIG_KEY_MAX];
    char have[CONFIG_KEY_MAX];

    if (!key || !*key || !out || max == 0) {
        return -1;
    }
    if (!kb_mount()) {
        return -1;
    }
    if (build_key(key, want, sizeof(want)) < 0) {
        return -1;
    }

    u32 cursor = 0, seq = 0;
    int n;
    while ((n = kb_next(&cursor, &seq, rec, sizeof(rec) - 1)) >= 0) {
        rec[n] = '\0';              /* kb_next copies bytes but does not terminate */
        u32 i = 0;
        for (; rec[i] && rec[i] != '\t' && i + 1 < sizeof(have); i++) {
            have[i] = rec[i];
        }
        have[i] = '\0';
        if (rec[i] != '\t') {
            continue;
        }
        if (strcmp(have, want) == 0) {
            const char *v = rec + i + 1;
            u32 j = 0;
            for (; v[j] && j + 1 < max; j++) {
                out[j] = v[j];
            }
            out[j] = '\0';
            return (int)j;
        }
    }
    return -1;
}

int config_del(const char *key)
{
    if (!key || !*key || !kb_mount()) {
        return 0;
    }
    u32 seq = seq_of(key);
    return seq ? kb_delete(seq) : 0;
}

void config_list(void)
{
    static char rec[KB_DATA_MAX];
    u32 cursor = 0, seq = 0;
    u32 shown = 0;
    int n;

    while ((n = kb_next(&cursor, &seq, rec, sizeof(rec) - 1)) >= 0) {
        rec[n] = '\0';              /* kb_next copies bytes but does not terminate */
        if (strncmp(rec, CFG_PREFIX, sizeof(CFG_PREFIX) - 1) != 0) {
            continue;
        }
        const char *p = rec + sizeof(CFG_PREFIX) - 1;
        char key[CONFIG_KEY_MAX];
        u32 i = 0;
        for (; p[i] && p[i] != '\t' && i + 1 < sizeof(key); i++) {
            key[i] = p[i];
        }
        key[i] = '\0';
        const char *value = (p[i] == '\t') ? p + i + 1 : "";
        klog("CFG", "%s = %s", key, value);
        shown++;
    }
    if (shown == 0) {
        klog("CFG", "no settings stored");
    }
}

int config_selftest(void)
{
    static const char key[] = "sidwa-selftest-setting";
    static const char v1[] = "first";
    static const char v2[] = "second";
    char out[CONFIG_VALUE_MAX];

    if (!config_set(key, v1)) {
        return 0;
    }
    if (config_get(key, out, sizeof(out)) < 0 || strcmp(out, v1) != 0) {
        return 0;
    }

    /* A second set must replace, not duplicate, so the read sees the new value
     * and only one record exists for the key. */
    if (!config_set(key, v2)) {
        return 0;
    }
    if (config_get(key, out, sizeof(out)) < 0 || strcmp(out, v2) != 0) {
        return 0;
    }

    /* Clean up so the partition is left exactly as it was found. */
    return config_del(key) && config_get(key, out, sizeof(out)) < 0;
}
