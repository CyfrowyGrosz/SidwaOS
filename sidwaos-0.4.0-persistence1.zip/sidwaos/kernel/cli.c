/* Command-line front end over serial.
 *
 * A thin reader over the shared action dispatcher (kernel/actions.c), plus the
 * `ask` entry point that hands free text to the AI bridge. Keeping dispatch in
 * one place means a typed command and an agent-chosen action run identical code.
 */

#include "cli.h"
#include "actions.h"
#include "ai.h"
#include "know.h"
#include "serial.h"
#include "string.h"
#include "stats.h"

/* One typed line. Large enough for a full task specification, not just a
 * command: `synth` takes the task and the expected output on one line, and a
 * task that needs a method spelled out -- "keep the pair in r0 and r1, count in
 * r3" -- is longer than a command name and its arguments. A smaller limit
 * silently truncated the specification and the model then had to guess at the
 * part that was cut. */
#define LINE_MAX 256
#define ARG_MAX  8

static char line[LINE_MAX];
static char raw[LINE_MAX];      /* untouched copy: tokenize() edits `line` in place */

/* Wait for one byte, halting between polls.
 *
 * serial_getc() spins on the UART, which is a busy-wait: the processor runs at
 * full speed doing nothing for as long as the user takes to type. This polls
 * instead, and when there is no byte it halts and tells the statistics module
 * so. That is what makes the CPU load figure mean something -- the only time
 * this machine is genuinely idle is here, and now it is measured. */
static char cli_getc(void)
{
    while (!serial_rx_ready()) {
        stats_idle_wait();
    }
    return (char)serial_getc();
}

/* Read one line with echo. Handles CR, LF and backspace. */
static int read_line(void)
{
    u32 n = 0;

    for (;;) {
        char c = cli_getc();

        if (c == '\r' || c == '\n') {
            serial_puts("\n");
            line[n] = '\0';
            for (u32 i = 0; i <= n; i++) {
                raw[i] = line[i];
            }
            return (int)n;
        }
        if (c == 0x7F || c == 0x08) {       /* backspace / delete */
            if (n > 0) {
                n--;
                serial_puts("\b \b");
            }
            continue;
        }
        if (n + 1 < LINE_MAX && c >= 0x20) {
            line[n++] = c;
            serial_putc(c);
        }
    }
}

/* Split `line` into whitespace-separated tokens, in place. */
static u32 tokenize(char *s, char **argv, u32 max)
{
    u32 argc = 0;

    while (*s && argc < max) {
        while (*s == ' ' || *s == '\t') {
            *s++ = '\0';
        }
        if (!*s) {
            break;
        }
        argv[argc++] = s;
        while (*s && *s != ' ' && *s != '\t') {
            s++;
        }
    }
    return argc;
}

/* The remainder of the line after the first token, for `ask`. */
static const char *rest_after(const char *s, const char *first)
{
    const char *p = s + strlen(first);
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    return p;
}

/* Answer a line that is not a command, by treating it as a question.
 *
 * A user should not have to remember a command name to ask the machine
 * something it may already know, so anything the dispatcher does not recognise
 * is looked up as it stands: RAM, then .sidwa, then the host. A miss is
 * recorded as a gap, which is how the machine's own list of what to learn grows
 * out of what it is actually asked -- the question is kept even though the
 * answer is not yet known. */
static void cli_query(const char *text)
{
    static char answer[KNOW_VALUE_MAX];
    if (ai_lookup(text, answer, sizeof(answer)) < 0) {
        /* ai_lookup() has already logged which tiers were tried and recorded
         * the gap; this is the line the user reads. */
        klog("AI", "I do not know '%s' yet", text);
        return;
    }
    klog("AI", "%s", answer);
}

void cli_run(void)
{
    serial_puts("\n3-state I/O machine - type 'help' for commands\n");

    for (;;) {
        char *argv[ARG_MAX];
        u32 argc;

        serial_puts("os> ");
        if (read_line() == 0) {
            continue;
        }
        argc = tokenize(line, argv, ARG_MAX);
        if (argc == 0) {
            continue;
        }

        if (strcmp(argv[0], "ask") == 0) {
            ai_ask(rest_after(raw, argv[0]));
            continue;
        }
        if (strcmp(argv[0], "ai") == 0) {
            int on = (argc > 1 && strcmp(argv[1], "on") == 0);
            ai_set_mode(on);
            klog("CLI", "AI bridge %s", on ? "on" : "off");
            continue;
        }

        int rc = actions_dispatch(argv[0], rest_after(raw, argv[0]));
        if (rc == ACTION_HALT) {
            serial_puts("halted\n");
            return;
        }
        if (rc == ACTION_UNKNOWN) {
            /* Not a command, so treat the line as a question. A user should be
             * able to ask the machine something without knowing that `know`
             * exists; the command name was the only reason a question had to be
             * wrapped in one. Commands still win: dispatch is tried first, and
             * only what it does not recognise becomes a query. */
            cli_query(raw);
        }
    }
}
