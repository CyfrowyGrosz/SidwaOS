/* App-blob validation and authorization. */

#include "app.h"
#include "ata.h"
#include "string.h"

/* The ATA layer always moves whole sectors, so a blob must be exactly one
 * sector. If this fails, reading a blob overruns its buffer and corrupts
 * whatever follows it in memory. */
_Static_assert(sizeof(struct app_blob) == ATA_SECTOR_SIZE,
               "app_blob must occupy exactly one ATA sector");

static const char *last_error;

/* Authorized serial keys. The "original serial key" check admits a program only
 * when its key appears here. Two keys are provisioned: one for the demo's valid
 * program, one spare. */
static const u32 authorized_keys[] = {
    0xA5A5C0DEu,
    0x1234BEEFu,
};
#define AUTHORIZED_KEY_COUNT (sizeof(authorized_keys) / sizeof(authorized_keys[0]))

u32 app_checksum(const u8 *payload, u32 size)
{
    u32 sum = 0;
    for (u32 i = 0; i < size; i++) {
        sum = (sum << 1) ^ (sum >> 31) ^ payload[i];
    }
    return sum;
}

int app_logic_test(const struct app_blob *blob)
{
    last_error = 0;

    if (blob->header.magic != APP_MAGIC) {
        last_error = "bad magic";
        return 0;
    }
    if (blob->header.version != APP_VERSION) {
        last_error = "bad version";
        return 0;
    }
    if (blob->header.size == 0 || blob->header.size > APP_MAX_PAYLOAD) {
        last_error = "size out of bounds";
        return 0;
    }
    if (blob->header.entry_offset >= blob->header.size) {
        last_error = "entry offset out of bounds";
        return 0;
    }
    if (app_checksum(blob->payload, blob->header.size) != blob->header.checksum) {
        last_error = "bad checksum";
        return 0;
    }
    return 1;
}

int app_key_verify(const struct app_blob *blob)
{
    for (u32 i = 0; i < AUTHORIZED_KEY_COUNT; i++) {
        if (blob->header.serial_key == authorized_keys[i]) {
            return 1;
        }
    }
    return 0;
}

const char *app_last_error(void)
{
    return last_error;
}
