/* The optimisation course. See include/optim.h.
 *
 * The lessons build up to one demonstration, run live in the kernel: the same
 * frame drawn through the VGA console two ways. The slow way writes each cell
 * through vga_putc_at and moves the hardware cursor after every character, which
 * means four I/O port writes per character. The fast way writes the cell words
 * directly and moves the cursor once. The pictures are identical; the cycle
 * counts are not.
 */

#include "optim.h"
#include "curriculum.h"
#include "vga.h"
#include "cache.h"
#include "serial.h"
#include "string.h"

/* The slow writer: the obvious transcription of "draw a frame".
 *
 * vga_putc_at bounds-checks the cell and writes one character; vga_gotoxy then
 * drives the CRTC cursor through four port writes. For an 80x25 frame that is
 * 2000 bounds checks and 8000 port writes to place 2000 cells.
 */
static void draw_slow(u8 attr)
{
    for (u32 y = 0; y < VGA_ROWS; y++) {
        for (u32 x = 0; x < VGA_COLS; x++) {
            vga_putc_at(x, y, ' ', attr);
            vga_gotoxy(x, y);               /* four port writes per cell */
        }
    }
    vga_box(0, 0, VGA_COLS, VGA_ROWS, attr);
}

/* The fast writer: the same frame, drawn once, without the per-cell cursor move.
 *
 * The bounds check is hoisted out because the loop bounds are known, the cell is
 * written as one 16-bit store rather than a checked byte, and the cursor moves a
 * single time at the end. Same picture, a fraction of the work.
 */
static void draw_fast(u8 attr)
{
    volatile u16 *cells = (volatile u16 *)VGA_BASE;
    u16 blank = (u16)' ' | ((u16)attr << 8);

    for (u32 i = 0; i < VGA_COLS * VGA_ROWS; i++) {
        cells[i] = blank;                   /* one store, no check */
    }
    vga_box(0, 0, VGA_COLS, VGA_ROWS, attr);
    vga_gotoxy(0, 0);                       /* the cursor moves once */
}

static u64 now_cycles(void)
{
    return tsc_read();
}

int optim_benchmark(void)
{
    u64 slow_start, slow_end, fast_start, fast_end;
    u64 slow_cycles, fast_cycles;

    /* The VGA console is shared, so save and restore the screen around the
     * run: the benchmark must not disturb whatever was on screen. */
    volatile u16 *cells = (volatile u16 *)VGA_BASE;
    static u16 saved[VGA_COLS * VGA_ROWS];
    static u16 slow_frame[VGA_COLS * VGA_ROWS];
    u8 attr = VGA_ATTR(VGA_LIGHTGRAY, VGA_BLUE);
    u32 n = VGA_COLS * VGA_ROWS;

    for (u32 i = 0; i < n; i++) {
        saved[i] = cells[i];
    }

    slow_start = now_cycles();
    draw_slow(attr);
    slow_end = now_cycles();
    for (u32 i = 0; i < n; i++) {
        slow_frame[i] = cells[i];           /* the picture to match */
    }

    fast_start = now_cycles();
    draw_fast(attr);
    fast_end = now_cycles();

    /* The pictures must match for the timing to mean anything. */
    int same = 1;
    for (u32 i = 0; i < n; i++) {
        if (cells[i] != slow_frame[i]) {
            same = 0;
            break;
        }
    }

    for (u32 i = 0; i < n; i++) {
        cells[i] = saved[i];
    }

    slow_cycles = slow_end - slow_start;
    fast_cycles = fast_end - fast_start;

    klog("OPTIM", "slow frame: %u cycles", (u32)slow_cycles);
    klog("OPTIM", "fast frame: %u cycles", (u32)fast_cycles);
    if (fast_cycles) {
        /* Scale both down until each fits 24 bits. Then sc * 100 still fits a
         * 32-bit word and the ratio can be found with 32-bit division, which
         * the kernel has without libgcc. */
        u64 sc = slow_cycles;
        u64 fc = fast_cycles;
        while (sc > 0xFFFFFFull || fc > 0xFFFFFFull) {
            sc >>= 1;
            fc >>= 1;
        }
        u32 a = (u32)sc;
        u32 b = (u32)fc;
        u32 r100 = b ? (a * 100u) / b : 0;
        u32 whole = r100 / 100;
        u32 frac = r100 % 100;
        klog("OPTIM", "the fast version is %u.%ux faster, same picture: %s",
             whole, frac < 10 ? 0 : frac / 10, same ? "yes" : "no");
    }
    return same;
}

void optim_show_pair(void)
{
    klog("OPTIM", "slow: per cell a bounds check and a cursor move");
    klog("OPTIM", "      for (y) for (x) { putc_at(x,y); gotoxy(x,y); }");
    klog("OPTIM", "fast: one store per cell, one cursor move per frame");
    klog("OPTIM", "      for (i) cells[i] = blank; gotoxy(0,0);");
}

static const struct lesson optim_lessons[] = {
    { 1, "Start from a program that works", 6, {
        "Optimisation begins with something",
        "correct and too slow, never with",
        "a guess about what is slow.",
        "Keep the working version; it is",
        "the reference the fast one must",
        "still match, byte for byte.",
    }},
    { 2, "Decompile it", 6, {
        "Build the slow version and read it.",
        "objdump -d shows the instructions.",
        "Look for work that repeats:",
        "the same bounds check in a loop,",
        "a function called with the same",
        "arguments a thousand times.",
    }},
    { 3, "Find the waste", 6, {
        "The slow frame moves the cursor",
        "after every character: four port",
        "writes each, 8000 for one screen.",
        "The port write is the cost, not the",
        "character. Waste is usually I/O",
        "done more often than it changes.",
    }},
    { 4, "Write the same program, faster", 6, {
        "Hoist the loop invariant out.",
        "Write the widest unit the data has,",
        "a word instead of two bytes.",
        "Move the cursor once, not per cell.",
        "The new code should read like the",
        "old, with the repeated work gone.",
    }},
    { 5, "Prove it is the same", 6, {
        "A fast program that draws a",
        "different picture is not an",
        "optimisation, it is a bug.",
        "Compare the output of both.",
        "In SidwaOS the benchmark draws",
        "both frames and checks they match.",
    }},
    { 6, "Measure, do not assume", 6, {
        "rdtsc counts CPU cycles.",
        "Read it before and after each run.",
        "The lesson is the number: the",
        "fast frame here is many times",
        "quicker, and the two frames are",
        "identical. Run 'optim bench'.",
    }},
};

static const u32 optim_lesson_count =
    sizeof(optim_lessons) / sizeof(optim_lessons[0]);

u32 optim_count(void) { return optim_lesson_count; }

const struct lesson *optim_get(u32 index)
{
    return index < optim_lesson_count ? &optim_lessons[index] : 0;
}

const struct lesson *optim_find(const char *keyword)
{
    for (u32 i = 0; i < optim_lesson_count; i++) {
        if (stristr(optim_lessons[i].title, keyword)) {
            return &optim_lessons[i];
        }
        for (u32 l = 0; l < optim_lessons[i].lines; l++) {
            if (stristr(optim_lessons[i].body[l], keyword)) {
                return &optim_lessons[i];
            }
        }
    }
    return 0;
}

void optim_print(const struct lesson *lesson)
{
    if (!lesson) {
        return;
    }
    klog("OPTIM", "Lesson %u: %s", lesson->number, lesson->title);
    for (u32 i = 0; i < lesson->lines; i++) {
        klog("OPTIM", "  %s", lesson->body[i]);
    }
}

void optim_print_all(void)
{
    klog("OPTIM", "optimisation course: %u lessons", optim_lesson_count);
    for (u32 i = 0; i < optim_lesson_count; i++) {
        optim_print(&optim_lessons[i]);
    }
}

int optim_selftest(void)
{
    /* The course is well formed when it has lessons and each names a title. */
    if (optim_lesson_count == 0) {
        return 0;
    }
    for (u32 i = 0; i < optim_lesson_count; i++) {
        if (!optim_lessons[i].title || !optim_lessons[i].lines) {
            return 0;
        }
    }

    /* The benchmark must draw two identical frames, or the course is teaching
     * from a broken example. */
    return optim_benchmark();
}
