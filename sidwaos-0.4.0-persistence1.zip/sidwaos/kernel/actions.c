/* Shared command dispatcher. See include/actions.h.
 *
 * The single-argument form is what the AI bridge uses; the CLI passes a whole
 * line and the same functions run.
 */

#include "actions.h"
#include "serial.h"
#include "string.h"
#include "state.h"
#include "cache.h"
#include "bitflow.h"
#include "aidebug.h"
#include "version.h"
#include "kb.h"
#include "localai.h"
#include "know.h"
#include "think.h"
#include "codec.h"
#include "fetch.h"
#include "config.h"
#include "ai.h"
#include "curriculum.h"
#include "gui.h"
#include "outcome.h"
#include "method.h"
#include "optim.h"
#include "layout.h"
#include "sysinfo.h"
#include "sasm.h"
#include "svm.h"
#include "net.h"
#include "ollama.h"
#include "stats.h"
#include "pedant.h"
#include "synth.h"

static u32 parse_u32(const char *s, u32 fallback)
{
    u32 value = 0;
    int any = 0;

    if (!s) {
        return fallback;
    }
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        s += 2;
        while (*s) {
            u32 d;
            char c = *s++;
            if (c >= '0' && c <= '9') {
                d = (u32)(c - '0');
            } else if (c >= 'a' && c <= 'f') {
                d = (u32)(c - 'a' + 10);
            } else if (c >= 'A' && c <= 'F') {
                d = (u32)(c - 'A' + 10);
            } else {
                break;
            }
            value = value * 16 + d;
            any = 1;
        }
        return any ? value : fallback;
    }
    while (*s >= '0' && *s <= '9') {
        value = value * 10 + (u32)(*s++ - '0');
        any = 1;
    }
    return any ? value : fallback;
}

void actions_help(void)
{
    serial_puts(
        "commands:\n"
        "  <question>           just type it: the machine answers, or records\n"
        "                       that it does not know and learns it later\n"
        "  help                 this text\n"
        "  status               dump state-machine statistics\n"
        "  run                  loop 1: run fragments (CPU)\n"
        "  hold                 loop 2: logic-test queued programs\n"
        "  store                loop 3: persist keyed programs to disk\n"
        "  cycle                run all three loops in order\n"
        "  cache                report CPU cache geometry and free L1\n"
        "  bitflow              run the bit-flow self tests\n"
        "  combine <abits> <bbits>  combine two operations into one flow\n"
        "  pack <count> <width>     pack N operations of given width\n"
        "  ask <text>           interpret a request in plain words\n"
        "  ai on|off            hand free-text requests to the AI bridge\n"
        "  ollama ask <q>       ask the host's Ollama model over the network\n"
        "  ollama learn <q>     ask, and hold the answer as unverified knowledge\n"
        "  ollama report        show the endpoint, counters and last answer\n"
        "  stats                sample memory, CPU load, disk and link speed\n"
        "  debug                show faults seen and recovery statistics\n"
        "  debug test           run the fault classifier self test\n"
        "  debug fault <n>      inject a CPU fault to exercise auto-debug\n"
        "  version              show the OS name and version\n"
        "  kb                   show the .sidwa partition: grade and records\n"
        "  kb list              list the records on .sidwa\n"
        "  kb grade <1|2|3>     set compression grade, rewriting the partition\n"
        "  kb put <text>        append a record to .sidwa\n"
        "  learn                train the local AI and save the weights\n"
        "  learn test           train to convergence and report accuracy\n"
        "  learn save           write the weights to .sidwa\n"
        "  learn load           reload the weights from .sidwa\n"
        "  learn reset          forget the trained weights\n"
        "  know <query>         look up a fact: RAM, then .sidwa, then web\n"
        "  know verify <query>  confirm a fact and persist it to .sidwa\n"
        "  know forget <query>  drop a fact that turned out to be wrong\n"
        "  know                 show the RAM knowledge cache\n"
        "  pedant               the machine's own critic: what it cannot answer\n"
        "  pedant audit         report what the machine's own state says is weak\n"
        "  pedant gaps          list unanswered questions, most-asked first\n"
        "  pedant save|load     persist or reload the gap ledger\n"
        "  pedant clear         forget the gap ledger\n"
        "  pedant test          run the critic self test\n"
        "  think <text>         reason about a request: weigh rules, model\n"
        "                       and past results, then act only if supported\n"
        "  think                show the thinking counters and last trace\n"        "  codec                encode the example program, raw vs packed\n"
        "  codec opt            time the two packed encoders, check same bytes\n"        "  fetch                show what has been fetched and learned\n"
        "  fetch learn <url> | <question>   fetch a page, hold the answer in RAM\n"
        "  fetch verify <a> | <b> | <question>  store it if two sources agree\n"
        "  set <key> <value>    store a setting on .sidwa\n"
        "  get [key]            show a setting, or all of them\n"
        "  unset <key>          remove a setting\n"
        "  lesson               list the C course\n"
        "  lesson <n>           teach lesson n of the C course\n"
        "  lesson <word>        find and teach the lesson matching a word\n"
        "  hello                teach Hello World, then show it as a GUI\n"
        "  rev                  list the reverse-engineering course\n"
        "  rev <n|word>         teach a reverse-engineering lesson\n"
        "  sysinfo              report CPU, RAM, disk and AI size\n"
        "  method               the 5-loop programming method\n"
        "  method <n|word>      teach one loop of the method\n"
        "  optim                the optimisation course\n"
        "  optim <n|word>       teach one optimisation lesson\n"
        "  optim bench          time the slow and fast frame writers\n"
        "  optim pair           show the slow and fast code side by side\n"
        "  install              what the installer needs from this disk\n"
        "  layout               show the disk layout in use\n"
        "  results              show which methods have achieved results\n"
        "  results save|load    persist or reload the result tallies\n"
        "  results reset        forget the result tallies\n"
        "  asm <n>              assemble and run built-in program n\n"
        "  synth <task> => <out>  have the model write a program and prove it\n"
        "  asm list             list the built-in example programs\n"
        "  asm                  assemble and run the default example\n"
        "  net                  show the network configuration and counters\n"
        "  net set <ip> <mask> <gw> <dns>   set the address\n"
        "  net ping <host>      resolve and ping a host\n"
        "  net dns <name>       resolve a name to an address\n"
        "  net http <url>       fetch a page over HTTP and show it\n"
        "  net probe            rescan PCI for the network card\n"
        "  ide                  open the program IDE (q quits)\n"
        "  gui                  open the windowed GUI (q quits)\n"
        "  halt                 stop the command line\n");
}

static void cmd_bitflow(void)
{
    klog("CLI", "nibble combine selftest: %s",
         bitflow_combine_selftest((const u8 *)"ABCDEFGH",
                                  (const u8 *)"12345678", 8) ? "ok" : "bad");
    klog("CLI", "process combine selftest: %s",
         bitflow_process_selftest() ? "ok" : "bad");
}

/* Parse two whitespace-separated numbers from `s`. Missing values use the
 * supplied defaults. */
static void parse_two(const char *s, u32 d1, u32 d2, u32 *v1, u32 *v2)
{
    char a[24];
    u32 n = 0;

    while (s && *s == ' ') {
        s++;
    }
    while (s && *s && *s != ' ' && n + 1 < sizeof(a)) {
        a[n++] = *s++;
    }
    a[n] = '\0';
    *v1 = parse_u32(a, d1);

    while (s && *s == ' ') {
        s++;
    }
    n = 0;
    while (s && *s && *s != ' ' && n + 1 < sizeof(a)) {
        a[n++] = *s++;
    }
    a[n] = '\0';
    *v2 = (n > 0) ? parse_u32(a, d2) : d2;
}

static void cmd_combine(u32 aw, u32 bw)
{
    struct bitflow_process a = { 0, (u8)aw, "a" };
    struct bitflow_process b = { 0, (u8)bw, "b" };
    u64 flow = 0;

    a.code = ((1ull << (aw ? aw - 1 : 0)) | 1ull) & 0xFFFFull;
    b.code = 0x5A5Aull;

    if (bitflow_combine_processes(&a, &b, &flow)) {
        u64 back_a = 0, back_b = 0;
        bitflow_split_process(flow, a.width, b.width, &back_a, &back_b);
        klog("CLI", "combine %u+%u bit = %u bit -> 0x%llx (a=0x%llx b=0x%llx)",
             aw, bw, aw + bw, flow, back_a, back_b);
    } else {
        klog("CLI", "combine %u+%u bit = %u bit: refused, over the 64-bit limit",
             aw, bw, aw + bw);
    }
}

static void cmd_pack(u32 count, u32 width)
{
    u64 flow = 0;

    if (bitflow_selftest_many(count, (u8)width, &flow)) {
        klog("CLI", "pack %u processes x %u bit = %u bit -> 0x%llx",
             count, width, count * width, flow);
    } else {
        klog("CLI", "pack %u processes x %u bit = %u bit: refused (needs >64 bit)",
             count, width, count * width);
    }
}

/* Split a command line into up to `max` whitespace-separated words, in place.
 * Returns the count. Used by the `net` command's sub-arguments. */
static u32 split_words(char *line, char *words[], u32 max)
{
    u32 n = 0;
    char *p = line;
    while (*p && n < max) {
        while (*p == ' ' || *p == '\t') {
            p++;
        }
        if (!*p) {
            break;
        }
        words[n++] = p;
        while (*p && *p != ' ' && *p != '\t') {
            p++;
        }
        if (*p) {
            *p++ = '\0';
        }
    }
    return n;
}

/* net [set ip mask gateway dns | ping <host> | dns <name> | http <url>] */
static void cmd_net(const char *arg)
{
    char line[256];
    u32 n = 0;
    for (const char *p = arg ? arg : ""; *p && n + 1 < sizeof(line); p++) {
        line[n++] = *p;
    }
    line[n] = '\0';

    char *w[8];
    u32 nw = split_words(line, w, 8);

    if (nw == 0) {
        if (!net_ready() && !net_init()) {
            klog("NET", "could not bring the interface up");
            return;
        }
        net_report();
        return;
    }

    if (strcmp(w[0], "probe") == 0) {
        net_probe();
        net_report();
        return;
    }

    if (!net_ready() && !net_init()) {
        klog("NET", "could not bring the interface up");
        return;
    }

    if (strcmp(w[0], "set") == 0) {
        /* net set <ip> <mask> <gateway> <dns> */
        const char *ip  = nw > 1 ? w[1] : 0;
        const char *m   = nw > 2 ? w[2] : 0;
        const char *gw  = nw > 3 ? w[3] : 0;
        const char *dns = nw > 4 ? w[4] : 0;
        if (net_configure(ip, m, gw, dns)) {
            net_report();
        } else {
            klog("NET", "bad address; use net set <ip> <mask> <gateway> <dns>");
        }
    } else if (strcmp(w[0], "ping") == 0) {
        if (nw < 2) {
            klog("NET", "ping <host>");
            return;
        }
        u8 ip[4];
        if (!net_dns_resolve(w[1], ip)) {
            klog("NET", "cannot resolve %s", w[1]);
            return;
        }
        char ipstr[16];
        net_format_ip(ip, ipstr);
        int rtt = net_ping(ip, 3000);
        if (rtt < 0) {
            klog("NET", "no reply from %s (%s)", w[1], ipstr);
        } else {
            klog("NET", "%s (%s) replied in %d ms", w[1], ipstr, rtt);
        }
    } else if (strcmp(w[0], "dns") == 0) {
        if (nw < 2) {
            klog("NET", "dns <name>");
            return;
        }
        u8 ip[4];
        if (net_dns_resolve(w[1], ip)) {
            char ipstr[16];
            net_format_ip(ip, ipstr);
            klog("NET", "%s -> %s", w[1], ipstr);
        } else {
            klog("NET", "no answer for %s", w[1]);
        }
    } else if (strcmp(w[0], "http") == 0) {
        if (nw < 2) {
            klog("NET", "http <url>");
            return;
        }
        static char body[8192];
        static char header[1024];
        int len = net_http_get(w[1], body, sizeof(body),
                               header, sizeof(header));
        if (len < 0) {
            klog("NET", "fetch failed");
            return;
        }
        /* Print the status line, then the first few lines of the body. */
        u32 s = 0;
        while (header[s] && header[s] != '\r' && header[s] != '\n' &&
               s < 100) {
            s++;
        }
        header[s] = '\0';
        klog("HTTP", "%s", header);
        klog("HTTP", "%d bytes of body", len);

        const char *p = body;
        u32 shown = 0;
        while (*p && shown < 12) {
            char out[80];
            u32 k = 0;
            while (*p && *p != '\n' && k + 1 < sizeof(out)) {
                out[k++] = *p++;
            }
            out[k] = '\0';
            if (*p == '\n') {
                p++;
            }
            if (out[0]) {
                klog("HTTP", "  %s", out);
            }
            shown++;
        }
    } else {
        klog("NET", "net [set ...|ping <host>|dns <name>|http <url>|probe]");
    }
}

/* ollama [ask <question> | learn <question> | model <name> | url <endpoint> |
 *         test | report]
 *
 * The kernel's own route to a model served by Ollama on the host, over the
 * virtual Ethernet adapter. `ask` answers without remembering; `learn` answers
 * and offers the answer to the knowledge cache, where it is held unverified
 * until a second answer agrees. */
static void cmd_ollama(const char *arg)
{
    char line[256];
    u32 n = 0;
    for (const char *p = arg ? arg : ""; *p && n + 1 < sizeof(line); p++) {
        line[n++] = *p;
    }
    line[n] = '\0';

    char *w[4];
    u32 nw = split_words(line, w, 4);

    if (nw == 0 || strcmp(w[0], "report") == 0) {
        ollama_report();
        return;
    }

    if (strcmp(w[0], "test") == 0) {
        ollama_selftest();
        return;
    }

    if (strcmp(w[0], "model") == 0) {
        if (nw < 2) {
            klog("OLLAMA", "model is %s", ollama_model());
            return;
        }
        ollama_set_endpoint(0, w[1]);
        klog("OLLAMA", "model set to %s", ollama_model());
        return;
    }

    if (strcmp(w[0], "url") == 0) {
        if (nw < 2) {
            klog("OLLAMA", "endpoint is %s", ollama_endpoint());
            return;
        }
        ollama_set_endpoint(w[1], 0);
        klog("OLLAMA", "endpoint set to %s", ollama_endpoint());
        return;
    }

    if (strcmp(w[0], "ask") == 0 || strcmp(w[0], "learn") == 0) {
        /* Everything after the subcommand is the question, so it may contain
         * spaces and need not be quoted. */
        const char *question = arg ? arg : "";
        while (*question && *question != ' ') {
            question++;
        }
        while (*question == ' ') {
            question++;
        }
        if (!*question) {
            klog("OLLAMA", "ollama %s <question>", w[0]);
            return;
        }

        static char answer[OLLAMA_ANSWER_MAX];
        int len;
        if (strcmp(w[0], "learn") == 0) {
            len = ollama_learn(question, answer, sizeof(answer));
        } else {
            len = ollama_ask(question, answer, sizeof(answer));
        }

        if (len < 0) {
            klog("OLLAMA", "no answer for '%s'", question);
            return;
        }
        klog("OLLAMA", "%s: %s", question, answer);
        if (strcmp(w[0], "learn") == 0) {
            /* Say which of the two happened: a stored fact is knowledge the
             * machine keeps, a held one is only a candidate. Reporting both the
             * same way made an unconfirmed answer look learned. */
            if (ollama_last_stored()) {
                klog("OLLAMA", "corroborated and stored on .sidwa");
            } else {
                klog("OLLAMA", "held in RAM unverified; ask again to confirm");
            }
        }
        return;
    }

    klog("OLLAMA", "ollama [ask|learn <question>|model <name>|url <endpoint>"
                   "|test|report]");
}


/* asm [n|list]: assemble a built-in program and run it on the VM, printing the
 * output. This is the command-line face of the IDE: it proves the assembler and
 * the interpreter work without opening a window. */
static void cmd_asm(const char *arg)
{
    if (arg && strcmp(arg, "list") == 0) {
        klog("ASM", "%u built-in programs:", sasm_example_count());
        for (u32 i = 0; i < sasm_example_count(); i++) {
            klog("ASM", "  %u: %s", i, sasm_example_name(i));
        }
        return;
    }

    u32 which = 0;
    if (arg && *arg) {
        which = parse_u32(arg, 0xFFFFFFFFu);
        if (which >= sasm_example_count()) {
            klog("ASM", "no program %u (try 'asm list')", which);
            return;
        }
    }

    const char *src = sasm_example(which);
    struct sasm_program prog;
    char err[SASM_ERROR_MAX];

    if (!sasm_assemble(src, &prog, err, sizeof(err))) {
        klog("ASM", "assemble failed: %s", err);
        return;
    }
    klog("ASM", "%s: %u instructions", sasm_example_name(which), prog.count);

    char out[SVM_OUT_MAX];
    struct svm vm;
    svm_reset(&vm);
    int rc = svm_run(&vm, &prog, out, sizeof(out));
    if (rc != SVM_OK) {
        klog("ASM", "run stopped: %s", svm_error_text(rc));
        return;
    }
    klog("ASM", "output (%u steps):", vm.steps);

    /* Print the output line by line through klog, so it lands in the GUI log
     * window as well as on the serial line. */
    const char *p = out;
    while (*p) {
        char line[80];
        u32 n = 0;
        while (*p && *p != '\n' && n + 1 < sizeof(line)) {
            line[n++] = *p++;
        }
        line[n] = '\0';
        if (*p == '\n') {
            p++;
        }
        klog("ASM", "  %s", line);
    }
}

/* synth <task> => <expected output>
 *
 * Ask the model to write a program for a task, then prove it works. The syntax
 * is the task, an arrow, and the output the program must print. The arrow is
 * what separates the two, so neither part has to be quoted.
 *
 * This is the improvised half of the machine: the task can be anything the
 * instruction set can express, and the model has never seen it. What makes it
 * safe is that the answer is not believed until it has been assembled, run, and
 * seen to print what was asked for.
 */
static void cmd_synth(const char *arg)
{
    if (!arg || !*arg) {
        klog("SYNTH", "synth <task> => <expected output>");
        klog("SYNTH", "e.g. synth add 6 and 7 => 13");
        klog("SYNTH", "the model writes SidwaASM; the VM checks the output");
        return;
    }

    /* Split on "=>". Everything before is the task, everything after is the
     * output the program must print. */
    static char line[SYNTH_TASK_MAX + SYNTH_EXPECT_MAX + 8];
    u32 n = 0;
    for (const char *p = arg; *p && n + 1 < sizeof(line); p++) {
        line[n++] = *p;
    }
    line[n] = '\0';

    char *arrow = strstr(line, "=>");
    if (!arrow) {
        klog("SYNTH", "need an expected output: synth <task> => <output>");
        return;
    }
    *arrow = '\0';
    char *task = line;
    char *expect = arrow + 2;

    /* Trim both ends so "task => out" and "task=>out" behave the same. */
    while (*task == ' ') task++;
    char *te = task + strlen(task);
    while (te > task && (te[-1] == ' ' || te[-1] == '\t')) {
        *--te = '\0';
    }
    while (*expect == ' ') expect++;
    char *ee = expect + strlen(expect);
    while (ee > expect && (ee[-1] == ' ' || ee[-1] == '\t')) {
        *--ee = '\0';
    }

    /* The command line is one line, but a program that prints more than one
     * number prints more than one line: OUT ends every value with a newline.
     * \n is how a multi-line expectation is written on a single command line. */
    synth_expand_escapes(expect);

    if (!*task || !*expect) {
        klog("SYNTH", "both the task and the output are needed");
        return;
    }

    static char source[SYNTH_SOURCE_MAX];
    struct sasm_program prog;
    int rc = synth_write(task, expect, source, sizeof(source), &prog);

    if (rc != SYNTH_OK) {
        klog("SYNTH", "could not do '%s': %s", task, synth_status_text(rc));
        return;
    }

    klog("SYNTH", "task: %s", task);
    klog("SYNTH", "expects: %s", expect);
    klog("SYNTH", "program (%u instructions):", prog.count);
    /* Print the source line by line through klog so it reaches the GUI log as
     * well as the serial line. */
    const char *p = source;
    while (*p) {
        char ln[80];
        u32 k = 0;
        while (*p && *p != '\n' && k + 1 < sizeof(ln)) {
            ln[k++] = *p++;
        }
        ln[k] = '\0';
        if (*p == '\n') {
            p++;
        }
        klog("SYNTH", "  %s", ln);
    }
}

/* Deliberately trigger a CPU exception so the auto-debugger can be seen working
 * end to end. The divide-by-zero path is chosen because it is the one fault the
 * kernel knows how to recover from: the handler skips the instruction and the
 * command returns normally. */
static void cmd_debug_fault(u32 which)
{
    volatile u32 zero = 0;
    volatile u32 numerator = 100;

    if (which == 0) {
        klog("CLI", "injecting divide-by-zero at a controlled point");
        volatile u32 quotient = numerator / zero;   /* raises exception 0 */
        klog("CLI", "survived, quotient=%u", quotient);
    } else if (which == 6) {
        klog("CLI", "injecting invalid opcode");
        __asm__ volatile("ud2");                    /* raises exception 6 */
        klog("CLI", "survived the invalid opcode");
    } else {
        klog("CLI", "debug fault <n>: use 0 (divide) or 6 (bad opcode)");
    }
}

int actions_dispatch(const char *cmd, const char *arg)
{
    if (!cmd) {
        return ACTION_UNKNOWN;
    }

    if (strcmp(cmd, "help") == 0) {
        actions_help();
    } else if (strcmp(cmd, "status") == 0) {
        state_stats_dump();
    } else if (strcmp(cmd, "run") == 0) {
        loop_run();
    } else if (strcmp(cmd, "hold") == 0) {
        loop_hold();
    } else if (strcmp(cmd, "store") == 0) {
        loop_store();
    } else if (strcmp(cmd, "cycle") == 0) {
        state_machine_run();
        state_stats_dump();
    } else if (strcmp(cmd, "cache") == 0) {
        cache_report();
    } else if (strcmp(cmd, "bitflow") == 0) {
        cmd_bitflow();
    } else if (strcmp(cmd, "combine") == 0) {
        u32 aw, bw;
        parse_two(arg, 4, 4, &aw, &bw);
        cmd_combine(aw, bw);
    } else if (strcmp(cmd, "pack") == 0) {
        u32 count, width;
        parse_two(arg, 10, 6, &count, &width);
        cmd_pack(count, width);
    } else if (strcmp(cmd, "debug") == 0) {
        if (arg && strstr(arg, "test")) {
            klog("CLI", "fault classifier selftest: %s",
                 aidebug_selftest() ? "ok" : "bad");
        } else if (arg && strstr(arg, "fault")) {
            /* The fault number follows the word "fault". */
            const char *p = strstr(arg, "fault") + 5;
            while (*p == ' ') {
                p++;
            }
            cmd_debug_fault(parse_u32(p, 0));
        } else {
            aidebug_dump();
            aidebug_stats();
        }
    } else if (strcmp(cmd, "version") == 0) {
        klog("CLI", "%s %s - %s", SIDWAOS_NAME, SIDWAOS_VERSION,
             SIDWAOS_TAGLINE);
    } else if (strcmp(cmd, "kb") == 0) {
        if (!arg || !*arg) {
            klog("KB", ".sidwa partition: grade=%s records=%u capacity=%u "
                 "slot=%u bytes",
                 kb_grade_name((u8)kb_grade()), kb_count(), kb_capacity(),
                 kb_data_bytes());
        } else if (strstr(arg, "list")) {
            klog("KB", ".sidwa partition: grade=%s records=%u",
                 kb_grade_name((u8)kb_grade()), kb_count());
            kb_list(16);
        } else if (strstr(arg, "grade")) {
            const char *p = strstr(arg, "grade") + 5;
            while (*p == ' ') {
                p++;
            }
            u32 g = parse_u32(p, 1);
            if (g < 1 || g > 3) {
                klog("KB", "grade must be 1, 2 or 3");
            } else if (kb_set_grade((u8)g)) {
                /* Each grade has its own model, because the grade sets the
                 * feature count and weights do not transfer between them. */
                localai_sync_grade();
                klog("KB", "model precision is now %u-bit over %u features",
                     localai_weight_bits(), localai_feature_count());
                if (localai_load()) {
                    klog("AI", "restored the model saved at grade %u", g);
                } else {
                    klog("AI", "no model saved at grade %u yet", g);
                }
            } else {
                klog("KB", "grade change failed");
            }
        } else if (strstr(arg, "put")) {
            const char *p = strstr(arg, "put") + 3;
            while (*p == ' ') {
                p++;
            }
            int seq = kb_append(p, strlen(p));
            if (seq < 0) {
                klog("KB", "record not stored");
            } else {
                klog("KB", "stored record %d (%u bytes)", seq, strlen(p));
            }
        } else {
            klog("KB", "kb [list|grade <1-3>|put <text>]");
        }
    } else if (strcmp(cmd, "learn") == 0) {
        if (!arg || !*arg) {
            localai_report();
        } else if (strstr(arg, "test")) {
            int ok = localai_selftest();
            klog("CLI", "local AI selftest: %s", ok ? "ok" : "bad");
            localai_report();
        } else if (strstr(arg, "save")) {
            klog("CLI", "weights save: %s", localai_save() ? "ok" : "failed");
        } else if (strstr(arg, "load")) {
            klog("CLI", "weights load: %s", localai_load() ? "ok" : "none");
        } else if (strstr(arg, "reset")) {
            localai_reset();
            klog("CLI", "weights reset");
        } else {
            klog("CLI", "learn [test|save|load|reset]");
        }
    } else if (strcmp(cmd, "know") == 0) {
        if (!arg || !*arg) {
            know_report();
        } else if (strncmp(arg, "verify ", 7) == 0) {
            /* Explicit corroboration: the only way a fact reaches the disk. */
            const char *q = arg + 7;
            if (know_verify(q)) {
                klog("KNOW", "verified '%s' and stored it on .sidwa", q);
            } else {
                klog("KNOW", "'%s' is not held, so there is nothing to verify", q);
            }
        } else if (strncmp(arg, "forget ", 7) == 0) {
            /* Take back knowledge that turned out to be wrong. */
            const char *q = arg + 7;
            if (know_forget(q)) {
                klog("KNOW", "forgot '%s', removed from RAM and .sidwa", q);
            } else {
                klog("KNOW", "nothing held for '%s'", q);
            }
        } else {
            /* ai_lookup checks RAM, then .sidwa, then the host agent. */
            static char answer[KNOW_VALUE_MAX];
            int n = ai_lookup(arg, answer, sizeof(answer));
            if (n < 0) {
                klog("KNOW", "nothing known about '%s'", arg);
            } else {
                klog("KNOW", "%s: %s", arg, answer);
            }
        }
    } else if (strcmp(cmd, "pedant") == 0) {
        /* The machine's own critic: what it cannot answer, and what its own
         * state says is weak. `pedant` lists the gaps, `pedant audit` reports
         * the weaknesses, and the rest manage the ledger directly. */
        if (!arg || !*arg) {
            pedant_report();
        } else if (strstr(arg, "audit")) {
            u32 n = pedant_audit();
            klog("PEDANT", "audit complete: %u finding(s)", n);
        } else if (strstr(arg, "gaps")) {
            pedant_report();
        } else if (strstr(arg, "save")) {
            klog("PEDANT", "ledger save: %s", pedant_save() ? "ok" : "failed");
        } else if (strstr(arg, "load")) {
            klog("PEDANT", "ledger load: %s", pedant_load() ? "ok" : "none");
        } else if (strstr(arg, "clear")) {
            pedant_clear();
            pedant_save();
            klog("PEDANT", "ledger cleared");
        } else if (strstr(arg, "test")) {
            klog("PEDANT", "selftest: %s", pedant_selftest() ? "ok" : "bad");
        } else {
            klog("PEDANT", "pedant [audit|gaps|save|load|clear|test]");
        }
    } else if (strcmp(cmd, "think") == 0) {
        /* Deliberate reasoning: score every candidate against the rules, the
         * model and the record, then act only if the evidence supports it. */
        if (!arg || !*arg) {
            think_report();
        } else if (strncmp(arg, "bench", 5) == 0) {
            /* Measure the batched scorer against the per-action one. */
            const char *probe = arg + 5;
            while (*probe == ' ') {
                probe++;
            }
            int ok = think_bench(*probe ? probe : 0);
            klog("THINK", "scoring benchmark: %s", ok ? "ok, same scores" : "MISMATCH");
        } else {
            enum think_result verdict;
            char trace[768];
            const char *choice = think_consider(arg, &verdict, trace,
                                                sizeof(trace));
            serial_puts(trace);
            serial_puts("\n");
            if (verdict == THINK_UNSURE) {
                klog("THINK", "no action is well enough supported; not acting");
            } else if (think_commit(arg, choice)) {
                /* The decision is fed back, so the fast path recognises the
                 * request next time. */
                klog("THINK", "acted on '%s' and learned it", choice);
            } else {
                klog("THINK", "chose '%s', which did not run", choice);
            }
        }
    } else if (strcmp(cmd, "set") == 0) {
        /* set <key> <value...>: split on the first space so the value keeps its
         * own spaces. Settings live on .sidwa, so they survive a reboot. */
        if (!arg || !*arg) {
            klog("CFG", "set <key> <value>");
        } else {
            const char *sp = arg;
            while (*sp && *sp != ' ' && *sp != '\t') {
                sp++;
            }
            if (!*sp) {
                klog("CFG", "set %s <value>: no value given", arg);
            } else {
                char key[CONFIG_KEY_MAX];
                u32 i = 0;
                for (const char *p = arg; p < sp && i + 1 < sizeof(key); p++) {
                    key[i++] = *p;
                }
                key[i] = '\0';
                const char *value = sp;
                while (*value == ' ' || *value == '\t') {
                    value++;
                }
                if (config_set(key, value)) {
                    klog("CFG", "%s = %s (stored on .sidwa)", key, value);
                } else {
                    klog("CFG", "could not store '%s'", key);
                }
            }
        }
    } else if (strcmp(cmd, "get") == 0) {
        if (!arg || !*arg) {
            config_list();
        } else {
            char value[CONFIG_VALUE_MAX];
            if (config_get(arg, value, sizeof(value)) >= 0) {
                klog("CFG", "%s = %s", arg, value);
            } else {
                klog("CFG", "'%s' is not set", arg);
            }
        }
    } else if (strcmp(cmd, "unset") == 0) {
        if (!arg || !*arg) {
            klog("CFG", "unset <key>");
        } else if (config_del(arg)) {
            klog("CFG", "removed '%s'", arg);
        } else {
            klog("CFG", "'%s' was not set", arg);
        }
    } else if (strcmp(cmd, "lesson") == 0) {
        if (!arg || !*arg) {
            curriculum_print_all();
        } else if (arg[0] >= '0' && arg[0] <= '9') {
            /* A number selects a lesson; the course is numbered from 1. */
            u32 n = parse_u32(arg, 0);
            if (n >= 1 && n <= curriculum_count()) {
                curriculum_print(curriculum_get(n - 1));
            } else {
                klog("C", "no lesson %u: the course has %u", n,
                     curriculum_count());
            }
        } else {
            const struct lesson *l = curriculum_find(arg);
            if (l) {
                curriculum_print(l);
            } else {
                klog("C", "no lesson matching '%s'", arg);
            }
        }
    } else if (strcmp(cmd, "hello") == 0) {
        /* The first program everyone writes, then the same program as a GUI. */
        const struct lesson *l = curriculum_find("Hello World");
        if (l) {
            curriculum_print(l);
        }
        klog("CLI", "opening the GUI on the Hello window; q quits");
        gui_init();
        gui_set_lesson(9);
        gui_set_window(GUI_WIN_HELLO);
        gui_run();
    } else if (strcmp(cmd, "gui") == 0) {
        gui_init();
        gui_run();
    } else if (strcmp(cmd, "rev") == 0) {
        if (!arg || !*arg) {
            rev_print_all();
        } else if (arg[0] >= '0' && arg[0] <= '9') {
            u32 n = parse_u32(arg, 0);
            if (n >= 1 && n <= rev_count()) {
                rev_print(rev_get(n - 1));
            } else {
                klog("RE", "no lesson %u: the course has %u", n, rev_count());
            }
        } else {
            const struct lesson *l = rev_find(arg);
            if (l) {
                rev_print(l);
            } else {
                klog("RE", "no lesson matching '%s'", arg);
            }
        }
    } else if (strcmp(cmd, "sysinfo") == 0) {
        sysinfo_report(0);
    } else if (strcmp(cmd, "method") == 0) {
        if (!arg || !*arg) {
            method_print_all();
        } else if (arg[0] >= '0' && arg[0] <= '9') {
            u32 n = parse_u32(arg, 0);
            if (n >= 1 && n <= method_count()) {
                method_print(method_get(n - 1));
            } else {
                klog("METHOD", "no loop %u: the method has %u", n,
                     method_count());
            }
        } else {
            const struct method_loop *l = method_find(arg);
            if (l) {
                method_print(l);
            } else {
                klog("METHOD", "no loop matching '%s'", arg);
            }
        }
    } else if (strcmp(cmd, "fetch") == 0) {
        /* Fetch a page and learn the answer to a question from it. One page is
         * held in RAM; two sources that agree are stored on .sidwa. */
        if (!arg || !*arg) {
            fetch_report();
        } else if (strncmp(arg, "learn ", 6) == 0) {
            /* fetch learn <url> | <question> */
            const char *rest = arg + 6;
            const char *bar = strstr(rest, " | ");
            if (!bar) {
                klog("FETCH", "usage: fetch learn <url> | <question>");
            } else {
                char url[256];
                u32 ul = (u32)(bar - rest);
                if (ul >= sizeof(url)) {
                    ul = sizeof(url) - 1;
                }
                for (u32 i = 0; i < ul; i++) {
                    url[i] = rest[i];
                }
                url[ul] = '\0';

                static char answer[FETCH_ANSWER_MAX];
                int n = fetch_learn(url, bar + 3, answer, sizeof(answer));
                if (n < 0) {
                    klog("FETCH", "learned nothing from that page");
                } else {
                    klog("FETCH", "%s", answer);
                    klog("FETCH", "held in RAM, unverified: one page cannot "
                                  "corroborate itself");
                }
            }
        } else if (strncmp(arg, "verify ", 7) == 0) {
            /* fetch verify <url a> | <url b> | <question> */
            const char *rest = arg + 7;
            const char *b1 = strstr(rest, " | ");
            const char *b2 = b1 ? strstr(b1 + 3, " | ") : 0;
            if (!b1 || !b2) {
                klog("FETCH", "usage: fetch verify <url a> | <url b> | <q>");
            } else {
                char ua[256], ub[256];
                u32 la = (u32)(b1 - rest);
                u32 lb = (u32)(b2 - (b1 + 3));
                if (la >= sizeof(ua)) la = sizeof(ua) - 1;
                if (lb >= sizeof(ub)) lb = sizeof(ub) - 1;
                for (u32 i = 0; i < la; i++) ua[i] = rest[i];
                ua[la] = '\0';
                for (u32 i = 0; i < lb; i++) ub[i] = (b1 + 3)[i];
                ub[lb] = '\0';

                static char answer[FETCH_ANSWER_MAX];
                int rc = fetch_corroborate(ua, ub, b2 + 3, answer,
                                           sizeof(answer));
                if (rc < 0) {
                    klog("FETCH", "a fetch failed; nothing was learned");
                } else if (rc == 0) {
                    klog("FETCH", "sources disagreed; nothing written to .sidwa");
                } else {
                    klog("FETCH", "%s", answer);
                }
            }
        } else {
            klog("FETCH", "usage: fetch [learn <url> | <q> | verify <a> | <b> | <q>]");
        }
    } else if (strcmp(cmd, "codec") == 0) {
        /* Binary encoding: encode the built-in program both ways and report
         * the sizes, or time the two packed encoders against each other. */
        static struct sasm_program prog;
        char err[SASM_ERROR_MAX];
        if (!sasm_assemble(sasm_example_source(), &prog, err, sizeof(err))) {
            klog("CODEC", "example did not assemble: %s", err);
        } else if (arg && strncmp(arg, "opt", 3) == 0) {
            klog("CODEC", "encoder benchmark: %s",
                 codec_opt(&prog) ? "ok, same bytes" : "MISMATCH");
        } else if (arg && strstr(arg, "raw")) {
            static u8 buf[CODEC_MAX_BYTES];
            u32 n = codec_encode(prog.code, prog.count, buf, sizeof(buf),
                                 CODEC_FMT_RAW);
            klog("CODEC", "raw: %u bytes for %u instructions", n, prog.count);
        } else if (arg && strstr(arg, "packed")) {
            static u8 buf[CODEC_MAX_BYTES];
            u32 n = codec_encode(prog.code, prog.count, buf, sizeof(buf),
                                 CODEC_FMT_PACKED);
            klog("CODEC", "packed: %u bytes for %u instructions", n, prog.count);
        } else {
            codec_report(&prog);
        }
    } else if (strcmp(cmd, "optim") == 0) {
        if (!arg || !*arg) {
            optim_print_all();
        } else if (strcmp(arg, "bench") == 0) {
            optim_benchmark();
        } else if (strcmp(arg, "pair") == 0) {
            optim_show_pair();
        } else if (arg[0] >= '0' && arg[0] <= '9') {
            u32 n = parse_u32(arg, 0);
            if (n >= 1 && n <= optim_count()) {
                optim_print(optim_get(n - 1));
            } else {
                klog("OPTIM", "no lesson %u: the course has %u", n,
                     optim_count());
            }
        } else {
            const struct lesson *l = optim_find(arg);
            if (l) {
                optim_print(l);
            } else {
                klog("OPTIM", "no lesson matching '%s'", arg);
            }
        }
    } else if (strcmp(cmd, "install") == 0) {
        layout_install_report();
    } else if (strcmp(cmd, "layout") == 0) {
        layout_report();
    } else if (strcmp(cmd, "results") == 0) {
        if (arg && strcmp(arg, "save") == 0) {
            klog("RESULT", outcome_save() ? "results saved to .sidwa"
                                          : "could not save results");
        } else if (arg && strcmp(arg, "load") == 0) {
            klog("RESULT", outcome_load() ? "results loaded from .sidwa"
                                          : "no saved results");
        } else if (arg && strcmp(arg, "reset") == 0) {
            outcome_reset();
            klog("RESULT", "results reset");
        } else {
            outcome_report();
        }
    } else if (strcmp(cmd, "net") == 0) {
        cmd_net(arg);
    } else if (strcmp(cmd, "ollama") == 0) {
        cmd_ollama(arg);
    } else if (strcmp(cmd, "stats") == 0) {
        /* `stats` samples and prints; `stats test` checks the arithmetic. */
        if (arg && strcmp(arg, "test") == 0) {
            stats_selftest();
        } else {
            stats_report();
        }
    } else if (strcmp(cmd, "asm") == 0) {
        cmd_asm(arg);
    } else if (strcmp(cmd, "synth") == 0) {
        cmd_synth(arg);
    } else if (strcmp(cmd, "ide") == 0) {
        /* The IDE is a GUI window; opening it here reuses the GUI key loop. */
        gui_run_ide();
    } else if (strcmp(cmd, "halt") == 0) {
        return ACTION_HALT;
    } else {
        return ACTION_UNKNOWN;
    }
    return ACTION_OK;
}
