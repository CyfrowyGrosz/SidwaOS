/* The .sidwa knowledge partition. See include/kb.h.
 *
 * Everything here is sector-sized I/O and fixed-size slots. The grade decides
 * the slot size, and the slot count follows from it, so a higher grade stores
 * more records at the cost of truncating longer ones.
 *
 * The whole partition is cached in one static buffer. It is 256 KiB, which is
 * why the image has to be sized for it (see tools/mkapp.py). Reads and writes
 * go through the cache; kb_flush() writes it back.
 */

#include "kb.h"
#include "layout.h"
#include "ata.h"
#include "serial.h"
#include "string.h"

/* On-disk header, first sector of the partition. */
struct kb_header {
    char magic[8];
    u32 version;
    u32 grade;
    u32 data_bytes;      /* payload bytes per slot */
    u32 count;           /* live records */
    u32 next_seq;        /* sequence number for the next append */
    u32 crc;             /* checksum of the fields above */
} __attribute__((packed));

struct kb_slot {
    u32 magic;
    u32 seq;
    u32 len;
    u32 crc;             /* checksum of `data` */
    u8  data[KB_DATA_MAX];
} __attribute__((packed));

#define KB_HEADER_SLOT_SIZE 512
#define KB_PAYLOAD_OFFSET   KB_HEADER_SLOT_SIZE

static u8  image[KB_SECTORS * ATA_SECTOR_SIZE];
static struct kb_header *hdr = (struct kb_header *)image;
static int mounted;

/* Slots per sector at the current grade. */
static u32 slots_per_sector(void)
{
    u32 bytes = hdr->data_bytes + 16;      /* struct kb_slot overhead */
    return ATA_SECTOR_SIZE / bytes;
}

static u32 slot_bytes(void)
{
    return ATA_SECTOR_SIZE / slots_per_sector();
}

static struct kb_slot *slot_at(u32 index)
{
    u32 per = slots_per_sector();
    u32 sector = index / per;
    u32 within = index % per;

    return (struct kb_slot *)(image + KB_PAYLOAD_OFFSET
                              + sector * ATA_SECTOR_SIZE
                              + within * slot_bytes());
}

/* Same checksum the app blobs use, so one implementation covers both. */
static u32 crc_of(const u8 *data, u32 len)
{
    u32 sum = 0;
    for (u32 i = 0; i < len; i++) {
        sum = (sum << 1) ^ (sum >> 31) ^ data[i];
    }
    return sum;
}

static u32 header_crc(void)
{
    struct kb_header copy = *hdr;
    copy.crc = 0;
    return crc_of((const u8 *)&copy, sizeof(copy));
}

static void header_seal(void)
{
    hdr->crc = 0;
    hdr->crc = header_crc();
}

static void flush(void)
{
    for (u32 i = 0; i < KB_SECTORS; i++) {
        ata_write_sectors(layout_kb_lba() + i, 1, image + i * ATA_SECTOR_SIZE);
    }
}

static void format(u32 grade, u32 data_bytes)
{
    memset(image, 0, sizeof(image));
    for (u32 i = 0; i < sizeof(hdr->magic); i++) {
        hdr->magic[i] = KB_MAGIC[i];
    }
    hdr->version = KB_VERSION;
    hdr->grade = grade;
    hdr->data_bytes = data_bytes;
    hdr->count = 0;
    hdr->next_seq = 1;
    header_seal();
}

u32 kb_grade(void) { return hdr->grade; }
u32 kb_data_bytes(void) { return hdr->data_bytes; }
u32 kb_count(void) { return hdr->count; }

u32 kb_capacity(void)
{
    u32 per = slots_per_sector();
    return (KB_SECTORS - 1) * per;
}

const char *kb_grade_name(u8 grade)
{
    switch (grade) {
    case 1: return "1 (no compression)";
    case 2: return "2 (light compression)";
    case 3: return "3 (max compression)";
    default: return "unknown";
    }
}

static u32 data_bytes_for(u32 grade)
{
    switch (grade) {
    case 2: return KB_GRADE2_DATA;
    case 3: return KB_GRADE3_DATA;
    default: return KB_GRADE1_DATA;
    }
}

int kb_mount(void)
{
    for (u32 i = 0; i < KB_SECTORS; i++) {
        if (!ata_read_sectors(layout_kb_lba() + i, 1, image + i * ATA_SECTOR_SIZE)) {
            klog("KB", "read failed at LBA %u", layout_kb_lba() + i);
            return 0;
        }
    }

    int magic_ok = (memcmp(hdr->magic, KB_MAGIC, 8) == 0);
    int crc_ok = magic_ok && (hdr->crc == header_crc());

    if (!magic_ok || !crc_ok || hdr->version != KB_VERSION
        || hdr->grade < 1 || hdr->grade > 3
        || hdr->data_bytes != data_bytes_for(hdr->grade)) {
        klog("KB", "no valid .sidwa partition, formatting");
        format(1, KB_GRADE1_DATA);
        flush();
    } else {
        klog("KB", "mounted .sidwa: grade=%u records=%u capacity=%u",
             hdr->grade, hdr->count, kb_capacity());
    }

    mounted = 1;
    return 1;
}

int kb_append(const void *data, u32 len)
{
    if (!mounted || !data) {
        return -1;
    }
    if (len > hdr->data_bytes) {
        klog("KB", "record of %u bytes exceeds the %u-byte slot at grade %u",
             len, hdr->data_bytes, hdr->grade);
        return -1;
    }
    if (hdr->count >= kb_capacity()) {
        klog("KB", "partition full (%u records)", hdr->count);
        return -1;
    }

    struct kb_slot *slot = slot_at(hdr->count);
    memset(slot, 0, slot_bytes());
    slot->magic = KB_REC_MAGIC;
    slot->seq = hdr->next_seq;
    slot->len = len;
    memcpy(slot->data, data, len);
    slot->crc = crc_of(slot->data, len);

    u32 seq = hdr->next_seq++;
    hdr->count++;
    header_seal();
    flush();
    return (int)seq;
}

int kb_read(u32 seq, void *out, u32 max)
{
    if (!mounted) {
        return -1;
    }

    for (u32 i = 0; i < hdr->count; i++) {
        struct kb_slot *slot = slot_at(i);
        if (slot->magic != KB_REC_MAGIC || slot->seq != seq) {
            continue;
        }
        if (slot->crc != crc_of(slot->data, slot->len)) {
            return -1;
        }
        u32 n = slot->len < max ? slot->len : max;
        memcpy(out, slot->data, n);
        if (n < max) {
            ((u8 *)out)[n] = '\0';
        }
        return (int)n;
    }
    return -1;
}

int kb_next(u32 *cursor, u32 *seq_out, void *out, u32 max)
{
    if (!mounted || !cursor) {
        return -1;
    }

    while (*cursor < hdr->count) {
        struct kb_slot *slot = slot_at((*cursor)++);
        if (slot->magic != KB_REC_MAGIC) {
            continue;
        }
        if (slot->crc != crc_of(slot->data, slot->len)) {
            continue;
        }
        u32 n = slot->len < max ? slot->len : max;
        if (out) {
            memcpy(out, slot->data, n);
            /* Terminate when there is room, so a caller scanning records as
             * strings sees the end of this one rather than the tail of a longer
             * record read before it. Callers that need this to be guaranteed
             * pass max one below the buffer size. */
            if (n < max) {
                ((u8 *)out)[n] = '\0';
            }
        }
        if (seq_out) {
            *seq_out = slot->seq;
        }
        return (int)n;
    }
    return -1;
}

int kb_delete(u32 seq)
{
    if (!mounted) {
        return 0;
    }

    for (u32 i = 0; i < hdr->count; i++) {
        struct kb_slot *slot = slot_at(i);
        if (slot->magic != KB_REC_MAGIC || slot->seq != seq) {
            continue;
        }

        /* Shift every later slot down one place so the live records stay
         * contiguous, then clear the slot left at the end. */
        for (u32 j = i; j + 1 < hdr->count; j++) {
            memcpy(slot_at(j), slot_at(j + 1), slot_bytes());
        }
        memset(slot_at(hdr->count - 1), 0, slot_bytes());
        hdr->count--;
        header_seal();
        flush();
        return 1;
    }
    return 0;
}

void kb_list(u32 max)
{
    u32 shown = 0;

    for (u32 i = 0; i < hdr->count && shown < max; i++) {
        struct kb_slot *slot = slot_at(i);
        if (slot->magic != KB_REC_MAGIC) {
            continue;
        }
        char preview[25];
        u32 n = slot->len < 24 ? slot->len : 24;
        for (u32 k = 0; k < n; k++) {
            char c = (char)slot->data[k];
            preview[k] = (c >= 0x20 && c < 0x7F) ? c : '.';
        }
        preview[n] = '\0';
        klog("KB", "rec %u len=%u %s", slot->seq, slot->len, preview);
        shown++;
    }
    if (hdr->count == 0) {
        klog("KB", "partition is empty");
    }
}

int kb_set_grade(u8 grade)
{
    if (!mounted || grade < 1 || grade > 3) {
        return 0;
    }
    if (grade == hdr->grade) {
        return 1;
    }

    u32 new_bytes = data_bytes_for(grade);
    if (hdr->count * new_bytes > (KB_SECTORS - 1) * ATA_SECTOR_SIZE) {
        klog("KB", "grade %u: %u records do not fit", grade, hdr->count);
        return 0;
    }

    /* Collect the live records before the layout changes under them. */
    static u8 scratch[KB_SECTORS * KB_DATA_MAX];
    static u32 lengths[KB_SECTORS];
    u32 count = hdr->count;

    for (u32 i = 0; i < count; i++) {
        struct kb_slot *slot = slot_at(i);
        u32 len = slot->len < KB_DATA_MAX ? slot->len : KB_DATA_MAX;
        lengths[i] = len;
        memset(scratch + i * KB_DATA_MAX, 0, KB_DATA_MAX);
        memcpy(scratch + i * KB_DATA_MAX, slot->data, len);
    }

    format(grade, new_bytes);

    for (u32 i = 0; i < count; i++) {
        kb_append(scratch + i * KB_DATA_MAX, lengths[i]);
    }

    /* kb_append flushes as it goes, but with no records to rewrite nothing above
     * touches the disk, so the new header would be lost. Flush unconditionally. */
    flush();

    klog("KB", "grade set to %s: %u records, capacity %u",
         kb_grade_name(grade), hdr->count, kb_capacity());
    return 1;
}

int kb_selftest(void)
{
    static const char probe[] = "sidwa-kb-probe-0123456789";
    char back[64];

    int seq = kb_append(probe, sizeof(probe) - 1);
    if (seq < 0) {
        return 0;
    }
    int n = kb_read((u32)seq, back, sizeof(back));
    if (n != (int)(sizeof(probe) - 1)) {
        return 0;
    }
    return memcmp(probe, back, (size_t)n) == 0;
}
