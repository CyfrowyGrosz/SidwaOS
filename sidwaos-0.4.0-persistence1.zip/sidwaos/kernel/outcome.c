/* Learning from results. See include/outcome.h.
 *
 * A small fixed table of action tallies, plus a record on the .sidwa partition
 * that holds them. The table is sized for the kernel's action vocabulary, which
 * is small and fixed, so a linear scan is the clearest implementation and there
 * is no hash to size or collide.
 *
 * Persistence follows the knowledge module: one record, key "OUTCOMES", value a
 * list of "name=successes:failures" entries. Saving replaces any earlier copy so
 * the tallies cannot accumulate duplicates.
 */

#include "outcome.h"
#include "kb.h"
#include "serial.h"
#include "string.h"

struct tally {
    char name[OUTCOME_NAME_MAX];
    u32  successes;
    u32  failures;
};

static struct tally table[OUTCOME_MAX];
static u32 used;

static void order_invalidate(void);

#define OUTCOME_KEY "OUTCOMES"

static struct tally *find(const char *name, int create)
{
    for (u32 i = 0; i < used; i++) {
        if (strcmp(table[i].name, name) == 0) {
            return &table[i];
        }
    }
    if (!create || used >= OUTCOME_MAX) {
        return 0;
    }

    struct tally *t = &table[used];
    u32 n = 0;
    for (; name[n] && n + 1 < OUTCOME_NAME_MAX; n++) {
        t->name[n] = name[n];
    }
    t->name[n] = '\0';
    t->successes = 0;
    t->failures = 0;
    used++;
    return t;
}

void outcome_reset(void)
{
    used = 0;
    order_invalidate();
}

void outcome_record(const char *action, int success)
{
    if (!action || !*action) {
        return;
    }

    struct tally *t = find(action, 1);
    if (!t) {
        return;
    }
    if (success) {
        t->successes++;
    } else {
        t->failures++;
    }
    order_invalidate();
}

int outcome_score(const char *action)
{
    struct tally *t = find(action, 0);
    if (!t) {
        return 0;
    }
    return (int)t->successes - (int)t->failures;
}

u32 outcome_attempts(const char *action)
{
    struct tally *t = find(action, 0);
    return t ? t->successes + t->failures : 0;
}

u32 outcome_successes(const char *action)
{
    struct tally *t = find(action, 0);
    return t ? t->successes : 0;
}

const char *outcome_best(const char *const *names, u32 count)
{
    if (!names || count == 0) {
        return 0;
    }

    /* Strictly-greater comparison, scanning in order, keeps the first candidate
     * on a tie. The caller's rule order is therefore the stable default and the
     * tallies only override it with a better record. */
    const char *best = names[0];
    int best_score = outcome_score(names[0]);

    for (u32 i = 1; i < count; i++) {
        int s = outcome_score(names[i]);
        if (s > best_score) {
            best = names[i];
            best_score = s;
        }
    }
    return best;
}

/* --- Disk ------------------------------------------------------------------- */

/* Read the OUTCOMES record's value into `out`. Returns the length, or -1 when
 * the record is absent. */
static int disk_read(char *out, u32 max)
{
    static char rec[KB_DATA_MAX];

    u32 cursor = 0, seq = 0;
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (strncmp(rec, OUTCOME_KEY "\t", sizeof(OUTCOME_KEY)) != 0) {
            continue;
        }
        const char *v = rec + sizeof(OUTCOME_KEY);
        u32 n = 0;
        for (; v[n] && n + 1 < max; n++) {
            out[n] = v[n];
        }
        out[n] = '\0';
        return (int)n;
    }
    return -1;
}

/* Delete the OUTCOMES record if present. Returns 1 if one was removed. */
static int disk_erase(void)
{
    static char rec[KB_DATA_MAX];

    u32 cursor = 0, seq = 0;
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (strncmp(rec, OUTCOME_KEY "\t", sizeof(OUTCOME_KEY)) == 0) {
            return kb_delete(seq);
        }
    }
    return 0;
}

/* Append a decimal number to `buf` at `n`. Returns the new length. */
static u32 put_num(char *buf, u32 n, u32 max, u32 value)
{
    char digits[12];
    u32 d = 0;

    if (value == 0) {
        digits[d++] = '0';
    }
    while (value > 0) {
        digits[d++] = (char)('0' + value % 10);
        value /= 10;
    }
    while (d > 0 && n + 1 < max) {
        buf[n++] = digits[--d];
    }
    return n;
}

/* Parse a decimal number, advancing *p past it. */
static u32 parse_num(const char **p)
{
    u32 v = 0;

    while (**p >= '0' && **p <= '9') {
        v = v * 10 + (u32)(**p - '0');
        (*p)++;
    }
    return v;
}

int outcome_save(void)
{
    char rec[KB_DATA_MAX];
    u32 n = 0;

    for (const char *k = OUTCOME_KEY "\t"; *k && n + 1 < sizeof(rec); k++) {
        rec[n++] = *k;
    }
    for (u32 i = 0; i < used && n + 1 < sizeof(rec); i++) {
        for (const char *p = table[i].name; *p && n + 1 < sizeof(rec); p++) {
            rec[n++] = *p;
        }
        if (n + 1 < sizeof(rec)) {
            rec[n++] = '=';
        }
        n = put_num(rec, n, sizeof(rec), table[i].successes);
        if (n + 1 < sizeof(rec)) {
            rec[n++] = ':';
        }
        n = put_num(rec, n, sizeof(rec), table[i].failures);
        if (n + 1 < sizeof(rec)) {
            rec[n++] = ';';
        }
    }
    rec[n] = '\0';

    if (!kb_mount()) {
        return 0;
    }
    disk_erase();
    return kb_append(rec, n) >= 0;
}

int outcome_load(void)
{
    char value[KB_DATA_MAX];

    if (disk_read(value, sizeof(value)) < 0) {
        return 0;
    }

    outcome_reset();

    const char *p = value;
    while (*p) {
        char name[OUTCOME_NAME_MAX];
        u32 n = 0;

        while (*p && *p != '=' && n + 1 < sizeof(name)) {
            name[n++] = *p++;
        }
        name[n] = '\0';
        if (*p != '=') {
            break;
        }
        p++;
        u32 succ = parse_num(&p);
        if (*p != ':') {
            break;
        }
        p++;
        u32 fail = parse_num(&p);

        struct tally *t = find(name, 1);
        if (t) {
            t->successes = succ;
            t->failures = fail;
        }
        if (*p == ';') {
            p++;
        }
    }
    return 1;
}

u32 outcome_action_count(void) { return used; }

/* Ranked order, best score first. Recomputed lazily after any change, so a run
 * of outcome_ranked() calls sorts once rather than per call. A handful of
 * entries makes selection sort the clear choice. */
static u8  order[OUTCOME_MAX];
static u32 order_of;        /* number of entries `order` is valid for */
static int order_valid;

static void build_order(void)
{
    u8 taken[OUTCOME_MAX];
    for (u32 i = 0; i < used; i++) {
        taken[i] = 0;
    }

    for (u32 rank = 0; rank < used; rank++) {
        int best = -1;
        for (u32 i = 0; i < used; i++) {
            if (taken[i]) {
                continue;
            }
            if (best < 0
                || outcome_score(table[i].name)
                   > outcome_score(table[best].name)) {
                best = (int)i;
            }
        }
        order[rank] = (u8)best;
        taken[best] = 1;
    }
    order_of = used;
    order_valid = 1;
}

static void order_invalidate(void)
{
    order_valid = 0;
}

const char *outcome_ranked(u32 rank)
{
    if (rank >= used) {
        return 0;
    }
    if (!order_valid || order_of != used) {
        build_order();
    }
    return table[order[rank]].name;
}

void outcome_report(void)
{
    if (used == 0) {
        klog("RESULT", "no actions scored yet");
        return;
    }

    klog("RESULT", "achieved results (%u actions):", used);
    for (u32 rank = 0; rank < used; rank++) {
        const char *name = outcome_ranked(rank);
        if (!name) {
            break;
        }
        klog("RESULT", "  %s ok=%u fail=%u score=%d", name,
             outcome_successes(name),
             outcome_attempts(name) - outcome_successes(name),
             outcome_score(name));
    }
}

int outcome_selftest(void)
{
    /* Keep any real record so the test leaves the partition as it found it. */
    char backup[KB_DATA_MAX];
    int had_backup = disk_read(backup, sizeof(backup)) >= 0;

    if (!kb_mount()) {
        return 0;
    }

    outcome_reset();
    outcome_record("run", 1);
    outcome_record("run", 1);
    outcome_record("run", 1);
    outcome_record("hold", 1);
    outcome_record("hold", 0);
    outcome_record("hold", 0);

    if (outcome_score("run") != 3 || outcome_score("hold") != -1) {
        return 0;
    }

    /* The ranker must prefer the method that worked. */
    static const char *const cands[] = { "hold", "run" };
    const char *best = outcome_best(cands, 2);
    if (!best || strcmp(best, "run") != 0) {
        return 0;
    }

    if (!outcome_save()) {
        return 0;
    }

    /* Wipe RAM, reload from disk, and the tallies must come back. */
    outcome_reset();
    if (!outcome_load() || outcome_score("run") != 3
        || outcome_score("hold") != -1) {
        return 0;
    }

    /* Restore what was there before the test. */
    disk_erase();
    if (had_backup) {
        char rec[KB_DATA_MAX];
        u32 n = 0;
        for (const char *k = OUTCOME_KEY "\t"; *k && n + 1 < sizeof(rec); k++) {
            rec[n++] = *k;
        }
        for (const char *p = backup; *p && n + 1 < sizeof(rec); p++) {
            rec[n++] = *p;
        }
        kb_append(rec, n);
    }

    outcome_reset();
    return 1;
}
