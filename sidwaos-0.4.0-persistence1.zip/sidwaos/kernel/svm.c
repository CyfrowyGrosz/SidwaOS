/* SidwaASM virtual machine. See include/svm.h.
 *
 * A direct-threaded-by-hand interpreter: one loop, one switch, one instruction
 * per iteration. Four registers live in an array, memory is a flat word array,
 * and a jump is bounds-checked before it is taken so a malformed program cannot
 * run the program counter off the end of the code.
 *
 * Output goes to a string buffer rather than the serial port. That is what lets
 * the IDE show a program's output in a window and lets the tests compare it
 * byte for byte.
 */

#include "svm.h"
#include "string.h"

void svm_reset(struct svm *vm)
{
    for (u32 i = 0; i < SVM_REGS; i++) {
        vm->reg[i] = 0;
    }
    for (u32 i = 0; i < SVM_MEM_WORDS; i++) {
        vm->mem[i] = 0;
    }
    vm->pc = 0;
    vm->zero = 0;
    vm->steps = 0;
    vm->halted = 0;
}

const char *svm_error_text(int code)
{
    switch (code) {
    case SVM_OK:        return "ok";
    case SVM_ERR_PC:    return "pc out of range";
    case SVM_ERR_STEPS: return "step limit reached (possible infinite loop)";
    case SVM_ERR_OP:    return "unknown opcode";
    default:            return "unknown error";
    }
}

/* --- Output buffer ---------------------------------------------------------- */

struct out_buf {
    char *s;
    u32 max;        /* bytes including the terminator */
    u32 len;
};

static void out_init(struct out_buf *o, char *s, u32 max)
{
    o->s = s;
    o->max = max;
    o->len = 0;
    if (max) {
        s[0] = '\0';
    }
}

static void out_char(struct out_buf *o, char c)
{
    if (o->len + 1 < o->max) {
        o->s[o->len++] = c;
        o->s[o->len] = '\0';
    }
}

static void out_uint(struct out_buf *o, u32 v)
{
    char rev[12];
    u32 r = 0;
    if (v == 0) {
        rev[r++] = '0';
    }
    while (v && r < sizeof(rev)) {
        rev[r++] = (char)('0' + (v % 10));
        v /= 10;
    }
    while (r) {
        out_char(o, rev[--r]);
    }
}

/* --- The interpreter -------------------------------------------------------- */

/* Apply a data-processing operand to a register. `dst` is the register the
 * result lands in; `mode`/`src`/`imm` describe the right-hand side. */
static u32 apply_operand(const struct svm *vm, u8 dst, u8 mode, u8 src, u32 imm)
{
    switch (mode) {
    case SASM_MODE_REG:  return vm->reg[src];
    case SASM_MODE_LOAD: return vm->mem[vm->reg[src] % SVM_MEM_WORDS];
    case SASM_MODE_IMM:  return imm;
    default:             (void)dst; return 0;
    }
}

int svm_run(struct svm *vm, const struct sasm_program *prog,
            char *out, u32 out_max)
{
    struct out_buf ob;
    out_init(&ob, out, out_max);

    vm->pc = prog->entry;
    vm->halted = 0;
    vm->steps = 0;

    while (!vm->halted) {
        if (vm->pc >= prog->count) {
            return SVM_ERR_PC;
        }
        if (vm->steps >= SVM_STEP_LIMIT) {
            return SVM_ERR_STEPS;
        }
        vm->steps++;

        const struct sasm_insn *in = &prog->code[vm->pc];
        u32 next_pc = vm->pc + 1;
        u8 dst = in->dst;
        u8 src = in->src;

        switch (in->op) {
        case SASM_OP_HLT:
            vm->halted = 1;
            break;

        case SASM_OP_MOV:
            if (in->mode == SASM_MODE_STORE) {
                /* MOV [rDst], rSrc */
                vm->mem[vm->reg[dst] % SVM_MEM_WORDS] = vm->reg[src];
            } else {
                vm->reg[dst] = apply_operand(vm, dst, in->mode, src, in->imm);
            }
            break;

        case SASM_OP_ADD:
            vm->reg[dst] += apply_operand(vm, dst, in->mode, src, in->imm);
            break;

        case SASM_OP_SUB:
            vm->reg[dst] -= apply_operand(vm, dst, in->mode, src, in->imm);
            break;

        case SASM_OP_MUL:
            vm->reg[dst] *= apply_operand(vm, dst, in->mode, src, in->imm);
            break;

        case SASM_OP_CMP: {
            u32 rhs = apply_operand(vm, dst, in->mode, src, in->imm);
            vm->zero = (vm->reg[dst] == rhs) ? 1u : 0u;
            break;
        }

        case SASM_OP_JMP:
            next_pc = in->imm;
            break;

        case SASM_OP_JZ:
            if (vm->zero) {
                next_pc = in->imm;
            }
            break;

        case SASM_OP_JNZ:
            if (!vm->zero) {
                next_pc = in->imm;
            }
            break;

        case SASM_OP_OUT:
            out_uint(&ob, vm->reg[dst]);
            out_char(&ob, '\n');
            break;

        case SASM_OP_OUTC:
            out_char(&ob, (char)(vm->reg[dst] & 0xFF));
            break;

        default:
            return SVM_ERR_OP;
        }

        /* Every jump is checked here, once, rather than at each jump opcode. */
        if (!vm->halted && next_pc >= prog->count) {
            return SVM_ERR_PC;
        }
        vm->pc = next_pc;
    }

    return SVM_OK;
}

int svm_run_source(const char *source, char *out, u32 out_max,
                   char *err, u32 err_max)
{
    struct sasm_program prog;
    if (!sasm_assemble(source, &prog, err, err_max)) {
        return SVM_ERR_OP;
    }
    struct svm vm;
    svm_reset(&vm);
    return svm_run(&vm, &prog, out, out_max);
}

/* --- Self test -------------------------------------------------------------- */

int svm_selftest(void)
{
    char out[SVM_OUT_MAX];
    char err[SASM_ERROR_MAX];

    int rc = svm_run_source(sasm_example_source(), out, sizeof(out),
                            err, sizeof(err));
    if (rc != SVM_OK) {
        return 0;
    }
    /* The example prints 1..5, one per line. */
    return strcmp(out, "1\n2\n3\n4\n5\n") == 0;
}
