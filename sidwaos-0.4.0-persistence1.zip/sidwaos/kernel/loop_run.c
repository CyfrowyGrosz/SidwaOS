/* Loop 1 (RUN): the CPU loop.
 *
 * Work items are "program fragments". Before a fragment runs, its two 4-bit
 * flows are combined into one byte flow (bitflow_combine), then the fragment is
 * entered through the fast-exit trampoline on a stack whose base is randomized
 * with a random bit. A canary at the stack bottom detects a fragment that ran
 * off its stack.
 */

#include "state.h"
#include "bitflow.h"
#include "rand.h"
#include "serial.h"
#include "app.h"

extern int  fast_enter(void *stack_top, u32 *canary_slot, u32 canary,
                       void (*entry)(void));

#define FRAG_STACK_SIZE 1024
#define FRAGMENT_COUNT  3

static u8 frag_stack[FRAG_STACK_SIZE] __attribute__((aligned(16)));

/* A fragment that does a small, bounded amount of work. */
static volatile u32 frag_accumulator;

static void fragment_work(void)
{
    u32 acc = 0;
    for (u32 i = 1; i <= 16; i++) {
        acc += i * 3;
    }
    frag_accumulator = acc;
}

/* A deliberately misbehaving fragment: it writes over its own canary, which is
 * exactly the corruption the trampoline is meant to catch. */
static u32 *bad_fragment_slot;

static void fragment_bad(void)
{
    if (bad_fragment_slot) {
        *bad_fragment_slot = 0xDEADBEEFu;
    }
}

struct fragment_desc {
    const char *name;
    void (*entry)(void);
    u8 lane_a[8];
    u8 lane_b[8];
    struct bitflow_process proc_a;   /* first operation  */
    struct bitflow_process proc_b;   /* second operation */
};

/* Two nibble lanes per fragment. Combining them yields the byte flow the
 * fragment is assembled from ("4 bit + 4 bit in one flow"). Each fragment also
 * carries two whole operations, which Loop 1 combines into one flow of up to
 * 64 bits before entering the fragment. */
static struct fragment_desc fragments[FRAGMENT_COUNT] = {
    { "work",     fragment_work,
      { 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8 },
      { 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF, 0x0 },
      { 0x0A, 4, "add" }, { 0xDEADBEEF, 32, "mul" } },
    { "work2",    fragment_work,
      { 0x0, 0xF, 0x0, 0xF, 0x0, 0xF, 0x0, 0xF },
      { 0xF, 0x0, 0xF, 0x0, 0xF, 0x0, 0xF, 0x0 },
      { 0xBEEF, 16, "shift" }, { 0x5A, 8, "xor" } },
    { "canary",   fragment_bad,
      { 0xA, 0xB, 0xC, 0xD, 0xE, 0xF, 0x0, 0x1 },
      { 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8 },
      { 0x0123456789ABCDEF, 64, "qword" }, { 0x0A, 4, "nibble" } },
};

void loop_run(void)
{
    struct state_stats *stats = state_stats_get();

    for (u32 i = 0; i < FRAGMENT_COUNT; i++) {
        struct fragment_desc *f = &fragments[i];
        u8 combined[8];

        /* 4 bit + 4 bit -> one flow. */
        bitflow_combine(f->lane_a, f->lane_b, combined, sizeof(combined));
        int flow_ok = bitflow_combine_selftest(f->lane_a, f->lane_b,
                                               sizeof(combined));

        /* Any operation + any operation -> one flow, up to 64 bits. */
        u64 proc_flow = 0;
        int proc_ok = bitflow_combine_processes(&f->proc_a, &f->proc_b,
                                                &proc_flow);

        /* Randomize the stack base with a random bit. */
        u32 bit = rand_bit();
        u8 *stack_top = frag_stack + FRAG_STACK_SIZE - (bit ? 8u : 0u);
        u32 *canary_slot = (u32 *)frag_stack;
        u32 canary = 0xCAFEBABEu ^ rand_u32();

        bad_fragment_slot = (i == FRAGMENT_COUNT - 1) ? canary_slot : 0;

        int clean = fast_enter(stack_top, canary_slot, canary, f->entry);

        klog("RUN", "fragment=%s bit=%u flow=%s proc=%s+%s->0x%llx canary=%s",
             f->name, bit, flow_ok ? "ok" : "bad",
             f->proc_a.name, f->proc_b.name,
             proc_ok ? proc_flow : 0ull,
             clean ? "intact" : "CORRUPTED");

        stats->run_fragments++;
        if (!clean) {
            stats->run_corrupted++;
        }
    }

    klog("RUN", "fast-exit ok, accumulator=%u", frag_accumulator);
}
