/* Kernel entry point: init hardware, load programs, run the 3-state machine. */

#include "types.h"
#include "serial.h"
#include "descriptors.h"
#include "interrupts.h"
#include "timer.h"
#include "rand.h"
#include "ata.h"
#include "app.h"
#include "state.h"
#include "bitflow.h"
#include "cache.h"
#include "cli.h"
#include "io.h"
#include "aidebug.h"
#include "version.h"
#include "kb.h"
#include "localai.h"
#include "know.h"
#include "config.h"
#include "sasm.h"
#include "svm.h"
#include "ide.h"
#include "net.h"
#include "curriculum.h"
#include "gui.h"
#include "outcome.h"
#include "sysinfo.h"
#include "layout.h"
#include "method.h"
#include "optim.h"
#include "think.h"
#include "codec.h"
#include "fetch.h"
#include "ollama.h"
#include "stats.h"
#include "pedant.h"
#include "synth.h"
#include "peephole.h"

/* Provided by loop_hold.c; parks a blob in the HOLD ring. */

/* The demo programs live in the blob region; its absolute LBA comes from the
 * disk layout, which the bootloader set. */
#define BLOB_COUNT    3
#define BLOB_SECTORS  ((sizeof(struct app_blob) + ATA_SECTOR_SIZE - 1) \
                       / ATA_SECTOR_SIZE)


static void load_demo_programs(void)
{
    static struct app_blob blob;

    for (u32 i = 0; i < BLOB_COUNT; i++) {
        u32 lba = layout_blob_lba() + i * BLOB_SECTORS;

        if (!ata_read_sectors(lba, (u8)BLOB_SECTORS, &blob)) {
            klog("KM", "failed to read blob %u at LBA %u", i, lba);
            continue;
        }
        klog("KM", "loaded blob %u: magic=0x%x key=0x%x",
             i, blob.header.magic, blob.header.serial_key);

        if (!hold_push(&blob)) {
            klog("KM", "HOLD queue full, dropping blob %u", i);
        } else {
            klog("KM", "pushed blob %u, ring count now %u", i, hold_count());
        }
    }
}

void kmain(u32 magic, u32 mbi)
{
    serial_init();
    /* Start capturing console output into the GUI's Log window before the first
     * line, so the window shows the whole boot trace. */
    gui_log_attach();
    klog("SIDWAOS", "%s %s - %s", SIDWAOS_NAME, SIDWAOS_VERSION,
         SIDWAOS_TAGLINE);
    klog("SERIAL", "COM1 ready");

    if (magic != 0x2BADB002u) {
        klog("KM", "bad multiboot magic 0x%x", magic);
        mbi = 0;        /* the pointer is not trustworthy either */
    } else {
        klog("KM", "multiboot hand-off ok");
    }

    /* Say what the machine is running on before anything else: CPU, RAM, disk
     * and the size of the local model. */
    sysinfo_set_mbi(mbi);
    sysinfo_report_cpu(mbi);

    /* Where the bootloader put us on the disk, before any disk I/O. */
    layout_init(0);

    /* Set when the PCI scan finds the network card. The ping itself waits until
     * the timer is running, after sti() below. */
    int have_net_card = 0;

    gdt_init();
    idt_init();
    interrupts_init();
    timer_init();
    rand_init();

    klog("CPU", "random bit seeded, first=%u", rand_bit());
    klog("CPU", "bitflow combine selftest: %s",
         bitflow_combine_selftest((const u8 *)"ABCDEFGH",
                                  (const u8 *)"12345678", 8) ? "ok" : "bad");
    klog("CPU", "bitflow process combine selftest: %s",
         bitflow_process_selftest() ? "ok" : "bad");

    /* The 64-bit limit is a budget, not a process count: ten 6-bit operations
     * fit in one flow (60 bits), ten 8-bit operations do not (80 bits). */
    {
        u64 flow_six = 0, flow_eight = 0;
        int ten_six = bitflow_selftest_many(10, 6, &flow_six);
        int ten_eight = bitflow_selftest_many(10, 8, &flow_eight);

        klog("CPU", "10 processes x 6 bit in one flow: %s (0x%llx)",
             ten_six ? "ok" : "bad", flow_six);
        klog("CPU", "10 processes x 8 bit (80 bit) refused: %s",
             ten_eight ? "NO - unexpectedly accepted" : "yes");
    }

    cache_init();
    cache_report();

    if (ata_init()) {
        klog("ATA", "primary master ready");
        load_demo_programs();
    } else {
        klog("ATA", "no drive detected - HOLD queue left empty");
    }

    /* Mount the .sidwa knowledge partition and bring up the local model. The
     * weights are loaded from disk if a previous session saved them. */
    if (kb_mount()) {
        localai_sync_grade();
        if (localai_load()) {
            klog("AI", "local model restored from .sidwa");
        } else {
            klog("AI", "no saved model, starting from zero weights");
        }
        localai_report();

        /* The knowledge cache is worth a quick proof at boot: a stored fact must
         * come back through the RAM and disk tiers. */
        klog("KNOW", "cache selftest: %s", know_selftest() ? "ok" : "bad");

        /* Settings share the partition, so prove set/get/replace/delete works
         * and leaves no record behind. */
        klog("CFG", "setting selftest: %s", config_selftest() ? "ok" : "bad");

        /* The assembler and the VM are the IDE's engine, so prove both at boot:
         * a program must assemble and run to its expected output. */
        klog("ASM", "assembler selftest: %s", sasm_selftest() ? "ok" : "bad");
        klog("VM", "interpreter selftest: %s", svm_selftest() ? "ok" : "bad");
        klog("IDE", "editor selftest: %s", ide_selftest() ? "ok" : "bad");

        /* Detect the network card here, but do not ping yet: every wait in the
         * stack is bounded by the PIT, which only advances once interrupts are
         * enabled below. */
        have_net_card = net_probe();

        /* The partition is mounted, so the disk and model sizes can be reported
         * with the real grade in place. */
        sysinfo_report_storage();

        /* The C course and the GUI are checked without a keyboard: the
         * controller is driven directly and the view must render the model. */
        klog("C", "course selftest: %s (%u lessons)",
             curriculum_selftest() ? "ok" : "bad", curriculum_count());
        klog("GUI", "MVC selftest: %s", gui_selftest() ? "ok" : "bad");

        /* Reverse engineering is a second course, checked the same way. */
        klog("RE", "course selftest: %s (%u lessons)",
             rev_selftest() ? "ok" : "bad", rev_count());

        /* The result tallies are the machine's record of what has worked.
         * Loading first means the boot selftest has real history to check
         * against, and it restores what the previous session achieved. */
        outcome_load();
        klog("RESULT", "selftest: %s", outcome_selftest() ? "ok" : "bad");

        /* The programming method is the ladder the C course climbs. */
        klog("METHOD", "selftest: %s", method_selftest() ? "ok" : "bad");
        klog("OPTIM", "selftest: %s", optim_selftest() ? "ok" : "bad");
        /* Deliberate reasoning is checked last, because it reads the model and
         * the tallies the steps above have just established. */
        klog("THINK", "selftest: %s", think_selftest() ? "ok" : "bad");
        /* Binary encoding is checked against the assembler's own output, and
         * its optimisation against the obvious encoder it replaces. */
        klog("CODEC", "selftest: %s", codec_selftest() ? "ok" : "bad");
        /* Fetch-and-learn is checked here, before the network is up: its
         * cleaning, extraction and its refusal to persist a lone source are all
         * network-free, so they can be proved at boot. The fetch itself is
         * exercised from the command line once the stack is running. */
        klog("FETCH", "selftest: %s", fetch_selftest() ? "ok" : "bad");
        /* The Ollama client is checked here for the same reason: building a
         * request and reading an answer out of a reply need no network, so a
         * regression in either is caught at boot. The POST itself is exercised
         * from the command line, where the stack is up. */
        klog("OLLAMA", "selftest: %s", ollama_selftest() ? "ok" : "bad");
        /* The statistics arithmetic is checked here too: the load fraction, the
         * image size and the rate conversions are all pure calculation, so a
         * regression shows at boot rather than as a wrong number on the chart. */
        klog("STATS", "selftest: %s", stats_selftest() ? "ok" : "bad");
        /* The selftest works on its own tallies; reload the real record so the
         * session starts with the history the previous one earned. */
        outcome_load();

        /* The critic's gap ledger. Loaded before the selftest so the audit has
         * real gaps to report, and restored after it, exactly as the tallies
         * are. The ledger is a work list for the host tool: questions this
         * machine could not answer, waiting to be taught. */
        pedant_load();
        klog("PEDANT", "selftest: %s", pedant_selftest() ? "ok" : "bad");
        if (pedant_gap_count() > 0) {
            klog("PEDANT", "%u question(s) await teaching: run `pedant gaps`",
                 pedant_gap_count());
        }

        /* The synthesis gate, checked with fixed programs and no network: a
         * correct program must be accepted, a wrong output, bad syntax and an
         * endless loop must each be rejected. The prompt is checked to name
         * every instruction, so it cannot drift from the assembler. */
        klog("SYNTH", "selftest: %s", synth_selftest() ? "ok" : "bad");
        klog("PEEPHOLE", "selftest: %s", peephole_selftest() ? "ok" : "bad");
    }

    sti();
    state_machine_run();
    state_stats_dump();

    /* With the timer running, the network can be exercised end to end: the
     * gateway is the one host QEMU's user-mode network always answers. */
    if (have_net_card) {
        klog("NET", "gateway selftest: %s",
             net_selftest() ? "ok" : "unreachable");
    }

    /* Drop into the command line so the same loops can be stepped by hand. */
    klog("KM", "entering command line");
    cli_run();

    klog("KM", "halt");
    for (;;) {
        hlt();
    }
}
