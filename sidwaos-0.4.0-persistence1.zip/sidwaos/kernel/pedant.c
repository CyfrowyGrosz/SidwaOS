/* The machine's own critic. See include/pedant.h.
 *
 * A fixed table of unanswered questions, plus an audit that reports what the
 * machine's own state says is weak. The table is small and fixed, so a linear
 * scan is the clearest implementation and there is no hash to size.
 *
 * Persistence follows the knowledge and outcome modules: one record keyed
 * "PEDANT", holding a list of "count|question" entries. The record contains no
 * tab, which is what keeps it out of the knowledge tier -- split_record() needs
 * a tab to accept a record, so the ledger can never be served as an answer.
 */

#include "pedant.h"
#include "kb.h"
#include "serial.h"
#include "string.h"
#include "localai.h"
#include "know.h"
#include "outcome.h"
#include "actions.h"

struct gap {
    char query[PEDANT_Q_MAX];
    u32  asks;
};

static struct gap gaps[PEDANT_MAX_GAPS];
static u32 used;

#define PEDANT_KEY "PEDANT"

/* --- The ledger ------------------------------------------------------------ */

static int same_query(const char *a, const char *b)
{
    return strcmp(a, b) == 0;
}

static struct gap *find(const char *query, int create)
{
    for (u32 i = 0; i < used; i++) {
        if (same_query(gaps[i].query, query)) {
            return &gaps[i];
        }
    }
    if (!create || used >= PEDANT_MAX_GAPS) {
        return 0;
    }

    struct gap *g = &gaps[used];
    u32 n = 0;
    for (; query[n] && n + 1 < PEDANT_Q_MAX; n++) {
        g->query[n] = query[n];
    }
    g->query[n] = '\0';
    g->asks = 0;
    used++;
    return g;
}

int pedant_note(const char *query)
{
    if (!query || !*query) {
        return 0;
    }

    struct gap *g = find(query, 1);
    if (!g) {
        /* The table is full. A new gap that cannot be recorded is dropped
         * rather than replacing one that can: the ledger is a work list, and
         * evicting a question that has been asked many times to make room for
         * one asked once would make it a worse list. */
        return 0;
    }

    int is_new = (g->asks == 0);
    g->asks++;
    return is_new;
}

int pedant_resolve(const char *query)
{
    if (!query || !*query) {
        return 0;
    }

    for (u32 i = 0; i < used; i++) {
        if (same_query(gaps[i].query, query)) {
            /* Close the hole by moving the last entry into it. Order is not
             * meaningful here; pedant_gaps() ranks on read. */
            gaps[i] = gaps[used - 1];
            used--;
            return 1;
        }
    }
    return 0;
}

u32 pedant_gap_asks(const char *query)
{
    struct gap *g = find(query, 0);
    return g ? g->asks : 0;
}

u32 pedant_gap_count(void)
{
    return used;
}

void pedant_clear(void)
{
    used = 0;
}

u32 pedant_gaps(char *out, u32 stride, u32 max)
{
    /* Most-asked first. Selection sort over a table this small is clearer than
     * carrying an index array, and it cannot allocate. */
    u32 order[PEDANT_MAX_GAPS];
    u32 n = used;
    for (u32 i = 0; i < n; i++) {
        order[i] = i;
    }
    for (u32 i = 0; i < n; i++) {
        u32 best = i;
        for (u32 j = i + 1; j < n; j++) {
            if (gaps[order[j]].asks > gaps[order[best]].asks) {
                best = j;
            }
        }
        u32 t = order[i];
        order[i] = order[best];
        order[best] = t;
    }

    u32 written = 0;
    for (u32 i = 0; i < n && written < max; i++) {
        char *dst = out + (u64)written * stride;
        const char *src = gaps[order[i]].query;
        u32 k = 0;
        for (; src[k] && k + 1 < stride; k++) {
            dst[k] = src[k];
        }
        dst[k] = '\0';
        written++;
    }
    return written;
}

/* --- The audit ------------------------------------------------------------- */

/* Count actions in the model's vocabulary that no dispatch has ever recorded.
 * An action the machine can choose but has never used is not evidence of a bug
 * -- most requests exercise a few actions -- but it is the first thing to look
 * at when the model keeps picking the same answer. */
static u32 unused_actions(void)
{
    u32 count = 0;
    u32 total = localai_action_count();

    for (u32 i = 0; i < total; i++) {
        const char *name = localai_action_name(i);
        if (name && outcome_attempts(name) == 0) {
            count++;
        }
    }
    return count;
}

/* The audit's findings, counted without logging. Kept separate from the
 * reporting so the selftest can assert on a result without printing findings
 * about its own test data -- a boot log that claims a gap exists when none does
 * is worse than no log at all. */
struct audit_findings {
    u32 gaps;       /* questions that reached every tier and found nothing */
    u32 unproven;   /* facts held in RAM, lost on the next turnover */
    u32 unused;     /* actions in the vocabulary nothing has ever chosen */
    u32 model_bad;  /* model corrected on more than half its steps */
};

static struct audit_findings audit_collect(void)
{
    struct audit_findings f;
    f.gaps = pedant_gap_count();
    f.unproven = know_unverified_count();
    f.unused = unused_actions();
    f.model_bad = (localai_examples() > 0
                   && localai_mistakes() * 2 > localai_examples());
    return f;
}

static void audit_print(const struct audit_findings *f)
{
    u32 findings = 0;

    if (f->gaps > 0) {
        klog("PEDANT", "%u question(s) could not be answered", f->gaps);
        findings++;
    }
    if (f->unproven > 0) {
        klog("PEDANT", "%u fact(s) held but unproven, lost on the next turnover",
             f->unproven);
        findings++;
    }
    if (f->unused > 0) {
        klog("PEDANT", "%u of %u action(s) have never been used",
             f->unused, localai_action_count());
        findings++;
    }
    if (f->model_bad) {
        klog("PEDANT", "model corrected on %u of %u step(s): grade too coarse?",
             localai_mistakes(), localai_examples());
        findings++;
    }

    if (findings == 0) {
        klog("PEDANT", "no weaknesses found: %u fact(s) verified, model ok",
             know_verified_count());
    }
}

u32 pedant_audit(void)
{
    struct audit_findings f = audit_collect();
    audit_print(&f);
    return (f.gaps > 0) + (f.unproven > 0) + (f.unused > 0) + (f.model_bad > 0);
}

void pedant_report(void)
{
    u32 n = pedant_gap_count();
    if (n == 0) {
        klog("PEDANT", "no open gaps: nothing asked has gone unanswered");
        return;
    }

    char buf[PEDANT_MAX_GAPS * PEDANT_Q_MAX];
    u32 got = pedant_gaps(buf, PEDANT_Q_MAX, PEDANT_MAX_GAPS);
    klog("PEDANT", "%u open gap(s), most-asked first:", got);
    for (u32 i = 0; i < got; i++) {
        const char *q = buf + i * PEDANT_Q_MAX;
        klog("PEDANT", "  %u  %s", pedant_gap_asks(q), q);
    }
}

/* --- Persistence ----------------------------------------------------------- */

static u32 put_num(char *buf, u32 n, u32 max, u32 value)
{
    char digits[12];
    u32 d = 0;

    if (value == 0) {
        digits[d++] = '0';
    }
    while (value > 0) {
        digits[d++] = (char)('0' + value % 10);
        value /= 10;
    }
    while (d > 0 && n + 1 < max) {
        buf[n++] = digits[--d];
    }
    return n;
}

static u32 parse_num(const char **p)
{
    u32 v = 0;
    while (**p >= '0' && **p <= '9') {
        v = v * 10 + (u32)(**p - '0');
        (*p)++;
    }
    return v;
}

static int disk_read(char *out, u32 max)
{
    static char rec[KB_DATA_MAX];

    u32 cursor = 0, seq = 0;
    /* sizeof(rec) - 1 so kb_next's terminator is always in range. */
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (strncmp(rec, PEDANT_KEY "\t", sizeof(PEDANT_KEY)) != 0) {
            continue;
        }
        const char *v = rec + sizeof(PEDANT_KEY);
        u32 k = 0;
        for (; v[k] && k + 1 < max; k++) {
            out[k] = v[k];
        }
        out[k] = '\0';
        return (int)k;
    }
    return -1;
}

static int disk_erase(void)
{
    static char rec[KB_DATA_MAX];

    u32 cursor = 0, seq = 0;
    while (kb_next(&cursor, &seq, rec, sizeof(rec) - 1) >= 0) {
        if (strncmp(rec, PEDANT_KEY "\t", sizeof(PEDANT_KEY)) == 0) {
            return kb_delete(seq);
        }
    }
    return 0;
}

/* Append a full ledger record whose value is `value`. Every write goes through
 * here so the "PEDANT\t" prefix cannot be forgotten: a record written without it
 * is invisible to disk_read(), which is how the selftest's restore silently
 * erased the real ledger at every boot. */
static int disk_write_value(const char *value)
{
    char rec[KB_DATA_MAX];
    u32 n = 0;

    for (const char *k = PEDANT_KEY "\t"; *k && n + 1 < sizeof(rec); k++) {
        rec[n++] = *k;
    }
    for (const char *p = value; *p && n + 1 < sizeof(rec); p++) {
        rec[n++] = *p;
    }
    rec[n] = '\0';
    return kb_append(rec, n) >= 0;
}

int pedant_save(void)
{
    char rec[KB_DATA_MAX];
    u32 n = 0;

    for (u32 i = 0; i < used && n + 1 < sizeof(rec); i++) {
        n = put_num(rec, n, sizeof(rec), gaps[i].asks);
        if (n + 1 < sizeof(rec)) {
            rec[n++] = '|';
        }
        for (const char *p = gaps[i].query; *p && n + 1 < sizeof(rec); p++) {
            rec[n++] = *p;
        }
        if (n + 1 < sizeof(rec)) {
            rec[n++] = ';';
        }
    }
    rec[n] = '\0';

    if (!kb_mount()) {
        return 0;
    }
    disk_erase();
    return disk_write_value(rec);
}

int pedant_load(void)
{
    char value[KB_DATA_MAX];

    if (disk_read(value, sizeof(value)) < 0) {
        return 0;
    }

    used = 0;
    const char *p = value;
    while (*p && used < PEDANT_MAX_GAPS) {
        u32 asks = parse_num(&p);
        if (*p != '|') {
            break;
        }
        p++;

        struct gap *g = &gaps[used];
        u32 n = 0;
        for (; *p && *p != ';' && n + 1 < PEDANT_Q_MAX; p++) {
            g->query[n++] = *p;
        }
        g->query[n] = '\0';
        g->asks = asks;
        if (*p == ';') {
            p++;
        }
        if (n > 0) {
            used++;
        }
    }
    return 1;
}

int pedant_selftest(void)
{
    /* Keep any real ledger so the test leaves the partition as it found it. */
    char backup[KB_DATA_MAX];
    int had_backup = disk_read(backup, sizeof(backup)) >= 0;

    if (!kb_mount()) {
        return 0;
    }

    pedant_clear();

    /* A new gap is new once and only once. */
    if (!pedant_note("what is a page fault")) {
        return 0;
    }
    if (pedant_note("what is a page fault")) {
        return 0;       /* second ask must not report a new gap */
    }
    if (pedant_gap_asks("what is a page fault") != 2) {
        return 0;
    }

    /* Ranking is by ask count, not insertion order. */
    pedant_note("what is a semaphore");
    pedant_note("what is a semaphore");
    pedant_note("what is a semaphore");

    char buf[PEDANT_MAX_GAPS * PEDANT_Q_MAX];
    u32 n = pedant_gaps(buf, PEDANT_Q_MAX, PEDANT_MAX_GAPS);
    if (n != 2) {
        return 0;
    }
    if (strcmp(buf + 0 * PEDANT_Q_MAX, "what is a semaphore") != 0) {
        return 0;       /* most-asked must come first */
    }

    /* Resolving closes the gap. */
    if (!pedant_resolve("what is a semaphore")) {
        return 0;
    }
    if (pedant_gap_count() != 1 || pedant_gap_asks("what is a semaphore") != 0) {
        return 0;
    }

    /* Save, wipe RAM, reload: the ledger must come back. */
    if (!pedant_save()) {
        return 0;
    }
    pedant_clear();
    if (!pedant_load() || pedant_gap_count() != 1
        || pedant_gap_asks("what is a page fault") != 2) {
        return 0;
    }

    /* The audit must find the gap we just recorded. Checked with the
     * non-printing collector: the selftest runs at every boot, and printing
     * findings about its own test data would make the boot log claim a gap
     * exists on a machine that has none. */
    struct audit_findings f = audit_collect();
    if (f.gaps == 0) {
        return 0;
    }

    /* Restore what was there before the test. */
    pedant_clear();
    disk_erase();
    if (had_backup) {
        /* `backup` holds the ledger's value, so it must go back through the
         * same writer that adds the key prefix. Appending it bare is what made
         * the restore a silent erase. */
        disk_write_value(backup);
        pedant_load();
    }
    return 1;
}
