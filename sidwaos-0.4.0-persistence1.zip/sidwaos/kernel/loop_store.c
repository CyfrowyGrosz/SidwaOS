/* Loop 3 (STORE): the HDD loop.
 *
 * Consumes programs that passed the logic test and writes them to disk, but
 * only when their serial key verifies. A program that failed Loop 2 never
 * reaches this point because it was never queued.
 */

#include "state.h"
#include "layout.h"
#include "ata.h"
#include "serial.h"

static u32 store_cursor;

int loop_store(void)
{
    struct state_stats *stats = state_stats_get();
    struct app_blob *blob;

    while ((blob = hold_next_valid()) != 0) {
        if (!app_key_verify(blob)) {
            klog("STORE", "key REJECTED (key=0x%x) - not stored",
                 blob->header.serial_key);
            stats->store_refused++;
            continue;
        }

        u32 lba = layout_store_lba() + store_cursor;
        u32 sectors = (sizeof(struct app_blob) + ATA_SECTOR_SIZE - 1)
                      / ATA_SECTOR_SIZE;

        if (ata_write_sectors(lba, (u8)sectors, blob)) {
            klog("STORE", "key OK, stored to LBA %u (%u sectors)",
                 lba, sectors);
            stats->store_written++;
            store_cursor += sectors;
        } else {
            klog("STORE", "key OK, but disk write FAILED at LBA %u", lba);
            stats->store_refused++;
        }
    }

    return (int)stats->store_written;
}
