/* Deliberate reasoning. See include/think.h.
 *
 * One thought is: propose candidates, score each against three kinds of
 * evidence, pick a winner, and grade how well supported it is. Nothing here
 * trains the model or runs an action; think_consider() is a pure function of
 * the machine's current state, which is what lets the selftest call it without
 * leaving marks.
 *
 * The three kinds of evidence are counted rather than summed freely. Counting
 * is deliberate: it makes "clear" mean "every kind agrees" instead of "the
 * numbers happened to be large", so the verdict stays interpretable no matter
 * how the weights scale. The record carries a negative weight as well as a
 * positive one, because an action that has failed before is evidence against
 * itself, and that is exactly the evidence a pure classifier cannot represent.
 */

#include "think.h"
#include "ai.h"
#include "actions.h"
#include "localai.h"
#include "outcome.h"
#include "serial.h"
#include "string.h"
#include "cache.h"

/* Points each kind of evidence contributes to a candidate's total.
 *
 * The record is made strictly dominant on purpose: W_RECORD is one more than
 * the most the other two can contribute together, so a candidate with a proven
 * record beats any candidate supported only by rules and model. That ordering
 * is the point of the whole module. A rule says what the words look like and
 * the model says what similar words meant; only the record says what actually
 * happened, and when the machine has measured a result it should not be talked
 * out of it by a second opinion about the text.
 *
 * A negative record is equally strong, so an action that has failed loses to
 * one with no history rather than being retried because the rules like it. */
#define W_RULE   2
#define W_MODEL  1
#define W_RECORD 4      /* > W_RULE + W_MODEL: results decide */

/* The weighted total for one candidate, given which kinds of evidence support
 * it and its net record. Exposed so the selftest can check the dominance
 * property directly, without touching any real tallies. */
i32 think_weigh(int rule, int model, i32 rec);

struct candidate {
    const char *name;
    u8  rule;       /* the keyword rules name it */
    u8  model;      /* the learned model leans towards it */
    u8  record;     /* it has achieved results before */
    int rule_order; /* position in the rule list, lower is more specific */
    i32 raw;        /* the model's raw score, for reporting */
    i32 rec;        /* successes minus failures */
    i32 score;      /* weighted total */
    u32 support;    /* how many kinds back it: 0..3 */
    u32 seen;       /* insertion order, the final tie-break */
};

static struct candidate cands[THINK_CANDIDATES];
static u32 nc;
static u32 next_seen;

static u32 thoughts;
static u32 unsure_thoughts;
static u64 total_cycles;
static char last_trace[768];

u32 think_count(void) { return thoughts; }
u32 think_unsure_count(void) { return unsure_thoughts; }
u64 think_cycles(void) { return total_cycles; }

/* --- Trace building --------------------------------------------------------
 *
 * The kernel has no snprintf, so the trace is assembled by appending to a
 * fixed buffer. Every helper is bounds-checked and returns the new length.
 */

static u32 tr_str(char *out, u32 n, u32 max, const char *s)
{
    for (const char *p = s; p && *p && n + 1 < max; p++) {
        out[n++] = *p;
    }
    if (max) {
        out[n] = '\0';
    }
    return n;
}

static u32 tr_uint(char *out, u32 n, u32 max, u32 v)
{
    char tmp[12];
    u32 t = 0;

    if (v == 0) {
        tmp[t++] = '0';
    }
    while (v > 0 && t < sizeof(tmp)) {
        tmp[t++] = (char)('0' + (v % 10));
        v /= 10;
    }
    while (t > 0 && n + 1 < max) {
        out[n++] = tmp[--t];
    }
    if (max) {
        out[n] = '\0';
    }
    return n;
}

static u32 tr_i32(char *out, u32 n, u32 max, i32 v)
{
    if (v < 0) {
        n = tr_str(out, n, max, "-");
        v = -v;
    }
    return tr_uint(out, n, max, (u32)v);
}

/* "+" or "-" for one evidence kind, so a line reads like a scorecard. */
static u32 tr_mark(char *out, u32 n, u32 max, int on)
{
    return tr_str(out, n, max, on ? "+" : "-");
}

/* --- Candidate set --------------------------------------------------------- */

static int find_cand(const char *name)
{
    for (u32 i = 0; i < nc; i++) {
        if (strcmp(cands[i].name, name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

static int add_cand(const char *name)
{
    if (!name || !*name) {
        return -1;
    }
    int at = find_cand(name);
    if (at >= 0) {
        return at;
    }
    if (nc >= THINK_CANDIDATES) {
        return -1;
    }
    struct candidate *c = &cands[nc];
    memset(c, 0, sizeof(*c));
    c->name = name;
    c->rule_order = 999;
    c->seen = next_seen++;
    return (int)nc++;
}

/* --- Scoring --------------------------------------------------------------- */

i32 think_weigh(int rule, int model, i32 rec)
{
    i32 score = (rule ? W_RULE : 0) + (model ? W_MODEL : 0);

    if (rec > 0) {
        score += W_RECORD;
    } else if (rec < 0) {
        score -= W_RECORD;      /* a failure is evidence against */
    }
    return score;
}

static void score_all(void)
{
    for (u32 i = 0; i < nc; i++) {
        struct candidate *c = &cands[i];

        c->rec = outcome_score(c->name);
        c->record = c->rec > 0 ? 1 : 0;
        c->score = think_weigh(c->rule, c->model, c->rec);
        c->support = (u32)c->rule + (u32)c->model + (u32)c->record;
    }
}

/* Pick the highest score. Ties go to the more specific rule, then the larger
 * raw model score, then the earlier insertion, so the winner is deterministic
 * and never depends on array order alone. */
static struct candidate *pick(void)
{
    struct candidate *best = 0;

    for (u32 i = 0; i < nc; i++) {
        struct candidate *c = &cands[i];
        if (!best) {
            best = c;
            continue;
        }
        if (c->score > best->score) {
            best = c;
        } else if (c->score == best->score) {
            if (c->rule_order < best->rule_order) {
                best = c;
            } else if (c->rule_order == best->rule_order
                       && c->raw > best->raw) {
                best = c;
            } else if (c->rule_order == best->rule_order
                       && c->raw == best->raw && c->seen < best->seen) {
                best = c;
            }
        }
    }
    return best;
}

/* --- The thought ----------------------------------------------------------- */

const char *think_consider(const char *text, enum think_result *result,
                           char *trace, u32 trace_max)
{
    u64 start = tsc_read();
    u32 n = 0;

    if (result) {
        *result = THINK_UNSURE;
    }
    if (trace && trace_max) {
        trace[0] = '\0';
    }

    nc = 0;
    next_seen = 0;

    /* Evidence 1: the keyword rules. Position matters, so the first rule the
     * text matches is recorded as the most specific. */
    const char *rules[THINK_CANDIDATES];
    u32 rc = ai_rule_actions(text, rules, THINK_CANDIDATES);
    for (u32 i = 0; i < rc; i++) {
        int at = add_cand(rules[i]);
        if (at >= 0 && !cands[at].rule) {
            cands[at].rule = 1;
            cands[at].rule_order = (int)i;
        }
    }

    /* Evidence 2: the learned model, every action it leans towards. One
     * tokenisation serves every action, rather than one per action: the
     * features depend only on the text, so deriving them once is the whole
     * saving and the scores are identical. See think_bench() for the measure. */
    i32 scores[THINK_ACTIONS_MAX];
    u32 actions = localai_action_count();
    if (actions > THINK_ACTIONS_MAX) {
        actions = THINK_ACTIONS_MAX;
    }
    localai_scores(text, scores, actions);
    for (u32 a = 0; a < actions; a++) {
        if (scores[a] > 0) {
            int at = add_cand(localai_action_name(a));
            if (at >= 0) {
                cands[at].model = 1;
                cands[at].raw = scores[a];
            }
        }
    }

    score_all();
    struct candidate *win = pick();

    /* Grade the winner by how many independent kinds back it. No evidence at
     * all is the one case that is refused rather than answered. */
    if (win) {
        if (win->support >= 3) {
            *result = THINK_CLEAR;
        } else if (win->support == 2) {
            *result = THINK_LEAN;
        } else if (win->support == 1) {
            *result = THINK_GUESS;
        } else {
            *result = THINK_UNSURE;
        }

        /* The model alone is not enough to act on. At a coarse grade it has
         * only a handful of feature slots, so unrelated words collide and it
         * will lean confidently towards some action for a request it has never
         * seen. A record is real evidence and a rule is stated evidence, but an
         * unsupported model positive is a guess about the shape of the text, so
         * it is downgraded to UNSURE rather than acted on. */
        if (*result == THINK_GUESS && win->model && !win->rule && !win->record) {
            *result = THINK_UNSURE;
        }
    }

    /* Build the trace: what was considered, and why the winner won. */
    n = tr_str(trace, n, trace_max, "think: ");
    n = tr_str(trace, n, trace_max, text && *text ? text : "(nothing)");
    for (u32 i = 0; i < nc; i++) {
        n = tr_str(trace, n, trace_max, "\n  ");
        n = tr_str(trace, n, trace_max, cands[i].name);
        n = tr_str(trace, n, trace_max, " rule");
        n = tr_mark(trace, n, trace_max, cands[i].rule);
        n = tr_str(trace, n, trace_max, " model");
        n = tr_mark(trace, n, trace_max, cands[i].model);
        n = tr_str(trace, n, trace_max, " record");
        n = tr_mark(trace, n, trace_max, cands[i].record);
        n = tr_str(trace, n, trace_max, " score ");
        n = tr_i32(trace, n, trace_max, cands[i].score);
        n = tr_str(trace, n, trace_max, " support ");
        n = tr_uint(trace, n, trace_max, cands[i].support);
    }
    n = tr_str(trace, n, trace_max, "\n  verdict ");
    if (win && *result != THINK_UNSURE) {
        n = tr_str(trace, n, trace_max, "winner ");
        n = tr_str(trace, n, trace_max, win->name);
        n = tr_str(trace, n, trace_max, " on ");
        n = tr_uint(trace, n, trace_max, win->support);
        n = tr_str(trace, n, trace_max, " of 3 kinds: ");
    }
    n = tr_str(trace, n, trace_max,
               *result == THINK_CLEAR ? "clear"
               : *result == THINK_LEAN ? "lean"
               : *result == THINK_GUESS ? "guess"
               : "unsure, refusing to act");

    if (trace && trace_max) {
        last_trace[0] = '\0';
        tr_str(last_trace, 0, sizeof(last_trace), trace);
    }

    thoughts++;
    if (*result == THINK_UNSURE) {
        unsure_thoughts++;
    }
    total_cycles += tsc_read() - start;

    return win ? win->name : "";
}

/* --- Acting on a thought ---------------------------------------------------
 *
 * An action name may carry an argument ("lesson 2"), so it is split on the
 * first space before dispatch: the name goes to the dispatcher and the rest
 * becomes the argument.
 */
static int dispatch_action(const char *name)
{
    char cmd[32];
    u32 n = 0;

    while (name[n] && name[n] != ' ' && n + 1 < sizeof(cmd)) {
        cmd[n] = name[n];
        n++;
    }
    cmd[n] = '\0';

    const char *arg = name[n] == ' ' ? name + n + 1 : 0;
    return actions_dispatch(cmd, arg);
}

/* Commit a decision: run it, record the result, and teach the model.
 *
 * Shared by think_act() and the command line, so a reasoned decision is fed
 * back the same way however it was reached. Without this the thinking path
 * would be a permanent second opinion that never improves the fast one. */
int think_commit(const char *text, const char *choice)
{
    if (!choice || !*choice) {
        return 0;
    }

    if (dispatch_action(choice) == ACTION_UNKNOWN) {
        outcome_record(choice, 0);
        return 0;
    }

    /* The decision becomes a training example, so the fast path recognises the
     * request next time, and a result, so a method that worked is preferred
     * when the evidence is otherwise equal. */
    outcome_record(choice, 1);
    localai_train(text, choice);
    return 1;
}

int think_act(const char *text)
{
    enum think_result verdict;
    const char *choice = think_consider(text, &verdict, 0, 0);

    if (verdict == THINK_UNSURE || !choice || !*choice) {
        klog("THINK", "not enough evidence to act on '%s'",
             text && *text ? text : "(nothing)");
        return 0;
    }

    if (!think_commit(text, choice)) {
        klog("THINK", "chose '%s' but it did not run", choice);
        return 0;
    }

    klog("THINK", "chose '%s' on %s evidence and learned it",
         choice,
         verdict == THINK_CLEAR ? "clear"
         : verdict == THINK_LEAN ? "leaning" : "thin");
    return 1;
}

/* --- Reporting and selftest ------------------------------------------------ */

void think_report(void)
{
    klog("THINK", "thoughts=%u unsure=%u cycles=%llu",
         thoughts, unsure_thoughts, total_cycles);
    if (last_trace[0]) {
        serial_puts(last_trace);
        serial_puts("\n");
    }
}

/* Time the slow and fast ways to score every action on the same text, and check
 * they agree.
 *
 * This is the optimisation course applied to the machine's own reasoning. The
 * slow way re-tokenises the request once per action; the fast way tokenises
 * once and reuses the features. The picture must match -- here, every action's
 * score must be identical -- or the speed is not a fair comparison.
 *
 * Returns 1 when both agree. Logs the cycles and the ratio either way. */
int think_bench(const char *text)
{
    const char *probe = text && *text ? text : "run the program on the cpu loop";
    i32 slow[THINK_ACTIONS_MAX];
    i32 fast[THINK_ACTIONS_MAX];
    u32 actions = localai_action_count();
    if (actions > THINK_ACTIONS_MAX) {
        actions = THINK_ACTIONS_MAX;
    }

    /* Repeat so the measurement is long enough to see past the clock's noise. */
    u32 reps = 64;

    u64 t0 = tsc_read();
    for (u32 r = 0; r < reps; r++) {
        for (u32 a = 0; a < actions; a++) {
            slow[a] = localai_score(probe, localai_action_name(a));
        }
    }
    u64 t1 = tsc_read();

    for (u32 r = 0; r < reps; r++) {
        localai_scores(probe, fast, actions);
    }
    u64 t2 = tsc_read();

    int same = 1;
    for (u32 a = 0; a < actions; a++) {
        if (slow[a] != fast[a]) {
            same = 0;
        }
    }

    u32 slow_c = (u32)((t1 - t0) / reps);
    u32 fast_c = (u32)((t2 - t1) / reps);

    klog("THINK", "score all %u actions: slow %u cycles, fast %u cycles",
         actions, slow_c, fast_c);
    if (fast_c) {
        /* Scale down until each fits 24 bits so the ratio is plain 32-bit
         * arithmetic, as the optim benchmark does. */
        u64 a = slow_c, b = fast_c;
        while (a > 0xFFFFFFull || b > 0xFFFFFFull) {
            a >>= 1;
            b >>= 1;
        }
        u32 r100 = b ? ((u32)a * 100u) / (u32)b : 0;
        klog("THINK", "the batched version is %u.%ux faster, same scores: %s",
             r100 / 100, (r100 % 100) / 10, same ? "yes" : "no");
    }
    return same;
}

int think_selftest(void)
{
    enum think_result verdict;
    char trace[512];
    const char *name;

    /* An empty request has no evidence of any kind, so the honest answer is to
     * refuse. This is the property the whole design exists to protect. */
    name = think_consider("", &verdict, trace, sizeof(trace));
    if (verdict != THINK_UNSURE || !name) {
        return 0;
    }

    /* A plainly worded request must be recognised, and the trace must say why.
     * The exact confidence depends on what the model has learned so far, so
     * only the choice and the trace are checked. */
    name = think_consider("run the program on the cpu loop", &verdict,
                          trace, sizeof(trace));
    if (!name || strcmp(name, "run") != 0 || verdict == THINK_UNSURE) {
        return 0;
    }
    if (!strstr(trace, "verdict") || !strstr(trace, "run")) {
        return 0;
    }

    /* A different request must reach a different action, or the evidence is not
     * actually being used. */
    name = think_consider("show the cache geometry and free l1", &verdict,
                          trace, sizeof(trace));
    if (!name || strcmp(name, "cache") != 0) {
        return 0;
    }

    /* Thinking must cost time, and the time must be counted: a zero here would
     * mean the cycle clock is not wired in. */
    {
        u64 before = think_cycles();
        think_consider("store this key program on the disk", &verdict,
                       trace, sizeof(trace));
        if (think_cycles() <= before) {
            return 0;
        }
    }

    /* The optimised scoring path must agree with the slow one it replaced, or
     * the speedup is not a fair comparison. */
    if (!think_bench(0)) {
        return 0;
    }

    /* The ordering of the evidence must be enforced, not merely intended: a
     * proven record has to beat any amount of text-based agreement, and a
     * failed record has to lose to having no record at all. Checked directly on
     * the weighing function, so no real tallies are touched. */
    i32 both_text = think_weigh(1, 1, 0);        /* rules and model agree */
    i32 proven    = think_weigh(0, 0, 1);        /* only a measured result */
    if (proven <= both_text) {
        return 0;                               /* results must decide */
    }
    if (think_weigh(1, 1, -1) >= think_weigh(0, 0, 0)) {
        return 0;                               /* failure must count against */
    }
    /* A lone unproven guess is the weakest evidence there is. */
    if (think_weigh(0, 1, 0) >= think_weigh(1, 0, 0)) {
        return 0;                               /* a rule beats the raw model */
    }

    /* An unsupported model positive must not become a decision. "xyzzy" is not
     * a word the model has seen, but at a coarse grade its hash lands on a slot
     * some real word trained, so the model alone can lean towards an action.
     * That is a guess about the shape of the text, not evidence, and the
     * verdict must be UNSURE so the machine declines to act on it. */
    name = think_consider("xyzzy plugh frobnicate", &verdict, trace,
                          sizeof(trace));
    if (verdict != THINK_UNSURE) {
        return 0;
    }

    return 1;
}
