/* Minimal formatted output over the serial port. */

#include "serial.h"
#include "types.h"
#include <stdarg.h>

/* Every formatted byte leaves through this sink. The serial port is the default;
 * the GUI swaps in its own capture so the on-screen log shows the same text. */
static void (*emit)(char) = serial_putc;

void console_set_sink(void (*fn)(char))
{
    emit = fn ? fn : serial_putc;
}

static void put_uint(u32 value, u32 base, int pad, char padc)
{
    char buf[32];
    int n = 0;

    if (value == 0) {
        buf[n++] = '0';
    }
    while (value > 0) {
        u32 digit = value % base;
        buf[n++] = (char)(digit < 10 ? '0' + digit : 'a' + (digit - 10));
        value /= base;
    }
    while (pad-- > n) {
        emit(padc);
    }
    while (n > 0) {
        emit(buf[--n]);
    }
}

static void put_int(i32 value)
{
    if (value < 0) {
        emit('-');
        put_uint((u32)(-value), 10, 0, ' ');
    } else {
        put_uint((u32)value, 10, 0, ' ');
    }
}

/* 64-bit formatting without 64-bit division: there is no 32-bit libgcc here, so
 * base 16 extracts nibbles with shifts and base 10 subtracts from a table of
 * powers of ten. */
static void put_uint64(u64 value, u32 base, u32 width, char pad)
{
    char buf[24];
    u32 i = 0;

    if (base == 16) {
        if (value == 0) {
            buf[i++] = '0';
        }
        while (value > 0) {
            u32 digit = (u32)(value & 0xF);
            buf[i++] = (digit < 10) ? (char)('0' + digit)
                                    : (char)('a' + digit - 10);
            value >>= 4;
        }
    } else {
        static const u64 pow10[] = {
            1ull, 10ull, 100ull, 1000ull, 10000ull, 100000ull, 1000000ull,
            10000000ull, 100000000ull, 1000000000ull, 10000000000ull,
            100000000000ull, 1000000000000ull, 10000000000000ull,
            100000000000000ull, 1000000000000000ull, 10000000000000000ull,
            100000000000000000ull, 1000000000000000000ull,
            10000000000000000000ull,
        };
        const u32 pow10_count = sizeof(pow10) / sizeof(pow10[0]);

        if (value == 0) {
            buf[i++] = '0';
        } else {
            int p = (int)pow10_count - 1;
            while (p > 0 && pow10[p] > value) {
                p--;
            }
            for (; p >= 0; p--) {
                u32 digit = 0;
                while (value >= pow10[p]) {
                    value -= pow10[p];
                    digit++;
                }
                buf[i++] = (char)('0' + digit);
            }
        }
    }

    while (i < width) {
        buf[i++] = pad;
    }
    while (i > 0) {
        emit(buf[--i]);
    }
}

static void vformat(const char *fmt, va_list ap)
{
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') {
            emit(*p);
            continue;
        }
        p++;
        switch (*p) {
        case 's': {
            const char *s = va_arg(ap, const char *);
            for (const char *q = s ? s : "(null)"; *q; q++) {
                emit(*q);
            }
            break;
        }
        case 'd': put_int(va_arg(ap, i32)); break;
        case 'u': put_uint(va_arg(ap, u32), 10, 0, ' '); break;
        case 'x': put_uint(va_arg(ap, u32), 16, 0, ' '); break;
        case 'p':
            emit('0');
            emit('x');
            put_uint(va_arg(ap, u32), 16, 8, '0');
            break;
        case 'c': emit((char)va_arg(ap, int)); break;
        case '%': emit('%'); break;
        case 'l':
            /* %llx / %llu: 64-bit values, needed to print a combined flow. */
            p++;
            if (*p == 'l') {
                p++;
            }
            switch (*p) {
            case 'x': put_uint64(va_arg(ap, u64), 16, 0, ' '); break;
            case 'u': put_uint64(va_arg(ap, u64), 10, 0, ' '); break;
            default:
                emit('%');
                emit('l');
                emit(*p);
                break;
            }
            break;
        default:
            emit('%');
            emit(*p);
            break;
        }
    }
}

void kprintf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vformat(fmt, ap);
    va_end(ap);
}

void klog(const char *tag, const char *fmt, ...)
{
    emit('[');
    for (const char *t = tag; *t; t++) {
        emit(*t);
    }
    emit(']');
    emit(' ');
    va_list ap;
    va_start(ap, fmt);
    vformat(fmt, ap);
    va_end(ap);
    emit('\n');
}
