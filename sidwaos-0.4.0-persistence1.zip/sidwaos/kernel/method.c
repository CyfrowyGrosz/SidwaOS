/* The programming method. See include/method.h.
 *
 * Five loops, each a list of steps, each refining the one above. The worked
 * example is the same program the C course ends on -- Hello World as a GUI --
 * so the method can be read straight through and the result is something the
 * machine already knows how to draw.
 *
 * Steps are plain ASCII under 72 columns so they render in the kernel's 80x25
 * text GUI without wrapping.
 */

#include "method.h"
#include "serial.h"
#include "string.h"

static const struct method_loop loops[] = {
    { 1, "What we want to achieve", "what is the goal, and which aspect of the program is it?", 6, {
        "Goal: show Hello, World! in a window.",
        "The user sees one greeting and can quit.",
        "Aspect: the view. The point is what is shown.",
        "Not the model yet, and not the keys yet.",
        "Done when: a window opens with the text.",
        "Write that sentence down before any code.",
    }},
    { 2, "Smaller pieces (complete functions)", "which functions finish a piece of the goal?", 7, {
        "gui_open()      open the window.",
        "gui_draw()      draw the greeting.",
        "gui_key()       return the next key.",
        "gui_close()     close the window.",
        "Each piece can be built and tested alone.",
        "A piece that cannot be split is not ready:",
        "it is still a goal, so go back to loop 1.",
    }},
    { 3, "Program objects", "what data do those functions work on?", 6, {
        "struct window  where it is and its size.",
        "struct state   the greeting string.",
        "struct state   the running flag.",
        "The window is what the view draws.",
        "The state is what the model holds.",
        "Name the objects before the signatures.",
    }},
    { 4, "Function declarations", "what are the exact signatures?", 6, {
        "struct window *gui_open(int w, int h);",
        "void gui_draw(struct window *win,",
        "              const struct state *st);",
        "int  gui_key(void);",
        "void gui_close(struct window *win);",
        "The types come straight from loop 3.",
    }},
    { 5, "Pseudo code", "what does each function actually do?", 8, {
        "gui_open:",
        "  clear the screen; draw the frame; return it.",
        "gui_draw:",
        "  print st->greeting inside the frame.",
        "gui_key:",
        "  wait for a key; return it.",
        "main:",
        "  open; draw; while key != 'q' draw; close.",
    }},
};

static const u32 loop_count = sizeof(loops) / sizeof(loops[0]);

u32 method_count(void) { return loop_count; }

const struct method_loop *method_get(u32 index)
{
    return index < loop_count ? &loops[index] : 0;
}

const struct method_loop *method_find(const char *keyword)
{
    if (!keyword || !*keyword) {
        return 0;
    }

    /* Titles first: "objects" should find loop 3, not the loop whose steps
     * happen to mention objects on the way past. */
    for (u32 i = 0; i < loop_count; i++) {
        if (stristr(loops[i].title, keyword)) {
            return &loops[i];
        }
    }
    for (u32 i = 0; i < loop_count; i++) {
        for (u32 s = 0; s < loops[i].steps; s++) {
            if (stristr(loops[i].step[s], keyword)) {
                return &loops[i];
            }
        }
    }
    return 0;
}

/* Append "Loop N: " and the title to `out`. Shared by the formatter and the
 * printer's buffer path. Returns the new length. */
static u32 put_header(const struct method_loop *loop, char *out, u32 n, u32 max)
{
    const char *k = "Loop ";
    for (const char *p = k; *p && n + 1 < max; p++) {
        out[n++] = *p;
    }
    if (loop->number >= 10 && n + 1 < max) {
        out[n++] = (char)('0' + loop->number / 10);
    }
    if (n + 1 < max) {
        out[n++] = (char)('0' + loop->number % 10);
    }
    if (n + 1 < max) {
        out[n++] = ':';
    }
    if (n + 1 < max) {
        out[n++] = ' ';
    }
    for (const char *p = loop->title; *p && n + 1 < max; p++) {
        out[n++] = *p;
    }
    return n;
}

u32 method_format(const struct method_loop *loop, char *out, u32 max)
{
    if (!loop || max == 0) {
        return 0;
    }

    u32 n = put_header(loop, out, 0, max);

    for (u32 s = 0; s < loop->steps; s++) {
        if (n + 1 < max) {
            out[n++] = '\n';
        }
        for (const char *p = loop->step[s]; *p && n + 1 < max; p++) {
            out[n++] = *p;
        }
    }

    out[n] = '\0';
    return n;
}

void method_print(const struct method_loop *loop)
{
    if (!loop) {
        klog("METHOD", "no such loop");
        return;
    }

    klog("METHOD", "Loop %u: %s", loop->number, loop->title);
    klog("METHOD", "  %s", loop->question);
    for (u32 s = 0; s < loop->steps; s++) {
        klog("METHOD", "  %u. %s", s + 1, loop->step[s]);
    }
}

void method_print_all(void)
{
    klog("METHOD", "programming method: %u loops, goal to pseudo code",
         loop_count);
    for (u32 i = 0; i < loop_count; i++) {
        method_print(&loops[i]);
    }
}

int method_selftest(void)
{
    char buf[768];

    /* The method is a ladder of five, in order. */
    if (loop_count != 5) {
        return 0;
    }
    for (u32 i = 0; i < loop_count; i++) {
        const struct method_loop *l = method_get(i);
        if (!l || l->number != i + 1 || l->steps == 0) {
            return 0;
        }
        /* Each loop must state the question it answers. */
        if (!l->question || !*l->question) {
            return 0;
        }
    }

    /* Each level must be findable by the thing it produces. */
    if (!method_find("achieve") || !method_find("functions")
        || !method_find("objects") || !method_find("declaration")
        || !method_find("pseudo")) {
        return 0;
    }

    /* The ladder must run from the goal down to the logic, and the last loop
     * must actually carry pseudo code. */
    const struct method_loop *last = method_get(loop_count - 1);
    u32 n = method_format(last, buf, sizeof(buf));
    if (n == 0 || !strstr(buf, "main:")) {
        return 0;
    }

    /* Loop 1 must describe the goal, not the code. */
    n = method_format(method_get(0), buf, sizeof(buf));
    return n > 0 && strstr(buf, "Goal:");
}
