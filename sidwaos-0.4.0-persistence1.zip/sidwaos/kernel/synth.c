/* Program synthesis. See include/synth.h.
 *
 * The model writes a program; the assembler and the virtual machine decide
 * whether to believe it. The prompt carries the whole instruction set, because
 * a model that has to guess at the language will invent instructions that do
 * not exist, and every such guess costs a round trip.
 *
 * The comparison is on the run's output text, trimmed of trailing whitespace on
 * each line, so a program that prints the right numbers in the right order
 * passes whether or not the model matched the expected spacing exactly. What it
 * does not forgive is a wrong value, a missing line or an extra one.
 */

#include "synth.h"
#include "svm.h"
#include "know.h"
#include "pedant.h"
#include "peephole.h"
#include "serial.h"
#include "string.h"

static void synth_improve(const char *task, char *source, u32 source_max,
                          struct sasm_program *prog);

/* The instruction set, as given to the model. Written out rather than derived
 * from sasm.h because the model needs the syntax, not the opcode numbers, and a
 * table built at run time would be more code than the text it produces. The
 * selftest checks it against sasm_op_name() so the two cannot drift apart. */
static const char *isa_text(void)
{
    return
        "SidwaASM has four registers r0..r3 and 64 words of memory.\n"
        "Instructions (one per line, operand separated by a comma):\n"
        "  MOV r0, 42        set a register to a constant\n"
        "  MOV r0, 'A'       set a register to a character's code (see below)\n"
        "  MOV r0, r1        copy a register\n"
        "  MOV r0, [r1]      load from memory at address r1\n"
        "  MOV [r0], r1      store r1 to memory at address r0\n"
        "  ADD r0, 1         add a constant\n"
        "  ADD r0, r1        add a register\n"
        "  SUB r0, 1         subtract a constant\n"
        "  MUL r0, 2         multiply by a constant\n"
        "  CMP r0, 10        compare with a constant, sets the zero flag\n"
        "  JMP label         jump\n"
        "  JZ label          jump if equal\n"
        "  JNZ label         jump if not equal\n"
        "  OUT r0            print a register as a decimal number and a newline\n"
        "  OUTC r0           print a register as a character\n"
        "  HLT               stop\n"
        "To print text, put each character in a register with a character literal "
        "and print it with OUTC. A character literal is the character in single "
        "quotes and stands for that character's code, so 'H' means 72 and ' ' "
        "means 32. For example, to print the text Hi:\n"
        "  MOV r0, 'H'\n"
        "  OUTC r0\n"
        "  MOV r0, 'i'\n"
        "  OUTC r0\n"
        "Use a literal rather than working out the number. OUTC prints a "
        "character; OUT prints a number.\n"
        "Every instruction takes at most two operands: a destination register "
        "and one source. There is no three-operand form, so to add two registers "
        "copy one first -- to compute r2 = r0 + r1 write:\n"
        "  MOV r2, r0\n"
        "  ADD r2, r1\n"
        "A loop is a label, the body, and a conditional jump back to the label. "
        "A loop that runs a fixed number of times uses a counter and jumps back "
        "while the counter is not zero. For example, to print 3, 2, 1:\n"
        "  MOV r3, 3\n"
        "loop:\n"
        "  OUT r3\n"
        "  SUB r3, 1\n"
        "  CMP r3, 0\n"
        "  JNZ loop\n"
        "  HLT\n"
        "To combine a loop with values that change, keep the values in registers "
        "and use a spare register as scratch when a step would otherwise "
        "overwrite a value it still needs.\n"
        "A label is a name followed by a colon on its own or at the start of a "
        "line. A line starting with ; is a comment.\n";
}

void synth_prompt(const char *task, const char *expect, char *out, u32 max)
{
    u32 n = 0;
    out[0] = '\0';

#define APP(s) \
    do { \
        for (const char *q = (s); *q; q++) { \
            if (n + 1 >= max) { out[n] = '\0'; return; } \
            out[n++] = *q; \
        } \
        out[n] = '\0'; \
    } while (0)

    APP("Write a SidwaASM program that does this task:\n");
    APP(task);
    APP("\nIt must print exactly this, and nothing else:\n");
    APP(expect);
    APP("\nThe input values are constants in the task; there is no input "
        "instruction, so put them in the program directly.\n\n");
    APP(isa_text());
    APP("Reply with the program only.\n");

#undef APP
}

/* The prompt for a second or later attempt: the same request, with what the
 * previous program actually printed quoted back.
 *
 * The sampler is pinned to temperature 0, so re-asking an identical prompt
 * returns the identical program -- a plain retry would only burn time. Showing
 * the model its own output is the one thing that changes the question, and it
 * turns the verifier from a yes/no gate into a teacher: the machine already
 * knows exactly how the program was wrong, because it ran it. */
void synth_prompt_retry(const char *task, const char *expect,
                        const char *got, char *out, u32 max)
{
    u32 n = 0;
    out[0] = '\0';

#define APP(s) \
    do { \
        for (const char *q = (s); *q; q++) { \
            if (n + 1 >= max) { out[n] = '\0'; return; } \
            out[n++] = *q; \
        } \
        out[n] = '\0'; \
    } while (0)

    synth_prompt(task, expect, out, max);
    n = (u32)strlen(out);

    APP("\nThe program you gave printed this:\n");
    APP(got);
    APP("\nThat is not what the task asks for. It must print exactly:\n");
    APP(expect);
    APP("\nPrint every character of the text, including the last one. Reply "
        "with the corrected program only.\n");

#undef APP
}

/* Expand \n into a real newline, in place. See include/synth.h.
 *
 * Two characters become one, so the string only ever shrinks and no buffer
 * bound changes. A backslash that starts nothing recognisable is left as it
 * stands rather than swallowed, so a literal backslash survives. */
void synth_expand_escapes(char *s)
{
    if (!s) {
        return;
    }
    char *d = s;
    for (const char *p = s; *p; p++) {
        if (*p == '\\' && p[1] == 'n') {
            *d++ = '\n';
            p++;
        } else {
            *d++ = *p;
        }
    }
    *d = '\0';
}

/* Compare a run's output with what was expected, ignoring trailing spaces and
 * blank lines. A wrong value or a missing or extra line is a mismatch. */
static int output_matches(const char *got, const char *expect)
{
    while (*got || *expect) {
        /* Take one line from each, ending at '\n'. */
        const char *ge = got;
        while (*ge && *ge != '\n') {
            ge++;
        }
        const char *ee = expect;
        while (*ee && *ee != '\n') {
            ee++;
        }

        /* Compare, ignoring trailing spaces and carriage returns. */
        u32 gl = (u32)(ge - got);
        u32 el = (u32)(ee - expect);
        while (gl > 0 && (got[gl - 1] == ' ' || got[gl - 1] == '\r')) {
            gl--;
        }
        while (el > 0 && (expect[el - 1] == ' ' || expect[el - 1] == '\r')) {
            el--;
        }

        /* An all-blank line on either side is skipped rather than compared, so
         * a stray blank line does not fail an otherwise correct program. */
        if (gl == 0 && el == 0) {
            if (*ge == '\n') ge++;
            if (*ee == '\n') ee++;
            continue;
        }
        if (gl != el) {
            return 0;
        }
        for (u32 i = 0; i < gl; i++) {
            if (got[i] != expect[i]) {
                return 0;
            }
        }

        if (*ge == '\n') ge++;
        if (*ee == '\n') ee++;
        got = ge;
        expect = ee;
    }
    return 1;
}

int synth_check(const char *source, const char *expect,
                struct sasm_program *prog, char *out, u32 out_max)
{
    struct sasm_program local;
    if (!prog) {
        prog = &local;
    }

    char err[SASM_ERROR_MAX];
    if (!sasm_assemble(source, prog, err, sizeof(err))) {
        klog("SYNTH", "does not assemble: %s", err);
        return SYNTH_BAD_ASM;
    }

    struct svm vm;
    svm_reset(&vm);
    int rc = svm_run(&vm, prog, out, out_max);
    if (rc != SVM_OK) {
        klog("SYNTH", "did not finish: %s", svm_error_text(rc));
        return SYNTH_BAD_RUN;
    }

    if (!output_matches(out, expect)) {
        klog("SYNTH", "wrong output: got '%s'", out);
        return SYNTH_MISMATCH;
    }
    return SYNTH_OK;
}

const char *synth_status_text(int code)
{
    switch (code) {
    case SYNTH_OK:       return "ok";
    case SYNTH_NO_MODEL: return "model unreachable";
    case SYNTH_NO_CODE:  return "reply held no program";
    case SYNTH_BAD_ASM:  return "does not assemble";
    case SYNTH_BAD_RUN:  return "does not finish";
    case SYNTH_MISMATCH: return "wrong output";
    default:             return "unknown";
    }
}

int synth_write(const char *task, const char *expect,
                char *source, u32 source_max, struct sasm_program *prog)
{
    if (!task || !*task || !expect) {
        return SYNTH_NO_CODE;
    }

    /* Before asking the model, try what the machine already knows. A task it
     * has solved before is answered from the partition, with no network and no
     * improvisation: the program that worked is the program to use again. */
    static char known[SYNTH_SOURCE_MAX];
    if (know_recall(task, known, sizeof(known)) > 0) {
        /* The recalled program is re-run, not trusted. A record on the partition
         * could have been written by an older build of the assembler, and a
         * program that no longer runs must not be handed back as an answer. */
        static char recheck[SVM_OUT_MAX];
        int rc = synth_check(known, expect, prog, recheck, sizeof(recheck));
        if (rc == SYNTH_OK) {
            u32 i = 0;
            for (; known[i] && i + 1 < source_max; i++) {
                source[i] = known[i];
            }
            source[i] = '\0';
            klog("SYNTH", "solved from what it already knew");
            return SYNTH_OK;
        }
        klog("SYNTH", "stored program no longer passes; writing a new one");
    }

    static char prompt[OLLAMA_CODE_MAX];
    synth_prompt(task, expect, prompt, sizeof(prompt));

    /* Ask, then prove. The gate decides whether the answer is accepted, so a
     * failed attempt costs time and nothing else -- which is what makes trying
     * more than once reasonable rather than reckless. Each attempt after the
     * first is told what the previous one printed. */
    static char reply[SYNTH_SOURCE_MAX];
    static char out[SVM_OUT_MAX];
    int rc = SYNTH_NO_MODEL;

    for (u32 attempt = 0; attempt < SYNTH_ATTEMPTS; attempt++) {
        if (ollama_ask_code(prompt, reply, sizeof(reply)) < 0) {
            /* Not a gap: the machine was not asked anything it could fail. */
            return SYNTH_NO_MODEL;
        }

        u32 i = 0;
        for (; reply[i] && i + 1 < source_max; i++) {
            source[i] = reply[i];
        }
        source[i] = '\0';

        rc = synth_check(source, expect, prog, out, sizeof(out));
        if (rc == SYNTH_OK) {
            break;
        }

        if (attempt + 1 < SYNTH_ATTEMPTS) {
            /* A program that will not assemble or will not run has no output
             * worth quoting, so only a wrong result earns the richer retry;
             * the rest just ask again. */
            if (rc == SYNTH_MISMATCH) {
                klog("SYNTH", "attempt %u printed '%s'; asking again",
                     attempt + 1, out);
                synth_prompt_retry(task, expect, out, prompt, sizeof(prompt));
            } else {
                klog("SYNTH", "attempt %u: %s; asking again",
                     attempt + 1, synth_status_text(rc));
                synth_prompt(task, expect, prompt, sizeof(prompt));
            }
        }
    }

    if (rc != SYNTH_OK) {
        /* A task it cannot do is a gap, recorded the same way an unanswered
         * question is. This is what makes the failure useful instead of merely
         * disappointing: the host tool reads these and teaches them. */
        pedant_note(task);
        pedant_save();
        klog("SYNTH", "%s; recorded as a gap", synth_status_text(rc));
        return rc;
    }

    /* It works. Now improve it, and prove the improvement changed nothing but
     * the length. */
    synth_improve(task, source, source_max, prog);

    /* Store it under the task, so the same task is answered without the model
     * next time. Held first, then verified: the corroboration is the run that
     * just succeeded, which is stronger evidence than a second opinion, but the
     * cache's rule is that nothing is stored unverified. */
    if (strlen(source) < KNOW_VALUE_MAX) {
        know_remember(task, source);
        know_verify(task);
    } else {
        klog("SYNTH", "works, but too long to store (%u bytes)",
             (u32)strlen(source));
    }

    klog("SYNTH", "wrote a working program (%u instructions)", prog->count);
    return SYNTH_OK;
}

/* Read a working program, shorten it, and record what was saved.
 *
 * This is the machine's "first point" turned on its own output: the program
 * that works is the slow build, the shorter one is the fast build, and the
 * saving is measured in VM steps because that is what the machine can actually
 * count.
 *
 * The shortened program is re-run and its output compared with the original's
 * before it replaces anything. A rewrite that changes what the program prints
 * is a bug in the optimiser, and this is where it is caught -- the same rule the
 * synthesis gate applies to the model, applied to the machine's own rewrite.
 *
 * What was saved is stored as knowledge under "optimise: <task>", so the record
 * of which kinds of waste the machine keeps finding survives a reboot and can be
 * read back. It is a note about the machine's own work, not a fact about the
 * world, but it is kept by the same mechanism for the same reason: it should not
 * have to be rediscovered.
 */
static void synth_improve(const char *task, char *source, u32 source_max,
                          struct sasm_program *prog)
{
    struct sasm_program before, after;
    char err[SASM_ERROR_MAX];
    if (!sasm_assemble(source, &before, err, sizeof(err))) {
        return;
    }

    struct peephole_report rep;
    u32 removed = peephole_optimise(&before, &after, &rep);
    if (removed == 0) {
        klog("SYNTH", "already minimal (%u instructions)", before.count);
        return;
    }

    /* The improvement must not change the output. Re-run both and compare. */
    static char out_before[SVM_OUT_MAX];
    static char out_after[SVM_OUT_MAX];
    struct svm vm;
    svm_reset(&vm);
    if (svm_run(&vm, &before, out_before, sizeof(out_before)) != SVM_OK) {
        return;
    }
    svm_reset(&vm);
    if (svm_run(&vm, &after, out_after, sizeof(out_after)) != SVM_OK) {
        return;
    }
    if (strcmp(out_before, out_after) != 0) {
        klog("SYNTH", "optimiser changed the output; keeping the original");
        return;
    }

    /* Show what it does before saying what changed, so the saving can be read
     * rather than taken on trust. */
    static char listing[512];
    peephole_list(&after, listing, sizeof(listing));
    const char *p = listing;
    klog("SYNTH", "optimised to %u instructions:", after.count);
    while (*p) {
        char ln[80];
        u32 k = 0;
        while (*p && *p != '\n' && k + 1 < sizeof(ln)) {
            ln[k++] = *p++;
        }
        ln[k] = '\0';
        if (*p == '\n') {
            p++;
        }
        klog("SYNTH", "  %s", ln);
    }

    static char summary[KNOW_VALUE_MAX];
    peephole_report_text(&rep, before.count, after.count, summary,
                         sizeof(summary));
    klog("SYNTH", "%s", summary);

    /* Record the opportunity under its own key. The task is trimmed to fit the
     * key field; the value holds the counts. */
    static char key[KNOW_KEY_MAX];
    u32 kn = 0;
    const char *prefix = "optimise: ";
    for (const char *q = prefix; *q && kn + 1 < sizeof(key); q++) {
        key[kn++] = *q;
    }
    for (const char *q = task; *q && kn + 1 < sizeof(key); q++) {
        key[kn++] = *q;
    }
    key[kn] = '\0';
    know_remember(key, summary);
    know_verify(key);

    /* Hand the improved program back, so what is stored under the task is the
     * shorter version. It has just been proved to print the same thing. */
    *prog = after;

    /* Render it back to source and re-assemble that text before trusting it.
     * The rendered form names jump targets as labels, so a program with jumps
     * survives the round trip; if the reassembled program differs in length the
     * render is wrong and the original source is kept instead. Storing the
     * optimised program without this check would store text that does not
     * reproduce what was verified. */
    static char rendered[SYNTH_SOURCE_MAX];
    peephole_render(&after, rendered, sizeof(rendered));

    struct sasm_program roundtrip;
    if (sasm_assemble(rendered, &roundtrip, err, sizeof(err))
        && roundtrip.count == after.count) {
        u32 k = 0;
        for (; rendered[k] && k + 1 < source_max; k++) {
            source[k] = rendered[k];
        }
        source[k] = '\0';
    } else {
        klog("SYNTH", "optimised program did not render back; keeping original");
        *prog = before;
    }
}

int synth_selftest(void)
{
    /* The prompt must name every instruction the assembler knows. A prompt that
     * omits one asks the model to guess at the language, and the guess shows up
     * as a program that will not assemble. Checked against sasm_op_name() so
     * adding an instruction without updating the prompt fails here. */
    static char prompt[OLLAMA_CODE_MAX];
    synth_prompt("a task", "an output", prompt, sizeof(prompt));

    for (u8 op = 0; op < SASM_OP_COUNT; op++) {
        const char *name = sasm_op_name(op);
        if (!name || !strstr(prompt, name)) {
            klog("SYNTH", "selftest: prompt does not name %s",
                 name ? name : "?");
            return 0;
        }
    }

    /* The retry prompt must still carry the task and the language -- it is the
     * only prompt a later attempt sees -- and must quote back what the previous
     * program printed, since that is the one thing that makes re-asking useful
     * under temperature 0. */
    static char retry[OLLAMA_CODE_MAX];
    synth_prompt_retry("a task", "an output", "a wrong thing",
                       retry, sizeof(retry));
    if (!strstr(retry, "a task") || !strstr(retry, "an output")
        || !strstr(retry, "a wrong thing")) {
        klog("SYNTH", "selftest: retry prompt lost the task, output or result");
        return 0;
    }
    for (u8 op = 0; op < SASM_OP_COUNT; op++) {
        const char *name = sasm_op_name(op);
        if (!name || !strstr(retry, name)) {
            klog("SYNTH", "selftest: retry prompt does not name %s",
                 name ? name : "?");
            return 0;
        }
    }

    /* The prompt must teach character literals, or a text task is asking the
     * model to compute ASCII codes by hand -- which it gets wrong. */
    if (!strstr(prompt, "'H'") || !strstr(prompt, "OUTC")) {
        klog("SYNTH", "selftest: prompt does not show a character literal");
        return 0;
    }

    /* The prompt must teach the two-operand rule and a loop, or a task that
     * needs either asks the model to invent syntax the ISA does not have. It
     * does: asked for a sequence it wrote "ADD r2, r0, r1" and never looped. */
    if (!strstr(prompt, "two operands") || !strstr(prompt, "JNZ")) {
        klog("SYNTH", "selftest: prompt does not teach the two-operand rule");
        return 0;
    }
    if (!strstr(prompt, "loop:") || !strstr(prompt, "counter")) {
        klog("SYNTH", "selftest: prompt does not show a loop");
        return 0;
    }

    /* \n in the expected output must become a real newline, so a task that
     * prints many numbers can be written on one command line. A lone backslash
     * must survive rather than be swallowed. */
    char esc[32];
    const char *esc_src = "1\\n2\\n3";
    u32 ei = 0;
    while (esc_src[ei] && ei + 1 < sizeof(esc)) {
        esc[ei] = esc_src[ei];
        ei++;
    }
    esc[ei] = '\0';
    synth_expand_escapes(esc);
    if (strcmp(esc, "1\n2\n3") != 0) {
        klog("SYNTH", "selftest: escapes expanded to '%s'", esc);
        return 0;
    }

    /* The gate must accept a correct program and reject a wrong one. Both
     * programs are fixed text, so this runs with no model and no network. */
    static char out[SVM_OUT_MAX];
    struct sasm_program prog;

    const char *good = "MOV r0, 6\nOUT r0\nHLT\n";
    if (synth_check(good, "6\n", &prog, out, sizeof(out)) != SYNTH_OK) {
        klog("SYNTH", "selftest: a correct program was rejected");
        return 0;
    }
    if (synth_check(good, "7\n", &prog, out, sizeof(out)) != SYNTH_MISMATCH) {
        klog("SYNTH", "selftest: a wrong output was accepted");
        return 0;
    }

    /* A program that does not assemble must be caught as such, not run. */
    if (synth_check("MOV r0\n", "6\n", &prog, out, sizeof(out))
        != SYNTH_BAD_ASM) {
        klog("SYNTH", "selftest: bad syntax was not caught");
        return 0;
    }

    /* A loop that never ends must be stopped by the step limit rather than
     * hanging the machine. */
    if (synth_check("loop:\nJMP loop\n", "6\n", &prog, out, sizeof(out))
        != SYNTH_BAD_RUN) {
        klog("SYNTH", "selftest: an endless loop was not stopped");
        return 0;
    }

    return 1;
}
