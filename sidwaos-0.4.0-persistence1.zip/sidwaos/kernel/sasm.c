/* SidwaASM assembler. See include/sasm.h.
 *
 * Two passes over the source. Pass 1 walks the lines, finds "label:" and counts
 * the instructions so every label gets an address; pass 2 emits the instructions
 * with those addresses substituted. Splitting it this way is what lets a jump
 * name a label defined further down the file, which is the normal shape of a
 * loop and the first thing anyone writes.
 *
 * The parser is a hand-written scanner rather than a table: there are twelve
 * instructions, and spelling them out keeps the error messages specific enough
 * to point at the line that is wrong.
 */

#include "sasm.h"
#include "serial.h"
#include "string.h"

/* --- Small helpers ---------------------------------------------------------- */

static int is_space(char c) { return c == ' ' || c == '\t' || c == '\r'; }

static int is_digit(char c) { return c >= '0' && c <= '9'; }

static int is_alpha(char c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}

static char lower(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
}

/* Case-insensitive compare of a NUL-terminated token. */
static int tok_eq(const char *tok, const char *word)
{
    u32 i = 0;
    for (; tok[i] && word[i]; i++) {
        if (lower(tok[i]) != word[i]) {
            return 0;
        }
    }
    return tok[i] == word[i];
}

/* Copy a token, lowercasing it. Returns the length. */
static u32 tok_copy(char *dst, u32 max, const char *src, u32 len)
{
    u32 i = 0;
    for (; i + 1 < max && i < len; i++) {
        dst[i] = lower(src[i]);
    }
    dst[i] = '\0';
    return i;
}

static void set_error(char *err, u32 err_max, u32 line, const char *reason)
{
    /* "line N: reason", built by hand because klog-style printf is not available
     * in the assembler's own string. */
    char num[12];
    u32 n = 0;
    if (line == 0) {
        num[n++] = '0';
    } else {
        char rev[12];
        u32 r = 0;
        u32 v = line;
        while (v && r < sizeof(rev)) {
            rev[r++] = (char)('0' + (v % 10));
            v /= 10;
        }
        while (r) {
            num[n++] = rev[--r];
        }
    }
    num[n] = '\0';

    u32 o = 0;
    const char *p = "line ";
    while (*p && o + 1 < err_max) {
        err[o++] = *p++;
    }
    for (const char *q = num; *q && o + 1 < err_max; q++) {
        err[o++] = *q;
    }
    if (o + 1 < err_max) {
        err[o++] = ':';
    }
    if (o + 1 < err_max) {
        err[o++] = ' ';
    }
    for (const char *q = reason; *q && o + 1 < err_max; q++) {
        err[o++] = *q;
    }
    err[o] = '\0';
}

/* --- Line scanning ---------------------------------------------------------- */

/* A parsed view of one source line. `m` is the mnemonic, `a`/`b` the two
 * operand fields. Everything is lowercased. */
struct line_view {
    char label[SASM_LABEL_MAX];
    char m[8];
    char a[24];
    char b[24];
    int has_label;
    int has_mnemonic;
};

/* Trim leading spaces, returning a pointer into the line. */
static const char *skip_space(const char *p)
{
    while (is_space(*p)) {
        p++;
    }
    return p;
}

/* Read the next token (up to a comma or space). A leading comma is skipped, so
 * the second operand of "mov r0, 1" is read as "1" and not as "". Returns the
 * end pointer.
 *
 * A character literal, 'x', is copied through verbatim: the quotes are kept and
 * the character inside is not lowercased, because 'A' and 'a' are different
 * values. Everything else is lowercased, since mnemonics and register names are
 * case-insensitive. */
static const char *read_token(const char *p, char *out, u32 max)
{
    u32 n = 0;
    p = skip_space(p);
    if (*p == ',') {
        p = skip_space(p + 1);
    }
    if (*p == '\'') {
        if (n + 1 < max) {
            out[n++] = *p;
        }
        p++;
        while (*p && *p != '\'' && n + 1 < max) {
            out[n++] = *p++;
        }
        if (*p == '\'' && n + 1 < max) {
            out[n++] = *p;
        }
        if (*p == '\'') {
            p++;
        }
        out[n] = '\0';
        return p;
    }
    while (*p && *p != ',' && *p != ';' && !is_space(*p)) {
        if (n + 1 < max) {
            out[n++] = lower(*p);
        }
        p++;
    }
    out[n] = '\0';
    return p;
}

/* Parse one line into a line_view. Returns 1 if the line holds anything. */
static int parse_line(const char *line, struct line_view *lv)
{
    lv->has_label = 0;
    lv->has_mnemonic = 0;
    lv->label[0] = '\0';
    lv->m[0] = '\0';
    lv->a[0] = '\0';
    lv->b[0] = '\0';

    const char *p = skip_space(line);
    if (*p == ';' || *p == '\0') {
        return 0;
    }

    /* A leading "word:" is a label definition. */
    const char *q = p;
    while (is_alpha(*q) || is_digit(*q)) {
        q++;
    }
    if (q > p && *q == ':') {
        tok_copy(lv->label, sizeof(lv->label), p, (u32)(q - p));
        lv->has_label = 1;
        p = skip_space(q + 1);
        if (*p == ';' || *p == '\0') {
            return 1;
        }
    }

    p = read_token(p, lv->m, sizeof(lv->m));
    if (lv->m[0] == '\0') {
        return lv->has_label;
    }
    lv->has_mnemonic = 1;

    p = read_token(p, lv->a, sizeof(lv->a));
    p = read_token(p, lv->b, sizeof(lv->b));
    return 1;
}

/* Number of registers the ISA exposes. Kept local so the assembler does not
 * depend on the VM's header, which includes this one. */
#define SASM_REGS 4

/* Parse "r0".."r3" into an index. Returns -1 when it is not a register. */
static int reg_index(const char *tok)
{
    if (tok[0] != 'r' || !is_digit(tok[1]) || tok[2] != '\0') {
        return -1;
    }
    int n = tok[1] - '0';
    return (n >= 0 && n < SASM_REGS) ? n : -1;
}

/* Parse a character literal, "'x'" or "'\n'", into its byte value. Returns 0 on
 * success, -1 when the token is not a well-formed literal.
 *
 * This is an assembler convenience, not an instruction: a literal compiles to
 * the same immediate form a decimal number does, so the instruction set is
 * unchanged and existing programs assemble exactly as before. It exists because
 * asking a small model for the ASCII code of each letter invites exactly the
 * mistake it made -- 'H' written as 7, 'W' as 44. Writing 'H' removes a step the
 * model was never good at. */
static int parse_char_lit(const char *tok, u32 *out)
{
    if (tok[0] != '\'') {
        return -1;
    }
    const char *p = tok + 1;
    char c;
    if (*p == '\\') {
        switch (p[1]) {
        case 'n':  c = '\n'; break;
        case 't':  c = '\t'; break;
        case 'r':  c = '\r'; break;
        case '0':  c = '\0'; break;
        case '\\': c = '\\'; break;
        case '\'': c = '\''; break;
        default:   return -1;
        }
        p += 2;
    } else if (*p && *p != '\'') {
        c = *p++;
    } else {
        return -1;              /* empty literal, '' */
    }
    if (*p != '\'' || p[1] != '\0') {
        return -1;
    }
    *out = (u32)(unsigned char)c;
    return 0;
}

/* Parse a decimal literal. Returns -1 when the token is not a plain number. */
static int parse_imm(const char *tok, u32 *out)
{
    if (tok[0] == '\'') {
        return parse_char_lit(tok, out);
    }
    if (!is_digit(tok[0])) {
        return -1;
    }
    u32 v = 0;
    for (const char *p = tok; *p; p++) {
        if (!is_digit(*p)) {
            return -1;
        }
        v = v * 10u + (u32)(*p - '0');
    }
    *out = v;
    return 0;
}

/* --- Label table ------------------------------------------------------------ */

struct label {
    char name[SASM_LABEL_MAX];
    u32 addr;
    int defined;
};

struct label_table {
    struct label items[SASM_MAX_LABELS];
    u32 count;
};

static struct label *label_find(struct label_table *t, const char *name)
{
    for (u32 i = 0; i < t->count; i++) {
        if (tok_eq(t->items[i].name, name)) {
            return &t->items[i];
        }
    }
    return 0;
}

static int label_add(struct label_table *t, const char *name, u32 addr)
{
    if (t->count >= SASM_MAX_LABELS) {
        return -1;
    }
    struct label *l = &t->items[t->count++];
    tok_copy(l->name, sizeof(l->name), name, (u32)strlen(name));
    l->addr = addr;
    l->defined = 1;
    return 0;
}

/* --- Opcode lookup ---------------------------------------------------------- */

static int mnemonic_op(const char *m)
{
    if (tok_eq(m, "hlt"))   { return SASM_OP_HLT; }
    if (tok_eq(m, "mov"))   { return SASM_OP_MOV; }
    if (tok_eq(m, "add"))   { return SASM_OP_ADD; }
    if (tok_eq(m, "sub"))   { return SASM_OP_SUB; }
    if (tok_eq(m, "mul"))   { return SASM_OP_MUL; }
    if (tok_eq(m, "cmp"))   { return SASM_OP_CMP; }
    if (tok_eq(m, "jmp"))   { return SASM_OP_JMP; }
    if (tok_eq(m, "jz"))    { return SASM_OP_JZ; }
    if (tok_eq(m, "jnz"))   { return SASM_OP_JNZ; }
    if (tok_eq(m, "out"))   { return SASM_OP_OUT; }
    if (tok_eq(m, "outc"))  { return SASM_OP_OUTC; }
    return -1;
}

/* --- Pass 1: label addresses ------------------------------------------------ */

/* Count the instruction a line emits: 0 for a label-only or blank line, 1
 * otherwise. Every instruction is one word of bytecode. */
static int count_instructions(const char *source, struct label_table *labels,
                             u32 *total, u32 *bad_line)
{
    u32 addr = 0;
    u32 line_no = 0;
    const char *p = source;

    while (*p) {
        const char *eol = p;
        while (*eol && *eol != '\n') {
            eol++;
        }
        line_no++;

        /* Copy the line so it can be scanned without NUL issues. */
        char buf[128];
        u32 n = 0;
        for (const char *q = p; q < eol && n + 1 < sizeof(buf); q++) {
            buf[n++] = *q;
        }
        buf[n] = '\0';

        struct line_view lv;
        if (parse_line(buf, &lv)) {
            if (lv.has_label) {
                if (label_add(labels, lv.label, addr) < 0) {
                    *bad_line = line_no;
                    return -1;
                }
            }
            if (lv.has_mnemonic) {
                if (mnemonic_op(lv.m) < 0) {
                    *bad_line = line_no;
                    return -2;
                }
                addr++;
            }
        }

        p = (*eol == '\n') ? eol + 1 : eol;
    }

    *total = addr;
    return 0;
}

/* --- Pass 2: emit ----------------------------------------------------------- */

/* Fill in a data-processing operand (MOV/ADD/SUB/MUL/CMP) and set mode.
 * `allow_mem` enables the bracketed [rN] forms; MOV is the only instruction
 * that takes them. */
static int operand_operand(const char *tok, u8 *mode, u8 *src, u32 *imm,
                           u8 *dst, int allow_mem)
{
    if (tok[0] == '[') {
        if (!allow_mem || tok[1] == '\0') {
            return -1;
        }
        char inner[8];
        u32 n = 0;
        const char *p = tok + 1;
        while (*p && *p != ']' && n + 1 < sizeof(inner)) {
            inner[n++] = lower(*p++);
        }
        if (*p != ']' || p[1] != '\0') {
            return -1;
        }
        inner[n] = '\0';
        int r = reg_index(inner);
        if (r < 0) {
            return -1;
        }
        *src = (u8)r;
        *mode = SASM_MODE_LOAD;      /* MOV rDst, [rSrc] */
        return 0;
    }

    int r = reg_index(tok);
    if (r >= 0) {
        *src = (u8)r;
        *mode = SASM_MODE_REG;
        return 0;
    }

    u32 v;
    if (parse_imm(tok, &v) == 0) {
        *imm = v;
        *mode = SASM_MODE_IMM;
        return 0;
    }

    (void)dst;
    return -1;
}

/* Emit one line into the program. Returns 0 on success, or -1/-2 to signal the
 * reason, with *bad_line set. */
static int emit_line(struct sasm_program *prog, const struct line_view *lv,
                     struct label_table *labels, u32 line_no, u32 *bad_line)
{
    int op = mnemonic_op(lv->m);
    if (op < 0) {
        *bad_line = line_no;
        return -2;
    }
    if (prog->count >= SASM_MAX_CODE) {
        *bad_line = line_no;
        return -3;
    }

    struct sasm_insn *in = &prog->code[prog->count];
    in->op = (u8)op;
    in->dst = 0;
    in->src = 0;
    in->mode = SASM_MODE_NONE;
    in->imm = 0;

    /* HLT takes no operand. */
    if (op == SASM_OP_HLT) {
        prog->count++;
        return 0;
    }

    /* OUT / OUTC take one register. */
    if (op == SASM_OP_OUT || op == SASM_OP_OUTC) {
        int r = reg_index(lv->a);
        if (r < 0) {
            *bad_line = line_no;
            return -1;
        }
        in->dst = (u8)r;
        prog->count++;
        return 0;
    }

    /* Jumps take a label, resolved in pass 2. */
    if (op == SASM_OP_JMP || op == SASM_OP_JZ || op == SASM_OP_JNZ) {
        struct label *l = label_find(labels, lv->a);
        if (!l) {
            *bad_line = line_no;
            return -1;
        }
        in->mode = SASM_MODE_LABEL;
        in->imm = l->addr;
        prog->count++;
        return 0;
    }

    /* Data processing: "OP dst, src". */
    int is_mov = (op == SASM_OP_MOV);

    /* MOV [rN], rM  -- a store. Checked before the plain-register form, because
     * "[r0]" is not itself a register name. */
    if (is_mov && lv->a[0] == '[') {
        char inner[8];
        u32 n = 0;
        const char *p = lv->a + 1;
        while (*p && *p != ']' && n + 1 < sizeof(inner)) {
            inner[n++] = lower(*p++);
        }
        inner[n] = '\0';
        int addr_reg = (*p == ']') ? reg_index(inner) : -1;
        int val_reg = reg_index(lv->b);
        if (addr_reg < 0 || val_reg < 0) {
            *bad_line = line_no;
            return -1;
        }
        in->dst = (u8)addr_reg;
        in->src = (u8)val_reg;
        in->mode = SASM_MODE_STORE;
        prog->count++;
        return 0;
    }

    int d = reg_index(lv->a);
    if (d < 0) {
        *bad_line = line_no;
        return -1;
    }
    in->dst = (u8)d;

    if (operand_operand(lv->b, &in->mode, &in->src, &in->imm,
                        &in->dst, is_mov) < 0) {
        *bad_line = line_no;
        return -1;
    }
    prog->count++;
    return 0;
}

/* --- Public entry points ---------------------------------------------------- */

int sasm_assemble(const char *source, struct sasm_program *prog,
                  char *err, u32 err_max)
{
    struct label_table labels;
    labels.count = 0;
    prog->count = 0;
    prog->entry = 0;

    if (!source) {
        set_error(err, err_max, 0, "no source");
        return 0;
    }

    u32 total = 0, bad_line = 0;
    int rc = count_instructions(source, &labels, &total, &bad_line);
    if (rc == -1) {
        set_error(err, err_max, bad_line, "too many labels");
        return 0;
    }
    if (rc == -2) {
        set_error(err, err_max, bad_line, "unknown instruction");
        return 0;
    }
    if (total > SASM_MAX_CODE) {
        set_error(err, err_max, 0, "program too long");
        return 0;
    }

    /* Pass 2. */
    u32 line_no = 0;
    const char *p = source;
    while (*p) {
        const char *eol = p;
        while (*eol && *eol != '\n') {
            eol++;
        }
        line_no++;

        char buf[128];
        u32 n = 0;
        for (const char *q = p; q < eol && n + 1 < sizeof(buf); q++) {
            buf[n++] = *q;
        }
        buf[n] = '\0';

        struct line_view lv;
        if (parse_line(buf, &lv) && lv.has_mnemonic) {
            int e = emit_line(prog, &lv, &labels, line_no, &bad_line);
            if (e == -1) {
                set_error(err, err_max, bad_line, "bad operand");
                return 0;
            }
            if (e == -2) {
                set_error(err, err_max, bad_line, "unknown instruction");
                return 0;
            }
            if (e == -3) {
                set_error(err, err_max, bad_line, "program too long");
                return 0;
            }
        }

        p = (*eol == '\n') ? eol + 1 : eol;
    }

    if (prog->count == 0) {
        set_error(err, err_max, 0, "empty program");
        return 0;
    }

    /* A program that does not end in HLT gets one appended.
     *
     * Running past the last instruction should mean "the program is over", the
     * way it does in every assembly language, rather than a fault. Without this
     * a program that simply stops -- which is what a model writing a listing
     * naturally produces -- is rejected for running off the end, even though
     * every instruction in it is correct. The appended HLT is what makes the
     * end of the source the end of the program. */
    if (prog->code[prog->count - 1].op != SASM_OP_HLT) {
        if (prog->count >= SASM_MAX_CODE) {
            set_error(err, err_max, 0, "program too long");
            return 0;
        }
        struct sasm_insn *hlt = &prog->code[prog->count++];
        hlt->op = SASM_OP_HLT;
        hlt->dst = 0;
        hlt->src = 0;
        hlt->mode = SASM_MODE_NONE;
        hlt->imm = 0;
    }

    if (err && err_max) {
        err[0] = '\0';
    }
    return 1;
}

const char *sasm_op_name(u8 op)
{
    switch (op) {
    case SASM_OP_HLT:  return "HLT";
    case SASM_OP_MOV:  return "MOV";
    case SASM_OP_ADD:  return "ADD";
    case SASM_OP_SUB:  return "SUB";
    case SASM_OP_MUL:  return "MUL";
    case SASM_OP_CMP:  return "CMP";
    case SASM_OP_JMP:  return "JMP";
    case SASM_OP_JZ:   return "JZ";
    case SASM_OP_JNZ:  return "JNZ";
    case SASM_OP_OUT:  return "OUT";
    case SASM_OP_OUTC: return "OUTC";
    default:           return "???";
    }
}

void sasm_disasm_one(const struct sasm_insn *insn, char *out, u32 max)
{
    /* Small formatter: mnemonic, then the operand in the form it was written.
     * Built by hand to avoid a printf dependency in this module. */
    u32 o = 0;
    const char *name = sasm_op_name(insn->op);
    for (const char *p = name; *p && o + 1 < max; p++) {
        out[o++] = *p;
    }
    out[o] = '\0';

    if (insn->op == SASM_OP_HLT) {
        return;
    }

    /* A space, then the operand text. */
    if (o + 1 < max) {
        out[o++] = ' ';
    }

    char tmp[32];
    u32 t = 0;

    /* Data-processing instructions name a destination register and then the
     * source operand: "MOV r0, 1". The destination was being dropped for every
     * form except the two below, which printed "MOV 1" -- a listing that cannot
     * be read back, and the reason a jump target is disassembled as a bare
     * number. The destination is emitted for the forms that have one. */
    int has_dst = (insn->op == SASM_OP_MOV || insn->op == SASM_OP_ADD
                   || insn->op == SASM_OP_SUB || insn->op == SASM_OP_MUL
                   || insn->op == SASM_OP_CMP)
                  && insn->mode != SASM_MODE_STORE;

    if (has_dst) {
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->dst);
        tmp[t++] = ',';
        tmp[t++] = ' ';
    }

    switch (insn->mode) {
    case SASM_MODE_REG:
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->src);
        break;
    case SASM_MODE_LOAD:
        tmp[t++] = '[';
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->src);
        tmp[t++] = ']';
        break;
    case SASM_MODE_STORE:
        tmp[t++] = '[';
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->dst);
        tmp[t++] = ']';
        tmp[t++] = ',';
        tmp[t++] = ' ';
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->src);
        break;
    case SASM_MODE_LABEL:
    case SASM_MODE_IMM: {
        /* Decimal. */
        char rev[12];
        u32 r = 0;
        u32 v = insn->imm;
        if (v == 0) {
            rev[r++] = '0';
        }
        while (v && r < sizeof(rev)) {
            rev[r++] = (char)('0' + (v % 10));
            v /= 10;
        }
        while (r && t + 1 < sizeof(tmp)) {
            tmp[t++] = rev[--r];
        }
        break;
    }
    default:
        break;
    }

    /* OUT/OUTC name only the register in dst. */
    if (insn->op == SASM_OP_OUT || insn->op == SASM_OP_OUTC) {
        t = 0;
        tmp[t++] = 'r';
        tmp[t++] = (char)('0' + insn->dst);
    }

    for (u32 i = 0; i < t && o + 1 < max; i++) {
        out[o++] = tmp[i];
    }
    out[o] = '\0';
}

/* --- Built-in example programs ---------------------------------------------- */

/* A small library so the IDE has something to open, and so the CLI can run a
 * program without a filesystem. Each entry is a complete program. */
static const struct {
    const char *name;
    const char *source;
} examples[] = {
    { "count",
      "; count from 1 to 5\n"
      "    mov r0, 1\n"
      "loop:\n"
      "    out r0\n"
      "    add r0, 1\n"
      "    cmp r0, 6\n"
      "    jnz loop\n"
      "    hlt\n" },
    { "sum",
      "; sum 1..10 = 55\n"
      "    mov r0, 1\n"
      "    mov r1, 0\n"
      "loop:\n"
      "    add r1, r0\n"
      "    add r0, 1\n"
      "    cmp r0, 11\n"
      "    jnz loop\n"
      "    out r1\n"
      "    hlt\n" },
    { "hello",
      "; print HELLO using character output\n"
      "    mov r0, 72\n"
      "    outc r0\n"
      "    mov r0, 69\n"
      "    outc r0\n"
      "    mov r0, 76\n"
      "    outc r0\n"
      "    outc r0\n"
      "    mov r0, 79\n"
      "    outc r0\n"
      "    mov r0, 10\n"
      "    outc r0\n"
      "    hlt\n" },
    { "fib",
      "; first 8 Fibonacci numbers\n"
      "    mov r0, 0\n"
      "    mov r1, 1\n"
      "    mov r2, 0\n"
      "loop:\n"
      "    out r0\n"
      "    mov r3, r0\n"
      "    add r3, r1\n"
      "    mov r0, r1\n"
      "    mov r1, r3\n"
      "    add r2, 1\n"
      "    cmp r2, 8\n"
      "    jnz loop\n"
      "    hlt\n" },
    { "mem",
      "; store a value, then read it back\n"
      "    mov r0, 5\n"
      "    mov r1, 42\n"
      "    mov [r0], r1\n"
      "    mov r2, 0\n"
      "    mov r2, [r0]\n"
      "    out r2\n"
      "    hlt\n" },
};

#define SASM_EXAMPLE_COUNT (sizeof(examples) / sizeof(examples[0]))

u32 sasm_example_count(void) { return (u32)SASM_EXAMPLE_COUNT; }

const char *sasm_example_name(u32 i)
{
    return (i < SASM_EXAMPLE_COUNT) ? examples[i].name : 0;
}

const char *sasm_example(u32 i)
{
    return (i < SASM_EXAMPLE_COUNT) ? examples[i].source : 0;
}

const char *sasm_example_source(void)
{
    return examples[0].source;
}

int sasm_selftest(void)
{
    struct sasm_program prog;
    char err[SASM_ERROR_MAX];

    /* Every built-in example must assemble, and the first must have the
     * expected shape. */
    for (u32 i = 0; i < SASM_EXAMPLE_COUNT; i++) {
        if (!sasm_assemble(examples[i].source, &prog, err, sizeof(err))) {
            return 0;
        }
    }
    if (!sasm_assemble(examples[0].source, &prog, err, sizeof(err))) {
        return 0;
    }
    if (prog.count != 6) {
        return 0;
    }

    /* Character literals: an assembler convenience that must compile to the
     * same immediate form a decimal number does. 'H' is 72, a space is 32, and
     * a newline is 10. If the tokenizer lowercased the literal, 'A' and 'a'
     * would collide; if the parser accepted a malformed literal, the model's
     * near-misses would assemble to the wrong value instead of failing. */
    static const char lit_src[] =
        "MOV r0, 'H'\n"
        "OUTC r0\n"
        "MOV r1, ' '\n"
        "OUTC r1\n"
        "MOV r2, '\\n'\n"
        "OUTC r2\n"
        "HLT\n";
    if (!sasm_assemble(lit_src, &prog, err, sizeof(err))) {
        return 0;
    }
    if (prog.count != 7) {
        return 0;
    }
    if (prog.code[0].imm != 72 || prog.code[2].imm != 32 ||
        prog.code[4].imm != 10) {
        return 0;
    }

    /* Case matters inside a literal: 'a' is 97, not 65. */
    if (!sasm_assemble("MOV r0, 'a'\nHLT\n", &prog, err, sizeof(err))) {
        return 0;
    }
    if (prog.code[0].imm != 97) {
        return 0;
    }

    /* A malformed literal must be rejected, not silently misread. */
    if (sasm_assemble("MOV r0, 'ab'\nHLT\n", &prog, err, sizeof(err))) {
        return 0;
    }
    if (sasm_assemble("MOV r0, ''\nHLT\n", &prog, err, sizeof(err))) {
        return 0;
    }
    if (sasm_assemble("MOV r0, 'a\nHLT\n", &prog, err, sizeof(err))) {
        return 0;
    }
    return 1;
}
