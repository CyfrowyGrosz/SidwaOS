/* Windowed text GUI, Model-View-Controller. See include/gui.h.
 *
 * Layout, 80x25:
 *
 *     row 0      menu bar
 *     rows 1-2   window title bar
 *     rows 3-21  window body (side panel on the left, content on the right)
 *     rows 22-24 status bar
 *
 * The model is small enough to hold in full: the current lesson, which window is
 * open, and a scrollback of recent log lines. Every repaint clears and redraws
 * from that state, so there is no incremental-update code to get wrong.
 *
 * The log window is fed by console_set_sink(): kernel logging still goes to the
 * serial port, and a copy is kept here. That is how the GUI shows the machine's
 * real output rather than a canned transcript.
 */

#include "gui.h"
#include "vga.h"
#include "keyboard.h"
#include "curriculum.h"
#include "serial.h"
#include "string.h"
#include "kb.h"
#include "serial.h"
#include "outcome.h"
#include "method.h"
#include "ide.h"

/* --- Model ------------------------------------------------------------------ */

struct gui_model {
    u32 lesson;                 /* index into the curriculum */
    u32 window;                 /* GUI_WIN_* */
    u32 log_head;               /* next slot to write in the scrollback */
    u32 log_count;
    char log[GUI_LOG_LINES][GUI_LOG_WIDTH];
    u32  log_partial_len;   /* bytes of the line being written */
};

static struct gui_model model;

/* --- Colours ---------------------------------------------------------------- */

#define COL_DESKTOP VGA_ATTR(VGA_LIGHTGRAY, VGA_BLUE)
#define COL_MENU    VGA_ATTR(VGA_BLACK, VGA_LIGHTGRAY)
#define COL_TITLE   VGA_ATTR(VGA_WHITE, VGA_BLUE)
#define COL_BODY    VGA_ATTR(VGA_BLACK, VGA_LIGHTGRAY)
#define COL_PANEL   VGA_ATTR(VGA_BLACK, VGA_CYAN)
#define COL_SEL     VGA_ATTR(VGA_WHITE, VGA_BLUE)
#define COL_STATUS  VGA_ATTR(VGA_BLACK, VGA_LIGHTGRAY)
#define COL_ACCENT  VGA_ATTR(VGA_YELLOW, VGA_BLUE)

/* Window geometry. */
#define WIN_X 1
#define WIN_Y 1
#define WIN_W 78
#define WIN_H 21
#define BODY_Y (WIN_Y + 3)
#define BODY_H (WIN_H - 4)
#define PANEL_X (WIN_X + 2)
#define PANEL_W 28
#define CONTENT_X (PANEL_X + PANEL_W + 2)
#define CONTENT_W (WIN_W - PANEL_W - 6)

/* --- Log capture ------------------------------------------------------------ */

/* Called for every byte of formatted console output. The byte still goes to the
 * serial port, and a copy is gathered into lines for the Log window. Installed
 * at boot, so the window shows the real boot trace rather than starting empty. */
static void gui_log_sink(char c)
{
    serial_putc(c);

    if (c == '\r') {
        /* Carriage return means "back to the start of this line", so a line
         * written in place -- the thinking indicator, which rewrites itself
         * once a second -- replaces the previous one instead of being appended
         * to it. The line is not committed here; only '\n' does that, so an
         * in-place line that is cleared before its newline never reaches the
         * window as text. */
        model.log_partial_len = 0;
        return;
    }
    if (c == '\n') {
        u32 slot = model.log_head;
        model.log[slot][model.log_partial_len] = '\0';
        model.log_head = (slot + 1) % GUI_LOG_LINES;
        if (model.log_count < GUI_LOG_LINES) {
            model.log_count++;
        }
        model.log_partial_len = 0;
        return;
    }
    if (model.log_partial_len + 1 < GUI_LOG_WIDTH) {
        model.log[model.log_head][model.log_partial_len++] = c;
    }
}

/* --- Model operations (the controller's only way to change state) ----------- */

u32 gui_lesson_index(void) { return model.lesson; }
u32 gui_window(void) { return model.window; }

void gui_set_lesson(u32 index)
{
    if (index < curriculum_count()) {
        model.lesson = index;
    }
}

static void gui_next_lesson(void)
{
    if (model.lesson + 1 < curriculum_count()) {
        model.lesson++;
    }
}

static void gui_prev_lesson(void)
{
    if (model.lesson > 0) {
        model.lesson--;
    }
}

void gui_set_window(u32 window)
{
    model.window = window;
}

/* --- View ------------------------------------------------------------------- */

static void draw_menu_bar(void)
{
    vga_fill(0, 0, VGA_COLS, 1, COL_MENU);
    vga_puts_at(1, 0, "SidwaOS", COL_MENU);
    vga_puts_at(10, 0, "C Course", COL_MENU);
    vga_puts_at(21, 0, "Log", COL_MENU);
    vga_puts_at(27, 0, "Hello", COL_MENU);
    vga_puts_at(35, 0, "Results", COL_MENU);
    vga_puts_at(45, 0, "Method", COL_MENU);
    vga_puts_at(53, 0, "IDE", COL_MENU);
    vga_puts_at(58, 0, "n/p i ide q", COL_MENU);
}

static void draw_window_frame(const char *title)
{
    vga_box(WIN_X, WIN_Y, WIN_W, WIN_H, COL_TITLE);
    vga_fill(WIN_X + 1, WIN_Y + 1, WIN_W - 2, 2, COL_TITLE);
    vga_puts_at(WIN_X + 2, WIN_Y + 1, title, COL_TITLE);
    vga_fill(WIN_X + 1, BODY_Y, WIN_W - 2, BODY_H, COL_BODY);
}

static void draw_lesson_panel(void)
{
    u32 count = curriculum_count();

    vga_fill(PANEL_X, BODY_Y, PANEL_W, BODY_H, COL_PANEL);
    vga_puts_at(PANEL_X + 1, BODY_Y, "LESSONS", COL_PANEL);

    for (u32 i = 0; i < count && i + 2 < BODY_H; i++) {
        const struct lesson *l = curriculum_get(i);
        char line[30];
        u32 n = 0;

        line[n++] = (i == model.lesson) ? '>' : ' ';
        line[n++] = ' ';
        if (l->number >= 10) {
            line[n++] = (char)('0' + l->number / 10);
        }
        line[n++] = (char)('0' + l->number % 10);
        line[n++] = ' ';
        for (const char *p = l->title; *p && n + 1 < sizeof(line); p++) {
            line[n++] = *p;
        }
        line[n] = '\0';

        u8 attr = (i == model.lesson) ? COL_SEL : COL_PANEL;
        vga_puts_clipped(PANEL_X + 1, BODY_Y + 2 + i, PANEL_W - 2, line, attr);
    }
}

static void draw_lesson_content(void)
{
    const struct lesson *l = curriculum_get(model.lesson);
    if (!l) {
        return;
    }

    char head[48];
    u32 n = 0;

    for (const char *p = "Lesson "; *p && n + 1 < sizeof(head); p++) {
        head[n++] = *p;
    }
    if (l->number >= 10) {
        head[n++] = (char)('0' + l->number / 10);
    }
    head[n++] = (char)('0' + l->number % 10);
    head[n++] = ':';
    head[n++] = ' ';
    for (const char *p = l->title; *p && n + 1 < sizeof(head); p++) {
        head[n++] = *p;
    }
    head[n] = '\0';

    vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W, head, COL_ACCENT);

    for (u32 i = 0; i < l->lines && i + 2 < BODY_H; i++) {
        vga_puts_clipped(CONTENT_X, BODY_Y + 2 + i, CONTENT_W, l->body[i],
                         COL_BODY);
    }
}

static void draw_log_window(void)
{
    vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W, "Kernel log (live)",
                     COL_ACCENT);

    /* Show the newest lines. The scrollback is a ring, so walk it from the
     * oldest surviving line to the newest. */
    u32 show = BODY_H - 3;
    if (show > model.log_count) {
        show = model.log_count;
    }
    u32 start = (model.log_head + GUI_LOG_LINES - model.log_count)
                % GUI_LOG_LINES;

    for (u32 i = 0; i < show; i++) {
        u32 idx = (start + model.log_count - show + i) % GUI_LOG_LINES;
        vga_puts_clipped(CONTENT_X, BODY_Y + 2 + i, CONTENT_W, model.log[idx],
                         COL_BODY);
    }
}

/* The Results window: which methods have actually achieved results. This is the
 * view of the tallies the AI uses to choose between competing rules. */
static void draw_results_window(void)
{
    vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W,
                     "Methods by achieved results", COL_ACCENT);

    u32 count = outcome_action_count();
    if (count == 0) {
        vga_puts_clipped(CONTENT_X, BODY_Y + 2, CONTENT_W,
                         "No action has been scored yet.", COL_BODY);
        vga_puts_clipped(CONTENT_X, BODY_Y + 3, CONTENT_W,
                         "Ask the AI something and the record starts.", COL_BODY);
        return;
    }

    vga_puts_clipped(CONTENT_X, BODY_Y + 1, CONTENT_W,
                     "action          ok  fail  score", COL_BODY);

    for (u32 rank = 0; rank < count && rank + 4 < BODY_H; rank++) {
        const char *name = outcome_ranked(rank);
        if (!name) {
            break;
        }

        char line[64];
        u32 n = 0;
        for (const char *p = name; *p && n < 16; p++) {
            line[n++] = *p;
        }
        while (n < 16) {
            line[n++] = ' ';
        }
        char num[12];
        u32 d = 0;
        u32 v = outcome_successes(name);
        if (v == 0) {
            num[d++] = '0';
        }
        while (v > 0) {
            num[d++] = (char)('0' + v % 10);
            v /= 10;
        }
        while (d > 0 && n < 20) {
            line[n++] = num[--d];
        }
        while (n < 20) {
            line[n++] = ' ';
        }
        v = outcome_attempts(name) - outcome_successes(name);
        d = 0;
        if (v == 0) {
            num[d++] = '0';
        }
        while (v > 0) {
            num[d++] = (char)('0' + v % 10);
            v /= 10;
        }
        while (d > 0 && n < 26) {
            line[n++] = num[--d];
        }
        while (n < 26) {
            line[n++] = ' ';
        }
        i32 sc = outcome_score(name);
        if (sc < 0) {
            line[n++] = '-';
            sc = -sc;
        }
        d = 0;
        if (sc == 0) {
            num[d++] = '0';
        }
        while (sc > 0) {
            num[d++] = (char)('0' + sc % 10);
            sc /= 10;
        }
        while (d > 0) {
            line[n++] = num[--d];
        }
        line[n] = '\0';

        vga_puts_clipped(CONTENT_X, BODY_Y + 3 + rank, CONTENT_W, line, COL_BODY);
    }
}

/* The Method window: the programming ladder, one loop at a time. The loop shown
 * follows the lesson cursor so n/p walks the method as well as the course. */
static void draw_method_window(void)
{
    u32 count = method_count();
    u32 sel = count ? model.lesson % count : 0;
    const struct method_loop *l = method_get(sel);

    if (!l) {
        vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W,
                         "No method loaded.", COL_BODY);
        return;
    }

    char head[64];
    u32 n = 0;
    const char *k = "Loop ";
    for (const char *p = k; *p && n + 1 < sizeof(head); p++) {
        head[n++] = *p;
    }
    head[n++] = (char)('0' + l->number);
    head[n++] = ':';
    head[n++] = ' ';
    for (const char *p = l->title; *p && n + 1 < sizeof(head); p++) {
        head[n++] = *p;
    }
    head[n] = '\0';
    vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W, head, COL_ACCENT);

    vga_puts_clipped(CONTENT_X, BODY_Y + 1, CONTENT_W, l->question, COL_BODY);

    for (u32 i = 0; i < l->steps && i + 4 < BODY_H; i++) {
        vga_puts_clipped(CONTENT_X, BODY_Y + 3 + i, CONTENT_W, l->step[i],
                         COL_BODY);
    }

    /* Where this loop sits in the ladder. */
    char foot[48];
    n = 0;
    for (const char *p = "loop "; *p && n + 1 < sizeof(foot); p++) {
        foot[n++] = *p;
    }
    foot[n++] = (char)('0' + (sel + 1));
    foot[n++] = '/';
    foot[n++] = (char)('0' + count);
    foot[n++] = ' ';
    for (const char *p = "(n/p)"; *p && n + 1 < sizeof(foot); p++) {
        foot[n++] = *p;
    }
    foot[n] = '\0';
    vga_puts_clipped(CONTENT_X, BODY_Y + BODY_H - 1, CONTENT_W, foot, COL_ACCENT);
}

static void draw_hello_window(void)
{
    vga_puts_clipped(CONTENT_X, BODY_Y, CONTENT_W, "Hello, World! as a GUI",
                     COL_ACCENT);

    /* The same program as lesson 2, then the MVC reading of it. */
    static const char *lines[] = {
        "The model holds the greeting string.",
        "",
        "    printf(\"Hello, World!\\n\");",
        "",
        "The view draws it in this window.",
        "The controller waits for a key.",
        "",
        "Same three parts as the console program,",
        "only now they paint a window.",
    };

    for (u32 i = 0; i < sizeof(lines) / sizeof(lines[0]) && i + 2 < BODY_H;
         i++) {
        vga_puts_clipped(CONTENT_X, BODY_Y + 2 + i, CONTENT_W, lines[i],
                         COL_BODY);
    }
}

static void draw_status_bar(void)
{
    char line[VGA_COLS + 1];
    u32 n = 0;
    char num[12];

    /* Built by hand rather than with a format string: the status bar is the one
     * place the model's numbers are shown, and it is short. */

    for (const char *p = "Lesson "; *p; p++) {
        line[n++] = *p;
    }
    u32 v = model.lesson + 1;
    u32 d = 0;
    if (v == 0) {
        num[d++] = '0';
    }
    while (v > 0) {
        num[d++] = (char)('0' + v % 10);
        v /= 10;
    }
    while (d > 0) {
        line[n++] = num[--d];
    }
    for (const char *p = "/"; *p; p++) {
        line[n++] = *p;
    }
    v = curriculum_count();
    d = 0;
    while (v > 0) {
        num[d++] = (char)('0' + v % 10);
        v /= 10;
    }
    while (d > 0) {
        line[n++] = num[--d];
    }
    for (const char *p = "   window: "; *p; p++) {
        line[n++] = *p;
    }
    const char *wname = model.window == GUI_WIN_LOG ? "log"
                      : model.window == GUI_WIN_HELLO ? "hello"
                      : model.window == GUI_WIN_RESULTS ? "results"
                      : model.window == GUI_WIN_METHOD ? "method"
                      : model.window == GUI_WIN_IDE ? "ide"
                      : "lessons";
    for (const char *p = wname; *p; p++) {
        line[n++] = *p;
    }
    for (const char *p = "   .sidwa records: "; *p; p++) {
        line[n++] = *p;
    }
    v = kb_count();
    d = 0;
    if (v == 0) {
        num[d++] = '0';
    }
    while (v > 0) {
        num[d++] = (char)('0' + v % 10);
        v /= 10;
    }
    while (d > 0) {
        line[n++] = num[--d];
    }
    line[n] = '\0';


    vga_fill(0, VGA_ROWS - 1, VGA_COLS, 1, COL_STATUS);
    vga_puts_clipped(1, VGA_ROWS - 1, VGA_COLS - 2, line, COL_STATUS);
}

/* Redraw the whole desktop from the model. */
static void gui_repaint(void)
{
    vga_fill(0, 0, VGA_COLS, VGA_ROWS, COL_DESKTOP);
    draw_menu_bar();

    const char *title = model.window == GUI_WIN_LOG ? "Kernel Log"
                      : model.window == GUI_WIN_HELLO ? "Hello, World!"
                      : model.window == GUI_WIN_RESULTS ? "Achieved Results"
                      : model.window == GUI_WIN_METHOD ? "Programming Method"
                      : model.window == GUI_WIN_IDE ? "Program IDE"
                      : "C Course";
    draw_window_frame(title);
    draw_lesson_panel();

    if (model.window == GUI_WIN_LOG) {
        draw_log_window();
    } else if (model.window == GUI_WIN_HELLO) {
        draw_hello_window();
    } else if (model.window == GUI_WIN_RESULTS) {
        draw_results_window();
    } else if (model.window == GUI_WIN_METHOD) {
        draw_method_window();
    } else if (model.window == GUI_WIN_IDE) {
        ide_draw();
    } else {
        draw_lesson_content();
    }

    draw_status_bar();
}

/* --- Controller ------------------------------------------------------------- */

int gui_handle_key(u16 key)
{
    /* The IDE owns the keyboard while it is open: its keys are text, so they
     * must not fall through to the desktop shortcuts. Esc leaves the IDE and
     * returns to the lesson list. */
    if (model.window == GUI_WIN_IDE) {
        if (!ide_handle_key(key)) {
            gui_set_window(GUI_WIN_LESSONS);
        }
        return 1;
    }

    switch (key) {
    case 'q':
    case 'Q':
    case KEY_ESC:
        return 0;
    case 'n':
    case 'N':
    case KEY_DOWN:
    case KEY_RIGHT:
        gui_next_lesson();
        /* Stepping stays in the Method window so the ladder can be walked; from
         * any other window it returns to the lesson list. */
        if (model.window != GUI_WIN_METHOD) {
            gui_set_window(GUI_WIN_LESSONS);
        }
        break;
    case 'p':
    case 'P':
    case KEY_UP:
    case KEY_LEFT:
        gui_prev_lesson();
        if (model.window != GUI_WIN_METHOD) {
            gui_set_window(GUI_WIN_LESSONS);
        }
        break;
    case 'l':
    case 'L':
        gui_set_window(GUI_WIN_LOG);
        break;
    case 'h':
    case 'H':
        gui_set_window(GUI_WIN_HELLO);
        break;
    case 'r':
    case 'R':
        gui_set_window(GUI_WIN_RESULTS);
        break;
    case 'm':
    case 'M':
        gui_set_window(GUI_WIN_METHOD);
        break;
    case 'i':
    case 'I':
        gui_set_window(GUI_WIN_IDE);
        break;
    case 'c':
    case 'C':
        gui_set_window(GUI_WIN_LESSONS);
        break;
    default:
        break;
    }
    return 1;
}

void gui_init(void)
{
    /* The log buffer is deliberately not cleared: it was filled from boot by
     * gui_log_attach(), and wiping it here would empty the Log window. Only the
     * view state is reset. */
    model.lesson = 0;
    model.window = GUI_WIN_LESSONS;
    vga_init();
    keyboard_init();
}

/* Start mirroring console output into the Log window. Called once at boot,
 * before the first log line, so the window holds the whole boot trace. */
void gui_log_attach(void)
{
    console_set_sink(gui_log_sink);
}

void gui_run(void)
{
    gui_repaint();

    for (;;) {
        u16 key = keyboard_wait();
        if (!gui_handle_key(key)) {
            break;
        }
        gui_repaint();
    }

    /* The desktop is gone, but logging continues into the Log window. */
}

void gui_run_ide(void)
{
    /* Open the desktop straight into the program IDE. The editor is a normal
     * window, so the same repaint and key loop drive it. */
    ide_init();
    model.window = GUI_WIN_IDE;
    vga_init();
    keyboard_init();
    gui_repaint();

    for (;;) {
        u16 key = keyboard_wait();
        if (!gui_handle_key(key)) {
            break;
        }
        gui_repaint();
    }
}

int gui_selftest(void)
{
    /* The controller changes the model... */
    gui_set_window(GUI_WIN_LESSONS);
    gui_set_lesson(0);
    if (gui_lesson_index() != 0) {
        return 0;
    }

    gui_handle_key('n');
    if (gui_lesson_index() != 1 || gui_window() != GUI_WIN_LESSONS) {
        return 0;
    }

    gui_handle_key('p');
    if (gui_lesson_index() != 0) {
        return 0;
    }

    /* ...the lesson can be driven to the end of the course and no further... */
    for (u32 i = 0; i < curriculum_count() + 3; i++) {
        gui_handle_key('n');
    }
    if (gui_lesson_index() != curriculum_count() - 1) {
        return 0;
    }

    /* ...window switching works... */
    gui_handle_key('l');
    if (gui_window() != GUI_WIN_LOG) {
        return 0;
    }
    gui_handle_key('h');
    if (gui_window() != GUI_WIN_HELLO) {
        return 0;
    }
    gui_handle_key('r');
    if (gui_window() != GUI_WIN_RESULTS) {
        return 0;
    }
    gui_handle_key('m');
    if (gui_window() != GUI_WIN_METHOD) {
        return 0;
    }

    /* ...and the view renders the model without faulting. */
    gui_repaint();

    /* 'q' asks to quit; any other key does not. */
    if (!gui_handle_key('n') || gui_handle_key('q')) {
        return 0;
    }

    /* Leave the model where the lesson list is, for whatever draws next. */
    gui_set_window(GUI_WIN_LESSONS);
    gui_set_lesson(0);
    gui_repaint();
    return 1;
}

