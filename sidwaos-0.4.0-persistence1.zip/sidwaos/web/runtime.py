"""Run SidwaOS in QEMU and talk to it over the serial line.

The kernel's console is COM1, and QEMU can expose that as a Unix socket. That
gives two things the web interface needs from one place:

  * a live log -- everything the kernel prints, including the boot trace, read
    off the socket as it happens
  * a command channel -- writing to the socket is exactly what typing at the
    `os>` prompt does, so the chat backend runs real commands on the real
    kernel rather than describing what it would do

The socket is the whole interface. There is no second path into the machine,
which is why a command issued from the web page and a command typed by hand
behave identically.
"""

from __future__ import annotations

import collections
import os
import shutil
import socket
import subprocess
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

QEMU = "qemu-system-i386"
SOCK = "/tmp/sidwaos-serial.sock"
KERNEL = os.path.join(ROOT, "kernel.elf")
DISK = os.path.join(ROOT, "disk.img")

PROMPT = "os> "
BOOT_READY = "entering command line"


class Runtime:
    """One QEMU instance, started on first use and kept running."""

    def __init__(self, log_size: int = 4000) -> None:
        self._lock = threading.RLock()
        self._log: collections.deque[str] = collections.deque(maxlen=log_size)
        self._subs: list[collections.deque] = []
        self._proc: subprocess.Popen | None = None
        self._sock: socket.socket | None = None
        self._reader: threading.Thread | None = None
        self._ready = threading.Event()
        self._tail = ""
        self._cmd_lock = threading.Lock()

    # --- lifecycle ---------------------------------------------------------

    def start(self) -> None:
        with self._lock:
            if self._proc is not None and self._proc.poll() is None:
                return

            # A socket file may be left behind by a previous run whose process is
            # gone. Try it once; if nothing answers, it is stale and gets removed
            # before QEMU is asked to create a fresh one.
            if os.path.exists(SOCK):
                try:
                    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    probe.settimeout(0.5)
                    probe.connect(SOCK)
                    probe.close()
                    os.unlink(SOCK)
                except OSError:
                    try:
                        os.unlink(SOCK)
                    except OSError:
                        pass

            # Run from a copy so the canonical disk image is never left dirty by
            # a browser session.
            run_disk = os.path.join(ROOT, "run.img")
            if os.path.exists(DISK) and not os.path.exists(run_disk):
                shutil.copyfile(DISK, run_disk)
            disk = run_disk if os.path.exists(run_disk) else DISK

            cmd = [
                QEMU,
                "-drive", f"file={disk},format=raw,if=ide,index=0",
                "-netdev", "user,id=n0",
                "-device", "rtl8139,netdev=n0",
                "-serial", f"unix:{SOCK},server=on,wait=off",
                "-display", "none",
                "-monitor", "none",
                "-no-reboot",
            ]
            self._proc = subprocess.Popen(
                cmd, cwd=ROOT,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )

            # Wait for QEMU to create the socket, then attach. The first connect
            # may race the listener, so retry until the deadline rather than
            # giving up on one failure.
            deadline = time.time() + 15.0
            while time.time() < deadline:
                if self._proc.poll() is not None:
                    raise RuntimeError("QEMU exited during startup")
                if os.path.exists(SOCK):
                    try:
                        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                        s.connect(SOCK)
                        s.settimeout(None)
                        self._sock = s
                        break
                    except OSError:
                        pass
                time.sleep(0.05)

            if self._sock is None:
                raise RuntimeError("could not attach to the QEMU serial socket")

            self._reader = threading.Thread(target=self._read_loop, daemon=True)
            self._reader.start()

    def stop(self) -> None:
        """Shut the machine down and drop the socket. Used on server exit."""
        with self._lock:
            if self._sock is not None:
                try:
                    self._sock.close()
                except OSError:
                    pass
                self._sock = None
            if self._proc is not None and self._proc.poll() is None:
                self._proc.terminate()
                try:
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._proc.kill()
            self._proc = None
            try:
                os.unlink(SOCK)
            except OSError:
                pass

    def _read_loop(self) -> None:
        assert self._sock is not None
        while True:
            try:
                chunk = self._sock.recv(4096)
            except OSError:
                break
            if not chunk:
                break
            text = self._tail + chunk.decode("utf-8", "replace")
            # Keep any partial line for the next chunk.
            lines = text.split("\n")
            self._tail = lines.pop()
            for line in lines:
                self._emit(line.rstrip("\r"))
        self._emit("[web] kernel serial closed")

    def _emit(self, line: str) -> None:
        if BOOT_READY in line:
            self._ready.set()
        with self._lock:
            self._log.append(line)
            for q in list(self._subs):
                try:
                    q.append(line)
                except Exception:
                    pass

    def wait_ready(self, timeout: float = 60.0) -> bool:
        return self._ready.wait(timeout)

    def ready(self) -> bool:
        """Whether the kernel has reached its command line."""
        return self._ready.is_set()

    def alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    # --- reading -----------------------------------------------------------

    def recent(self, n: int = 200) -> list[str]:
        with self._lock:
            return list(self._log)[-n:]

    def subscribe(self) -> collections.deque:
        q: collections.deque = collections.deque(maxlen=1000)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q: collections.deque) -> None:
        with self._lock:
            if q in self._subs:
                self._subs.remove(q)

    # --- writing -----------------------------------------------------------

    def send_raw(self, text: str) -> None:
        with self._lock:
            if self._sock is None:
                raise RuntimeError("serial not attached")
            self._sock.sendall(text.encode())

    def run_command(self, cmd: str, wait: float = 1.6) -> str:
        """Type `cmd` at the kernel prompt and collect what it prints.

        One command at a time: the kernel has a single console, so two callers
        typing at once would interleave and neither would get a clean answer.
        """
        with self._cmd_lock:
            q = self.subscribe()
            try:
                self.send_raw(cmd + "\r\n")
                deadline = time.time() + wait
                while time.time() < deadline:
                    time.sleep(0.05)
                lines = list(q)
            finally:
                self.unsubscribe(q)

        out: list[str] = []
        want = cmd.strip()
        # The kernel prints "os> " with no trailing newline, so the prompt can
        # arrive trimmed to "os>" or glued to the echoed line ("os> version").
        # Match the core of it rather than the padded form.
        core = PROMPT.strip()
        for line in lines:
            s = line.strip()
            if not s:
                continue
            if s.startswith(core):
                s = s[len(core):].strip()
            if not s or s == want:
                continue
            out.append(s)
        return "\n".join(out)


_runtime: Runtime | None = None
_runtime_lock = threading.Lock()


def get_runtime() -> Runtime:
    global _runtime
    with _runtime_lock:
        if _runtime is None:
            _runtime = Runtime()
            _runtime.start()
        return _runtime
