"""The SidwaOS web interface: a small HTTP server on top of the serial runtime.

Serves three things:

  /                the page (HTML, CSS and JS inlined so there is one file)
  /api/chat        POST a message, get the assistant's answer as SSE
  /api/log         server-sent events carrying the kernel's serial output live
  /api/status      whether the machine is up, and its version
  /download/disk.img  the disk image, so the system can be taken away

The server is the standard library only. There is no framework and no build
step: the page is a string and the endpoints are functions, which is all this
needs and keeps the whole thing readable next to the kernel it serves.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from runtime import get_runtime, ROOT
from ai import answer, COMMANDS

HOST = os.environ.get("SIDWAOS_WEB_HOST", "0.0.0.0")
PORT = int(os.environ.get("SIDWAOS_WEB_PORT", "80"))
PAGE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html")
ZIP_PATH = os.path.join(ROOT, "sidwaos-0.4.0.zip")
_zip_lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # --- helpers -----------------------------------------------------------

    def log_message(self, fmt, *args):        # keep the console quiet
        pass

    def _send(self, code: int, body: bytes, ctype: str,
              extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj).encode(), "application/json")

    # --- routes ------------------------------------------------------------

    def do_GET(self) -> None:                  # noqa: N802
        path = self.path.split("?", 1)[0]

        if path in ("/", "/index.html"):
            try:
                with open(PAGE, "rb") as fh:
                    body = fh.read()
            except OSError:
                body = b"<h1>SidwaOS</h1><p>index.html is missing.</p>"
            self._send(200, body, "text/html; charset=utf-8")
            return

        if path == "/api/status":
            self._json(self._status())
            return

        if path == "/api/commands":
            self._json({"commands": COMMANDS})
            return

        if path == "/api/log":
            self._stream_log()
            return

        if path == "/api/stats":
            self._json(self._stats())
            return

        if path == "/download/disk.img":
            self._download(os.path.join(ROOT, "disk.img"),
                           "sidwaos-disk.img")
            return

        if path == "/download/sidwaos.zip":
            self._download_zip()
            return

        self._send(404, b"not found", "text/plain")

    def do_HEAD(self) -> None:                 # noqa: N802
        """Headers only, so a client can check the download before taking it."""
        path = self.path.split("?", 1)[0]
        if path == "/download/disk.img":
            disk = os.path.join(ROOT, "disk.img")
            if not os.path.exists(disk):
                self._send(404, b"", "text/plain")
                return
            size = os.path.getsize(disk)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition",
                             'attachment; filename="sidwaos-disk.img"')
            self.end_headers()
            return
        if path in ("/", "/index.html"):
            size = os.path.getsize(PAGE) if os.path.exists(PAGE) else 0
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(size))
            self.end_headers()
            return
        self._send(404, b"", "text/plain")

    def do_POST(self) -> None:                 # noqa: N802
        path = self.path.split("?", 1)[0]
        if path != "/api/chat":
            self._send(404, b"not found", "text/plain")
            return

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            data = {}
        message = str(data.get("message", ""))

        self._stream_chat(message)

    # --- status ------------------------------------------------------------

    def _status(self) -> dict:
        rt = get_runtime()
        return {
            "alive": rt.alive(),
            "ready": rt.ready(),
            "version": VERSION,
        }

    def _stats(self) -> dict:
        """Run `stats` on the kernel and parse the sample out of its output.

        The kernel owns the numbers; this only reads them back. Parsing the
        printed lines rather than exposing a binary structure keeps one source of
        truth -- the same line a person sees on the console is the one the chart
        plots, so the two can never disagree.
        """
        rt = get_runtime()
        if not rt.ready():
            return {"ready": False}
        text = rt.run_command("stats", wait=6.0)
        return _parse_stats(text)

    # --- server-sent events ------------------------------------------------

    def _sse_start(self, close_after: bool = False) -> None:
        """Begin an event stream.

        There is no Content-Length on a stream, so a client can only tell the
        response has ended when the connection closes. A finite stream -- the
        chat reply -- therefore says so up front and closes; the live log is
        open-ended and stays connected.
        """
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("X-Accel-Buffering", "no")
        if close_after:
            self.send_header("Connection", "close")
            self.close_connection = True
        else:
            self.send_header("Connection", "keep-alive")
        self.end_headers()

    def _sse(self, event: str, data) -> None:
        payload = data if isinstance(data, str) else json.dumps(data)
        frame = f"event: {event}\ndata: {payload}\n\n"
        self.wfile.write(frame.encode())
        self.wfile.flush()

    def _stream_log(self) -> None:
        """Replay recent history, then follow the kernel live."""
        rt = get_runtime()
        try:
            self._sse_start()
        except (BrokenPipeError, ConnectionResetError):
            return

        q = rt.subscribe()
        try:
            for line in rt.recent(120):
                self._sse("log", line)
            while True:
                try:
                    line = q.popleft()
                except IndexError:
                    time.sleep(0.25)
                    # A comment frame keeps the connection alive through proxies.
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    continue
                self._sse("log", line)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            rt.unsubscribe(q)

    def _stream_chat(self, message: str) -> None:
        """Answer in stages, so the interface can show the machine's evidence
        before the prose arrives."""
        rt = get_runtime()
        try:
            self._sse_start(close_after=True)
        except (BrokenPipeError, ConnectionResetError):
            return

        try:
            self._sse("start", {"message": message})

            # Show that work is happening while the kernel is driven.
            self._sse("status", {"text": "thinking"})

            result = answer(message, rt)

            if result.get("command"):
                self._sse("command", {"command": result["command"]})
            if result.get("output"):
                self._sse("output", {"output": result["output"]})

            # Stream the reply word by word: it reads like a chat, and it keeps
            # a slow answer from looking like a hung connection.
            words = result["reply"].split(" ")
            for i, w in enumerate(words):
                self._sse("token", w if i == 0 else " " + w)
                time.sleep(0.012)

            self._sse("done", {"source": result.get("source", "knowledge")})
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    # --- download ----------------------------------------------------------

    def _download(self, path: str, filename: str) -> None:
        if not os.path.exists(path):
            self._send(404, f"{os.path.basename(path)} not found".encode(),
                       "text/plain")
            return
        size = os.path.getsize(path)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition",
                         f'attachment; filename="{filename}"')
        self.end_headers()
        try:
            with open(path, "rb") as fh:
                while True:
                    chunk = fh.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _download_zip(self) -> None:
        """The whole system as a zip: sources plus the bootable disk.

        Packaged on first request and reused after, so the download is a plain
        file send rather than a fresh archive each time. A lock keeps two
        simultaneous requests from writing it at once.
        """
        with _zip_lock:
            if not os.path.exists(ZIP_PATH):
                try:
                    subprocess.run(
                        [sys.executable,
                         os.path.join(ROOT, "tools", "mkzip.py"),
                         "--out", ZIP_PATH, "--quiet"],
                        cwd=ROOT, check=True,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                        timeout=120,
                    )
                except (subprocess.SubprocessError, OSError) as exc:
                    self._send(500, f"could not package: {exc}".encode(),
                               "text/plain")
                    return
        self._download(ZIP_PATH, os.path.basename(ZIP_PATH))


VERSION = "0.4.0"


# --- statistics parsing ------------------------------------------------------

# The kernel prints the sample as `[STATS] <metric>: <value>` lines. Each regex
# pulls the numbers out of one line, so a change to the wording in kernel/stats.c
# shows up here as a missing field rather than as a silently wrong chart.
_STATS_PATTERNS = {
    "kernel_kib": re.compile(r"memory: kernel (\d+) KiB"),
    "ram_mib":    re.compile(r"of (\d+) MiB RAM"),
    "cpu_tenths": re.compile(r"cpu load: (\d+)\.(\d)%"),
    "disk_read":  re.compile(r"disk \.sidwa: read (\d+) KiB/s"),
    "disk_write": re.compile(r"write (\d+) KiB/s"),
    "link_kbps":  re.compile(r"link: (\d+) KiB/s"),
    "link_rtt":   re.compile(r"round trip (\d+) us"),
}


def _parse_stats(text: str) -> dict:
    """Turn the kernel's `[STATS]` lines into a dict for the page.

    Missing fields are left out rather than defaulted to zero, so the chart can
    tell "not measured" from "measured as nothing" -- a link that is down and a
    link that transferred zero bytes are different facts.
    """
    out: dict = {"ready": True}
    for line in text.splitlines():
        if "STATS]" not in line:
            continue
        m = _STATS_PATTERNS["kernel_kib"].search(line)
        if m:
            out["kernel_kib"] = int(m.group(1))
        m = _STATS_PATTERNS["ram_mib"].search(line)
        if m:
            out["ram_mib"] = int(m.group(1))
        m = _STATS_PATTERNS["cpu_tenths"].search(line)
        if m:
            # Tenths of a percent, kept as one number so the chart does not have
            # to reassemble a fraction.
            out["cpu_tenths"] = int(m.group(1)) * 10 + int(m.group(2))
        m = _STATS_PATTERNS["disk_read"].search(line)
        if m:
            out["disk_read_kbps"] = int(m.group(1))
        m = _STATS_PATTERNS["disk_write"].search(line)
        if m:
            out["disk_write_kbps"] = int(m.group(1))
        m = _STATS_PATTERNS["link_kbps"].search(line)
        if m:
            out["link_kbps"] = int(m.group(1))
        m = _STATS_PATTERNS["link_rtt"].search(line)
        if m:
            out["link_rtt_us"] = int(m.group(1))
    return out


def _serve(port: int) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer((HOST, port), Handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def main() -> None:
    # Bring the machine up before accepting requests, so the first visitor sees
    # a running system rather than a cold start.
    rt = get_runtime()
    rt.start()
    if rt.wait_ready(90):
        print("[web] kernel is up")
    else:
        print("[web] kernel did not reach the command line; serving anyway")

    # One runtime, one or more listeners. The work-host ports are included so
    # the public URL reaches the same machine rather than a second copy of it.
    ports = [int(p) for p in
             os.environ.get("SIDWAOS_WEB_PORTS", str(PORT)).split(",") if p]
    servers = []
    for p in ports:
        try:
            servers.append(_serve(p))
            print(f"[web] SidwaOS {VERSION} interface on http://{HOST}:{p}/")
        except OSError as exc:
            print(f"[web] port {p} unavailable: {exc}")

    if not servers:
        print("[web] no port could be bound")
        rt.stop()
        return

    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
    finally:
        for s in servers:
            s.shutdown()
        rt.stop()


if __name__ == "__main__":
    main()
