"""The AI behind the SidwaOS web chat.

Three layers, tried in order, and the order is the point:

  1. an intent planner grounded in the kernel's real command set, which also
     runs the chosen command on the running machine and answers with what the
     kernel actually printed
  2. a curated knowledge base for questions about the system itself -- what it
     is, how the three states work, what the thinking algorithm does
  3. an optional language model, when one is configured, for everything else

The first two need no network and no credentials, so the chat always answers
something true about this machine. The model is the only part that can say
something false, so it is last and it is optional, and when it is absent the
answer says so rather than inventing one.

The command layer is what makes this more than a canned FAQ. When a user asks
"what is the cache", the planner picks `cache`, types it at the real kernel
prompt over the serial line, and returns the real output. The answer is
observed, not described.
"""

from __future__ import annotations

import json
import os
import re
import urllib.request

# --- The kernel's own command set -------------------------------------------

COMMANDS: dict[str, str] = {
    "help": "list every command",
    "status": "dump state-machine statistics",
    "run": "loop 1: run fragments on the CPU",
    "hold": "loop 2: logic-test queued programs",
    "store": "loop 3: persist keyed programs to disk",
    "cycle": "run all three loops in order",
    "cache": "CPU cache geometry and free L1",
    "bitflow": "run the bit-flow self tests",
    "version": "OS name and version",
    "sysinfo": "CPU, RAM, disk and AI size",
    "kb": "the .sidwa partition: grade and records",
    "know": "the RAM knowledge cache",
    "think": "the reasoning counters and last trace",
    "codec": "encode the example program, raw vs packed",
    "method": "the 5-loop programming method",
    "optim": "the optimisation course",
    "lesson": "the C course",
    "rev": "the reverse-engineering course",
    "results": "which methods have achieved results",
    "layout": "the disk layout in use",
    "net": "network configuration and counters",
    "debug": "faults seen and recovery statistics",
    "learn": "train the local AI and save the weights",
    "fetch": "what has been fetched and learned",
    "install": "what the installer needs from this disk",
}

# Requests that map to a command. Checked in order, most specific first.
INTENTS: list[tuple[str, str]] = [
    (r"\bversion\b|\bwhat version\b|\bwhich version\b", "version"),
    (r"\bsysinfo\b|\bcpu\b.*\bram\b|\bhow much (ram|memory|disk)\b|\bspecs?\b", "sysinfo"),
    (r"\bcache\b|\bl1\b|\bl2\b|\bl3\b", "cache"),
    (r"\bcodec\b|\bencod|\bpacked\b|\braw bytes\b", "codec"),
    (r"\bthink\b|\breason|\bhow does it decide\b|\bthinking\b", "think"),
    (r"\bknow\b|\bknowledge\b|\bfacts?\b", "know"),
    (r"\b\.sidwa\b|\bpartition\b|\bkb\b|\brecords?\b", "kb"),
    (r"\bresults?\b|\bwhich methods?\b|\btally\b|\btallies\b", "results"),
    (r"\blayout\b|\bdisk layout\b|\blba\b", "layout"),
    (r"\bnetwork\b|\bnet\b|\bip address\b|\bping\b", "net"),
    (r"\bfault\b|\bdebug\b|\bcrash\b|\brecover", "debug"),
    (r"\bbitflow\b|\bbit ?flow\b", "bitflow"),
    (r"\bmethod\b|\bpseudo ?code\b|\bwhere (do i|to) start\b", "method"),
    (r"\boptimi|\bfaster\b|\bslow\b|\bbenchmark\b", "optim"),
    (r"\breverse\b|\bdisassembl|\bassembly\b", "rev"),
    (r"\blesson\b|\bteach\b|\bcourse\b|\blearn c\b", "lesson"),
    (r"\bfetch\b|\bdownload\b|\bweb page\b", "fetch"),
    (r"\bcycle\b|\ball three loops\b|\brun everything\b", "cycle"),
    (r"\bstatus\b|\bstate\b|\bstatistics\b|\bstats\b", "status"),
    (r"\brun\b|\bexecute\b|\bcpu loop\b", "run"),
    (r"\bhold\b|\blogic test\b", "hold"),
    (r"\bstore\b|\bpersist\b|\bdisk\b", "store"),
    (r"\binstall\b|\busb\b", "install"),
    (r"\bhelp\b|\bwhat can (you|it) do\b|\bcommands\b", "help"),
]

# --- Knowledge about the system ---------------------------------------------

KB: list[tuple[str, str]] = [
    (r"what is sidwaos|what is this|about this (os|system)|overview",
     "SidwaOS is a minimal bootable x86 kernel written in NASM and C. It is a "
     "'3-state I/O machine': State 1 RUN executes program fragments on the CPU, "
     "State 2 HOLD logic-tests queued programs, and State 3 STORE persists keyed "
     "programs to disk. It has its own two-stage bootloader (no GRUB), a .sidwa "
     "partition that holds durable facts and learned weights, and cooperative "
     "loops rather than preemptive scheduling."),
    (r"three states|3 states|state machine|what are the states|run hold store",
     "The machine cycles through three states. RUN (State 1) runs program "
     "fragments on the CPU and checks a canary. HOLD (State 2) hangs data and "
     "logic-tests queued programs, rejecting malformed ones. STORE (State 3) "
     "writes programs whose serial key is authorised to the .sidwa partition. "
     "Each state hands its output to the next, and a cycle runs all three."),
    (r"thinking algorithm|how does (it|the machine) think|reasoning",
     "The thinking algorithm (kernel/think.c) is the deliberate path, where "
     "localai is the fast one. It scores every candidate action against three "
     "independent kinds of evidence -- the keyword rules, the learned model, and "
     "the record of which actions have actually produced results -- then grades "
     "how well supported the winner is: clear, lean, guess, or unsure. The "
     "outcome record is weighted to dominate the other two, because a measured "
     "result is evidence about the world and text similarity is not. When nothing "
     "is supported it returns 'unsure' and refuses to act rather than guessing."),
    (r"optimis|optimiz|the optimisation course|first point",
     "Optimisation here is taught as one idea repeated: start from a program that "
     "works, keep it as the reference, write a faster version that must produce "
     "identical output, and measure the difference. The machine applies it to "
     "itself -- batched model scoring is ~12x faster with identical scores, the "
     "codec's word encoder is ~11x faster with identical bytes, and the frame "
     "writer is ~3x faster with an identical picture."),
    (r"fetch and learn|fetch-and-learn|learn from (the )?web|download a page",
     "Fetch-and-learn joins the network stack to the knowledge cache. It fetches "
     "a page, cleans the HTML to plain text, and extracts the sentence that best "
     "answers a question. One page is held in RAM as unverified, because a page "
     "cannot corroborate itself. Two sources that agree are corroboration, and "
     "only then is the fact written to .sidwa."),
    (r"\.sidwa|sidwa partition",
     "The .sidwa partition is the durable store. It holds fixed-size KEY/VALUE "
     "records at a compression grade that sets the slot size, plus the learned "
     "model weights and the result tallies. It is mounted at boot, so facts and "
     "training survive a reboot."),
    (r"bootloader|no grub|how does it boot",
     "SidwaOS uses its own two-stage bootloader rather than GRUB. Stage 1 is a "
     "512-byte sector that loads stage 2, and stage 2 reads the kernel from the "
     "disk and hands off with a Multiboot-style header. The disk layout is "
     "recorded so the kernel can find the .sidwa partition and the blob region "
     "without a filesystem."),
    (r"network|tcp|http|rtl8139",
     "The network stack is a real client-side IPv4 implementation over an RTL8139 "
     "driver: Ethernet, ARP, IP, ICMP, UDP, TCP, DNS and an HTTP client. It can "
     "resolve a name, open a TCP connection and fetch a page. There is no DHCP "
     "client and no routing table; the address is set with `net set`."),
    (r"wifi|wireless",
     "There is no wireless support. QEMU has no 802.11 emulation at all -- every "
     "emulated NIC is wired Ethernet -- so a wireless driver could not be "
     "exercised here even if one were written."),
    (r"localai|local ai|the model|neural|classifier",
     "The local AI is a tiny linear classifier over hashed request tokens, with "
     "one weight vector per action. Its capacity is set by the .sidwa compression "
     "grade: at grade 1 it is 8-bit weights over 8 feature slots, which is coarse "
     "on purpose. It learns from the machine's own rules and from reasoned "
     "decisions, and is saved to the partition so training persists."),
    (r"who (made|wrote|built) (you|this)|author|license",
     "SidwaOS is built as a teaching system: a small, complete machine whose "
     "whole behaviour can be read in its source. The repository is "
     "CyfrowyGrosz/SidwaOS."),
]

GREETING = (
    "Hello. I am the SidwaOS assistant. I can run this machine's real commands "
    "and report what the kernel prints, and I know how the system works. Try "
    "\"what is the cache\", \"run a cycle\", \"how does the thinking algorithm "
    "work\", or \"what version is it\"."
)


def _match(text: str, patterns: list[tuple[str, str]]) -> str | None:
    for pattern, answer in patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return answer
    return None


EXPLANATORY = re.compile(
    r"^\s*(how|what|why|when|where|which|explain|describe|tell me|"
    r"can you (explain|describe)|does it|do you)\b",
    re.IGNORECASE,
)


def is_explanatory(text: str) -> bool:
    """Whether a request asks for an explanation rather than an action."""
    return bool(EXPLANATORY.match(text))


def plan_command(text: str) -> str | None:
    """The kernel command a request is asking for, or None."""
    t = text.strip().lower()
    if not t:
        return None

    # A leading slash is an explicit command, e.g. "/codec opt".
    if t.startswith("/"):
        return text.strip()[1:]

    for pattern, cmd in INTENTS:
        if re.search(pattern, t):
            return cmd
    return None


# --- Optional language model ------------------------------------------------

def _llm_configured() -> bool:
    return bool(os.environ.get("SIDWAOS_LLM_KEY"))


def _llm_answer(question: str, context: str) -> str | None:
    """Ask a chat model, grounded with real kernel output when we have it."""
    key = os.environ.get("SIDWAOS_LLM_KEY", "")
    if not key:
        return None
    base = os.environ.get(
        "SIDWAOS_LLM_URL",
        "https://api.openai.com/v1/chat/completions",
    )
    model = os.environ.get("SIDWAOS_LLM_MODEL", "gpt-4o-mini")

    system = (
        "You are the assistant for SidwaOS, a small teaching operating system "
        "written in NASM and C. Answer briefly and accurately. If kernel output "
        "is given, base your answer on it and do not contradict it. If you do not "
        "know, say so plainly."
    )
    user = question
    if context:
        user = f"{question}\n\nReal output from the running kernel:\n{context}"

    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.2,
    }).encode()

    req = urllib.request.Request(base, data=body, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
    })
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.load(resp)
        return data["choices"][0]["message"]["content"].strip()
    except Exception:                      # noqa: BLE001 - any failure is fine
        return None


def answer(question: str, runtime) -> dict:
    """Answer `question`, running a command on the machine when one applies.

    Returns a dict with the reply text, the command that was run (if any) and
    the raw kernel output (if any), so the interface can show the evidence.
    """
    q = (question or "").strip()
    result: dict = {"reply": "", "command": None, "output": None,
                    "source": "knowledge"}

    if not q:
        result["reply"] = GREETING
        return result

    if re.fullmatch(r"(hi|hello|hey|yo|good (morning|afternoon|evening))[.!]?",
                    q, re.IGNORECASE):
        result["reply"] = GREETING
        return result

    # A request is either an action ("run a cycle", "/codec") or an explanation
    # ("how does the thinking algorithm work"). Both can match a command, but
    # they want different things from it: an action wants the machine driven and
    # its output shown, an explanation wants the answer, with the command only as
    # supporting evidence. So the order of the next two steps depends on which
    # one this is.
    cmd = plan_command(q)
    known = _match(q, KB)
    explanatory = is_explanatory(q)

    def run_and_answer() -> dict:
        """Drive the machine and answer with what it printed."""
        try:
            out = runtime.run_command(cmd)
        except Exception as exc:            # noqa: BLE001
            result["reply"] = f"The machine did not answer: {exc}"
            return result

        result["command"] = cmd
        result["output"] = out
        result["source"] = "kernel"

        if _llm_configured():
            narrated = _llm_answer(q, out)
            if narrated:
                result["reply"] = narrated
                result["source"] = "llm+kernel"
                return result

        # The kernel's output is shown verbatim in the evidence block, so the
        # prose does not repeat it. It says what was run and what it does.
        first = cmd.split()[0]
        desc = COMMANDS.get(first, "")
        if out:
            result["reply"] = (
                f"I ran `{cmd}` on the machine"
                + (f" \u2014 {desc}." if desc else ".")
            )
        else:
            result["reply"] = f"I ran `{cmd}`; the machine printed nothing."
        return result

    def answer_from_knowledge() -> dict:
        result["reply"] = known
        result["source"] = "knowledge"
        if _llm_configured():
            better = _llm_answer(q, known)
            if better:
                result["reply"] = better
                result["source"] = "llm+knowledge"
        return result

    if explanatory:
        # Prefer the explanation; fall back to the machine for a live fact.
        if known:
            return answer_from_knowledge()
        if cmd:
            return run_and_answer()
    else:
        # An action: drive the machine; fall back to knowledge for a topic.
        if cmd:
            return run_and_answer()
        if known:
            return answer_from_knowledge()
    if _llm_configured():
        llm = _llm_answer(q, "")
        if llm:
            result["reply"] = llm
            result["source"] = "llm"
            return result
        result["reply"] = (
            "I could not reach a language model, and this request does not map "
            "onto a command or a topic I know. Try \"/help\" to see the machine's "
            "commands."
        )
        result["source"] = "none"
        return result

    # No model configured: be honest and useful rather than inventing an answer.
    result["reply"] = (
        "I do not have an answer for that. I answer from this machine's real "
        "commands and from what I know about SidwaOS; for anything else a "
        "language model would need to be configured (SIDWAOS_LLM_KEY). "
        "Try asking about the states, the thinking algorithm, the codec, the "
        "network, or the .sidwa partition, or run a command like \"/status\"."
    )
    result["source"] = "none"
    return result
