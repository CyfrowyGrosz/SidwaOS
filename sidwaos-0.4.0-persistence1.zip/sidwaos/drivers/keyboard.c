/* PS/2 keyboard driver. See include/keyboard.h.
 *
 * Scancode set 1: a key press sends one byte, a release sends the same byte with
 * bit 7 set (0x80 | code). Shift and caps-lock decide the case and which symbol
 * a key produces.
 *
 * The decode table maps a scancode to its unshifted character, with 0 for keys
 * that have no printable form. Keys the GUI uses as commands -- the arrows, Esc,
 * Tab -- are handled before the table is consulted.
 */

#include "keyboard.h"
#include "interrupts.h"
#include "io.h"
#include "serial.h"
#include "types.h"

#define KBD_DATA   0x60
#define KBD_STATUS 0x64

#define KBD_BUF_SIZE 64     /* power of two: the ring wraps with a mask */

static volatile u16 buffer[KBD_BUF_SIZE];
static volatile u32 head;    /* next write */
static volatile u32 tail;    /* next read */
static u8 shift;
static u8 ctrl;
static u8 caps;

/* Scancode to unshifted character. Zero means "no printable character". */
static const char normal_map[128] = {
    0,   27,  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t','q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0,   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0,   '\\','z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,
    '*', 0,   ' ',
};

static const char shift_map[128] = {
    0,   27,  '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
    '\t','Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
    0,   'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~',
    0,   '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,
    '*', 0,   ' ',
};

static void push(u16 key)
{
    u32 next = (head + 1) & (KBD_BUF_SIZE - 1);
    if (next == tail) {
        return;         /* full: drop the newest rather than overwrite */
    }
    buffer[head] = key;
    head = next;
}

/* Keys with no printable form that the GUI still needs. */
static u16 named_key(u8 scancode)
{
    switch (scancode) {
    case 0x48: return KEY_UP;
    case 0x50: return KEY_DOWN;
    case 0x4B: return KEY_LEFT;
    case 0x4D: return KEY_RIGHT;
    case 0x01: return KEY_ESC;
    case 0x0F: return KEY_TAB;
    default:   return KEY_NONE;
    }
}

static void keyboard_irq(struct regs *r)
{
    (void)r;

    u8 scancode = inb(KBD_DATA);

    /* A release is the press with bit 7 set; only the modifiers matter. */
    if (scancode & 0x80) {
        u8 code = (u8)(scancode & 0x7F);
        if (code == 0x2A || code == 0x36) {
            shift = 0;
        }
        if (code == 0x1D) {
            ctrl = 0;
        }
        return;
    }

    if (scancode == 0x2A || scancode == 0x36) {
        shift = 1;
        return;
    }
    if (scancode == 0x1D) {
        ctrl = 1;
        return;
    }
    if (scancode == 0x3A) {
        caps = (u8)!caps;
        return;
    }

    u16 key = named_key(scancode);
    if (key != KEY_NONE) {
        push(key);
        return;
    }

    char c = shift ? shift_map[scancode] : normal_map[scancode];
    if (c >= 'a' && c <= 'z' && caps) {
        c = (char)(c - 'a' + 'A');
    }
    if (c >= 'A' && c <= 'Z' && caps && shift) {
        c = (char)(c - 'A' + 'a');
    }
    if (c) {
        push((u16)(u8)c);
    }
}

void keyboard_init(void)
{
    head = 0;
    tail = 0;
    shift = 0;
    ctrl = 0;
    caps = 0;
    irq_install_handler(1, keyboard_irq);
    klog("KBD", "PS/2 keyboard ready (IRQ1)");
}

u16 keyboard_get(void)
{
    if (head == tail) {
        return KEY_NONE;
    }
    u16 key = buffer[tail];
    tail = (tail + 1) & (KBD_BUF_SIZE - 1);
    return key;
}

u32 keyboard_pending(void)
{
    return (head + KBD_BUF_SIZE - tail) & (KBD_BUF_SIZE - 1);
}

void keyboard_flush(void)
{
    tail = head;
}

u16 keyboard_wait(void)
{
    for (;;) {
        u16 key = keyboard_get();
        if (key != KEY_NONE) {
            return key;
        }
        /* Wait for the next interrupt rather than spinning on the port. */
        __asm__ volatile("hlt");
    }
}
