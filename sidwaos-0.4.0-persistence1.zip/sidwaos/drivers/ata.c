/* ATA PIO driver (primary bus, master drive).
 *
 * Two different waits are needed and conflating them is the classic ATA bug:
 *
 *   - Before issuing a command, wait until the drive is idle: BSY clear and
 *     DRDY set. DRQ must NOT be set at this point.
 *   - After issuing a read/write, wait until BSY clears and DRQ SETS, which is
 *     the drive announcing a 512-byte block is ready to transfer.
 */

#include "ata.h"
#include "io.h"
#include "serial.h"

#define ATA_DATA    0x1F0
#define ATA_ERROR   0x1F1
#define ATA_SECCNT  0x1F2
#define ATA_LBA_LO  0x1F3
#define ATA_LBA_MID 0x1F4
#define ATA_LBA_HI  0x1F5
#define ATA_DRIVE   0x1F6
#define ATA_STATUS  0x1F7
#define ATA_COMMAND 0x1F7

#define ATA_SR_BSY  0x80
#define ATA_SR_DRDY 0x40
#define ATA_SR_DF   0x20
#define ATA_SR_DRQ  0x08
#define ATA_SR_ERR  0x01

#define ATA_CMD_IDENTIFY 0xEC
#define ATA_CMD_READ  0x20
#define ATA_CMD_WRITE 0x30
#define ATA_CMD_FLUSH 0xE7

/* Implemented in drivers/ata_pio.asm. */
void ata_io_wait_400ns(void);
void ata_read_data(u16 *buf, u32 words);
void ata_write_data(const u16 *buf, u32 words);

static u32 drive_sectors;

/* Wait until the drive is ready to accept a command. */
static int ata_wait_idle(void)
{
    for (u32 i = 0; i < 1000000; i++) {
        u8 status = inb(ATA_STATUS);
        if (status & ATA_SR_BSY) {
            continue;
        }
        if (status & (ATA_SR_ERR | ATA_SR_DF)) {
            return 0;
        }
        if ((status & ATA_SR_DRDY) && !(status & ATA_SR_DRQ)) {
            return 1;
        }
    }
    return 0;
}

/* Wait until a data block is ready to transfer (DRQ set). */
static int ata_wait_drq(void)
{
    for (u32 i = 0; i < 1000000; i++) {
        u8 status = inb(ATA_STATUS);
        if (status & ATA_SR_BSY) {
            continue;
        }
        if (status & (ATA_SR_ERR | ATA_SR_DF)) {
            return 0;
        }
        if (status & ATA_SR_DRQ) {
            return 1;
        }
    }
    return 0;
}

static void ata_select_lba(u32 lba, u8 count)
{
    outb(ATA_DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));  /* master, LBA mode */
    ata_io_wait_400ns();
    outb(ATA_SECCNT, count);
    outb(ATA_LBA_LO,  (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (u8)((lba >> 16) & 0xFF));
}

int ata_init(void)
{
    outb(ATA_DRIVE, 0xA0);      /* select master */
    ata_io_wait_400ns();

    /* A zeroed LBA range is the conventional no-op that lets us poll status. */
    outb(ATA_SECCNT, 0);
    outb(ATA_LBA_LO, 0);
    outb(ATA_LBA_MID, 0);
    outb(ATA_LBA_HI, 0);

    if (!ata_wait_idle()) {
        return 0;
    }

    /* IDENTIFY the drive so its size is known. The sector count is the 32-bit
     * word at offset 60; the older 28-bit fields are a fallback for drives that
     * report zero there. */
    outb(ATA_SECCNT, 0);
    outb(ATA_LBA_LO, 0);
    outb(ATA_LBA_MID, 0);
    outb(ATA_LBA_HI, 0);
    outb(ATA_COMMAND, ATA_CMD_IDENTIFY);
    ata_io_wait_400ns();

    u8 status = inb(ATA_STATUS);
    if (status == 0) {
        return 0;       /* no drive on the bus */
    }
    if (!ata_wait_drq()) {
        return 0;
    }

    u16 id[256];
    ata_read_data(id, 256);

    u32 lba28 = ((u32)id[61] << 16) | id[60];
    u32 lba48_lo = ((u32)id[101] << 16) | id[100];
    u32 lba48_hi = ((u32)id[103] << 16) | id[102];
    u32 sectors = lba48_lo ? lba48_lo : lba28;

    drive_sectors = sectors;
    (void)lba48_hi;

    return 1;
}

u32 ata_sectors(void) { return drive_sectors; }

u32 ata_size_mb(void)
{
    /* 2048 sectors is 1 MiB. */
    return drive_sectors / 2048;
}

int ata_read_sectors(u32 lba, u8 count, void *buf)
{
    if (!ata_wait_idle()) {
        return 0;
    }

    ata_select_lba(lba, count);
    outb(ATA_COMMAND, ATA_CMD_READ);

    u8 *dst = (u8 *)buf;
    for (u8 s = 0; s < count; s++) {
        if (!ata_wait_drq()) {
            return 0;
        }
        ata_read_data((u16 *)(dst + (u32)s * ATA_SECTOR_SIZE), ATA_SECTOR_SIZE / 2);
        ata_io_wait_400ns();
    }
    return 1;
}

int ata_write_sectors(u32 lba, u8 count, const void *buf)
{
    if (!ata_wait_idle()) {
        return 0;
    }

    ata_select_lba(lba, count);
    outb(ATA_COMMAND, ATA_CMD_WRITE);

    const u8 *src = (const u8 *)buf;
    for (u8 s = 0; s < count; s++) {
        if (!ata_wait_drq()) {
            return 0;
        }
        ata_write_data((const u16 *)(src + (u32)s * ATA_SECTOR_SIZE),
                       ATA_SECTOR_SIZE / 2);
        ata_io_wait_400ns();
    }

    /* Flush the drive's write cache so the data actually lands. */
    outb(ATA_COMMAND, ATA_CMD_FLUSH);
    return ata_wait_idle();
}
