; ATA PIO primitives.
;
; The C driver owns the protocol (status polling, command sequencing); these
; routines only perform the raw port transfers, keeping every actual `in`/`out`
; in assembly.
bits 32

section .text

global ata_io_wait_400ns
global ata_read_data
global ata_write_data

; void ata_io_wait_400ns(void) - read the status port 4 times (~400 ns).
ata_io_wait_400ns:
    mov dx, 0x1F7
    in al, dx
    in al, dx
    in al, dx
    in al, dx
    ret

; void ata_read_data(uint16_t *buf, uint32_t words)
; Reads `words` 16-bit values from the data port (0x1F0) into buf.
ata_read_data:
    pushad
    mov edi, [esp + 36]     ; buf
    mov ecx, [esp + 40]     ; words
    mov dx, 0x1F0
.loop:
    test ecx, ecx
    jz .done
    in ax, dx
    mov [edi], ax
    add edi, 2
    dec ecx
    jmp .loop
.done:
    popad
    ret

; void ata_write_data(const uint16_t *buf, uint32_t words)
; Writes `words` 16-bit values to the data port (0x1F0) from buf.
ata_write_data:
    pushad
    mov esi, [esp + 36]     ; buf
    mov ecx, [esp + 40]     ; words
    mov dx, 0x1F0
.loop:
    test ecx, ecx
    jz .done
    mov ax, [esi]
    out dx, ax
    add esi, 2
    dec ecx
    jmp .loop
.done:
    popad
    ret
