/* Realtek RTL8139 NIC driver. See include/rtl8139.h.
 *
 * Register offsets and bit meanings follow the RTL8139C datasheet, which is also
 * what QEMU's emulation implements. Everything is polled: the kernel never
 * installs a network interrupt handler, so the network stack always runs in
 * normal context where it can allocate, block on the timer, and log.
 */

#include "rtl8139.h"
#include "pci.h"
#include "io.h"
#include "serial.h"
#include "string.h"
#include "timer.h"

/* Register offsets from the I/O base. */
#define R_IDR0      0x00        /* MAC address, 6 bytes */
#define R_TSD0      0x10        /* transmit status, 4 descriptors */
#define R_TSAD0     0x20        /* transmit start address, 4 descriptors */
#define R_RBSTART   0x30        /* receive buffer start (physical) */
#define R_CR        0x37        /* command register */
#define R_CAPR      0x38        /* current address of packet read */
#define R_CBR       0x3A        /* current buffer address (read only) */
#define R_IMR       0x3C        /* interrupt mask */
#define R_ISR       0x3E        /* interrupt status */
#define R_TCR       0x40        /* transmit configuration */
#define R_RCR       0x44        /* receive configuration */

/* Command register bits. */
#define CR_BUFE     0x01        /* buffer empty (read only) */
#define CR_TE       0x04        /* transmitter enable */
#define CR_RE       0x08        /* receiver enable */
#define CR_RST      0x10        /* reset */

/* Interrupt status bits. */
#define ISR_ROK     0x01
#define ISR_RER     0x02
#define ISR_TOK     0x04
#define ISR_TER     0x08
#define ISR_RXOVW   0x10
#define ISR_PUN     0x20
#define ISR_FOVW    0x40

/* Transmit status descriptor bits.
 *
 * The card, not the driver, sets the ownership bit when it finishes a frame, so
 * the driver writes only the length. Both the ownership bit and the OK bit are
 * therefore completion signals; either one means the frame is on the wire. This
 * matches the Linux 8139too driver and QEMU's emulation. */
#define TSD_OWN     0x2000      /* set by the card when it owns/finished it */
#define TSD_UNDERRUN 0x4000
#define TSD_OK      0x8000      /* transmit completed */

/* Receive configuration: accept broadcast, multicast, physical match and all,
 * and wrap the ring at 8 KiB so a frame never straddles the end. */
#define RCR_ACCEPT  0x0F
#define RCR_WRAP    (1u << 7)

/* Receive ring: 8 KiB plus the 16-byte header slack the WRAP bit requires. */
#define RX_BUF_SIZE (8192 + 16 + 1536)
#define RX_RING     8192

#define TX_BUF_SIZE 2048

/* Static buffers, so the card DMAs into known physical memory. Paging is off,
 * so a kernel address is also a physical address. One transmit buffer per
 * descriptor, because the card walks the descriptors in turn. */
static u8  rx_buffer[RX_BUF_SIZE] __attribute__((aligned(16)));
static u8  tx_buffers[4][TX_BUF_SIZE] __attribute__((aligned(16)));

static u16 io_base;
static u8  mac[6];
static int present;
static u32 rx_offset;
static u32 rx_count;
static u32 tx_count;
static u32 tx_descriptor;

static u8  reg8(u16 off)  { return inb((u16)(io_base + off)); }
static u16 reg16(u16 off) { return inw((u16)(io_base + off)); }
static u32 reg32(u16 off) { return inl((u16)(io_base + off)); }

static void reg8_set(u16 off, u8 v)   { outb((u16)(io_base + off), v); }
static void reg16_set(u16 off, u16 v) { outw((u16)(io_base + off), v); }
static void reg32_set(u16 off, u32 v) { outl((u16)(io_base + off), v); }

int rtl8139_present(void) { return present; }
const u8 *rtl8139_mac(void) { return mac; }
u16 rtl8139_io_base(void) { return io_base; }
u32 rtl8139_rx_count(void) { return rx_count; }
u32 rtl8139_tx_count(void) { return tx_count; }


/* Enable I/O decoding for a PCI device: the command register's low bit. */
static void pci_enable_io(const struct pci_device *d)
{
    u32 cmd = pci_read_config(d->bus, d->slot, d->func, 0x04);
    cmd |= 0x0001;              /* I/O space enable */
    cmd |= 0x0004;              /* bus master enable, needed for DMA */
    pci_write_config(d->bus, d->slot, d->func, 0x04, cmd);
}

int rtl8139_init(void)
{
    struct pci_device d;
    if (!pci_find_device(0x10EC, 0x8139, &d)) {
        klog("NET", "no RTL8139 on the PCI bus");
        return 0;
    }

    if (!pci_bar_is_mmio(d.bar[0])) {
        io_base = (u16)pci_bar_addr(d.bar[0]);
    } else {
        /* The card is in memory-mapped mode. This driver only speaks port I/O,
         * which is how QEMU presents it, so say so rather than guessing. */
        klog("NET", "RTL8139 is memory-mapped; port I/O mode required");
        return 0;
    }

    pci_enable_io(&d);
    klog("NET", "RTL8139 at %x:%x.%x io 0x%x",
         d.bus, d.slot, d.func, io_base);

    /* Software reset, then wait for the card to clear the reset bit itself. */
    reg8_set(R_CR, CR_RST);
    u32 spin = 0;
    while ((reg8(R_CR) & CR_RST) && spin < 100000) {
        spin++;
    }
    if (reg8(R_CR) & CR_RST) {
        klog("NET", "reset did not complete");
        return 0;
    }

    /* The MAC is loaded from the EEPROM into IDR0..IDR5 by the reset. */
    for (u32 i = 0; i < 6; i++) {
        mac[i] = reg8((u16)(R_IDR0 + i));
    }
    klog("NET", "MAC %x:%x:%x:%x:%x:%x",
         mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

    /* Power up and clear the interrupt mask: this driver polls, so no interrupt
     * should ever be raised. */
    reg8_set(0x52, 0x00);       /* CONFIG1: clear power-down */
    reg16_set(R_IMR, 0x0000);
    reg16_set(R_ISR, 0xFFFF);   /* clear anything already pending */

    /* Receive ring. The card DMAs here, so this must be a physical address. */
    memset(rx_buffer, 0, sizeof(rx_buffer));
    reg32_set(R_RBSTART, (u32)rx_buffer);
    rx_offset = 0;
    reg16_set(R_CAPR, 0);       /* the read pointer starts at the ring base */

    /* Interframe gap and DMA burst: standard gap, 1024-byte bursts. */
    reg32_set(R_TCR, 0x0300 | 0x1A);
    /* Accept our own address plus broadcast, and wrap at 8 KiB. */
    reg32_set(R_RCR, RCR_ACCEPT | RCR_WRAP);

    /* Enable the transmitter and receiver together. */
    reg8_set(R_CR, CR_TE | CR_RE);

    present = 1;
    return 1;
}

/* Poll one transmit descriptor until the card reports it finished the frame.
 *
 * The card sets the ownership bit and the OK bit on completion; either one is a
 * success. The transmit-OK interrupt flag is checked first, because under
 * emulation it is updated more promptly than the descriptor word. An underrun
 * means the frame was not sent. */
static int tx_wait(u32 descriptor)
{
    u16 tsd = (u16)(R_TSD0 + descriptor * 4);
    u32 start = timer_ticks();
    while (timer_ticks() - start < 1000) {      /* 10 s at 100 Hz */
        if (reg16(R_ISR) & ISR_TOK) {
            reg16_set(R_ISR, ISR_TOK);          /* write 1 to clear */
            return 1;
        }
        u32 status = reg32(tsd);
        if (status & (TSD_OK | TSD_OWN)) {
            return 1;
        }
        if (status & TSD_UNDERRUN) {
            return 0;
        }
    }
    klog("NET", "tx timeout: TSD=0x%x ISR=0x%x CR=0x%x",
         reg32(tsd), reg16(R_ISR), reg8(R_CR));
    return 0;
}

int rtl8139_send(const void *frame, u32 len)
{
    if (!present || len > TX_BUF_SIZE) {
        return 0;
    }

    /* The card never transmits less than the 60-byte Ethernet minimum. */
    u32 send_len = len < 60 ? 60 : len;

    /* The card walks its four transmit descriptors in turn, so each frame must
     * use the next one. Reusing descriptor 0 every time leaves the second frame
     * waiting on a descriptor the card has already passed. Each descriptor needs
     * its own buffer, because the card may still be reading the previous one
     * when the next is queued. */
    u32 d = tx_descriptor;
    u8 *buf = tx_buffers[d];

    memcpy(buf, frame, len);
    if (send_len > len) {
        memset(buf + len, 0, send_len - len);
    }

    /* Writing the length starts the transmission. The card sets the ownership
     * and OK bits when it finishes, which is what tx_wait() waits for. */
    reg32_set((u16)(R_TSAD0 + d * 4), (u32)buf);
    reg32_set((u16)(R_TSD0 + d * 4), send_len);

    if (!tx_wait(d)) {
        klog("NET", "transmit failed (len %u, descriptor %u)", send_len, d);
        return 0;
    }
    tx_descriptor = (d + 1) & 3;
    tx_count++;
    return 1;
}

/* Read one frame out of the ring, advancing the read pointer. */
static int rx_poll(void *buf, u32 max)
{
    /* The card is empty when the read pointer has caught the write pointer, or
     * when it says the buffer is empty. */
    if (reg8(R_CR) & CR_BUFE) {
        return -1;
    }
    u16 capr = reg16(R_CAPR);
    u16 cbr = reg16(R_CBR);
    if (capr == cbr) {
        return -1;
    }

    u8 *slot = rx_buffer + rx_offset;
    u16 status = (u16)(slot[0] | (slot[1] << 8));
    u16 length = (u16)(slot[2] | (slot[3] << 8));

    if (!(status & ISR_ROK)) {
        /* A bad frame still has to be consumed, or the ring stalls forever. */
        klog("NET", "receive error, status 0x%x", status);
        return -1;
    }

    /* The length covers the payload plus the trailing CRC, which is not part of
     * the frame handed to the stack. */
    u32 payload = (length >= 4) ? (u32)length - 4 : 0;
    u32 copy = payload > max ? max : payload;
    if (copy) {
        memcpy(buf, slot + 4, copy);
    }

    /* Advance to the next slot, rounded up to a 4-byte boundary. */
    rx_offset = (rx_offset + 4 + length + 3) & ~3u;
    rx_offset %= RX_RING;
    reg16_set(R_CAPR, (u16)(rx_offset - 16));
    return (int)copy;
}

int rtl8139_recv(void *buf, u32 max)
{
    if (!present) {
        return -1;
    }
    int n = rx_poll(buf, max);
    if (n >= 0) {
        rx_count++;
    }
    return n;
}
