; Time-stamp counter read.
bits 32

section .text
global tsc_read

; uint64_t tsc_read(void) - returns the TSC in edx:eax.
tsc_read:
    rdtsc
    ret
