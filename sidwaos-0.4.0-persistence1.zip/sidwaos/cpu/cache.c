/* CPU cache geometry detection and a free-capacity probe.
 *
 * CPUID leaf 4 (deterministic cache parameters) describes each cache level.
 * Not every CPU implements it, so the detector falls back to conservative
 * defaults and says so, rather than reporting a fabricated size.
 *
 * The free-capacity probe then measures how much of the detected L1 data cache
 * is genuinely usable: it walks an array of increasing size and finds the point
 * where the per-access cost jumps, which is the point the working set no longer
 * fits. The kernel image, statics and stacks are already resident, so this
 * figure is normally below the raw L1 size.
 */

#include "cache.h"
#include "serial.h"
#include "string.h"

static struct cache_info info;

/* Array used by the probe. Kept in .bss, outside the probed region itself. */
#define PROBE_BYTES (256 * 1024)
static u8 probe_array[PROBE_BYTES] __attribute__((aligned(4096)));

static u64 read_tsc(void)
{
    return tsc_read();
}

static int cpuid_supported(void)
{
    u32 eax, ebx, ecx, edx;
    __asm__ volatile("cpuid"
                     : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx)
                     : "a"(0));
    return eax >= 4;
}

/* Query one cache level via CPUID leaf 4. Returns 1 if the level exists. */
static int cpuid_cache(u32 index, u32 *type, u32 *level, u32 *line,
                       u32 *ways, u32 *sets, u32 *partitions)
{
    u32 eax, ebx, ecx, edx;
    __asm__ volatile("cpuid"
                     : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx)
                     : "a"(4), "c"(index));

    *type = eax & 0x1F;
    if (*type == 0) {
        return 0;               /* no more caches */
    }
    *level      = (eax >> 5) & 0x07;
    *line       = (ebx & 0x0FFF) + 1;
    *partitions = ((ebx >> 12) & 0x03FF) + 1;
    *ways       = ((ebx >> 22) & 0x03FF) + 1;
    *sets       = ecx + 1;
    return 1;
}

void cache_init(void)
{
    /* Conservative defaults for a 486-era fallback path. */
    info.l1d_kb = 8;
    info.l2_kb = 0;
    info.l3_kb = 0;
    info.line_bytes = 32;

    if (!cpuid_supported()) {
        klog("CACHE", "cpuid leaf 4 unavailable, using defaults");
        return;
    }

    for (u32 i = 0; i < 16; i++) {
        u32 type, level, line, ways, sets, partitions;

        if (!cpuid_cache(i, &type, &level, &line, &ways, &sets, &partitions)) {
            break;
        }

        /* Type 1 = data cache, 3 = unified. */
        if (type != 1 && type != 3) {
            continue;
        }

        u32 size = (ways * partitions * line * sets) / 1024;

        if (level == 1) {
            info.l1d_kb = size;
            info.line_bytes = line;
        } else if (level == 2) {
            info.l2_kb = size;
        } else if (level == 3) {
            info.l3_kb = size;
        }
    }
}

const struct cache_info *cache_get(void)
{
    return &info;
}

/* Time `iterations` dependent accesses with a stride of 64 bytes (one cache
 * line), returning TSC ticks per access. Dependent (xorshift) indexing keeps the
 * accesses serialized so the figure reflects latency, not throughput. */
static u64 probe_ticks(u32 bytes, u32 iterations)
{
    u32 slots = bytes / 64;
    u32 index = 0;

    for (u32 i = 0; i < slots; i++) {
        probe_array[i * 64] = (u8)i;
    }

    u64 start = read_tsc();
    for (u32 i = 0; i < iterations; i++) {
        index = (index * 1103515245u + 12345u) % slots;
        probe_array[index * 64] ^= 1;
    }
    u64 end = read_tsc();

    return (end - start) / iterations;
}

u32 cache_probe_l1_free_kb(void)
{
    /* Compare the cost at a small working set against the cost at larger sizes.
     * The largest set that stays within a small multiple of the small case is
     * taken as still cache-resident. The result is capped at the detected L1d
     * size: a larger working set can still be fast by living in L2, which would
     * otherwise be misreported as free L1. */
    u64 baseline = probe_ticks(4 * 1024, 4096);
    u32 best_kb = 4;

    for (u32 kb = 8; kb <= 64; kb *= 2) {
        if (kb * 1024 > PROBE_BYTES) {
            break;
        }
        u64 ticks = probe_ticks(kb * 1024, 4096);

        /* Allow 3x slack for measurement noise; beyond that the working set has
         * spilled out of L1. */
        if (ticks > baseline * 3) {
            break;
        }
        best_kb = kb;
    }

    u32 cap = info.l1d_kb ? info.l1d_kb : 8;
    return best_kb < cap ? best_kb : cap;
}

void cache_report(void)
{
    klog("CACHE", "L1d=%uKB L2=%uKB L3=%uKB line=%uB",
         info.l1d_kb, info.l2_kb, info.l3_kb, info.line_bytes);

    u32 free_kb = cache_probe_l1_free_kb();
    klog("CACHE", "L1 free for kernel work: %uKB (probe working-set scan)",
         free_kb);
}
