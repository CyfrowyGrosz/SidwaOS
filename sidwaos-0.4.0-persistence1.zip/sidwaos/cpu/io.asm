; Port I/O primitives.
; All low-level device access in this kernel goes through these routines.
bits 32

section .text

global outb
global outw
global inb
global inw
global inl
global outl
global io_wait

; void outb(uint16_t port, uint8_t value)
outb:
    mov dx, [esp + 4]       ; port
    mov al, [esp + 8]       ; value
    out dx, al
    ret

; void outw(uint16_t port, uint16_t value)
outw:
    mov dx, [esp + 4]
    mov ax, [esp + 8]
    out dx, ax
    ret

; uint8_t inb(uint16_t port)
inb:
    mov dx, [esp + 4]
    xor eax, eax
    in al, dx
    ret

; uint16_t inw(uint16_t port)
inw:
    mov dx, [esp + 4]
    xor eax, eax
    in ax, dx
    ret

; void io_wait(void) - write to unused port 0x80 for a short bus delay.
io_wait:
    xor al, al
    out 0x80, al
    ret

; uint32_t inl(uint16_t port)
inl:
    mov dx, [esp + 4]
    xor eax, eax
    in eax, dx
    ret

; void outl(uint16_t port, uint32_t value)
outl:
    mov dx, [esp + 4]
    mov eax, [esp + 8]
    out dx, eax
    ret
