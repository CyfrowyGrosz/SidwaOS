; COM1 serial driver (38400 8N1). The kernel's primary observable channel.
bits 32

%define COM1 0x3F8

section .text

global serial_init
global serial_putc
global serial_puts
global serial_hex

; void serial_init(void)
serial_init:
    pushad
    mov dx, COM1 + 1        ; IER: disable interrupts
    xor al, al
    out dx, al

    mov dx, COM1 + 3        ; LCR: enable DLAB to set divisor
    mov al, 0x80
    out dx, al

    mov dx, COM1 + 0        ; DLL: divisor low (3 -> 38400 baud)
    mov al, 0x03
    out dx, al
    mov dx, COM1 + 1        ; DLM: divisor high
    xor al, al
    out dx, al

    mov dx, COM1 + 3        ; LCR: 8 bits, no parity, 1 stop, DLAB off
    mov al, 0x03
    out dx, al

    mov dx, COM1 + 2        ; FCR: enable FIFO, clear, 14-byte threshold
    mov al, 0xC7
    out dx, al

    mov dx, COM1 + 4        ; MCR: DTR, RTS, OUT2
    mov al, 0x0B
    out dx, al
    popad
    ret

; void serial_putc(char c)
serial_putc:
    pushad
    mov bl, [esp + 36]      ; arg1: pushad(32) + return address(4)
.wait:
    mov dx, COM1 + 5        ; LSR
    in al, dx
    test al, 0x20           ; transmit holding register empty?
    jz .wait
    mov dx, COM1
    mov al, bl
    out dx, al
    popad
    ret

; void serial_puts(const char *s)
serial_puts:
    pushad
    mov esi, [esp + 36]
.next:
    lodsb
    test al, al
    jz .done
    movzx eax, al
    push eax
    call serial_putc
    add esp, 4
    jmp .next
.done:
    popad
    ret

; void serial_hex(uint32_t value)
; Prints 8 lowercase hex digits. Waits for the FIFO inline, so no nested call
; and no stack juggling around a helper. Uses esi for the value so ebx is free
; to hold the character across the LSR poll (dx is used for the port).
serial_hex:
    pushad
    mov esi, [esp + 36]
    mov ecx, 8              ; 8 nibbles, most significant first
.loop:
    rol esi, 4
    mov eax, esi
    and eax, 0x0F
    cmp al, 10
    jb .digit
    add al, 'a' - 10
    jmp .emit
.digit:
    add al, '0'
.emit:
    mov bl, al              ; stash the character; ebx is otherwise unused
.wait:
    mov dx, COM1 + 5
    in al, dx
    test al, 0x20
    jz .wait
    mov dx, COM1
    mov al, bl
    out dx, al
    dec ecx
    jnz .loop
    popad
    ret

; int serial_rx_ready(void) - 1 when a byte is waiting in the receive buffer.
global serial_rx_ready
serial_rx_ready:
    push edx
    mov dx, COM1 + 5        ; LSR
    in al, dx
    and eax, 0x01           ; data ready?
    pop edx
    ret

; int serial_getc(void) - blocking read of one byte (low 8 bits of the result).
global serial_getc
serial_getc:
    push edx
.wait:
    mov dx, COM1 + 5
    in al, dx
    test al, 0x01
    jz .wait
    mov dx, COM1
    in al, dx
    movzx eax, al
    pop edx
    ret
