/* Entropy and PRNG.
 *
 * Bare metal under QEMU gives no RDRAND guarantee, so the seed mixes PIT tick
 * deltas with the CMOS/RTC registers, then a xorshift32 generator expands it.
 * The PIT deltas are sampled in a tight loop; on real hardware the low bits
 * vary, which is enough to make the fragment stack base unpredictable.
 */

#include "rand.h"
#include "timer.h"
#include "io.h"

#define CMOS_ADDR 0x70
#define CMOS_DATA 0x71

static u32 state;

static u8 cmos_read(u8 reg)
{
    outb(CMOS_ADDR, reg);
    return inb(CMOS_DATA);
}

static u32 mix(u32 x)
{
    /* A cheap avalanche step so a small input change spreads across all bits. */
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

void rand_init(void)
{
    u32 seed = 0x9E3779B9u;

    /* PIT tick deltas: jitter in the loop gives us unpredictable low bits. */
    u32 prev = timer_ticks();
    for (int i = 0; i < 32; i++) {
        u32 now = timer_ticks();
        seed = mix(seed ^ (now - prev) ^ (u32)i);
        prev = now;
    }

    /* RTC seconds/minutes/hours add slow-moving but independent entropy. */
    seed ^= (u32)cmos_read(0x00) << 0;
    seed ^= (u32)cmos_read(0x02) << 8;
    seed ^= (u32)cmos_read(0x04) << 16;

    state = seed ? seed : 0x1234567u;
}

u32 rand_u32(void)
{
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}

u32 rand_bit(void)
{
    return rand_u32() & 1u;
}
