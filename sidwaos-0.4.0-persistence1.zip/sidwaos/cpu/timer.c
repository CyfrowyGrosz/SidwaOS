/* PIT (8253/8254) channel 0 driver. Provides the tick that drives all loops. */

#include "timer.h"
#include "interrupts.h"
#include "io.h"

#define PIT_CH0   0x40
#define PIT_CMD   0x43
#define PIT_BASE  1193182

static volatile u32 ticks;

static void timer_irq(struct regs *r)
{
    (void)r;
    ticks++;
}

void timer_init(void)
{
    u32 divisor = PIT_BASE / PIT_HZ;

    outb(PIT_CMD, 0x36);                    /* channel 0, lobyte/hibyte, mode 3 */
    outb(PIT_CH0, (u8)(divisor & 0xFF));
    outb(PIT_CH0, (u8)((divisor >> 8) & 0xFF));

    irq_install_handler(0, timer_irq);
}

u32 timer_ticks(void)
{
    return ticks;
}

void timer_sleep_ms(u32 ms)
{
    /* Round up: at PIT_HZ=100 a tick is 10ms, so a 5ms request truncates to
     * zero and would return without sleeping at all. Callers that poll in
     * short steps -- the AI bridge waiting for a host reply -- would then spin
     * through their whole budget in microseconds instead of waiting. */
    u32 want = (ms * PIT_HZ + 999) / 1000;
    if (want == 0 && ms > 0) {
        want = 1;
    }
    u32 target = ticks + want;
    while (ticks < target) {
        hlt();
    }
}
