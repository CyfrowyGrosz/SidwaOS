#ifndef OS_PEEPHOLE_H
#define OS_PEEPHOLE_H

#include "types.h"
#include "sasm.h"

/* Improving a program without changing what it does.
 *
 * This is the "first point" the machine was built around, applied to code the
 * machine wrote itself: take a program that works, read what it actually does,
 * and write a version that looks the same but runs in fewer steps.
 *
 * The measure is instructions, not cycles. Every SidwaASM instruction costs one
 * VM step, so a shorter program is a faster one, and that is a claim that can be
 * checked rather than asserted. No wall-clock claim is made, because it would
 * depend on a real CPU's choice of instruction and this is a virtual one.
 *
 * The rewrites are local: each looks at one or two neighbouring instructions.
 *
 *   fold     MOV rX, a  followed by  ADD/SUB/MUL rX, b  ->  MOV rX, a op b
 *   drop     ADD rX, 0, SUB rX, 0, MUL rX, 1, MOV rX, rX  -- no effect
 *   fall     JMP to the instruction immediately after it
 *
 * Two things make this safe, and both are easy to get wrong:
 *
 *   Jumps hold absolute addresses. Removing an instruction moves every
 *   instruction after it, so each jump target is rewritten through an old-to-new
 *   address map. A jump aimed at a removed instruction is mapped to the next one
 *   that survives, which is the address it would have reached anyway.
 *
 *   An instruction that is the target of a jump is never removed or folded
 *   away, however useless it looks on its own, because a jump lands on it. The
 *   only exception is the fold, which keeps the first instruction and rewrites
 *   it in place.
 *
 * The result is still not trusted: the caller runs both versions and compares
 * their output. A rewrite that changes the output is a bug, and the check is
 * what catches it.
 */

/* What a run of the optimiser found and did. */
struct peephole_report {
    u32 fold_imm;       /* MOV+op pairs merged into one instruction */
    u32 identity;       /* no-op instructions removed */
    u32 jmp_next;       /* jumps to the following instruction removed */
    u32 removed;        /* total instructions removed */
    u32 passes;         /* passes needed to reach a fixed point */
};

/* Optimise `in` into `out`, repeating until nothing more can be removed. `out`
 * may be the same program as `in`. `rep` may be NULL. Returns the number of
 * instructions removed, which is the saving in VM steps. */
u32 peephole_optimise(const struct sasm_program *in, struct sasm_program *out,
                      struct peephole_report *rep);

/* One-line summary of a report, for the log and for the stored record, e.g.
 * "removed 3 of 9: fold 1, identity 2, fall 0". */
void peephole_report_text(const struct peephole_report *rep,
                          u32 before, u32 after, char *out, u32 max);

/* Write `prog` as an assembly listing, one instruction per line, into `out`.
 * This is the decoding step: the program as text, so what it does can be read
 * before deciding what to change. Returns the number of lines. */
u32 peephole_list(const struct sasm_program *prog, char *out, u32 max);

/* Write `prog` back out as source that will assemble to the same program.
 *
 * The difference from peephole_list() is the jump targets. A listing may show a
 * jump as a bare address, because a human reading it can count. Source cannot:
 * the assembler resolves a jump by label name, so an optimised program with
 * absolute jump targets has to have those targets given names again before it
 * can be stored and later reassembled.
 *
 * A label is emitted at every address a jump lands on, named "L<address>", and
 * each jump names it. Returns the number of lines written. */
u32 peephole_render(const struct sasm_program *prog, char *out, u32 max);

int peephole_selftest(void);

#endif /* OS_PEEPHOLE_H */
