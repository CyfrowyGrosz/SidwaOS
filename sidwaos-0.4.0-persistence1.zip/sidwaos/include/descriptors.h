#ifndef OS_DESCRIPTORS_H
#define OS_DESCRIPTORS_H

#include "types.h"

struct gdt_entry {
    u16 limit_low;
    u16 base_low;
    u8  base_mid;
    u8  access;
    u8  granularity;
    u8  base_high;
} __attribute__((packed));

struct gdt_ptr {
    u16 limit;
    u32 base;
} __attribute__((packed));

struct idt_entry {
    u16 base_low;
    u16 selector;
    u8  always_zero;
    u8  flags;
    u16 base_high;
} __attribute__((packed));

struct idt_ptr {
    u16 limit;
    u32 base;
} __attribute__((packed));

/* Implemented in boot/gdt.asm. */
void gdt_load(u32 gdt_ptr_addr);

void gdt_init(void);
void idt_init(void);

/* Set a gate in the IDT (used by idt_init and the PIC setup). */
void idt_set_gate(int index, u32 handler, u16 selector, u8 flags);

#endif /* OS_DESCRIPTORS_H */
