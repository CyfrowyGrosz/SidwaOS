#ifndef OS_SVM_H
#define OS_SVM_H

#include "types.h"
#include "sasm.h"

/* The SidwaASM virtual machine.
 *
 * A bytecode interpreter over the output of sasm_assemble(). Four registers,
 * 64 words of memory, a zero flag, and a program counter. Running a program is
 * one loop with a switch on the opcode.
 *
 * Two things make it safe to run a program a user just typed:
 *
 *   * every jump is bounds-checked, so a bad label cannot leave the code array
 *   * the step limit stops an infinite loop, so the IDE never hangs
 *
 * Program output is written to a caller-supplied buffer rather than the serial
 * port, so the IDE can show it in a window and the tests can compare it.
 */

#define SVM_MEM_WORDS  64
#define SVM_REGS       4
#define SVM_STEP_LIMIT 100000
#define SVM_OUT_MAX    256

struct svm {
    u32 reg[SVM_REGS];
    u32 mem[SVM_MEM_WORDS];
    u32 pc;
    u32 zero;                       /* the zero flag, 0 or 1 */
    u32 steps;
    int halted;
};

/* Why a run stopped. */
#define SVM_OK        0
#define SVM_ERR_PC    1             /* pc left the code array */
#define SVM_ERR_STEPS 2             /* the step limit was reached */
#define SVM_ERR_OP    3             /* unknown opcode */

/* Reset the machine, ready to run a program. */
void svm_reset(struct svm *vm);

/* Run `prog` until it halts or fails. Output is appended to `out` (a
 * NUL-terminated string, up to `out_max` bytes including the terminator).
 * Returns one of the SVM_* codes. */
int svm_run(struct svm *vm, const struct sasm_program *prog,
            char *out, u32 out_max);

/* Human-readable reason for a return code from svm_run(). */
const char *svm_error_text(int code);

/* Assemble and run a program in one call. Returns the SVM_* code. */
int svm_run_source(const char *source, char *out, u32 out_max,
                   char *err, u32 err_max);

int svm_selftest(void);

#endif /* OS_SVM_H */
