#ifndef OS_OPTIM_H
#define OS_OPTIM_H

#include "types.h"

/* The optimisation course.
 *
 * The first thing this course teaches is the whole loop: take a program that
 * works but runs slowly, read what it actually does, and write a version that
 * looks the same but runs fast. Reading the slow build is how you find the
 * waste; the fast build is the evidence that you understood it.
 *
 * The course is data, like the C and reverse-engineering courses, so it can be
 * taught a lesson at a time over the serial line or shown in the GUI.
 *
 * It also carries a live demonstration. The VGA console is the machine's
 * "beauty I/O": every character is written to memory-mapped screen memory with
 * the cursor moved through the slow I/O ports. Drawing a frame the obvious way
 * is the slow program. Drawing the same frame with the cursor updated once, and
 * the screen written in words, is the fast one. optim_benchmark() runs both and
 * reports the cycle counts, so the lesson is a measurement, not a claim.
 */

/* Course lessons. */
u32 optim_count(void);
const struct lesson *optim_get(u32 index);
const struct lesson *optim_find(const char *keyword);
void optim_print(const struct lesson *lesson);
void optim_print_all(void);

/* One timed run of the slow and fast frame writers. Returns 1 when both drew
 * the same picture, which is what makes the comparison fair. */
int optim_benchmark(void);

/* Print the slow and fast frame writers side by side, so the difference can be
 * read as much as measured. */
void optim_show_pair(void);

int optim_selftest(void);

#endif /* OS_OPTIM_H */
