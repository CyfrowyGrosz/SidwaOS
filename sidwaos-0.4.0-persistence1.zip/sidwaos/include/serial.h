#ifndef OS_SERIAL_H
#define OS_SERIAL_H

#include <stdint.h>

#define COM1 0x3F8

/* Assembly-implemented byte-level driver. */
void serial_init(void);
void serial_putc(char c);
void serial_puts(const char *s);
void serial_hex(uint32_t value);
int  serial_rx_ready(void);
int  serial_getc(void);

/* C-level formatted logging (kernel/console.c). */
void kprintf(const char *fmt, ...);
void klog(const char *tag, const char *fmt, ...);

/* Redirect formatted output away from the serial port. The GUI uses this to
 * mirror the log on screen. Pass NULL to go back to the serial port. */
void console_set_sink(void (*fn)(char));

#endif /* OS_SERIAL_H */
