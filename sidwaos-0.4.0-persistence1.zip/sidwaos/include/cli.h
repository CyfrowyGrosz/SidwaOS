#ifndef OS_CLI_H
#define OS_CLI_H

/* Command-line front end over the serial port. Each loop of the 3-state machine
 * is exposed as a command, so the same code that the automated boot path drives
 * can be stepped by hand.
 */
void cli_run(void);

#endif /* OS_CLI_H */
