#ifndef OS_PEDANT_H
#define OS_PEDANT_H

#include "types.h"

/* The machine's own critic.
 *
 * Everything else in the kernel is content: knowledge, weights, tallies. This
 * module is the one that stands back and asks whether any of it is good enough.
 * It exists because a system that only answers cannot tell you what it cannot
 * answer -- a miss is silent, and silence looks the same as success from the
 * outside.
 *
 * Two jobs, kept separate:
 *
 *   The ledger   records questions the machine failed to answer, and how often
 *                each was asked. This is the difference between "I don't know"
 *                and "I don't know, and here is what I keep being asked".
 *   The audit    inspects the machine's own state and reports what is weak:
 *                gaps awaiting knowledge, facts held but unproven, a model that
 *                still needs correcting, actions nothing has ever used.
 *
 * The ledger is what makes expansion automatic rather than manual. A miss is
 * normally forgotten the moment the console moves on. Recorded, it becomes a
 * work list: the host tool reads the gaps, teaches them, and the same question
 * is answered unaided next boot. That loop -- miss, record, teach, resolve -- is
 * the whole point of the module.
 *
 * The ledger is persisted to .sidwa under the reserved key "PEDANT", in the
 * same one-record format the result tallies use. Like "OUTCOMES", that record
 * is a reserved key rather than a fact: it is stored so the work list survives
 * a reboot, and it is not knowledge about anything. The two are kept apart by
 * key, not by the record format, so `know PEDANT` would return the ledger --
 * the same pre-existing quirk the tallies have, and not worth a separate
 * mechanism here.
 */

#define PEDANT_MAX_GAPS 16
#define PEDANT_Q_MAX    48      /* matches KNOW_KEY_MAX, so a gap can become a fact */

/* Record that `query` could not be answered. Called on every miss. A question
 * already in the ledger has its count raised instead of being stored twice, so
 * the ledger stays a list of distinct gaps and the counts show what is asked
 * most. Returns 1 when the gap was new. */
int pedant_note(const char *query);

/* Record that `query` has been answered, so its gap can be closed. Called on
 * every hit, so the ledger reflects what is still missing rather than what was
 * once missing. Returns 1 when a gap was cleared. */
int pedant_resolve(const char *query);

/* Gaps in the order they should be taught: most-asked first, because that is
 * the question the machine is most often failing. Returns the count; each name
 * is written into `out` at `i * stride`. */
u32 pedant_gaps(char *out, u32 stride, u32 max);

u32 pedant_gap_count(void);
u32 pedant_gap_asks(const char *query);   /* 0 when not a known gap */

/* Forget every gap. Used after teaching, and by the selftest. */
void pedant_clear(void);

/* Inspect the machine's own state and log one finding per line. Returns the
 * number of weaknesses found, so a caller can act on "is anything wrong?" rather
 * than parsing the log. */
u32 pedant_audit(void);

/* Log the gaps, most-asked first. */
void pedant_report(void);

/* Persist the ledger to .sidwa, replacing any earlier copy. Returns 1 on
 * success. A failure is not fatal: the ledger is a convenience, and losing it
 * costs the machine a work list, not knowledge. */
int pedant_save(void);

/* Load the ledger from .sidwa, replacing what is held. Returns 1 when a record
 * was found. */
int pedant_load(void);

/* Note, re-note, resolve, rank, persist and reload. Returns 1 on success. */
int pedant_selftest(void);

#endif /* OS_PEDANT_H */
