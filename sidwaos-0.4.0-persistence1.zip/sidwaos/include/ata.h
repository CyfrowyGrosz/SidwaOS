#ifndef OS_ATA_H
#define OS_ATA_H

#include "types.h"

#define ATA_SECTOR_SIZE 512

/* Initialize the primary ATA bus (PIO mode). Returns 1 on success. */
int ata_init(void);

/* Total addressable sectors reported by IDENTIFY, 0 if unknown. */
u32 ata_sectors(void);

/* Drive size in MiB, from the IDENTIFY sector count. */
u32 ata_size_mb(void);

/* Read `count` sectors starting at LBA `lba` into `buf`. */
int ata_read_sectors(u32 lba, u8 count, void *buf);

/* Write `count` sectors starting at LBA `lba` from `buf`. */
int ata_write_sectors(u32 lba, u8 count, const void *buf);

#endif /* OS_ATA_H */
