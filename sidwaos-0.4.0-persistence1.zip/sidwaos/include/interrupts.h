#ifndef OS_INTERRUPTS_H
#define OS_INTERRUPTS_H

#include "types.h"

/* Register layout pushed by the NASM ISR stubs (see boot/isr.asm). */
struct regs {
    u32 gs, fs, es, ds;
    u32 edi, esi, ebp, esp_dummy, ebx, edx, ecx, eax;
    u32 int_no, err_code;
    u32 eip, cs, eflags, useresp, ss;
};

typedef void (*irq_handler_t)(struct regs *);

void interrupts_init(void);
void irq_install_handler(int irq, irq_handler_t handler);

/* Called from the assembly stubs. */
void isr_dispatch(struct regs *r);
void irq_dispatch(struct regs *r);

/* Assembly entry points. */
void isr0(void);
void irq0(void);
void irq1(void);

#endif /* OS_INTERRUPTS_H */
