#ifndef OS_LAYOUT_H
#define OS_LAYOUT_H

#include "types.h"

/* Where the kernel's disk regions live.
 *
 * The bootloader passes a base LBA: 0 when SidwaOS owns the whole disk, or the
 * start of its partition when it shares a disk with another system. Every region
 * is an offset from that base, so the same kernel runs from a whole disk or from
 * a partition without being rebuilt.
 *
 * The offsets themselves match tools/mkboot.py, which lays the image out.
 */
#define LAYOUT_BLOB_LBA     64      /* demo program blobs */
#define LAYOUT_STORE_LBA    128     /* Loop 3 scratch */
#define LAYOUT_STORE_SECT   64
#define LAYOUT_KB_LBA       256     /* the .sidwa knowledge partition */
#define LAYOUT_KB_SECTORS   512

/* Set the disk base from the bootloader's hand-off. Called once at boot, before
 * any disk I/O. A base of 0 means the whole disk. */
void layout_init(u32 base_lba);

/* The disk base, and the absolute LBA of each region. */
u32 layout_base(void);
u32 layout_blob_lba(void);
u32 layout_store_lba(void);
u32 layout_kb_lba(void);

/* The size of the whole SidwaOS region, in sectors. The installer uses this to
 * decide how large a partition has to be. */
u32 layout_region_sectors(void);

/* Print the disk layout: the base and the absolute LBA of each region, so the
 * installer's choices can be checked from inside the running system. */
void layout_report(void);

/* The layout as the installer sees it: how many sectors the SidwaOS region
 * needs, and whether the current disk has room. */
void layout_install_report(void);

#endif /* OS_LAYOUT_H */
