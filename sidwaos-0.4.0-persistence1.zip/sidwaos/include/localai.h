#ifndef OS_LOCALAI_H
#define OS_LOCALAI_H

#include "types.h"

/* Local self-learning AI.
 *
 * A small linear classifier runs on the CPU. It maps a tokenised request onto
 * one of the kernel's actions, learns from its own mistakes, and persists its
 * weights to the .sidwa partition so training survives a reboot.
 *
 * The learning rule is the puzzle-weight update. Every feature carries a
 * weight that is adjusted by the error on each example. The compression grade
 * decides how many bits of each weight are kept, so the grade is a real
 * precision/space trade rather than a label:
 *
 *   grade 1  no compression   8-bit weights, 8 features   (coarsest)
 *   grade 2  light            12-bit weights, 16 features
 *   grade 3  maximum          16-bit weights, 32 features  (finest)
 *
 * A lower grade quantises harder: it packs the model into fewer bytes and
 * classifies more coarsely. A higher grade keeps more precision and can
 * separate requests a lower grade confuses.
 */

#define LAI_ACTIONS  12      /* actions the model can choose between */
#define LAI_FEATURES_MAX 32  /* feature slots at the highest grade */

/* Train on one example: `text` should be classified as action `label`.
 * Returns 1 when the model already predicted it, 0 when it had to correct. */
int localai_train(const char *text, const char *label);

/* Classify `text`, returning the action name. Never NULL. */
const char *localai_predict(const char *text);

/* Predict and run the resulting action. Returns 1 if an action was dispatched
 * from the model (as opposed to no confident match). */
int localai_act(const char *text);

/* Persist the weights to .sidwa. Returns 1 on success. */
int localai_save(void);

/* Load the weights from .sidwa. Returns 1 on success, 0 when nothing valid is
 * stored and the model keeps its current state. */
int localai_load(void);

/* Reload the model's precision for the current partition grade. Called after
 * the grade changes so weights are quantised to the new width. */
void localai_sync_grade(void);

/* Wipe the weights back to zero and forget the training count. */
void localai_reset(void);

u32 localai_examples(void);      /* training steps performed */
u32 localai_mistakes(void);      /* steps that needed a correction */
u32 localai_weight_bits(void);   /* precision for the current grade */
u32 localai_feature_count(void); /* feature slots in use */
u32 localai_model_bytes(void);   /* bytes the model occupies on disk */

/* The actions the model can choose between, by index. Used by callers that need
 * to weigh every candidate rather than accept the model's single best answer. */
u32 localai_action_count(void);
const char *localai_action_name(u32 index);

/* The model's raw score for one action on `text`. Positive means the model
 * leans that way, zero means it has no opinion. */
i32 localai_score(const char *text, const char *label);

/* Score every action on `text`, in action order, from one tokenisation. Same
 * results as localai_score() per action, without re-deriving the features. */
void localai_scores(const char *text, i32 *out, u32 max);

/* Classify every built-in example, learn from the misses, then classify again.
 * Returns 1 when the second pass classifies all of them correctly. */
int localai_selftest(void);

/* Log the current model: grade, precision, accuracy on the built-in set. */
void localai_report(void);

#endif /* OS_LOCALAI_H */
