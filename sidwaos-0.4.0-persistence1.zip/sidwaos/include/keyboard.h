#ifndef OS_KEYBOARD_H
#define OS_KEYBOARD_H

#include "types.h"

/* PS/2 keyboard, scancode set 1.
 *
 * IRQ1 is already unmasked by the interrupt setup, so this only has to install a
 * handler and turn raw scancodes into key events. Decoding happens in the
 * interrupt and the results go into a ring buffer, because the GUI consumes keys
 * at its own pace while the hardware keeps sending them.
 *
 * Keys are reported as printable ASCII where possible, with named codes for the
 * rest. Keeping the decode in one place means the GUI never sees a scancode.
 */

#define KEY_NONE      0
#define KEY_UP        0x101
#define KEY_DOWN      0x102
#define KEY_LEFT      0x103
#define KEY_RIGHT     0x104
#define KEY_ESC       0x105
#define KEY_TAB       0x106
#define KEY_ENTER     '\n'
#define KEY_BACKSPACE '\b'

void keyboard_init(void);

/* Next key, or KEY_NONE when the buffer is empty. */
u16 keyboard_get(void);

/* Next key, waiting for one to arrive. */
u16 keyboard_wait(void);

/* Number of keys waiting. */
u32 keyboard_pending(void);

/* Drop anything buffered, e.g. before taking over the screen. */
void keyboard_flush(void);

#endif /* OS_KEYBOARD_H */
