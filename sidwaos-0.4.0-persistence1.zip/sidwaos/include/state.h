#ifndef OS_STATE_H
#define OS_STATE_H

#include "types.h"
#include "app.h"

enum state {
    STATE_RUN = 0,   /* loop 1: CPU / stack / fast exit */
    STATE_HOLD,      /* loop 2: hang data + logic test */
    STATE_STORE,     /* loop 3: HDD persist, gated by serial key */
    STATE_DONE,
};

struct state_stats {
    u32 run_fragments;
    u32 run_corrupted;
    u32 hold_passed;
    u32 hold_failed;
    u32 store_written;
    u32 store_refused;
};

void state_machine_run(void);
void state_stats_dump(void);
struct state_stats *state_stats_get(void);

/* Transition logging, e.g. "[STATE] RUN -> HOLD". */
void state_log_transition(enum state from, enum state to);

/* Loop implementations. */
void loop_run(void);
void loop_hold(void);
int  loop_store(void);

/* Shared queue of validated programs, produced by HOLD and consumed by STORE. */
struct app_blob *hold_next_valid(void);
void hold_submit(const struct app_blob *blob);
int  hold_push(const struct app_blob *blob);
u32  hold_count(void);

#endif /* OS_STATE_H */
