#ifndef OS_METHOD_H
#define OS_METHOD_H

#include "types.h"

/* A programming method, written as a list of tasks to reach a working program.
 *
 * The method is a ladder of five loops. Each loop is a list of steps, and each
 * loop refines the one above it, so the same goal is described more concretely
 * at every level:
 *
 *   loop 1  what we want to achieve -- the goal and the aspect of the program
 *   loop 2  smaller pieces          -- the complete functions it needs
 *   loop 3  program objects         -- the data those functions work on
 *   loop 4  function declarations   -- the signatures, written before the bodies
 *   loop 5  pseudo code             -- the logic in plain words
 *
 * The point is the order. A programmer who starts at loop 5 writes code that
 * does not fit the goal; one who works down from loop 1 has a shape to type
 * into. The loops are held as data so the AI can hand them out one at a time,
 * the GUI can show them, and the command line can walk them.
 *
 * "Complete" in loop 2 is deliberate: a piece is only a piece if it can be
 * finished and tested on its own. A step that cannot is still a goal, not yet a
 * function, and belongs in loop 1 until it can be split.
 */

#define METHOD_MAX_STEPS 8
#define METHOD_STEP_MAX  72

struct method_loop {
    u8   number;
    const char *title;      /* what this loop produces */
    const char *question;   /* the question it answers */
    u32  steps;
    const char *step[METHOD_MAX_STEPS];
};

u32 method_count(void);

/* Loop by index (0-based), or NULL when out of range. */
const struct method_loop *method_get(u32 index);

/* Find a loop by keyword in its title or steps, e.g. "object" or "pseudo". */
const struct method_loop *method_find(const char *keyword);

/* Print one loop with its steps, numbered. */
void method_print(const struct method_loop *loop);

/* Print every loop in order. */
void method_print_all(void);

/* Write a loop to a buffer as "Loop N: title" plus its steps. Returns the number
 * of characters written. Used by the GUI. */
u32 method_format(const struct method_loop *loop, char *out, u32 max);

int method_selftest(void);

#endif /* OS_METHOD_H */
