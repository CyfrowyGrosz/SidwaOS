/* Freestanding string/memory helpers (kernel/lib.c). */
#ifndef OS_STRING_H
#define OS_STRING_H

#include "types.h"

void *memset(void *dst, int c, size_t n);
void *memcpy(void *dst, const void *src, size_t n);
int   memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
int   strcmp(const char *a, const char *b);
int   strncmp(const char *a, const char *b, size_t n);
char *strstr(const char *haystack, const char *needle);
char *stristr(const char *haystack, const char *needle);

#endif /* OS_STRING_H */
