#ifndef OS_IO_H
#define OS_IO_H

#include <stdint.h>

/* Port I/O primitives, implemented in cpu/io.asm. */
void     outb(uint16_t port, uint8_t  value);
void     outw(uint16_t port, uint16_t value);
void     outl(uint16_t port, uint32_t value);
uint8_t  inb(uint16_t port);
uint16_t inw(uint16_t port);
uint32_t inl(uint16_t port);

/* Short delay for slow legacy devices (writes to an unused port). */
void io_wait(void);

static inline void cli(void) { __asm__ volatile("cli"); }
static inline void sti(void) { __asm__ volatile("sti"); }
static inline void hlt(void) { __asm__ volatile("hlt"); }

#endif /* OS_IO_H */
