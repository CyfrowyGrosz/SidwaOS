#ifndef OS_TIMER_H
#define OS_TIMER_H

#include "types.h"

#define PIT_HZ 100

void timer_init(void);
u32  timer_ticks(void);

/* Busy-wait for `ms` milliseconds using the PIT tick counter. */
void timer_sleep_ms(u32 ms);

#endif /* OS_TIMER_H */
