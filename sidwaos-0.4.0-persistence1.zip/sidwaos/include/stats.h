#ifndef OS_STATS_H
#define OS_STATS_H

#include "types.h"

/* The four things worth watching on a machine this small, sampled on demand.
 *
 *   memory      how much of the kernel image is resident, and how much RAM the
 *               machine was given to hold it in
 *   cpu         how busy the processor has been since the previous sample, from
 *               the ticks spent halted waiting for input
 *   disk        how fast .sidwa reads and writes, timed against the ATA port
 *   link        how fast the network answers, timed against the gateway
 *
 * The point of sampling rather than asserting a fixed figure is that all four
 * depend on the host: a busy host slows the link, a QEMU cache setting changes
 * the disk number, and the CPU figure is a measurement of this run and nothing
 * else. A stat that never moves would not be a stat.
 *
 * Sampling the disk and the link both touch hardware, so they are only done
 * when the machine is up: stats_sample() reports what it can and leaves the
 * rest at zero with a note, rather than blocking the console.
 */

struct stats_sample {
    /* Memory, in bytes. `ram_bytes` is the total the bootloader reported;
     * `kernel_bytes` is the loaded image, from the link address to _kernel_end. */
    u32 ram_bytes;
    u32 kernel_bytes;

    /* Processor load over the sampling window, in tenths of a percent
     * (0..1000). One decimal place is enough to see the number move without
     * inventing precision the measurement does not have. */
    u32 cpu_load_tenths;

    /* .sidwa disk, in KiB per second. Zero when the disk is absent. */
    u32 disk_read_kbps;
    u32 disk_write_kbps;

    /* Network, in KiB per second, and the round trip that produced it in
     * microseconds. Zero when the link is down. */
    u32 link_kbps;
    u32 link_rtt_us;
};

/* Take a fresh sample of everything. Safe to call repeatedly; each call is a
 * measurement, not a cached value. The CPU figure covers the interval since the
 * previous call, so the first call after boot reports the boot itself. */
void stats_sample(struct stats_sample *out);

/* Tell the load accounting that the caller is about to halt waiting for work.
 * Called by the command line's input loop; nothing else should call it, or the
 * load figure will read lower than the machine really was. */
void stats_idle_wait(void);

/* Print a sample as one line per metric. */
void stats_report(void);

/* The most recent sample, for a caller that wants the numbers without taking a
 * new measurement. Zeroed until the first stats_sample(). */
const struct stats_sample *stats_last(void);

/* Exercise the arithmetic with fixed inputs: the load fraction, the KiB/s
 * conversion and the image-size calculation. Network- and disk-free, so it runs
 * in the boot selftest. Returns 1 on success. */
int stats_selftest(void);

#endif /* OS_STATS_H */
