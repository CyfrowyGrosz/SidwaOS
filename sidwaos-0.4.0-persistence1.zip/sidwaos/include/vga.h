#ifndef OS_VGA_H
#define OS_VGA_H

#include "types.h"

/* VGA text-mode console at 0xB8000.
 *
 * The kernel's only other output is the serial port, which is fine for logs but
 * has no screen. The GUI needs a real display, so this drives the 80x25 text
 * mode the firmware leaves us in: two bytes per cell, a character and a colour
 * attribute.
 *
 * Text mode rather than a pixel framebuffer because the GUI here is a windowed
 * text interface, and text mode gives 80x25 cells with no font or double
 * buffering to manage. Cell addressing also makes the MVC view a simple
 * function of the model: the view asks for a rectangle and writes characters.
 */

#define VGA_COLS 80
#define VGA_ROWS 25
#define VGA_BASE 0xB8000

/* Colour attributes, background in the high nibble. */
#define VGA_BLACK      0x0
#define VGA_BLUE       0x1
#define VGA_GREEN      0x2
#define VGA_CYAN       0x3
#define VGA_RED        0x4
#define VGA_MAGENTA    0x5
#define VGA_BROWN      0x6
#define VGA_LIGHTGRAY  0x7
#define VGA_DARKGRAY   0x8
#define VGA_LIGHTBLUE  0x9
#define VGA_LIGHTGREEN 0xA
#define VGA_LIGHTCYAN  0xB
#define VGA_LIGHTRED   0xC
#define VGA_YELLOW     0xE
#define VGA_WHITE      0xF

#define VGA_ATTR(fg, bg) ((u8)(((bg) << 4) | (fg)))

void vga_init(void);

/* Attribute used by the character-at-a-time calls below. */
void vga_set_attr(u8 attr);

void vga_clear(u8 attr);
void vga_putc_at(u32 x, u32 y, char c, u8 attr);
void vga_puts_at(u32 x, u32 y, const char *s, u8 attr);

/* Fill a rectangle with spaces in the given attribute. */
void vga_fill(u32 x, u32 y, u32 w, u32 h, u8 attr);

/* Draw a single-line box border. */
void vga_box(u32 x, u32 y, u32 w, u32 h, u8 attr);

/* Print at the cursor, which advances and scrolls at the bottom. */
void vga_puts(const char *s);
void vga_printf(const char *fmt, ...);
void vga_gotoxy(u32 x, u32 y);

/* Write a string clipped to `w` cells, padding the remainder with spaces so a
 * shorter value cannot leave the tail of a longer one on screen. */
void vga_puts_clipped(u32 x, u32 y, u32 w, const char *s, u8 attr);

#endif /* OS_VGA_H */
