#ifndef OS_CACHE_H
#define OS_CACHE_H

#include "types.h"

struct cache_info {
    u32 l1d_kb;
    u32 l2_kb;
    u32 l3_kb;
    u32 line_bytes;
};

/* Detect cache geometry via CPUID leaf 4, falling back to conservative
 * defaults when the leaf is unavailable. */
void cache_init(void);

const struct cache_info *cache_get(void);

/* Estimate how much L1 data cache is effectively free to the kernel by scanning
 * working-set sizes and finding the largest one that still runs at full speed.
 * This is the capacity actually available once the kernel image, stacks and
 * statics are resident, so it is usually smaller than the raw L1 size. */
u32 cache_probe_l1_free_kb(void);

/* Log cache geometry and the free estimate. */
void cache_report(void);

/* Read the time-stamp counter, for cycle-accurate probes. */
u64 tsc_read(void);

#endif /* OS_CACHE_H */
