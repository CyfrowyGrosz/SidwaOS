#ifndef OS_CONFIG_H
#define OS_CONFIG_H

#include "types.h"

/* Durable machine settings.
 *
 * Key/value pairs held on the .sidwa partition alongside knowledge, so a
 * setting survives a reboot. Records are written with a "cfg:" key prefix to
 * keep them apart from facts: know_recall() matches keys exactly, so a fact
 * query can never be served a setting by accident.
 *
 * This store is for settings the kernel itself acts on. It cannot grant the
 * machine network access -- web lookups run in the host agent (see ai.h) and
 * read their credentials from the host environment, never from here.
 */

#define CONFIG_KEY_MAX   48
#define CONFIG_VALUE_MAX 200

/* Set `key` to `value`, replacing any previous value. Returns 1 on success. */
int config_set(const char *key, const char *value);

/* Read `key` into `out`. Returns the value length, or -1 when unset. */
int config_get(const char *key, char *out, u32 max);

/* Remove `key`. Returns 1 if it was present. */
int config_del(const char *key);

/* Log one line per setting. */
void config_list(void);

/* Set, read back, overwrite and delete a key. Returns 1 on success. */
int config_selftest(void);

#endif /* OS_CONFIG_H */
