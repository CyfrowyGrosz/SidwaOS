#ifndef OS_RAND_H
#define OS_RAND_H

#include "types.h"

/* Seed the PRNG from PIT tick deltas and the CMOS/RTC. */
void rand_init(void);

/* xorshift32 step. */
u32 rand_u32(void);

/* A single random bit, used to randomize the fragment stack base. */
u32 rand_bit(void);

#endif /* OS_RAND_H */
