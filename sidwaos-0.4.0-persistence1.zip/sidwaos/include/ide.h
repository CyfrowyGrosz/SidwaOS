#ifndef OS_IDE_H
#define OS_IDE_H

#include "types.h"

/* The program IDE.
 *
 * A small text editor for SidwaASM programs, wired to the assembler and the VM.
 * It is where a program is written, assembled, and run, all inside the machine:
 * there is no host toolchain and no filesystem involved.
 *
 * The editor is a fixed grid of lines, which is all a freestanding kernel can
 * offer without a heap:
 *
 *   lines[0..n-1]   the source, one line per row
 *   cursor          line and column
 *   output          whatever the last run printed, or the assembler's error
 *
 * Keys, because a text-mode machine has no mouse:
 *
 *   printable        insert at the cursor
 *   Enter            split the line
 *   Backspace        delete before the cursor
 *   arrows           move the cursor
 *   Tab              load the next built-in example
 *   Ctrl-R           assemble and run
 *   Ctrl-L           clear the output pane
 *   Esc / Ctrl-Q     leave the IDE
 *
 * The editor is deliberately a separate module from the desktop GUI: the
 * desktop asks the IDE to draw and to take a key, and never reaches into the
 * editor's buffer. That keeps the two state machines independent.
 */

#define IDE_MAX_LINES  24
#define IDE_LINE_LEN   62
#define IDE_OUT_LINES  8
#define IDE_OUT_LEN    76

void ide_init(void);

/* Draw the editor into the GUI's body area. */
void ide_draw(void);

/* Feed one key to the editor. Returns 0 when the key asked to leave the IDE. */
int ide_handle_key(u16 key);

/* Assemble the buffer and run it, filling the output pane with the program's
 * output or the assembler's error. */
void ide_run(void);

/* Replace the buffer with built-in program `which`, modulo the library size. */
void ide_load_example(u32 which);

/* Read-only accessors, used by the self test. */
const char *ide_source(void);
const char *ide_output(void);
u32 ide_line_count(void);

/* Type a whole program through the key handler, so the test exercises the same
 * path a user does, then run it and check the output. Returns 1 on success. */
int ide_selftest(void);

#endif /* OS_IDE_H */
