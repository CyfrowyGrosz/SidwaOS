#ifndef OS_PCI_H
#define OS_PCI_H

#include "types.h"

/* Minimal PCI configuration-space access.
 *
 * Enough to find a device by vendor and device ID and read its BARs. The kernel
 * only needs one device (the NIC), so this is a scan, not a bus manager.
 *
 * Configuration space is reached through the 0xCF8/0xCFC pair: write the
 * "address" (bus, slot, function, register) to 0xCF8, then read or write the
 * data port.
 */

#define PCI_VENDOR_INVALID 0xFFFF

/* The class/subclass for a network controller, from a config-space read. */
struct pci_device {
    u8  bus, slot, func;
    u16 vendor, device;
    u8  class_code, subclass, prog_if;
    u8  irq;
    u32 bar[6];
};

/* Read a 32-bit config-space register for one device. */
u32 pci_read_config(u8 bus, u8 slot, u8 func, u8 offset);
void pci_write_config(u8 bus, u8 slot, u8 func, u8 offset, u32 value);

/* Find the first device matching vendor/device. Returns 1 and fills `out`. */
int pci_find_device(u16 vendor, u16 device, struct pci_device *out);

/* Find the first device in a class/subclass. Returns 1 and fills `out`. */
int pci_find_class(u8 class_code, u8 subclass, struct pci_device *out);

/* Log every device found on the bus, for the boot trace. */
void pci_list(void);

/* Is `bar` a memory BAR? Its base address, with the low flag bits cleared. */
int  pci_bar_is_mmio(u32 bar);
u32  pci_bar_addr(u32 bar);

#endif /* OS_PCI_H */
