#ifndef OS_CURRICULUM_H
#define OS_CURRICULUM_H

#include "types.h"

/* A C teaching curriculum for the local AI.
 *
 * The AI can already look facts up and classify requests. This gives it a body
 * of knowledge to actually teach: a short course in C, ending with the first
 * program everyone writes. The lessons are held as data, so the AI can hand them
 * out one at a time and the GUI can show them alongside the running machine.
 *
 * Each lesson carries a number, a title, and a body of a few lines. The bodies
 * are plain text so they can go to the serial log, the on-screen GUI, or a
 * spoken-style answer without reformatting.
 */

#define LESSON_MAX_LINES 8
#define LESSON_LINE_MAX  64

struct lesson {
    u8   number;
    const char *title;
    u8   lines;
    const char *body[LESSON_MAX_LINES];
};

/* A course is an ordered set of lessons with a name. There are two: the C
 * course, which teaches writing code, and the reverse-engineering course, which
 * teaches reading it. Both are taught through the same lesson machinery. */
struct course {
    const char *name;
    const struct lesson *lessons;
    u32 count;
};

u32 curriculum_courses(void);
const struct course *curriculum_course(u32 index);

/* The C course: lessons on writing programs. */
u32 curriculum_count(void);

/* Lesson by index (0-based), or NULL when out of range. */
const struct lesson *curriculum_get(u32 index);

/* Find a lesson by keyword in its title, e.g. "loop" or "hello". */
const struct lesson *curriculum_find(const char *keyword);

/* Print one lesson to the log, numbered and formatted. */
void curriculum_print(const struct lesson *lesson);

/* Print every lesson in order. */
void curriculum_print_all(void);

/* Print a lesson to a buffer as "N. title" plus its body lines. Returns the
 * number of characters written. Used by the GUI. */
u32 curriculum_format(const struct lesson *lesson, char *out, u32 max);

int curriculum_selftest(void);

/* The reverse-engineering course: lessons on reading compiled code. */
u32 rev_count(void);
const struct lesson *rev_get(u32 index);
const struct lesson *rev_find(const char *keyword);
void rev_print(const struct lesson *lesson);
void rev_print_all(void);
int rev_selftest(void);

#endif /* OS_CURRICULUM_H */
