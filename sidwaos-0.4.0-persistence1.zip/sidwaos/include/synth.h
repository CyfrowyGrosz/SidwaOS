#ifndef OS_SYNTH_H
#define OS_SYNTH_H

#include "types.h"
#include "sasm.h"
#include "ollama.h"

/* Program synthesis: the machine writes a program, then proves it works.
 *
 * This is the half of the AI that improvises. Everything else in the machine
 * answers questions from knowledge it already holds; this asks a model to write
 * a program for a task it has never seen, and then decides whether to believe
 * it.
 *
 * The deciding is the point. Improvisation is only safe when it cannot pass a
 * wrong answer off as a right one, and a program can be checked in a way a
 * sentence cannot: it can be assembled, run, and its output compared against
 * what was asked for. So the rule here is the same rule the knowledge cache
 * follows -- nothing is kept on one source -- except the second opinion is not
 * another model, it is the assembler and the virtual machine.
 *
 *   propose   the model writes SidwaASM for the task
 *   assemble  sasm_assemble(); a program that does not parse is not a program
 *   run       svm_run(); it must halt within the step limit, not run off the end
 *   check     its output must equal the output the task asked for
 *
 * Only a program that passes all four is remembered, and it is remembered as
 * knowledge under the task, so the next request for the same task is answered
 * from .sidwa without the network. A program that fails is recorded as a pedant
 * gap, so the machine can be taught the task it cannot yet do.
 *
 * Inputs are baked into the source as immediates rather than read at run time.
 * The instruction set has no input instruction, and adding one would change the
 * language every existing program is written in. A task therefore states its
 * inputs and the output they should produce, and the model writes a program
 * that computes that output from those constants.
 *
 * The measure of improvement is instruction count, not cycles. Every SidwaASM
 * instruction costs one VM step, so a shorter program is a faster program here,
 * and that is a claim the machine can actually check. It makes no claim about
 * wall-clock speed, which would depend on a real CPU's choice of instruction.
 */

#define SYNTH_TASK_MAX   160
#define SYNTH_EXPECT_MAX 192
#define SYNTH_SOURCE_MAX OLLAMA_CODE_MAX

/* How many times to ask for a program before giving up.
 *
 * One is not enough for a small model on a task that needs care -- printing a
 * string means one step per character, and qwen2.5:3b drops the last character
 * of "Hello World" most times it is asked. But an identical retry is useless:
 * the sampler is pinned to temperature 0, so the same prompt gives the same
 * wrong program every time. Each retry therefore carries the verifier's finding
 * back to the model -- what the previous attempt actually printed -- which is
 * the only thing that can change the answer.
 *
 * This is safe to do at all only because the gate runs on every attempt: a
 * retry can waste time but can never store a wrong program. */
#define SYNTH_ATTEMPTS   3

/* Expand the escapes a user can type in an expected output, in place. Only
 * \n is recognised, because that is the one a program's output actually needs:
 * OUT ends every number with a newline, so any task that prints more than one
 * number has a multi-line expectation. The command line gives the expectation
 * on a single line, so \n is how a multi-line result is written there.
 *
 * The expansion never lengthens the string, so it is safe to do in place. */
void synth_expand_escapes(char *s);

/* What happened to one synthesis request. */
#define SYNTH_OK        0   /* assembled, ran, and matched the expected output */
#define SYNTH_NO_MODEL  1   /* the model could not be reached */
#define SYNTH_NO_CODE   2   /* the reply held no program */
#define SYNTH_BAD_ASM   3   /* the program did not assemble */
#define SYNTH_BAD_RUN   4   /* it did not run to completion */
#define SYNTH_MISMATCH  5   /* it ran, but printed something else */

/* Ask the model for a program that prints `expect` for `task`, then prove it.
 * On success the source is in `source` and the program in `prog`. On any
 * failure the reason is logged, `source` may hold what was tried, and the task
 * is recorded as a gap so it can be taught. Returns a SYNTH_* code. */
int synth_write(const char *task, const char *expect,
                char *source, u32 source_max, struct sasm_program *prog);

/* Text for a SYNTH_* code. */
const char *synth_status_text(int code);

/* Assemble `source`, run it, and compare the output to `expect`. This is the
 * gate on its own, with no model involved, so it can be tested directly.
 * Returns SYNTH_OK, SYNTH_BAD_ASM, SYNTH_BAD_RUN or SYNTH_MISMATCH. */
int synth_check(const char *source, const char *expect,
                struct sasm_program *prog, char *out, u32 out_max);

/* The prompt handed to the model for `task` and `expect`. Exposed so the
 * selftest can assert it names every instruction the language has -- a prompt
 * that omits one asks the model to guess. */
void synth_prompt(const char *task, const char *expect, char *out, u32 max);

/* The prompt for a later attempt: the same request with `got`, what the
 * previous program actually printed, quoted back to the model. A retry of an
 * unchanged prompt is useless under temperature 0, so this is what makes a
 * second attempt worth making. */
void synth_prompt_retry(const char *task, const char *expect,
                        const char *got, char *out, u32 max);

int synth_selftest(void);

#endif /* OS_SYNTH_H */
