#ifndef OS_VERSION_H
#define OS_VERSION_H

#define SIDWAOS_NAME    "SidwaOS"
#define SIDWAOS_TAGLINE "3-state I/O machine"
#define SIDWAOS_VERSION "0.4.0"

#endif /* OS_VERSION_H */
