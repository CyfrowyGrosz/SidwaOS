#ifndef OS_KNOW_H
#define OS_KNOW_H

#include "types.h"

/* Knowledge cache and lookup.
 *
 * The local AI can only classify what it has learned. When it meets a request it
 * does not know, it needs facts, and this module supplies them in three tiers,
 * cheapest first:
 *
 *   1. RAM   -- recently looked-up facts, held in a small hash table
 *   2. HDD   -- facts persisted on the .sidwa partition from earlier sessions
 *   3. WEB   -- a lookup through the host agent (see ai_lookup_remote)
 *
 * Tier 1 exists because the disk is slow and a repeated question should not
 * cost a disk read, let alone a network round trip. Tier 2 exists because RAM
 * does not survive a reboot. Tier 3 is the only tier that reaches outside the
 * machine.
 *
 * Only knowledge reaches the disk. A fact starts unverified in RAM, and is
 * written to the partition only once it has been corroborated -- either by an
 * independent lookup returning the same answer, or by an explicit verify. A
 * guess, a wrong answer or a failed lookup stays in RAM and is dropped when the
 * cache turns over; a logical mistake is never persisted as knowledge. This is
 * why know_remember() alone cannot write to disk.
 */

#define KNOW_KEY_MAX   48
#define KNOW_VALUE_MAX 240

/* Look up `query`. Checks RAM, then the partition. Returns the value length, or
 * -1 when neither tier has it. The caller then falls back to the web tier. */
int know_recall(const char *query, char *out, u32 max);

/* Read a fact from RAM only, without counting a hit and without touching the
 * disk. Used to compare a fresh answer against what is already held. */
int know_peek_ram(const char *query, char *out, u32 max);

/* Hold a fact in RAM. It is unverified and is NOT written to the partition:
 * unproven data must not become durable knowledge. */
void know_remember(const char *query, const char *value);

/* Promote a RAM fact to verified and persist it to the partition. This is the
 * only path by which knowledge is written to disk. Returns 1 on success. */
int know_verify(const char *query);

/* Drop a fact from RAM and delete its record from the partition, for knowledge
 * that later turns out to be wrong. Returns 1 if anything was removed. */
int know_forget(const char *query);

u32 know_cache_count(void);
u32 know_verified_count(void);
u32 know_unverified_count(void);
u32 know_cache_hits(void);

/* Log the cache contents, split into verified and unverified. */
void know_report(void);

/* Exercise all three tiers, then remove the test fact so no junk is left on the
 * partition. Returns 1 on success. */
int know_selftest(void);

#endif /* OS_KNOW_H */
