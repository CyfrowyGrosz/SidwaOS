#ifndef OS_NET_H
#define OS_NET_H

#include "types.h"

/* IPv4 network stack with a real HTTP client.
 *
 * Layering, from the wire up:
 *
 *   Ethernet  -- the RTL8139 driver moves frames
 *   ARP       -- address resolution, with a small cache
 *   IPv4      -- addressing, checksums, demultiplexing by protocol
 *   ICMP      -- echo request/reply, which is what `ping` uses
 *   UDP       -- datagrams, used by DNS
 *   TCP       -- a client-side subset: connect, send, receive, close
 *   DNS       -- a resolver that walks the host's configured name server
 *   HTTP      -- GET a URL over TCP and return the body
 *
 * There is no DHCP client and no routing table. The address is whatever
 * net_configure() is told, which the `net` command takes from the command line.
 * QEMU's user-mode network hands out 10.0.2.15 with a gateway of 10.0.2.2 and a
 * DNS server of 10.0.2.3, so those are the defaults.
 *
 * Everything is polled and single-threaded. A receive path runs to completion
 * inside net_poll(), which is why the stack can use plain static buffers and
 * cannot deadlock against itself.
 */

#define NET_MTU         1500
#define NET_FRAME_MAX   1514
#define NET_IP_MAX      64
#define NET_ARP_MAX     16
#define NET_TCP_WINDOW  4096

/* Configuration, all in network byte order once set. */
struct net_config {
    u8  ip[4];
    u8  mask[4];
    u8  gateway[4];
    u8  dns[4];
};

/* Bring up the NIC and set the address. Returns 1 on success. */
int  net_init(void);
int  net_ready(void);

/* Set the address from dotted-quad text, e.g. "10.0.2.15". Any argument may be
 * NULL to leave that field alone. Returns 1 when every field parsed. */
int  net_configure(const char *ip, const char *mask,
                   const char *gateway, const char *dns);

const struct net_config *net_config_get(void);
u32  net_rx_frames(void);
u32  net_tx_frames(void);

/* Resolve a dotted quad into 4 bytes. Returns 1 on success. */
int  net_parse_ip(const char *text, u8 out[4]);
/* Format 4 bytes as "a.b.c.d". `out` must hold 16 bytes. */
void net_format_ip(const u8 ip[4], char *out);

/* --- Link and network ------------------------------------------------------- */

/* Resolve `ip` to a MAC, sending ARP requests and polling for a reply. Returns 1
 * and fills `mac_out` on success. */
int  net_arp_resolve(const u8 ip[4], u8 mac_out[6]);

/* Send an ICMP echo request and wait for the matching reply. Returns the
 * round-trip time in milliseconds, or -1 on timeout. */
int  net_ping(const u8 ip[4], u32 timeout_ms);

/* Resolve a host name to an address through the configured DNS server. Returns 1
 * on success. */
int  net_dns_resolve(const char *name, u8 out[4]);

/* --- HTTP ------------------------------------------------------------------- */

/* Fetch an http:// URL and copy the response body into `body`. Returns the body
 * length, or -1 on any failure. `header_out` (may be NULL) receives the raw
 * status line and headers. */
int  net_http_get(const char *url, char *body, u32 body_max,
                  char *header_out, u32 header_max);

/* The general form: any method, with an optional request body. A NULL or empty
 * `body_in` sends no body and no Content-Length, which is what GET wants. */
int  net_http_request(const char *method, const char *url,
                      const char *content_type, const char *body_in,
                      char *body, u32 body_max,
                      char *header_out, u32 header_max);

/* The general form with an explicit wait budget, in timer ticks (100 Hz).
 * `ceiling_ticks` bounds the whole request and `idle_ticks` the longest gap
 * with no new bytes. See net_http_post_json_timed(). */
int  net_http_request_timed(const char *method, const char *url,
                            const char *content_type, const char *body_in,
                            char *body, u32 body_max,
                            char *header_out, u32 header_max,
                            u32 ceiling_ticks, u32 idle_ticks);

/* Called while a request is waiting for its reply, once at the start and then
 * once per whole second, with the ticks elapsed so far. A request to a model
 * can sit silent for most of a minute, and without this the machine looks
 * frozen: the wait is real work, and this is how the caller shows it. Pass NULL
 * for no reporting. */
typedef void (*net_progress_fn)(u32 elapsed_ticks);

int  net_http_request_progress(const char *method, const char *url,
                               const char *content_type, const char *body_in,
                               char *body, u32 body_max,
                               char *header_out, u32 header_max,
                               u32 ceiling_ticks, u32 idle_ticks,
                               net_progress_fn progress);

/* POST a JSON body. Used to ask a local model server a question. */
int  net_http_post_json(const char *url, const char *json,
                        char *body, u32 body_max,
                        char *header_out, u32 header_max);

/* POST with an explicit wait budget, in timer ticks (100 Hz).
 *
 * The defaults in net_http_post_json() are sized for a web server that answers
 * as soon as it is asked. A local language model does not: it computes the
 * whole reply before sending the first byte, so a request that is working
 * perfectly can sit silent for tens of seconds. `ceiling_ticks` bounds the
 * whole request and `idle_ticks` the longest gap with no new bytes; a caller
 * that knows its server is slow raises both rather than being cut off. */
int  net_http_post_json_timed(const char *url, const char *json,
                              char *body, u32 body_max,
                              char *header_out, u32 header_max,
                              u32 ceiling_ticks, u32 idle_ticks);

/* POST with an explicit wait budget and a progress callback, for a server slow
 * enough that the wait needs showing. See net_http_request_progress(). */
int  net_http_post_json_progress(const char *url, const char *json,
                                 char *body, u32 body_max,
                                 char *header_out, u32 header_max,
                                 u32 ceiling_ticks, u32 idle_ticks,
                                 net_progress_fn progress);

/* Report the configuration and counters. */
void net_report(void);

/* One turn of the receive path: drain the ring and dispatch each frame. Called
 * by the receive loop inside the stack; exposed so a caller can pump it. */
void net_poll(void);

/* Probe the NIC and print what was found, without configuring an address. Used
 * at boot so the trace shows whether a card is present. */
int  net_probe(void);

/* Send an ICMP echo to the gateway and check the reply, then resolve a name and
 * fetch a small page. Returns 1 when the local link works, independent of
 * whether the wider internet is reachable. */
int  net_selftest(void);

#endif /* OS_NET_H */
