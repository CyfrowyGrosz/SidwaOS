#ifndef OS_AIDEBUG_H
#define OS_AIDEBUG_H

#include "types.h"

/* AI auto-debug: automatic diagnosis and recovery for faults.
 *
 * On a CPU exception the kernel prints the raw machine state, classifies the
 * fault into a known cause, reports a diagnosis and a suggested fix, and — for
 * faults that are safe to survive — repairs the situation and resumes instead of
 * hanging. Every episode is recorded so `debug` can show what happened and
 * `debug learn` can report how often each class has recurred.
 *
 * The classifier is deliberately a table, not a model: it must run in a fault
 * handler with no guarantees about memory or the stack. The same diagnosis text
 * is emitted on the AI bridge channel, so a host-side agent sees the fault and
 * can propose a repair for the cases the table cannot resolve.
 */

#define FAULT_MAX_CLASSES 8

struct fault_record {
    const char *cause;
    const char *fix;
    u32 count;
    u32 last_int_no;
    u32 last_eip;
};

/* Classify and report a fault. `r` is the register frame from the ISR.
 * Returns 1 when the kernel can resume after recovery, 0 when it must stop. */
int aidebug_handle_fault(void *regs);

/* Print every fault class seen so far, with counts. */
void aidebug_dump(void);

/* Print the recovery statistics (episodes, recovered, fatal). */
void aidebug_stats(void);

/* Exercise the classifier against a set of synthetic faults, to prove the
 * diagnoses are reachable without crashing the machine. Returns 1 if all
 * expected causes were produced. */
int aidebug_selftest(void);

#endif /* OS_AIDEBUG_H */
