#ifndef OS_FETCH_H
#define OS_FETCH_H

#include "types.h"

/* Fetch a page and learn from it.
 *
 * The network stack can already fetch a URL, and the knowledge cache can
 * already hold facts. This module is the flow that joins them: fetch a page,
 * turn it into plain text, find the part that answers a question, and offer it
 * to the knowledge cache.
 *
 * The joining is where the care is, because the knowledge cache has a rule and
 * this module must not break it: a fact reaches the .sidwa partition only once
 * it has been corroborated. A web page is not corroboration of itself. So a
 * single fetch learns into RAM only, where the fact is held as unverified and
 * may be dropped, and nothing is written to disk.
 *
 * Two fetches of two different sources that agree are corroboration, and that
 * is what fetch_corroborate() is for: it fetches both, extracts the answer from
 * each, and persists only when the two agree. This is the same standard the
 * rest of the machine holds to -- a guess is never written down as knowledge --
 * applied to the web, which is the least reliable source the machine has.
 *
 * The page-to-answer step is plain text processing with no network in it, so it
 * is tested at boot, when the machine has no network yet. The fetch itself is
 * exercised from the command line, where the stack is up.
 */

#define FETCH_TEXT_MAX   4096   /* cleaned page text */
#define FETCH_ANSWER_MAX 240    /* one extracted answer */
#define FETCH_KEY_MAX    48     /* the question, as a cache key */

/* Fetch `url` and clean the response body into plain text in `out`: tags
 * removed, script and style blocks dropped, common entities decoded, runs of
 * whitespace collapsed. Returns the text length, or -1 when the fetch failed.
 *
 * This is the only function here that touches the network. */
int fetch_text(const char *url, char *out, u32 max);

/* Clean HTML into plain text in `out`. Network-free, so the selftest can
 * exercise it on fixed input. Returns the text length. */
u32 fetch_clean(const char *html, char *out, u32 max);

/* The best answer to `question` within `text`, without any network access.
 * Splits the text into sentences, scores each by how many of the question's
 * words it contains, and copies the highest scoring one to `out`. Returns the
 * length, or 0 when no sentence mentions any of the question's words.
 *
 * Exposed and network-free so the selftest can exercise it on fixed input. */
u32 fetch_extract(const char *text, const char *question, char *out, u32 max);

/* Fetch `url`, extract the answer to `question`, and hold it in RAM as
 * unverified knowledge. Nothing is written to the partition: one page cannot
 * corroborate itself. Returns the answer length, or -1 on failure. */
int fetch_learn(const char *url, const char *question, char *answer,
                u32 answer_max);

/* Whether two extracted answers corroborate each other, ignoring case and
 * punctuation. Network-free, so the selftest can check both outcomes. */
int fetch_answers_agree(const char *a, u32 alen, const char *b, u32 blen);

/* Fetch two sources and persist the answer only if they agree. Returns 1 when
 * the answer was corroborated and stored on .sidwa, 0 when the sources
 * disagreed (the first answer is still held in RAM, unverified), and -1 when a
 * fetch failed. */
int fetch_corroborate(const char *url_a, const char *url_b,
                      const char *question, char *answer, u32 answer_max);

/* Cumulative counters, for the report. */
u32 fetch_pages(void);      /* pages fetched */
u32 fetch_bytes(void);      /* bytes of cleaned text produced */
u32 fetch_learned(void);    /* answers extracted */
u32 fetch_corroborated(void);/* answers confirmed by a second source */

/* Log the counters and the last extracted answer. */
void fetch_report(void);

/* Exercise the network-free parts: cleaning and extraction on fixed input, and
 * that a single fetch is never treated as corroboration. Returns 1 on
 * success. */
int fetch_selftest(void);

#endif /* OS_FETCH_H */
