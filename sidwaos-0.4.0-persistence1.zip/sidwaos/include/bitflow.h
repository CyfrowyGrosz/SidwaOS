/* 4+4 bit flow combiner.
 *
 * Two independent 4-bit flows are combined into one 8-bit flow ("4 bit + 4 bit
 * in one flow"). Each 4-bit flow is a stream of nibbles; combining pairs them
 * lane A as the high nibble and lane B as the low nibble of each output byte.
 *
 * This is how Loop 1 assembles a program fragment: the two half-byte flows are
 * merged into a single runnable byte flow immediately before execution.
 */
#ifndef OS_BITFLOW_H
#define OS_BITFLOW_H

#include "types.h"

/* Combine nibble lanes A (high) and B (low) into `count` bytes. */
void bitflow_combine(const u8 *a, const u8 *b, u8 *dst, u32 count);

/* Combine in place: dst holds lane A, src holds lane B. Safe when dst == a. */
void bitflow_combine_inplace(u8 *a, const u8 *b, u32 count);

/* Combine with a carry: when a+b overflows 8 bits the carry propagates into the
 * next byte, so the two 4-bit flows form one continuous 4-bit-at-a-time stream. */
void bitflow_combine_carry(const u8 *a, const u8 *b, u8 *dst, u32 count);

/* Verify that combining A and B then re-extracting recovers both lanes. */
int bitflow_combine_selftest(const u8 *a, const u8 *b, u32 count);

/* Extract the two lanes back out of a combined byte flow. */
void bitflow_extract(const u8 *src, u8 *a, u8 *b, u32 count);

/* --- Process combination ---------------------------------------------------
 *
 * A "process" is one operation encoded in `width` bits. Loop 1 combines two
 * different processes -- any operation plus any operation -- into a single flow
 * by packing A into the high bits and B into the low bits. The combined flow is
 * at most 64 bits, so a->width + b->width must not exceed 64.
 */
#define BITFLOW_MAX_BITS 64

struct bitflow_process {
    u64 code;
    u8 width;
    const char *name;
};

/* Pack A (high) and B (low) into one 64-bit flow. Returns 1 on success, 0 if the
 * widths are zero or their sum exceeds BITFLOW_MAX_BITS. */
int bitflow_combine_processes(const struct bitflow_process *a,
                              const struct bitflow_process *b, u64 *dst);

/* Recover both operations from a combined flow. */
void bitflow_split_process(u64 flow, u8 width_a, u8 width_b,
                           u64 *a, u64 *b);

/* Round-trip every pair of the built-in operations through the combiner.
 * Returns 1 if all pairs survive combine-then-split unchanged. */
int bitflow_process_selftest(void);

/* Pack `count` operations into one 64-bit flow, procs[0] in the highest bits.
 * The number of operations is limited only by their total width: ten 6-bit
 * operations fit (60 bits), ten 8-bit operations do not (80 bits). Returns 1 on
 * success, 0 if any width is zero or the total exceeds BITFLOW_MAX_BITS. */
int bitflow_combine_many(const struct bitflow_process *procs, u32 count,
                         u64 *dst);

/* Recover `count` operations from a flow. `widths[i]` is the width of the i-th
 * operation, in the same order used to combine. Returns 1 on success. */
int bitflow_split_many(u64 flow, const u8 *widths, u32 count, u64 *out);

/* Verify that a flow packed from `count` equal-width operations round-trips, and
 * report the packing through `dst`. Returns 1 on success. */
int bitflow_selftest_many(u32 count, u8 width, u64 *dst);

#endif /* OS_BITFLOW_H */
