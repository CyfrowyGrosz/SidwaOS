#ifndef OS_RTL8139_H
#define OS_RTL8139_H

#include "types.h"

/* Realtek RTL8139 NIC driver, in I/O-port mode with polling.
 *
 * The card is found by scanning PCI configuration space for vendor 0x10EC and
 * device 0x8139. There is no interrupt handler: the kernel polls the interrupt
 * status register instead. That keeps the driver out of interrupt context, where
 * the network stack could not safely run, and a text-mode machine has nothing
 * better to do than spin while a packet is in flight.
 *
 * The receive ring is an 8 KiB buffer with the card's WRAP bit set, so a packet
 * is never split across the end of the ring. That removes the fiddliest part of
 * the driver at the cost of a smaller ring, which is the right trade for a
 * request/response client.
 */

/* Probe PCI, reset the card and bring it up. Returns 1 on success. */
int  rtl8139_init(void);

int  rtl8139_present(void);
const u8 *rtl8139_mac(void);
u16  rtl8139_io_base(void);
u32  rtl8139_rx_count(void);
u32  rtl8139_tx_count(void);

/* Send one Ethernet frame. The driver pads it to the 60-byte minimum. */
int  rtl8139_send(const void *frame, u32 len);

/* Receive one frame into `buf`. Returns the frame length, or -1 when the ring
 * is empty. */
int  rtl8139_recv(void *buf, u32 max);

#endif /* OS_RTL8139_H */
