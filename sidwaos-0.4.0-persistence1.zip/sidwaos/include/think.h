#ifndef OS_THINK_H
#define OS_THINK_H

#include "types.h"

/* Deliberate reasoning: the slow, checkable path to a decision.
 *
 * The machine already answers in one step. localai_predict() is intuition: it
 * scores the request and returns the best action immediately. It is fast and
 * usually right, and it has no idea whether it is right -- a confident wrong
 * answer costs nothing at the moment it is given.
 *
 * Thinking is the opposite trade. It spends more time and produces a decision
 * that carries its own working: a trace of what was considered, what the
 * evidence was, and how close the call was. Two properties follow from that:
 *
 *   1. Every candidate is scored, not just the winner, so a decision can be
 *      reported as close or clear rather than presented as certain.
 *   2. Evidence can be found insufficient. When nothing supports an action the
 *      result is THINK_UNSURE, not a guess. A machine that answers "I do not
 *      know" is more useful than one that always answers.
 *
 * The evidence is the machine's own, in three independent kinds:
 *
 *   rules   the keyword rules in ai.c -- what the words plainly say
 *   model   localai's learned weights -- what similar requests meant before
 *   record  outcome tallies -- which actions have actually achieved results
 *
 * The three disagree in useful ways. A rule fires on a literal word; the model
 * generalises past it; the record knows which of two plausible actions has
 * worked. Thinking counts the agreement and weights the record highest, because
 * results are the only evidence that is about the world rather than the text.
 *
 * The reasoning is replayed as a trace so the caller can see it, and the
 * decision is fed back to the model as a training example, so a hard call made
 * slowly once becomes a fast call next time. That feedback is what makes this
 * a thinking algorithm rather than a second opinion.
 */

/* A decision and its confidence. */
enum think_result {
    THINK_UNSURE = 0,   /* evidence too thin: refuse rather than guess */
    THINK_GUESS  = 1,   /* no candidate won on evidence; the best raw score won */
    THINK_LEAN   = 2,   /* one candidate led, but not decisively */
    THINK_CLEAR  = 3,   /* one candidate led on every kind of evidence */
};

/* How many candidates a single thought will weigh. */
#define THINK_CANDIDATES 8

/* Upper bound on the model's action set, so the batch score array is a fixed
 * size. Kept in step with LAI_ACTIONS. */
#define THINK_ACTIONS_MAX 16

/* Consider `text` and choose an action, without running it. This is the step
 * that takes time; think_act() is this followed by the dispatch.
 *
 * Returns the chosen action name (never NULL -- an unsure result still names
 * the best candidate so the trace has something to report), and writes the
 * confidence to *result. *trace, when not NULL, receives the reasoning as
 * newline-separated lines. */
const char *think_consider(const char *text, enum think_result *result,
                           char *trace, u32 trace_max);

/* Consider and then run the chosen action. Returns 1 when an action ran, 0
 * when the machine was unsure and declined to act. */
int think_act(const char *text);

/* Run an already-chosen action, record its result and teach the model. Shared
 * by think_act() and the command line so a reasoned decision is fed back the
 * same way however it was reached. Returns 1 when the action ran. */
int think_commit(const char *text, const char *choice);

/* Run a handful of requests through the thinking path and check that the
 * verdicts match the evidence: a clear request is clear, an empty one is
 * unsure, and a tie is reported as such. Leaves the model and the tallies as
 * it found them. Returns 1 on success. */
int think_selftest(void);

/* The weighted total for one candidate, from which kinds of evidence support it
 * (rules, model, record) and its net outcome score. The record is weighted to
 * dominate the other two, so a measured result beats text-based agreement.
 * Exposed so the ordering can be asserted without touching real tallies. */
i32 think_weigh(int rule, int model, i32 rec);

/* Cumulative counters, for the report. */
u32 think_count(void);       /* thoughts performed */
u32 think_unsure_count(void);/* thoughts that declined to act */
u64 think_cycles(void);      /* total cycles spent thinking */

/* Log the counters and the last trace. */
void think_report(void);

/* Time the slow and fast ways to score every action on `text` (or a default
 * probe when `text` is NULL) and check they agree. The optimisation course
 * applied to the machine's own reasoning. Returns 1 when the scores match. */
int think_bench(const char *text);

#endif /* OS_THINK_H */
