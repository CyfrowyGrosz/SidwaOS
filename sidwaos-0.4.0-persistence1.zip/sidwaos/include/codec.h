#ifndef OS_CODEC_H
#define OS_CODEC_H

#include "types.h"
#include "sasm.h"

/* Binary encoding for assembled programs, and the optimisation of it.
 *
 * An assembled program is an array of struct sasm_insn, which is 8 bytes each
 * in memory: four bytes of fields and a 32-bit immediate, with the field bytes
 * mostly padding. That is fine to run and wasteful to store, and the .sidwa
 * partition is small.
 *
 * Two formats are offered, and the difference between them is the whole lesson:
 *
 *   raw     eight bytes per instruction, a straight copy of the struct.
 *           Nothing to get wrong, and nothing saved.
 *   packed  a 16-bit descriptor plus the immediate in as few bytes as it needs.
 *           op, mode, dst and src come to eleven bits, so all four fit one
 *           word; the immediate is omitted entirely when it is zero.
 *
 * Packed is byte-aligned on purpose. A bit-packed stream would be a little
 * smaller and much slower to read, because every field would need a shift and a
 * mask across a byte boundary. Keeping the descriptor on a two-byte boundary
 * means the decoder is a 16-bit load and the encoder is a 16-bit store, so the
 * size is recovered without paying for it in time.
 *
 * The optimisation itself is inside the encoder. The obvious way to write a
 * packed stream is a bit writer: push each field a bit at a time into an
 * accumulator. It works, and it is slow, because a five-bit field costs five
 * iterations. Because the four fields together fit a word, the fast encoder
 * builds that word and stores it once. Both produce the same bytes; the
 * self test checks that, and codec_opt() measures the difference in cycles.
 * That is the optimisation course applied to the machine's own file format.
 */

/* Stream magic, "SDBC". */
#define CODEC_MAGIC 0x43424453u

/* Formats. */
#define CODEC_FMT_RAW     0
#define CODEC_FMT_PACKED  1
#define CODEC_FMT_COUNT   2

/* Raw is fixed width; packed never exceeds this per instruction. */
#define CODEC_RAW_BYTES_PER_INSN 8
#define CODEC_MAX_BYTES          2048

/* Encode `count` instructions into `out` in `fmt`. Returns the number of bytes
 * written, or 0 if they do not fit. */
u32 codec_encode(const struct sasm_insn *code, u32 count, u8 *out, u32 max,
                 u8 fmt);

/* Decode up to `max` instructions from `in`. Returns the number decoded, or 0
 * on a malformed stream. */
u32 codec_decode(const u8 *in, u32 len, struct sasm_insn *code, u32 max,
                 u8 fmt);

/* Human-readable format name, e.g. "packed". */
const char *codec_format_name(u8 fmt);

/* Encode a program in both formats and report the sizes and the saving. */
void codec_report(const struct sasm_program *prog);

/* Time the bit-at-a-time encoder against the word-at-a-time one on `prog`, and
 * check they emit the same bytes. Logs the cycles and the ratio. Returns 1 when
 * the two encoders agree. */
int codec_opt(const struct sasm_program *prog);

/* Assemble the built-in example, encode it every way, decode it back and check
 * the instructions are unchanged; then run codec_opt() on it. Returns 1 on
 * success. */
int codec_selftest(void);

#endif /* OS_CODEC_H */
