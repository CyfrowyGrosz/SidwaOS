#ifndef OS_AI_H
#define OS_AI_H

#include "types.h"

/* AI bridge: hand a free-text request to a host-side agent.
 *
 * The kernel cannot hold a language model, so it speaks a tiny line protocol
 * over the same serial port used by the command line:
 *
 *   kernel -> host   "\x01AI <request>\n"
 *   host   -> kernel "\x01ACT <command> <arg>\n"   one or more actions
 *                    "\x01SAY <text>\n"           optional narration
 *                    "\x01END\n"                  end of reply
 *
 * Lines without the \x01 prefix are printed as agent prose. If no host agent
 * answers within the timeout, the request falls back to local keyword matching,
 * so the kernel still works with nothing attached.
 */
void ai_set_mode(int on);
int  ai_mode(void);

/* Interpret `text` and run whatever it asks for. */
void ai_ask(const char *text);

/* Knowledge lookup. Checks the RAM cache, then the .sidwa partition, then the
 * host agent (which may reach the network). A result fetched from the host is
 * remembered, so the same question is never asked of the network twice.
 *
 * Returns the answer length, or -1 when nothing could be found. */
/* The built-in keyword rules for `text`, most specific first, written into
 * `out` (up to `max`). Returns how many matched. Exposed so the thinking
 * algorithm can weigh the rules against the model and the machine's record. */
u32 ai_rule_actions(const char *text, const char **out, u32 max);

int ai_lookup(const char *query, char *out, u32 max);

#endif /* OS_AI_H */
