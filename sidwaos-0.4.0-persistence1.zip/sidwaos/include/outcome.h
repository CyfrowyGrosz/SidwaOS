#ifndef OS_OUTCOME_H
#define OS_OUTCOME_H

#include "types.h"

/* Learning from results.
 *
 * The keyword rules and the learned model both pick an action from the words in
 * a request. Neither of them knows whether that action actually worked. This
 * module remembers, and lets the machine prefer the method that has worked
 * before over one that has not.
 *
 * Every dispatch is scored: an action that ran and produced a result counts as
 * a success, one that matched nothing counts as a failure. The running tally is
 * kept per action and persisted to the .sidwa partition, so the machine keeps
 * its record across reboots.
 *
 * This is a second, slower kind of learning than the model weights. The model
 * learns what a request means; the tallies learn which answer is worth giving.
 * When several rules match the same request, the tallies break the tie.
 */

#define OUTCOME_MAX      24
#define OUTCOME_NAME_MAX 24

/* Forget every tally. */
void outcome_reset(void);

/* Record how `action` turned out. A non-zero `success` means the action ran and
 * achieved a result. */
void outcome_record(const char *action, int success);

/* Net record for an action: successes minus failures, or 0 when it has no
 * history. Used to rank competing actions. */
int outcome_score(const char *action);

u32 outcome_attempts(const char *action);
u32 outcome_successes(const char *action);

/* Pick the action with the best achieved results from `names`. Returns names[0]
 * when no candidate has a record, or NULL when there are no candidates. The
 * order of `names` is the tie-break, so a stable rule order still decides
 * between equally successful actions. */
const char *outcome_best(const char *const *names, u32 count);

/* Persist the tallies to .sidwa, replacing any earlier copy. Returns 1 on
 * success. */
int outcome_save(void);

/* Load the tallies from .sidwa, replacing what is held. Returns 1 when a record
 * was found. */
int outcome_load(void);

/* Number of actions with a record. */
u32 outcome_action_count(void);

/* The action at `rank` when ordered best score first. Returns NULL when rank is
 * out of range. The view uses this so it does not have to re-sort the tallies. */
const char *outcome_ranked(u32 rank);

/* Log one line per action with a record, best first. */
void outcome_report(void);

/* Record, rank, persist, reload and compare. Returns 1 on success. */
int outcome_selftest(void);

#endif /* OS_OUTCOME_H */
