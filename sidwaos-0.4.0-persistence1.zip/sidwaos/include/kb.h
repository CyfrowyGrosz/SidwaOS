#ifndef OS_KB_H
#define OS_KB_H

#include "types.h"

/* The .sidwa knowledge partition.
 *
 * A fixed region of the disk, separate from the program blobs (LBA 64) and the
 * STORE scratch area (LBA 128), that holds durable key/value records. The
 * learned model and the query log live here, so knowledge survives a reboot.
 *
 * Records are fixed-size slots. The slot size is the compression grade:
 *
 *   grade 1  480 bytes/slot, 1 slot per sector   no compression
 *   grade 2  240 bytes/slot, 2 slots per sector  light compression
 *   grade 3  120 bytes/slot, 4 slots per sector  maximum compression
 *
 * A smaller slot packs more records into the partition but truncates anything
 * longer, so raising the grade is a real trade: capacity up, per-record size
 * down. kb_set_grade() rewrites the partition in the new layout.
 */

/* The partition's absolute LBA comes from the disk layout (include/layout.h);
 * KB_LBA there is the offset from the disk base. KB_SECTORS is the size. */
#define KB_SECTORS     512
#define KB_MAGIC       "SIDWAKB1"
#define KB_VERSION     1u
#define KB_REC_MAGIC   0x4B425344u   /* "DSBK" */

/* Payload bytes available in a slot at each grade. */
#define KB_GRADE1_DATA 480
#define KB_GRADE2_DATA 240
#define KB_GRADE3_DATA 120

/* Largest payload any grade can hold. */
#define KB_DATA_MAX    KB_GRADE1_DATA

/* Records in the partition at grade 1. */
#define KB_MAX_RECORDS KB_SECTORS

/* Mount the partition, formatting it if the magic is absent or the checksum
 * fails. Returns 1 when the partition is usable. */
int kb_mount(void);

/* Append a record. Returns the record's sequence number, or -1 on failure
 * (full partition, or no partition mounted). */
int kb_append(const void *data, u32 len);

/* Read record `seq` into `out`. Returns the payload length, or -1 if the record
 * is absent or its checksum fails. */
int kb_read(u32 seq, void *out, u32 max);

u32 kb_count(void);          /* live records */
u32 kb_capacity(void);       /* slots available at the current grade */
u32 kb_grade(void);          /* 1, 2 or 3 */
u32 kb_data_bytes(void);     /* payload bytes per slot */

/* Walk the records in order. Start with *cursor == 0; returns the payload
 * length and stores the record's sequence number in *seq_out, or -1 at the end.
 * Used by callers that need to scan the partition rather than read a known key.
 *
 * The payload is copied without its own terminator, but if it is shorter than
 * `max` a '\0' is written after it. Pass `max` as the buffer size minus one when
 * scanning the payload as a string: that guarantees the terminator is in range,
 * so a short record cannot be read with a longer record's tail still behind it. */
int kb_next(u32 *cursor, u32 *seq_out, void *out, u32 max);

/* Remove record `seq`, compacting the slots after it so the live records stay
 * contiguous. Returns 1 if the record was found and removed. Used to take back
 * knowledge that turns out to be wrong. */
int kb_delete(u32 seq);

/* Change the compression grade, rewriting every live record into the new
 * layout. Returns 1 on success, 0 if the records do not fit or the grade is
 * out of range. */
int kb_set_grade(u8 grade);

/* Log one line per live record: seq, length, first bytes. */
void kb_list(u32 max);

/* Write, read back and compare a record. Returns 1 on success. */
int kb_selftest(void);

/* Human-readable name of a grade, e.g. "3 (max compression)". */
const char *kb_grade_name(u8 grade);

#endif /* OS_KB_H */
