#ifndef OS_SYSINFO_H
#define OS_SYSINFO_H

#include "types.h"

/* Machine report, printed once at boot.
 *
 * The first thing the machine does is say what it is running on: the CPU and its
 * capabilities, how much RAM it was handed, the disk it found, and how large the
 * local model is. Knowing the hardware up front turns a later "why is this
 * slow" into a question with an answer.
 *
 * `mbi` is the multiboot information pointer passed to kmain. It is read for
 * the memory map; when the bootloader did not supply one the report says so
 * rather than guessing.
 */
void sysinfo_report(u32 mbi);

/* The two halves, for when the disk is not up yet at boot. */
void sysinfo_report_cpu(u32 mbi);
void sysinfo_report_storage(void);

/* Remember the boot multiboot pointer so a later report can reuse it. */
void sysinfo_set_mbi(u32 mbi);

/* Total RAM in bytes, from the bootloader's memory map. 0 when the bootloader
 * supplied no map, so a caller can say "unknown" rather than print a zero that
 * looks like a measurement. */
u32 sysinfo_ram_bytes(void);

#endif /* OS_SYSINFO_H */
