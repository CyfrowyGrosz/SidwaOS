#ifndef OS_SASM_H
#define OS_SASM_H

#include "types.h"

/* SidwaASM: the small assembly language the IDE writes programs in.
 *
 * The instruction set is deliberately tiny -- four registers, a flat array of
 * 64 words as memory, and twelve instructions. That is enough to write real
 * programs (loops, arithmetic, I/O) while staying small enough to assemble and
 * run inside the kernel with no heap and no libc.
 *
 * A program is text. The assembler reads it in two passes so a jump can name a
 * label that appears later in the file:
 *
 *   pass 1  walk the source, assign an address to every label
 *   pass 2  emit the instructions, resolving label operands to addresses
 *
 * Errors are reported with the line number and a reason, so the IDE can put the
 * cursor on the offending line.
 *
 * Syntax
 * ------
 *   ; comment to end of line
 *   label:                     define a label
 *   MOV  r0, 42                rN = immediate
 *   MOV  r0, r1                rN = register
 *   MOV  r0, [r1]              rN = memory[r1]      (load)
 *   MOV  [r0], r1              memory[r0] = r1      (store)
 *   ADD  r0, 1                 rN += immediate
 *   ADD  r0, r1                rN += register
 *   SUB  r0, 1                 rN -= immediate
 *   MUL  r0, 2                 rN *= immediate
 *   CMP  r0, 10                set the zero flag from rN - immediate
 *   JMP  loop                  jump to label
 *   JZ   done                  jump to label when the zero flag is set
 *   JNZ  loop                  jump to label when the zero flag is clear
 *   OUT  r0                    print rN as a decimal number
 *   OUTC r0                    print rN as a character
 *   HLT                        stop
 *
 * Register names are r0..r3.
 *
 * A program that does not end in HLT has one appended, so running past the last
 * instruction means the program finished rather than faulted. A listing that
 * simply stops is a complete program.
 */

/* Program limits. The bytecode is a flat array, so a program is capped at
 * SASM_MAX_CODE instructions. */
#define SASM_MAX_CODE     256
#define SASM_MAX_LABELS   64
#define SASM_MAX_SOURCE   2048
#define SASM_LABEL_MAX    24
#define SASM_ERROR_MAX    96

/* One assembled instruction. `imm` holds the operand: an immediate, a register
 * index, or a resolved label address, depending on the opcode. */
struct sasm_insn {
    u8  op;
    u8  dst;            /* destination register, or 0 when unused */
    u8  src;            /* source register, or 0 when unused */
    u8  mode;           /* SASM_MODE_* for MOV/ADD/SUB/MUL/CMP */
    u32 imm;            /* immediate value or resolved label address */
};

/* Operand forms. */
#define SASM_MODE_NONE   0
#define SASM_MODE_REG    1
#define SASM_MODE_IMM    2
#define SASM_MODE_LOAD   3   /* MOV rN, [rM] */
#define SASM_MODE_STORE  4   /* MOV [rN], rM */
#define SASM_MODE_LABEL  5   /* jump target */

/* Opcodes. */
#define SASM_OP_HLT  0
#define SASM_OP_MOV  1
#define SASM_OP_ADD  2
#define SASM_OP_SUB  3
#define SASM_OP_MUL  4
#define SASM_OP_CMP  5
#define SASM_OP_JMP  6
#define SASM_OP_JZ   7
#define SASM_OP_JNZ  8
#define SASM_OP_OUT  9
#define SASM_OP_OUTC 10
#define SASM_OP_COUNT 11

struct sasm_program {
    struct sasm_insn code[SASM_MAX_CODE];
    u32 count;                      /* instructions emitted */
    u32 entry;                      /* first instruction */
};

/* Assemble `source` into `prog`. Returns 1 on success. On failure returns 0 and
 * fills `err` with "line N: reason". */
int sasm_assemble(const char *source, struct sasm_program *prog,
                  char *err, u32 err_max);

/* Mnemonic for an opcode, for the disassembler and the IDE listing. */
const char *sasm_op_name(u8 op);

/* Print one instruction as assembly text, resolving nothing. */
void sasm_disasm_one(const struct sasm_insn *insn, char *out, u32 max);

/* The built-in example program, used by the IDE's "load example" key and by the
 * self tests. */
const char *sasm_example_source(void);

/* The built-in program library, so the IDE has programs to open and the CLI can
 * run one without a filesystem. `sasm_example(i)` returns NULL out of range. */
u32 sasm_example_count(void);
const char *sasm_example_name(u32 i);
const char *sasm_example(u32 i);

/* Assemble the built-in example program and check it runs to the expected
 * output. Returns 1 on success. */
int sasm_selftest(void);

#endif /* OS_SASM_H */
