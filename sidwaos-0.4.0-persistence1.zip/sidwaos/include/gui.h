#ifndef OS_GUI_H
#define OS_GUI_H

#include "types.h"

/* A windowed text GUI, built as Model-View-Controller.
 *
 * The split, and what each part is allowed to touch:
 *
 *   Model       gui_model: what to show and which window is open. It holds no
 *               screen coordinates and never writes to the display. It is the
 *               only part that reads or writes the .sidwa partition, so the
 *               machine's stored knowledge has exactly one owner.
 *
 *   View        draws the model with the VGA driver: the desktop, the window
 *               frames, the lesson text and the status bar. It reads the model
 *               and writes pixels, and nothing else. Redrawing from scratch on
 *               every repaint means the view can never disagree with the model.
 *
 *   Controller  reads the keyboard, turns a key into a request ("next lesson",
 *               "open the log"), and applies it to the model. It never draws.
 *
 * Keeping the arrows one-way -- controller to model to view -- is what makes the
 * GUI predictable: a key changes the model, the model is redrawn, and the screen
 * is a pure function of the model.
 *
 * The interface is modelled on a desktop: a menu bar, a main window, a side
 * panel listing the lessons, and a status bar. It is text mode, so "windows" are
 * bordered rectangles.
 */

/* A line of the scrollback log shown in the Log window. */
#define GUI_LOG_LINES  64
#define GUI_LOG_WIDTH  72

void gui_init(void);

/* Begin mirroring console output into the Log window. Called at boot, before
 * the first log line, so the window shows the whole boot trace. */
void gui_log_attach(void);

/* Open the desktop and run its key loop until the user quits. */
void gui_run(void);

/* Model accessors, used by the view and by the tests. */
u32  gui_lesson_index(void);
void gui_set_lesson(u32 index);
u32  gui_window(void);
void gui_set_window(u32 window);

/* Feed one key to the controller. Returns 0 when the key asked to quit. */
int gui_handle_key(u16 key);

/* Which window is showing. */
#define GUI_WIN_LESSONS 0
#define GUI_WIN_LOG     1
#define GUI_WIN_HELLO   2
#define GUI_WIN_RESULTS 3
#define GUI_WIN_METHOD  4
#define GUI_WIN_IDE     5

/* Open the desktop with the program IDE already showing, and run its key loop
 * until the user quits. Used by the `ide` command. */
void gui_run_ide(void);

/* Drive the model and view without a keyboard, and confirm the view renders the
 * model. Returns 1 on success. */
int gui_selftest(void);

#endif /* OS_GUI_H */
