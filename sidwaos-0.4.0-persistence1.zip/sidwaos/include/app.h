#ifndef OS_APP_H
#define OS_APP_H

#include "types.h"

#define APP_MAGIC   0x4F534150u   /* "OSAP" */
#define APP_VERSION 1

#define APP_MAX_PAYLOAD 492   /* header(20) + payload = exactly 512 = one sector */

/* On-disk program blob. Fixed size so it maps to a whole number of sectors. */
struct app_header {
    u32 magic;
    u16 version;
    u16 size;                     /* payload bytes */
    u32 checksum;                 /* sum of payload bytes */
    u32 serial_key;               /* authorization key */
    u32 entry_offset;             /* offset of the fragment entry within payload */
} __attribute__((packed));

struct app_blob {
    struct app_header header;
    u8 payload[APP_MAX_PAYLOAD];
} __attribute__((packed));

/* Compute the payload checksum used by the header. */
u32 app_checksum(const u8 *payload, u32 size);

/* Structural validation ("logic test"). Returns 1 if the blob is well formed. */
int app_logic_test(const struct app_blob *blob);

/* Serial-key check. Returns 1 if the key is authorized for this blob. */
int app_key_verify(const struct app_blob *blob);

/* Human-readable reason for the last logic_test failure (NULL if it passed). */
const char *app_last_error(void);

#endif /* OS_APP_H */
