#ifndef OS_ACTIONS_H
#define OS_ACTIONS_H

/* Shared command dispatcher.
 *
 * The serial command line and the AI bridge both reach the machine through the
 * same action names, so an intent chosen by an agent runs exactly the code a
 * typed command would.
 */

#define ACTION_UNKNOWN 0
#define ACTION_OK      1
#define ACTION_HALT   -1

void actions_help(void);

/* Run `cmd` with optional `arg`. Returns ACTION_OK when handled, ACTION_UNKNOWN
 * when the name is not recognised, ACTION_HALT when the caller should stop. */
int actions_dispatch(const char *cmd, const char *arg);

#endif /* OS_ACTIONS_H */
