#ifndef OS_OLLAMA_H
#define OS_OLLAMA_H

#include "types.h"

/* Talk to a language model served by Ollama on the host, over the network.
 *
 * This is the kernel's own route to the teacher, separate from the serial
 * bridge. The bridge in ai.c works when a host agent is attached to the serial
 * port; this module works over the virtual Ethernet adapter, so the machine can
 * ask the model a question with nothing attached to the serial line.
 *
 * The host is reachable at a fixed address: QEMU's user-mode network maps the
 * gateway 10.0.2.2 to the host running QEMU, so that is where Ollama listens
 * when it is running on the same machine. The address is a default, not a rule;
 * ollama_set_endpoint() changes it.
 *
 * The request is a POST of one JSON object to /api/generate with stream=false,
 * so the reply arrives whole in one response rather than as a stream of
 * fragments the kernel would have to reassemble.
 *
 * What comes back is a JSON document, and this module does not carry a JSON
 * parser. It reads out the one field it needs, "response", with a small
 * scanner, because the alternative is a general parser used exactly once.
 *
 * Answering is not learning. A reply from the model is offered to the knowledge
 * cache with know_remember(), which holds it in RAM unverified; it reaches
 * .sidwa only if a later answer agrees, through the same rule every other
 * source follows. This module cannot write to the partition.
 */

#define OLLAMA_DEFAULT_URL   "http://10.0.2.2:11434/api/generate"
#define OLLAMA_DEFAULT_MODEL "qwen2.5:0.5b"
#define OLLAMA_ANSWER_MAX    512

/* A generated program is far longer than a fact: the reply holds source text
 * with newlines, and the prompt carries the instruction set so the model knows
 * the language. Both get their own, larger limit. */
#define OLLAMA_CODE_MAX      4096

/* How long a program request may take, in timer ticks (100 Hz).
 *
 * A model computes the whole reply before sending anything, so a request that
 * is working fine sends no bytes for as long as it is thinking, and a program
 * takes longer to think about than a sentence. Measured on qwen2.5:3b under
 * QEMU, a program request took about 45 s. The ceiling is set well above that
 * so a slow machine is not mistaken for a dead one, and the idle window above
 * it again, since silence on this path means "still working". */
#define OLLAMA_CODE_CEILING_TICKS 12000u   /* 120 s overall */
#define OLLAMA_CODE_IDLE_TICKS     6000u   /* 60 s with no new bytes */

/* How often the wait reports itself, in timer ticks. Once a second: often
 * enough that the machine never looks frozen, rare enough that the report does
 * not become the noise it is meant to cut through. */
#define OLLAMA_THINKING_TICKS       100u

/* The three states of the machine, as they apply to one model request. The
 * kernel already runs a RUN -> HOLD -> STORE cycle, and asking the model maps
 * onto it exactly: RUN is the machine working on its own, HOLD is the machine
 * waiting on something outside itself, STORE is what it keeps. The wait is
 * labelled this way because that is what it is -- the machine is held, not
 * hung -- and because a user watching a screen with no output for a minute
 * cannot tell the difference otherwise.
 *
 * The text is a single line rewritten in place (a carriage return, not a
 * newline), so the report does not fill the log with one line per second. */
void ollama_thinking_begin(const char *what);
void ollama_thinking_tick(u32 elapsed_ticks);
void ollama_thinking_end(void);

/* Point the client at a different server or path. Copies `url` and `model`.
 * Either may be NULL to leave that field alone. */
void ollama_set_endpoint(const char *url, const char *model);

const char *ollama_endpoint(void);
const char *ollama_model(void);

/* Ask the model `question` and copy its answer into `out` (up to `max`).
 * Returns the answer length, or -1 when the model could not be reached or the
 * reply held no answer. Network and JSON handling only: nothing is cached and
 * nothing is written to disk. */
int ollama_ask(const char *question, char *out, u32 max);

/* Ask the model for a program rather than a fact.
 *
 * This is a separate path from ollama_ask() because every step that makes that
 * one good for a fact is wrong for a program: it asks for "one short sentence",
 * it collapses the answer to a single line, and it trims to the knowledge
 * cache's field size. A program is many lines and far longer than a fact, so
 * this path preserves the answer exactly as the model wrote it.
 *
 * Nothing is cached and nothing is stored: a generated program is only a
 * proposal until it has been assembled and run. Returns the answer length, or
 * -1 when the model could not be reached. */
int ollama_ask_code(const char *prompt, char *out, u32 max);

/* ollama_ask(), then hold the answer in RAM as unverified knowledge under
 * `question`. Returns the answer length, or -1 on failure. The second call for
 * the same question is what corroborates the fact and stores it. */
int ollama_learn(const char *question, char *out, u32 max);

/* Whether the most recent ollama_learn() corroborated and stored the fact,
 * rather than only holding it as a candidate. */
int ollama_last_stored(void);

/* Cumulative counters, for the report. */
u32 ollama_asks(void);      /* requests sent */
u32 ollama_ok(void);        /* requests that produced an answer */
u32 ollama_learned(void);   /* answers offered to the knowledge cache */

/* Log the endpoint, the counters and the last answer. */
void ollama_report(void);

/* Exercise the network-free parts: building the request body and pulling the
 * answer out of a reply. Returns 1 on success. */
int ollama_selftest(void);

#endif /* OS_OLLAMA_H */
