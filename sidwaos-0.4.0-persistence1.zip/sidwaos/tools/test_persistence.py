#!/usr/bin/env python3
"""Host-side regression tests for preserving SidwaOS learned knowledge."""
import importlib.util
import os
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("mkboot", ROOT / "tools" / "mkboot.py")
mkboot = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mkboot)


class DiskImagePersistenceTests(unittest.TestCase):
    def test_rebuild_copies_existing_knowledge_region(self):
        sectors = 4096
        total_bytes = sectors * mkboot.SECTOR
        start = mkboot.KB_LBA * mkboot.SECTOR
        size = mkboot.KB_SECTORS * mkboot.SECTOR
        marker = b"SIDWA-PERSISTENCE-REGRESSION"
        with tempfile.TemporaryDirectory() as td:
            old_path = os.path.join(td, "disk.img")
            old = bytearray(total_bytes)
            old[start:start + len(marker)] = marker
            old[start + size - 1] = 0xA5
            with open(old_path, "wb") as f:
                f.write(old)

            new = bytearray(total_bytes)
            preserved = mkboot.preserve_existing_regions(new, old_path, 0, sectors)
            self.assertTrue(preserved)
            self.assertEqual(new[start:start + len(marker)], marker)
            self.assertEqual(new[start + size - 1], 0xA5)
            self.assertEqual(new[0], 0)  # unrelated boot area is not copied

    def test_fresh_image_has_nothing_to_preserve(self):
        with tempfile.TemporaryDirectory() as td:
            image = bytearray(4096 * mkboot.SECTOR)
            self.assertFalse(mkboot.preserve_existing_regions(
                image, os.path.join(td, "missing.img"), 0, 4096))

    def test_short_old_image_is_not_copied(self):
        with tempfile.TemporaryDirectory() as td:
            old_path = os.path.join(td, "short.img")
            with open(old_path, "wb") as f:
                f.write(b"too short")
            image = bytearray(4096 * mkboot.SECTOR)
            self.assertFalse(mkboot.preserve_existing_regions(image, old_path, 0, 4096))


if __name__ == "__main__":
    unittest.main(verbosity=2)
