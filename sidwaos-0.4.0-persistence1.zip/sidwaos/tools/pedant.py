#!/usr/bin/env python3
"""Close the machine's learning loop from its own record of what it cannot answer.

The kernel keeps a ledger of questions it failed to answer (kernel/pedant.c).
That ledger is the missing half of teaching: ollama_teach.py has to be told what
to teach, while this tool asks the machine what it needs. The difference matters
because only the machine knows what it was actually asked and could not answer.

The loop:

    read    the machine's open gaps, most-asked first
    teach   ask the teacher, twice, so the kernel corroborates and stores
    close   ask again so the gap is resolved, and save the ledger
    verify  reboot and confirm the machine answers unaided

Nothing is invented on this side. The questions come from the machine, the
answers come from the teacher, and the test is the machine answering by itself.

    python3 tools/pedant.py                  # close every gap it can
    python3 tools/pedant.py --dry-run        # show the gaps, teach nothing
    python3 tools/pedant.py --model qwen2.5:3b
    python3 tools/pedant.py --limit 3        # the three most-asked gaps
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from ollama_teach import (  # noqa: E402
    DEFAULT_MODEL,
    OLLAMA_HOST,
    Session,
    Teacher,
    import_knowledge,
    knows,
)

# "[PEDANT]   3  what is a semaphore" -- the ask count, then the question.
# The two-or-more spaces are load-bearing: the header line "[PEDANT] 3 open
# gap(s), most-asked first:" has a single space after the count, so requiring
# two keeps the header from being read as a gap named "open gap(s), ...".
GAP_LINE = re.compile(r"^\[PEDANT\]\s+(\d+)\s{2,}(.+?)\s*$")


def read_gaps(session: Session) -> list[tuple[str, int]]:
    """The machine's open gaps, most-asked first, as (question, asks)."""
    out = session.command("pedant gaps")
    gaps: list[tuple[str, int]] = []
    for line in out.splitlines():
        m = GAP_LINE.match(line.strip())
        if m:
            gaps.append((m.group(2).strip(), int(m.group(1))))
    return gaps


def close_gap(session: Session, question: str, passes: int = 4) -> bool:
    """Teach one gap until the machine answers it unaided. True on success.

    The kernel only stores a fact once two lookups agree, so each pass asks
    twice: the first reply is held unverified, the second corroborates it and
    writes it to .sidwa. A pass that does not take is retried, because at
    temperature 0 the first reply after model load can differ from the
    steady-state one and the disagreement resets the corroboration.
    """
    for _ in range(passes):
        session.command(f"know {question}")
        out = session.command(f"know {question}")
        if knows(out):
            return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Teach SidwaOS the questions it could not answer.")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--host", default=OLLAMA_HOST)
    ap.add_argument("--disk", default="disk.img",
                    help="image to read gaps from and teach (default: disk.img)")
    ap.add_argument("--output",
                    help="write the taught image here (default: --disk, in place)")
    ap.add_argument("--limit", type=int, default=0,
                    help="teach at most this many gaps, most-asked first")
    ap.add_argument("--dry-run", action="store_true",
                    help="list the gaps and exit without teaching")
    ap.add_argument("--no-teacher", action="store_true",
                    help="list gaps without Ollama, to inspect the ledger only")
    args = ap.parse_args()

    teacher: Teacher | None = None
    if not (args.no_teacher or args.dry_run):
        teacher = Teacher(model=args.model, host=args.host)
        if not teacher.available():
            print(f"[pedant] no Ollama at {args.host}.", file=sys.stderr)
            print("[pedant] start it with `ollama serve`, or pass --dry-run.",
                  file=sys.stderr)
            return 2
        print(f"[pedant] teacher: {args.model} at {args.host}")

    target = args.output or args.disk
    session = Session(teacher=teacher, disk=args.disk)
    try:
        session.boot()

        gaps = read_gaps(session)
        if not gaps:
            print("[pedant] the machine has no open gaps: nothing to teach.")
            return 0

        print(f"[pedant] the machine cannot answer {len(gaps)} question(s):")
        for q, asks in gaps:
            print(f"  asked {asks}x  {q}")

        if args.dry_run or args.no_teacher:
            return 0

        todo = gaps[:args.limit] if args.limit > 0 else gaps

        # The bridge has to be on for the kernel to ask the host at all: with it
        # off, ai_lookup() answers from RAM and .sidwa only and never reaches
        # tier 3, so every gap would stay open no matter what the teacher knows.
        session.command("ai on")

        taught: list[str] = []
        failed: list[str] = []
        for q, _ in todo:
            if close_gap(session, q):
                taught.append(q)
                print(f"[pedant] closed: {q}")
            else:
                failed.append(q)
                print(f"[pedant] still open: {q}")

        # Resolving a gap only clears it in RAM, so the ledger has to be written
        # back or the machine would re-list a question it can now answer.
        if taught:
            session.command("pedant save")

        if taught:
            if import_knowledge(session.work, target):
                print(f"\n[pedant] saved {len(taught)} answer(s) to {target}")
            else:
                print("\n[pedant] the answers were measured but not saved.",
                      file=sys.stderr)
                return 1
    finally:
        session.close()
        session.discard()

    # Verify on a fresh boot with no teacher: this is the machine answering by
    # itself, which is the only result that counts.
    print("\n[pedant] verifying on a fresh boot (no teacher)")
    check = Session(teacher=None, disk=target)
    try:
        check.boot()
        check.command("ai off")
        still_open = [q for q, _ in read_gaps(check)]
        for q in taught:
            out = check.command(f"know {q}")
            state = "answers unaided" if knows(out) else "STILL DOES NOT KNOW"
            print(f"  {state}: {q}")
        for q in failed:
            print(f"  left open: {q}")
        if still_open:
            print(f"  gaps remaining in the ledger: {len(still_open)}")
    finally:
        check.close()
        check.discard()

    print(f"\nclosed {len(taught)} of {len(todo)} attempted"
          + (f", {len(failed)} left open" if failed else ""))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
