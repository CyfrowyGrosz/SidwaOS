#!/usr/bin/env python3
"""Build a bootable SidwaOS disk image with the kernel's own bootloader.

This replaces GRUB. The image is a plain BIOS disk: write it to a pendrive with
`dd` and the machine boots straight into SidwaOS.

Boot path:

    LBA 0          stage 1, a 446-byte MBR that reads stage 2 and jumps to it
    LBA 1..32      stage 2, which reads the kernel ELF, enters protected mode,
                   places the ELF segments and jumps to the kernel entry with a
                   Multiboot hand-off (see boot/stage1.asm, boot/stage2.asm)

Disk layout, matching the absolute LBAs the kernel addresses at run time:

    LBA 64..127    demo program blobs, as tools/mkapp.py writes them
    LBA 128..191   STORE scratch, written by Loop 3
    LBA 256..767   the .sidwa knowledge partition
    LBA 2048..     the kernel ELF itself

The kernel is placed past the .sidwa partition so the region the kernel writes
and the region the bootloader reads never overlap.

Usage:
    python3 tools/mkboot.py disk.img [--size-mb 8] [--kernel kernel.elf]
"""

import argparse
import os
import shutil
import struct
import subprocess
import sys
import tempfile

SECTOR = 512
STAGE2_LBA = 1
STAGE2_SECTORS = 32                 # stage 2 is padded to 16 KiB
KERNEL_LBA = 2048                   # past the .sidwa partition
SIGNATURE = struct.pack("<I", 0x53444232)   # "SDB2", as stage2.asm stores it
STAGE1_SIG = struct.pack("<I", 0x53444231)  # "SDB1", as stage1.asm stores it

# The kernel's absolute-LBA layout. These must match kernel/kmain.c (BLOB_LBA),
# kernel/loop_store.c (STORE_LBA) and include/kb.h (KB_LBA, KB_SECTORS).
BLOB_LBA = 64
STORE_LBA = 128
STORE_SECTORS = 64
KB_LBA = 256
KB_SECTORS = 512

# Reused from mkapp.py so the demo blobs are identical on both disks.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mkapp  # noqa: E402


def run(cmd: list[str]) -> None:
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        sys.stderr.write(f"command failed: {' '.join(cmd)}\n")
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit(1)


def assemble(src: str, dst: str) -> None:
    run(["nasm", "-f", "bin", src, "-o", dst])


def patch_stage1(stage1: bytes, stage2_lba: int) -> bytes:
    """Write the LBA stage 2 lives at into the field stage 1 reads."""
    at = stage1.find(STAGE1_SIG)
    if at < 0:
        sys.stderr.write("stage 1 signature not found\n")
        raise SystemExit(1)
    data = bytearray(stage1)
    data[at + 4:at + 8] = struct.pack("<I", stage2_lba)
    return bytes(data)


def patch_stage2(stage2: bytes, kernel_lba: int, kernel_sectors: int,
                 base_lba: int) -> bytes:
    """Write the kernel's LBA, length and disk base into stage 2's fields."""
    at = stage2.find(SIGNATURE)
    if at < 0:
        sys.stderr.write("stage 2 signature not found\n")
        raise SystemExit(1)
    data = bytearray(stage2)
    data[at + 4:at + 8] = struct.pack("<I", kernel_lba)
    data[at + 8:at + 12] = struct.pack("<I", kernel_sectors)
    data[at + 12:at + 16] = struct.pack("<I", base_lba)
    return bytes(data)


def write_partition_table(image: bytearray, start: int, sectors: int) -> None:
    """Put one type-0x7F partition over the kernel area, for recognition.

    The bootloader reads absolute LBAs, so this is informational: it tells other
    tools that the region holds a SidwaOS install rather than free space.
    """
    entry = bytearray(16)
    entry[0] = 0x80
    entry[1:4] = b"\x00\x02\x00"
    entry[4] = 0x7F
    entry[5:8] = b"\xfe\xff\xff"
    entry[8:12] = struct.pack("<I", start)
    entry[12:16] = struct.pack("<I", sectors)
    image[446:462] = entry
    image[510] = 0x55
    image[511] = 0xAA


def build_blobs() -> bytes:
    """The same three demo blobs mkapp.py writes, as a flat region."""
    blobs = [
        mkapp.build_blob(b"HELLO-FROM-BLOB-0", mkapp.AUTHORIZED_KEYS[0]),
        mkapp.build_blob(b"HELLO-FROM-BLOB-1", mkapp.AUTHORIZED_KEYS[0],
                         corrupt=True),
        mkapp.build_blob(b"HELLO-FROM-BLOB-2", 0xBADBAD99),
    ]
    return b"".join(blobs)


def preserve_existing_regions(image: bytearray, output_path: str, base_lba: int,
                              total_sectors: int) -> bool:
    """Preserve the existing .sidwa knowledge partition when rebuilding.

    Building a new boot/kernel image must not silently erase the user's learned
    facts. The new image is still initialized from zero, but the old knowledge
    region is copied over when the previous image is large enough to contain it.
    Returns True when a region was preserved.
    """
    if not os.path.exists(output_path):
        return False
    start = (base_lba + KB_LBA) * SECTOR
    end = start + KB_SECTORS * SECTOR
    if end > len(image) or os.path.getsize(output_path) < end:
        return False
    with open(output_path, "rb") as fh:
        fh.seek(start)
        saved = fh.read(KB_SECTORS * SECTOR)
    if len(saved) != KB_SECTORS * SECTOR:
        return False
    image[start:end] = saved
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a bootable SidwaOS disk")
    ap.add_argument("output", nargs="?", default="disk.img")
    ap.add_argument("--size-mb", type=int, default=8)
    ap.add_argument("--kernel", default=None)
    ap.add_argument("--base-lba", type=int, default=0,
                    help="disk LBA the SidwaOS region starts at (0 = whole disk)")
    args = ap.parse_args()

    if shutil.which("nasm") is None:
        sys.stderr.write("nasm not found\n")
        return 1

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    kernel_path = args.kernel or os.path.join(root, "kernel.elf")
    if not os.path.exists(kernel_path):
        sys.stderr.write(f"{kernel_path} not found; run make first\n")
        return 1

    with open(kernel_path, "rb") as fh:
        kernel = fh.read()
    kernel_sectors = (len(kernel) + SECTOR - 1) // SECTOR

    tmp = tempfile.mkdtemp(prefix="sidwa-boot-")
    try:
        stage1_bin = os.path.join(tmp, "stage1.bin")
        stage2_bin = os.path.join(tmp, "stage2.bin")
        assemble(os.path.join(root, "boot", "stage1.asm"), stage1_bin)
        assemble(os.path.join(root, "boot", "stage2.asm"), stage2_bin)

        with open(stage1_bin, "rb") as fh:
            stage1 = fh.read()
        with open(stage2_bin, "rb") as fh:
            stage2 = fh.read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    if len(stage1) != SECTOR:
        sys.stderr.write("stage 1 is not exactly one sector\n")
        return 1
    if len(stage2) > STAGE2_SECTORS * SECTOR:
        sys.stderr.write("stage 2 does not fit in its reserved sectors\n")
        return 1

    base = args.base_lba
    stage1 = patch_stage1(stage1, base + STAGE2_LBA)
    stage2 = patch_stage2(stage2, base + KERNEL_LBA, kernel_sectors, base)

    total_sectors = args.size_mb * 1024 * 1024 // SECTOR
    need = KERNEL_LBA + kernel_sectors
    if total_sectors < need:
        total_sectors = need + 64

    # Never shrink an image that is already there: a partition install writes
    # into an existing disk and must leave its size, and its other partitions,
    # alone.
    if os.path.exists(args.output):
        existing = os.path.getsize(args.output) // SECTOR
        if existing > total_sectors:
            total_sectors = existing

    image = bytearray(total_sectors * SECTOR)
    off = base * SECTOR
    if base:
        # A partition install: keep the existing MBR so the partition table and
        # its 0x55AA signature survive, and replace only the boot code. Stage 1
        # is patched to read stage 2 from inside the partition.
        if os.path.exists(args.output):
            with open(args.output, "rb") as fh:
                image[0:SECTOR] = fh.read(SECTOR)
        image[0:446] = stage1[:446]
    else:
        image[0:SECTOR] = stage1
    image[off + STAGE2_LBA * SECTOR:off + STAGE2_LBA * SECTOR + len(stage2)] = stage2

    blobs = build_blobs()
    image[off + BLOB_LBA * SECTOR:off + BLOB_LBA * SECTOR + len(blobs)] = blobs
    image[off + KERNEL_LBA * SECTOR:off + KERNEL_LBA * SECTOR + len(kernel)] = kernel

    if base == 0:
        write_partition_table(image, KERNEL_LBA, total_sectors - KERNEL_LBA)

    preserved = preserve_existing_regions(image, args.output, base, total_sectors)

    with open(args.output, "wb") as fh:
        fh.write(image)

    print(f"wrote {args.output}: {total_sectors} sectors "
          f"({total_sectors * SECTOR} bytes)")
    print(f"  stage 1 at LBA 0, stage 2 at LBA {STAGE2_LBA} "
          f"({len(stage2)} bytes)")
    print(f"  kernel at LBA {KERNEL_LBA} ({len(kernel)} bytes, "
          f"{kernel_sectors} sectors)")
    print(f"  blobs at LBA {BLOB_LBA}, .sidwa at LBA {KB_LBA}")
    print("  preserved existing .sidwa knowledge partition" if preserved
          else "  no existing .sidwa partition to preserve; first boot will format it")
    print(f"  write to a pendrive with: "
          f"sudo dd if={args.output} of=/dev/sdX bs=4M status=progress")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
