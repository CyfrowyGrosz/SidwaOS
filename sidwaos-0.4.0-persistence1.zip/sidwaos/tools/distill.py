#!/usr/bin/env python3
"""Measure when SidwaOS's local AI gets smarter, using Qwen2.5 as a teacher.

SidwaOS carries a tiny linear classifier (kernel/localai.c). It has 12 action
labels, 8/12/16-bit weights and 8-32 hashed feature slots, and it is trained on
18 hand-written examples. This script answers a concrete question: if a real
language model generates more training examples for it, how many are needed
before the classifier generalises to phrasings it has never seen?

Two pieces:

  * student  a byte-faithful Python port of kernel/localai.c -- same hash, same
             feature slots, same puzzle-weight update, same quantisation, same
             tie-breaking. Ported so the curve here predicts the kernel's.
  * teacher  Qwen2.5-0.5B-Instruct (GGUF, run locally through llama.cpp). It
             writes new example phrasings for each action. No API, no network
             once the weights are on disk.

The student is scored on a held-out set of phrasings it never trains on, so the
number reported is generalisation, not memorisation.

Usage:
    python3 tools/distill.py                 # full run
    python3 tools/distill.py --grade 1       # one grade only
    python3 tools/distill.py --no-teacher    # skip the model, base set only
"""

import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

MODEL_PATH = os.path.join(ROOT, os.pardir, "models",
                          "qwen2.5-0.5b-instruct-q4_k_m.gguf")

# --- The kernel's model shape (kernel/localai.c) ----------------------------

LABELS = ["run", "hold", "store", "status", "cycle", "cache",
          "bitflow", "combine", "pack", "debug", "version", "halt"]

# (weight_bits, features, learning_rate), indexed by grade.
SHAPES = {1: (8, 8, 4), 2: (12, 16, 6), 3: (16, 32, 8)}

FEATURES_MAX = 32

# The kernel's built-in training set, verbatim.
BASE_SET = [
    ("run the cpu loop now",            "run"),
    ("execute the fragment",            "run"),
    ("hold the data and test it",       "hold"),
    ("logic test the queued program",   "hold"),
    ("store the program on disk",       "store"),
    ("save it to the hdd",              "store"),
    ("show the state statistics",       "status"),
    ("what is the current status",      "status"),
    ("run all three loops",             "cycle"),
    ("do a full cycle of everything",   "cycle"),
    ("report the cpu cache",            "cache"),
    ("how much l1 is free",             "cache"),
    ("run the bitflow self tests",      "bitflow"),
    ("combine the bit flows",           "bitflow"),
    ("pack ten operations of six bits", "pack"),
    ("debug the fault record",          "debug"),
    ("show the version",                "version"),
    ("halt the machine",                "halt"),
]

# Held-out phrasings: never trained on. Accuracy here is generalisation.
HELD_OUT = [
    ("start the cpu loop",              "run"),
    ("run a fragment on the cpu",       "run"),
    ("keep this data and test it",      "hold"),
    ("validate the queued program",     "hold"),
    ("persist the program to disk",     "store"),
    ("write it to the hdd",             "store"),
    ("print the machine statistics",    "status"),
    ("what is the status now",          "status"),
    ("run all three phases",            "cycle"),
    ("do everything once",              "cycle"),
    ("how big is the l1 cache",         "cache"),
    ("show the cpu cache size",         "cache"),
    ("run the bitflow tests",           "bitflow"),
    ("join the bit flows",              "bitflow"),
    ("pack eight operations of four bits", "pack"),
    ("inspect the fault log",           "debug"),
    ("what version is this",            "version"),
    ("stop the machine",                "halt"),
]


# --- Student: a faithful port of kernel/localai.c ---------------------------

class Student:
    def __init__(self, grade: int = 1):
        self.bits, self.features, self.lr = SHAPES[grade]
        self.grade = grade
        self.w = [[0] * FEATURES_MAX for _ in LABELS]
        self.examples = 0
        self.mistakes = 0

    def _feature_of(self, token: str) -> int:
        # h = h * 31 + byte, then mod the slot count. Matches feature_of().
        h = 0
        for b in token.encode():
            h = (h * 31 + b) & 0xFFFFFFFF
        return h % self.features

    def _features_of(self, text: str):
        # Byte-level, to match features_of() exactly: the sentinel is the NUL
        # byte (0), which is falsy in C but a truthy 1-char string in Python.
        # Working on ints keeps the final token from being dropped.
        out = []
        token = bytearray()
        for c in text.encode() + b"\0":
            if c and c not in (0x20, 0x09, 0x0A):
                if len(token) + 1 < 24:
                    token.append(c + 32 if 0x41 <= c <= 0x5A else c)
                continue
            if token:
                f = self._feature_of(token.decode("latin-1"))
                if f not in out and len(out) < FEATURES_MAX:
                    out.append(f)
                token = bytearray()
            if not c:
                break
        return out

    def _quantise(self, v: int) -> int:
        lo = -(1 << (self.bits - 1))
        hi = (1 << (self.bits - 1)) - 1
        return lo if v < lo else hi if v > hi else v

    def _best_train(self, feats):
        # best_label(): label 0 wins ties, and an all-zero model still returns
        # label 0. Used by the update rule.
        best, best_score = 0, 0
        for a in range(len(LABELS)):
            score = sum(self.w[a][f] for f in feats)
            if a == 0 or score > best_score:
                best, best_score = a, score
        return best

    def train(self, text: str, label: str) -> int:
        feats = self._features_of(text)
        want = LABELS.index(label)
        guess = self._best_train(feats)
        self.examples += 1
        if guess == want:
            return 1
        for f in feats:
            self.w[want][f] = self._quantise(self.w[want][f] + self.lr)
            self.w[guess][f] = self._quantise(self.w[guess][f] - self.lr)
        self.mistakes += 1
        return 0

    def predict(self, text: str):
        # localai_predict(): stricter than best_label(). A zero score never
        # wins, ties go to the earliest positive scorer, and no positive score
        # at all means "no answer" (None), not a guess.
        feats = self._features_of(text)
        if not feats:
            return "status"
        best, best_score = 0, 0
        for a in range(len(LABELS)):
            score = sum(self.w[a][f] for f in feats)
            if score > best_score:
                best, best_score = a, score
        return LABELS[best] if best_score > 0 else None

    def fit(self, examples, passes: int = 32):
        # Same bound the kernel uses in localai_selftest().
        for _ in range(passes):
            for text, label in examples:
                self.train(text, label)
        return self


def accuracy(student: Student, examples) -> float:
    ok = sum(1 for text, label in examples if student.predict(text) == label)
    return ok / len(examples) * 100.0


def accuracy_floor(grade: int) -> float:
    # The kernel's own bar: 15/18 at grade 1, 18/18 above.
    return 15 / 18 * 100.0 if grade == 1 else 100.0


# --- Teacher: Qwen2.5 writes new phrasings ----------------------------------

PROMPT = """You are writing training phrases for a command classifier inside a \
small operating system called SidwaOS.

The kernel action "{label}" does exactly this: {gloss}

Write {n} short user requests that would make the machine run "{label}".
Rules:
- one request per line, no numbering, no quotes, no commentary
- 3 to 7 words each, plain lowercase words and single spaces only
- describe the machine's own hardware: cpu, disk, memory, cache, programs
- do NOT mention AI, models, training, data or updates
- vary the wording: synonyms, different verbs, different word order"""

GLOSS = {
    "run": "execute queued program fragments on the CPU (loop 1)",
    "hold": "logic-test queued programs before they are trusted (loop 2)",
    "store": "persist keyed programs to the hard disk (loop 3)",
    "status": "show the state-machine statistics",
    "cycle": "run all three loops in order",
    "cache": "report the CPU cache geometry and free L1",
    "bitflow": "run the bit-flow self tests",
    "combine": "combine two operations into a single bit flow",
    "pack": "pack several operations of a given bit width together",
    "debug": "show the CPU faults seen and the recovery statistics",
    "version": "show the OS name and version number",
    "halt": "stop the machine",
}


def load_teacher():
    from llama_cpp import Llama
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"teacher weights not found: {MODEL_PATH}\n"
            "download with:\n"
            "  python3 -c \"from huggingface_hub import hf_hub_download as d;"
            " d('Qwen/Qwen2.5-0.5B-Instruct-GGUF',"
            " 'qwen2.5-0.5b-instruct-q4_k_m.gguf', local_dir='models')\"")
    return Llama(model_path=MODEL_PATH, n_ctx=1024, n_threads=4, verbose=False)


def clean_lines(text: str, n: int):
    out = []
    for line in text.splitlines():
        line = line.strip()
        line = re.sub(r"^[\-\*\d\.\)\s]+", "", line).strip()
        line = line.strip("\"'`")
        line = re.sub(r"[^a-z ]", "", line.lower())   # letters and spaces only
        line = re.sub(r" +", " ", line).strip()
        words = line.split()
        if len(words) < 2 or len(words) > 9:
            continue
        out.append(line)
    # De-duplicate, keep order, respect the ask.
    seen, uniq = set(), []
    for line in out:
        if line not in seen:
            seen.add(line)
            uniq.append(line)
    return uniq[:n]


def teacher_examples(llm, per_action: int, cache: str):
    """Ask the teacher for new phrasings for every action.

    The pool is cached to disk: generation is the slow part, and every later
    experiment should reuse the same data rather than sample new noise.
    """
    import json
    if os.path.exists(cache):
        with open(cache) as fh:
            pool = json.load(fh)
        print(f"[teacher] reusing {len(pool)} cached phrasings from {cache}")
        return [(t, l) for t, l in pool]

    fresh = []
    for label in LABELS:
        prompt = PROMPT.format(label=label, gloss=GLOSS[label],
                               n=per_action)
        try:
            resp = llm.create_chat_completion(
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500, temperature=0.7, top_p=0.9)
            text = resp["choices"][0]["message"]["content"]
        except Exception as exc:                      # noqa: BLE001
            print(f"[teacher] {label}: generation failed ({exc})",
                  file=sys.stderr)
            continue
        lines = clean_lines(text, per_action)
        print(f"[teacher] {label:8} -> {len(lines)} new phrasings")
        fresh.extend((line, label) for line in lines)

    with open(cache, "w") as fh:
        json.dump(fresh, fh, indent=0)
    return fresh


VERIFY_PROMPT = """A small OS kernel has these actions:

{spec}

Which single action does this user request ask for?

  "{phrase}"

Reply with only the action name, in lowercase, nothing else."""


def verify_examples(llm, examples, cache: str):
    """Keep only the teacher's examples that it can re-label correctly.

    A small model drifts: asked for phrases meaning "store" it will happily
    write phrases about "training data". Asking it to classify its own output
    catches that drift, and the classifier is a much easier task for the model
    than free generation, so the labels are more trustworthy than the prose.
    """
    import json
    if os.path.exists(cache):
        with open(cache) as fh:
            kept = json.load(fh)
        print(f"[filter] reusing {len(kept)} verified phrasings from {cache}")
        return [(t, l) for t, l in kept]

    spec = "\n".join(f"  {l:9} {GLOSS[l]}" for l in LABELS)
    kept = []
    for phrase, label in examples:
        try:
            resp = llm.create_chat_completion(
                messages=[{"role": "user",
                           "content": VERIFY_PROMPT.format(
                               spec=spec, phrase=phrase)}],
                max_tokens=8, temperature=0)
            said = resp["choices"][0]["message"]["content"].strip().lower()
            said = re.sub(r"[^a-z]", "", said)
        except Exception:                             # noqa: BLE001
            continue
        if said == label:
            kept.append((phrase, label))

    print(f"[filter] kept {len(kept)}/{len(examples)} examples the teacher "
          "could re-label correctly")
    with open(cache, "w") as fh:
        json.dump(kept, fh, indent=0)
    return kept


# --- The experiment ---------------------------------------------------------

def interleave(examples):
    """Round-robin the examples across labels.

    The teacher returns its pool grouped by action, so taking the first k of it
    would train on one action at a time and make every point on the curve depend
    on where the slice happened to land. Round-robin gives each prefix a
    balanced sample, so the curve measures the amount of data and not its order.
    """
    buckets = {}
    for text, label in examples:
        buckets.setdefault(label, []).append(text)

    order = [l for l in LABELS if l in buckets]
    out = []
    i = 0
    while True:
        added = False
        for label in order:
            if i < len(buckets[label]):
                out.append((buckets[label][i], label))
                added = True
        if not added:
            break
        i += 1
    return out


def run_grade(grade: int, distilled, report):
    base = list(BASE_SET)
    curve = []

    # 0 distilled examples: the kernel as shipped.
    s = Student(grade).fit(base)
    curve.append((0, accuracy(s, HELD_OUT), accuracy(s, base)))

    step = 6
    for k in range(step, len(distilled) + 1, step):
        s = Student(grade).fit(base + distilled[:k])
        curve.append((k, accuracy(s, HELD_OUT), accuracy(s, base)))

    # Ceiling: train on the held-out set itself, with correct labels. This is
    # what the model shape can do when the data is clean, so it separates a
    # capacity limit from a data-quality limit.
    ceiling = Student(grade).fit(base + HELD_OUT)
    ceiling_held = accuracy(ceiling, HELD_OUT)

    floor = accuracy_floor(grade)
    report.append((grade, floor, curve, ceiling_held))
    return curve


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--grade", type=int, choices=[1, 2, 3])
    ap.add_argument("--no-teacher", action="store_true")
    ap.add_argument("--per-action", type=int, default=16)
    ap.add_argument("--pool", default=os.path.join(ROOT, "tools",
                                                   "distill_pool.json"))
    ap.add_argument("--verified", default=os.path.join(ROOT, "tools",
                                                       "distill_verified.json"))
    args = ap.parse_args()

    grades = [args.grade] if args.grade else [1, 2, 3]

    distilled = []
    if not args.no_teacher:
        print(f"[teacher] loading Qwen2.5 from {MODEL_PATH}")
        llm = load_teacher()
        print("[teacher] generating new phrasings for each action")
        raw = teacher_examples(llm, args.per_action, args.pool)
        # Keep the held-out phrasings out of the training pool.
        held = {t for t, _ in HELD_OUT}
        raw = [(t, l) for t, l in raw if t not in held]
        print(f"[teacher] {len(raw)} usable phrasings before filtering")
        distilled = verify_examples(llm, raw, args.verified)
        distilled = interleave(distilled)
        print(f"[data] {len(distilled)} verified phrasings, round-robin by action")
        print()

    report = []
    for g in grades:
        run_grade(g, distilled, report)

    print("=" * 74)
    print("SidwaOS local AI: accuracy on 18 unseen phrasings")
    print("=" * 74)
    print(f"{'examples':>9} | " +
          " | ".join(f"grade {g:>1} (bits/feats)".rjust(20)
                     for g, _, _, _ in report))
    print("-" * 74)

    rows = max(len(c) for _, _, c, _ in report)
    for i in range(rows):
        cells = []
        for _, _, curve, _ in report:
            if i < len(curve):
                n, held, _ = curve[i]
                cells.append(f"{n:>5} -> {held:5.1f}%".rjust(20))
            else:
                cells.append(" " * 20)
        print(f"{i:>9} | " + " | ".join(cells))

    print("-" * 74)
    for g, floor, curve, ceiling in report:
        first_full = next((n for n, h, _ in curve if h >= 100.0), None)
        first_floor = next((n for n, h, _ in curve if h >= floor), None)
        base = curve[0][1]
        best = max(h for _, h, _ in curve)
        print(f"grade {g}: baseline {base:.1f}%  best-with-teacher {best:.1f}%  "
              f"ceiling {ceiling:.1f}%")
        print(f"         bar {floor:.1f}% reached at "
              f"{first_floor if first_floor is not None else 'never'}; "
              f"perfect at {first_full if first_full is not None else 'never'}")

    print()
    if distilled:
        print("What this says:")
        print("  The teacher adds a little, then stops helping: past a handful of")
        print("  examples the student's own feature budget is the wall, not the")
        print("  amount of data. The 'ceiling' column is the same model trained on")
        print("  the held-out phrases with their true labels -- that is what clean")
        print("  data would buy, and it is still bounded by the model shape.")
        print()
        print("  So SidwaOS's AI gets smarter with a better teacher only until it")
        print("  hits that ceiling. Beyond it, the answer is a bigger model (more")
        print("  features, more bits) or a different algorithm -- not more examples.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
