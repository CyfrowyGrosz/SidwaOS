#!/usr/bin/env python3
"""Teach SidwaOS's local AI from a language model running in local Ollama.

The kernel cannot hold a language model and has no network stack. What it does
have is a knowledge cache (RAM plus the .sidwa partition) and a bridge: when a
lookup misses both, it writes "\\x01LOOKUP <question>" to the serial port and
waits for an answer. That seam is what this tool uses, and it is why the loop
below needs no change to the kernel.

The loop is: ask the machine a question. If it answers from its own knowledge,
there is nothing to do. If it does not, ask Ollama, hand the answer back over
the bridge, and ask again -- the kernel corroborates the second agreeing answer
and writes the fact to .sidwa. Then move to the next question, until the
machine answers them by itself.

Knowledge accumulates in the machine, not in this process. Restart the kernel
and it still answers, which is what makes this import rather than caching.

    python3 tools/ollama_teach.py                 # teach the built-in questions
    python3 tools/ollama_teach.py --list          # show what is already known
    python3 tools/ollama_teach.py --model qwen2.5:3b
    python3 tools/ollama_teach.py "what is a syscall"

Three pieces, kept separate so each can be reasoned about and tested alone:

  Teacher   talks to Ollama over HTTP
  Session   owns one QEMU, speaks the bridge protocol, drives the command line
  teach()   the loop, and the report of what the machine learned
"""

from __future__ import annotations

import argparse
import json
import os
import pty
import re
import select
import shutil
import subprocess
import sys
import threading
import time
import tty
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

sys.path.insert(0, HERE)
import mkboot  # noqa: E402

# The .sidwa partition, from tools/mkboot.py, which is the same layout the
# kernel addresses at run time. Facts live here, so this is what gets copied
# back when teaching finishes.
KB_LBA = mkboot.KB_LBA
KB_SECTORS = mkboot.KB_SECTORS
SECTOR = mkboot.SECTOR

QEMU = "qemu-system-i386"
PROMPT = "os> "

# The bridge protocol, from include/ai.h.
MARK = "\x01"
LOOKUP = MARK + "LOOKUP "

# Field sizes the kernel will accept, from include/know.h. An answer longer
# than this would be truncated on arrival, so it is trimmed here instead where
# the cut can be made at a word boundary.
KNOW_KEY_MAX = 48
KNOW_VALUE_MAX = 240

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
DEFAULT_MODEL = os.environ.get("SIDWAOS_OLLAMA_MODEL", "qwen2.5:3b")

# Told to the teacher so its reply can be stored as one record: a single
# sentence, no preamble, no markdown. The kernel has no room for a lecture and
# no renderer for formatting.
SYSTEM_PROMPT = (
    "You are the teacher for a small operating system's knowledge cache. "
    "Answer the user's question in one plain sentence of at most 200 "
    "characters. State the fact directly. Do not greet, do not explain that "
    "you are an AI, do not use markdown or bullet points."
)

# Questions the machine should end up able to answer by itself. Each is
# something a small OS would plausibly be asked and cannot work out on its own.
DEFAULT_QUESTIONS = [
    "what is a syscall",
    "what does the kernel do",
    "what is virtual memory",
    "what is an interrupt",
    "what is a device driver",
    "what is a filesystem",
]


def one_line(text: str, limit: int = KNOW_VALUE_MAX) -> str:
    """Flatten `text` to a single line that fits the kernel's record size."""
    flat = " ".join((text or "").split())
    if len(flat) <= limit:
        return flat
    cut = flat[:limit]
    space = cut.rfind(" ")
    if space > limit // 2:
        cut = cut[:space]
    return cut.rstrip(" ,;:.") + "."


class Teacher:
    """A language model served by local Ollama.

    Temperature is pinned to 0 for a reason that is not about quality: the
    kernel only stores a fact once two lookups return the same answer, so a
    teacher that rephrases itself every time would never corroborate anything.
    """

    def __init__(self, model: str = DEFAULT_MODEL, host: str = OLLAMA_HOST,
                 timeout: float = 120.0) -> None:
        self.model = model
        self.host = host.rstrip("/")
        self.timeout = timeout

    def available(self) -> bool:
        try:
            with urllib.request.urlopen(self.host + "/api/tags",
                                        timeout=5) as resp:
                json.load(resp)
            return True
        except (urllib.error.URLError, OSError, ValueError):
            return False

    def models(self) -> list[str]:
        try:
            with urllib.request.urlopen(self.host + "/api/tags",
                                        timeout=10) as resp:
                data = json.load(resp)
        except (urllib.error.URLError, OSError, ValueError):
            return []
        return [m.get("name", "") for m in data.get("models", [])]

    def ask(self, question: str) -> str | None:
        """Answer `question`, or None if the teacher cannot be reached."""
        body = json.dumps({
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": question},
            ],
            "stream": False,
            "options": {"temperature": 0, "num_predict": 120},
        }).encode()

        req = urllib.request.Request(
            self.host + "/api/chat", data=body,
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.load(resp)
        except (urllib.error.URLError, OSError, ValueError) as exc:
            print(f"[teach] teacher unavailable: {exc}", file=sys.stderr)
            return None

        answer = (payload.get("message") or {}).get("content", "")
        answer = one_line(answer)
        return answer or None


class Session:
    """One QEMU instance, driven over the serial line.

    Runs on a scratch copy of the disk so teaching a machine does not alter the
    canonical image. A background reader watches every line: bridge requests are
    answered immediately, everything else is command output.
    """

    def __init__(self, teacher: Teacher | None = None,
                 disk: str = "disk.img") -> None:
        self.teacher = teacher
        self.work = os.path.join(ROOT, "teach.img")
        shutil.copyfile(os.path.join(ROOT, disk), self.work)

        self._master, slave = pty.openpty()
        # Raw mode on the pty pair. Without it the line discipline buffers
        # input until a newline, echoes bytes back to the writer, and interprets
        # control characters -- all of which corrupt the \x01 bridge protocol.
        # The kernel then sees a mangled reply and reports no answer at all.
        tty.setraw(slave)
        tty.setraw(self._master)
        self._proc = subprocess.Popen(
            [QEMU, "-drive", f"file={self.work},format=raw,if=ide,index=0",
             "-netdev", "user,id=n0", "-device", "rtl8139,netdev=n0",
             "-serial", "stdio", "-display", "none",
             "-no-reboot", "-no-shutdown"],
            stdin=slave, stdout=slave, stderr=subprocess.DEVNULL,
            cwd=ROOT,
        )
        os.close(slave)

        self._raw = ""
        self._lock = threading.Lock()
        self._cmd_lock = threading.Lock()
        self._cond = threading.Condition(self._lock)
        self._stop = threading.Event()
        self.bridge_hits = 0
        self.taught: list[str] = []

        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    # --- serial ------------------------------------------------------------

    def _read_loop(self) -> None:
        pending = ""
        while not self._stop.is_set():
            ready, _, _ = select.select([self._master], [], [], 0.2)
            if not ready:
                continue
            try:
                chunk = os.read(self._master, 4096)
            except OSError:
                return
            if not chunk:
                return
            pending += chunk.decode("latin-1")

            # Act only on whole lines. The kernel writes a request in several
            # chunks, so answering a partial read would reply too early.
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                if line.startswith(LOOKUP):
                    self._answer_lookup(line[len(LOOKUP):].strip())
                    continue
                with self._cond:
                    self._raw += line + "\n"
                    self._cond.notify_all()

            # The prompt carries no newline, so it never arrives as a line.
            if pending.endswith(PROMPT):
                with self._cond:
                    self._raw += pending
                    pending = ""
                    self._cond.notify_all()

    def _answer_lookup(self, query: str) -> None:
        """Reply to a kernel LOOKUP: this is the import seam."""
        self.bridge_hits += 1
        answer = self.teacher.ask(query) if self.teacher else None
        if answer:
            self.taught.append(query)
            print(f"[teach] taught: {query} -> {answer}")
            self._write(MARK + "KNOW " + answer + "\n")
        else:
            print(f"[teach] nothing to teach for: {query}")
            self._write(MARK + "NONE\n")
        self._write(MARK + "END\n")

    def _write(self, text: str) -> None:
        try:
            os.write(self._master, text.encode("latin-1"))
        except OSError:
            pass

    # --- commands ----------------------------------------------------------

    def boot(self, timeout: float = 20.0) -> None:
        """Wait for the command line to appear."""
        end = time.time() + timeout
        while time.time() < end:
            with self._lock:
                if "entering command line" in self._raw:
                    break
            time.sleep(0.1)

    def command(self, cmd: str, timeout: float = 30.0) -> str:
        """Type `cmd` at the prompt and return what the kernel prints."""
        with self._cmd_lock:
            with self._lock:
                mark = len(self._raw)
            self._write(cmd + "\r\n")

            # The kernel echoes the command and then prints the prompt again
            # once it is done, so a prompt after the echo means finished.
            end = time.time() + timeout
            while time.time() < end:
                with self._lock:
                    seen = self._raw[mark:]
                    # Ignore the first prompt, which is the echo of this line.
                    if seen.count(PROMPT) >= 2:
                        break
                time.sleep(0.05)

            with self._lock:
                text = self._raw[mark:]

        return self._clean(text, cmd)

    @staticmethod
    def _clean(text: str, cmd: str) -> str:
        out: list[str] = []
        want = cmd.strip()
        for line in text.splitlines():
            s = line.strip()
            if not s:
                continue
            if s.startswith(PROMPT.strip()):
                s = s[len(PROMPT.strip()):].strip()
            if not s or s == want:
                continue
            out.append(s)
        return "\n".join(out)

    def close(self) -> None:
        self._stop.set()
        try:
            self._proc.terminate()
            self._proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self._proc.kill()
        except OSError:
            pass
        try:
            os.close(self._master)
        except OSError:
            pass

    def discard(self) -> None:
        """Remove the scratch image. Call after the caller has taken the facts."""
        try:
            os.unlink(self.work)
        except OSError:
            pass


# --- Reading the kernel's answers -------------------------------------------

# How the kernel says it does not know, in each of its two modes.
UNKNOWN = ("nothing known about", "no local copy of", "bridge is off")


def knows(output: str) -> bool:
    """True when the kernel answered from *verified* knowledge.

    Only two things count: a RAM/disk hit ("served from cache") or a stored
    answer. A fact the kernel merely heard from the teacher is held unverified
    and does not count -- it is a candidate awaiting corroboration, and treating
    it as knowledge made this tool report success on the first pass while the
    machine could not actually answer.
    """
    text = output.lower()
    if any(u in text for u in UNKNOWN):
        return False
    if "unverified" in text:
        return False
    return "served from cache" in text or "know] " in text


def answer_of(output: str) -> str:
    m = re.search(r"KNOW\]\s+(.*?):\s+(.*)", output)
    return m.group(2).strip() if m else ""


# --- The teaching loop -------------------------------------------------------

class Report:
    def __init__(self) -> None:
        self.before: dict[str, bool] = {}
        self.after: dict[str, bool] = {}
        self.learned: list[str] = []

    @property
    def knew_before(self) -> int:
        return sum(1 for v in self.before.values() if v)

    @property
    def knows_after(self) -> int:
        return sum(1 for v in self.after.values() if v)

    def summary(self) -> str:
        total = len(self.before)
        return (f"answered unaided before: {self.knew_before}/{total}\n"
                f"answered unaided after:  {self.knows_after}/{total}\n"
                f"new facts imported:      {len(self.learned)}")


def teach(session: Session, questions: list[str],
          passes: int = 3, verbose: bool = True) -> Report:
    """Teach the machine until it can answer `questions` by itself.

    The order matters. "Before" is measured with the bridge OFF, because asking
    a question with the bridge on is itself a lesson: the kernel would look the
    answer up and hold it, and the measurement would report knowledge the
    machine did not have. With the bridge off, `know` can only answer from RAM
    and .sidwa, which is exactly the unaided test we want.

    Each unknown question is then asked twice per pass. The first answer is held
    unverified; the second agreeing answer is what corroborates it and writes it
    to .sidwa. One ask per pass would still work but wastes a whole pass per
    fact waiting for the second.
    """
    report = Report()

    if verbose:
        print("[teach] measuring what the machine knows unaided (bridge off)")
    session.command("ai off")
    for q in questions:
        out = session.command(f"know {q}")
        report.before[q] = knows(out)
        if verbose:
            mark = "knows" if report.before[q] else "does not know"
            print(f"[teach] {mark}: {q}")

    session.command("ai on")

    for p in range(passes):
        remaining = [q for q in questions if not report.after.get(q)]
        if not remaining:
            break
        if verbose:
            print(f"\n[teach] pass {p + 1}: {len(remaining)} to teach")
        for q in remaining:
            # Two asks: the first is held, the second corroborates and stores.
            session.command(f"know {q}")
            out = session.command(f"know {q}")
            report.after[q] = knows(out)
            if report.after[q] and not report.before.get(q):
                if q not in report.learned:
                    report.learned.append(q)

    # Final measurement with the bridge off again, so the closing number is the
    # same unaided test as the opening one and the two are comparable.
    if verbose:
        print("\n[teach] re-measuring unaided (bridge off)")
    session.command("ai off")
    for q in questions:
        report.after[q] = knows(session.command(f"know {q}"))

    return report


def import_knowledge(scratch: str, target: str) -> bool:
    """Copy the .sidwa partition from `scratch` into `target`.

    The session teaches a scratch copy so a failed run cannot damage the image
    you boot. That safety is worthless if the facts are then deleted, which is
    what used to happen: the run reported 6/6 learned and threw all six away, so
    a fresh boot still knew nothing. Copying the partition back is what makes
    the knowledge real.

    Only the .sidwa region is copied, not the whole image: the scratch copy
    differs from the target in exactly this region, and a surgical copy cannot
    disturb the boot code or the kernel even if the two images ever diverge.
    """
    start = KB_LBA * SECTOR
    length = KB_SECTORS * SECTOR
    try:
        with open(scratch, "rb") as src, open(target, "r+b") as dst:
            src.seek(start)
            data = src.read(length)
            if len(data) != length:
                return False
            dst.seek(start)
            dst.write(data)
            dst.flush()
            os.fsync(dst.fileno())
        return True
    except OSError as exc:
        print(f"[teach] could not save to {target}: {exc}", file=sys.stderr)
        return False


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Teach SidwaOS's local AI from local Ollama.")
    ap.add_argument("questions", nargs="*",
                    help="questions to teach (default: a built-in set)")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--host", default=OLLAMA_HOST)
    ap.add_argument("--passes", type=int, default=4)
    ap.add_argument("--disk", default="disk.img",
                    help="image to teach (default: disk.img)")
    ap.add_argument("--output",
                    help="write the taught image here (default: --disk, in place)")
    ap.add_argument("--list", action="store_true",
                    help="show what the machine already knows, then exit")
    ap.add_argument("--no-teacher", action="store_true",
                    help="run without Ollama, to show what a miss looks like")
    args = ap.parse_args()

    teacher: Teacher | None = None
    if not args.no_teacher:
        teacher = Teacher(model=args.model, host=args.host)
        if not teacher.available():
            print(f"[teach] no Ollama at {args.host}.", file=sys.stderr)
            print("[teach] start it with `ollama serve`, or pass --no-teacher.",
                  file=sys.stderr)
            return 2
        print(f"[teach] teacher: {args.model} at {args.host}")

    questions = args.questions or DEFAULT_QUESTIONS

    session = Session(teacher=teacher, disk=args.disk)
    try:
        session.boot()
        if args.list:
            for q in questions:
                out = session.command(f"know {q}")
                state = "known" if knows(out) else "unknown"
                print(f"{state:8} {q}")
                if knows(out):
                    print(f"         {answer_of(out)}")
            return 0

        report = teach(session, questions, passes=args.passes)

        # Take the facts out of the scratch image before it is discarded, or
        # the run teaches nothing that survives. The report above is measured
        # on the live session, so it is only true of the saved image once this
        # copy has happened.
        target = args.output or args.disk
        if report.learned:
            if import_knowledge(session.work, target):
                print(f"\n[teach] saved {len(report.learned)} fact(s) to {target}")
            else:
                print("\n[teach] the facts were measured but not saved.",
                      file=sys.stderr)
    finally:
        session.close()
        session.discard()

    print("\n" + report.summary())
    if report.learned:
        print("\nimported this run:")
        for q in report.learned:
            print(f"  {q}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
