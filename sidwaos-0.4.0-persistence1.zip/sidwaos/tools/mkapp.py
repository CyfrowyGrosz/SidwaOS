#!/usr/bin/env python3
"""Build a disk image containing demo program blobs and the .sidwa partition.

Layout:
  - LBA 0..63    : reserved (GRUB stage data lives on the ISO, not here)
  - LBA 64..     : program blobs, one blob per ceil(sizeof(blob)/512) sectors
  - LBA 128..191 : STORE scratch, written by Loop 3 at run time
  - LBA 256..767 : the .sidwa knowledge partition (512 sectors, 256 KiB)

Three blobs are written:
  0. valid payload + authorized key        -> logic PASS, key OK, stored
  1. corrupt payload (bad checksum)        -> logic FAIL, never reaches STORE
  2. valid payload + unauthorized key      -> logic PASS, key REJECTED

The .sidwa partition starts zeroed. The kernel formats it on first mount
because the magic is absent, so nothing has to be pre-seeded here.

Usage:
    python3 mkapp.py disk.img
"""

import struct
import sys

SECTOR = 512
BLOB_LBA = 64
STORE_LBA = 128          # must match STORE_LBA in kernel/loop_store.c
STORE_SECTORS = 64       # scratch space for persisted programs
KB_LBA = 256             # must match KB_LBA in include/kb.h
KB_SECTORS = 512         # 256 KiB
APP_MAGIC = 0x4F534150
APP_VERSION = 1
APP_MAX_PAYLOAD = 492   # header(20) + payload = 512 = one sector
HEADER = struct.Struct("<IHHIII")          # magic, version, size, checksum,
                                           # serial_key, entry_offset

AUTHORIZED_KEYS = (0xA5A5C0DE, 0x1234BEEF)


def checksum(payload: bytes) -> int:
    total = 0
    for byte in payload:
        total = ((total << 1) ^ (total >> 31) ^ byte) & 0xFFFFFFFF
    return total


def build_blob(payload: bytes, key: int, *, corrupt: bool = False) -> bytes:
    assert len(payload) <= APP_MAX_PAYLOAD
    sum_ = checksum(payload)
    if corrupt:
        sum_ ^= 0xDEADBEEF          # make the checksum not match the payload

    header = HEADER.pack(APP_MAGIC, APP_VERSION, len(payload), sum_, key, 0)
    blob = header + payload
    blob += b"\x00" * (-len(blob) % SECTOR)
    return blob


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    path = sys.argv[1]

    blobs = [
        ("valid/authorized", build_blob(b"HELLO-FROM-BLOB-0", AUTHORIZED_KEYS[0])),
        ("bad checksum", build_blob(b"HELLO-FROM-BLOB-1", AUTHORIZED_KEYS[0],
                                    corrupt=True)),
        ("valid/unauthorized", build_blob(b"HELLO-FROM-BLOB-2", 0xBADBAD99)),
    ]

    blob_sectors = 1
    total_sectors = max(BLOB_LBA + blob_sectors * len(blobs),
                        STORE_LBA + STORE_SECTORS,
                        KB_LBA + KB_SECTORS)

    image = bytearray(total_sectors * SECTOR)
    for i, (name, blob) in enumerate(blobs):
        offset = (BLOB_LBA + i * blob_sectors) * SECTOR
        image[offset:offset + len(blob)] = blob
        print(f"blob {i} ({name}): LBA {BLOB_LBA + i * blob_sectors}, "
              f"{len(blob)} bytes")

    with open(path, "wb") as fh:
        fh.write(image)
    print(f"wrote {path}: {total_sectors} sectors "
          f"({total_sectors * SECTOR} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
