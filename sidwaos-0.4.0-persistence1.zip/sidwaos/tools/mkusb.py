#!/usr/bin/env python3
"""Build a bootable SidwaOS USB image (usb.img).

The image is a complete disk, not an ISO. Written to a pendrive with `dd` it
boots on a BIOS machine and carries its own .sidwa partition, so the machine can
save its model and knowledge to the stick and find them again next boot.

Layout, in sectors of 512 bytes:

    LBA 0            MBR with GRUB stage 1 (boot.img)
    LBA 1..2047      GRUB core image (biosdisk + part_msdos + fat + multiboot)
    LBA 2048..       FAT32 boot partition, mounted as (hd0,msdos1)
                       /boot/grub/grub.cfg
                       /boot/kernel.elf
    ...              the kernel's own disk area, kept clear of GRUB:
                       LBA 64..127    demo program blobs (as on disk.img)
                       LBA 128..191   STORE scratch
                       LBA 256..767   .sidwa knowledge partition

The kernel's area is addressed by absolute LBA, the same numbers disk.img uses,
so the two images behave identically once the kernel is running. The FAT
partition is placed at LBA 2048 -- past the .sidwa partition, which ends at LBA
768 -- so the filesystem GRUB reads and the partition the kernel writes never
overlap.

Requires: grub-mkimage, grub-bios-setup, mformat/mcopy (mtools), sgdisk or
mtools' sfdisk, all of which ship with grub-pc-bin and mtools.

Usage:
    python3 tools/mkusb.py usb.img [--size-mb 64]
"""

import argparse
import os
import shutil
import struct
import subprocess
import sys
import tempfile

SECTOR = 512
PART_START = 2048           # 1 MiB, the conventional first partition
GRUB_CORE_SECTORS = 2048    # room for the core image (stage 1.5 + modules)

# The kernel's absolute-LBA layout. These must match kernel/kmain.c (BLOB_LBA),
# kernel/loop_store.c (STORE_LBA) and include/kb.h (KB_LBA, KB_SECTORS).
BLOB_LBA = 64
STORE_LBA = 128
STORE_SECTORS = 64
KB_LBA = 256
KB_SECTORS = 512

# Modules the core image needs: BIOS disk access, MBR partition tables, the FAT
# reader for the boot partition, multiboot to load the kernel, and the pieces of
# normal mode that find and run grub.cfg.
GRUB_MODULES = [
    "biosdisk", "part_msdos", "fat", "multiboot", "multiboot2",
    "normal", "configfile", "search", "search_label", "search_fs_uuid",
    "ls", "boot", "echo", "test", "cat", "halt", "reboot",
]

GRUB_PREFIX = "(hd0,msdos1)/boot/grub"


def run(cmd: list[str], **kw) -> None:
    """Run a command, failing loudly with its output on error."""
    result = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if result.returncode != 0:
        sys.stderr.write(f"command failed: {' '.join(cmd)}\n")
        sys.stderr.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise SystemExit(1)


# Some distributions keep grub-bios-setup under the module directory rather
# than on PATH, so it is looked for in both places.
GRUB_BIN_DIRS = ["/usr/lib/grub/i386-pc", "/usr/lib/grub/i386-pc/bin"]


def find_tool(tool: str) -> str | None:
    found = shutil.which(tool)
    if found:
        return found
    for d in GRUB_BIN_DIRS:
        candidate = os.path.join(d, tool)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def require(tool: str) -> str:
    found = find_tool(tool)
    if found is None:
        sys.stderr.write(f"missing tool: {tool}\n")
        sys.stderr.write("install grub-pc-bin and mtools\n")
        raise SystemExit(1)
    return found


def build_core(tmp: str) -> bytes:
    """Build the GRUB core image that stage 1 loads."""
    core = os.path.join(tmp, "core.img")
    cmd = ["grub-mkimage", "-O", "i386-pc", "-o", core,
           "-p", GRUB_PREFIX, "-d", "/usr/lib/grub/i386-pc"]
    cmd += GRUB_MODULES
    run(cmd)
    with open(core, "rb") as fh:
        data = fh.read()
    if len(data) > GRUB_CORE_SECTORS * SECTOR:
        sys.stderr.write("grub core image does not fit in the reserved area\n")
        raise SystemExit(1)
    return data


def write_mbr(image: bytearray, core: bytes) -> None:
    """Put GRUB stage 1 in LBA 0 and the core image right after it.

    grub-bios-setup wants a device or file and writes boot.img plus core.img at
    the offsets it computes. Running it on the finished image is the supported
    path, so this is only a fallback that lays the two pieces down directly.
    """
    boot_img = "/usr/lib/grub/i386-pc/boot.img"
    with open(boot_img, "rb") as fh:
        stage1 = fh.read()
    image[0:len(stage1)] = stage1
    image[SECTOR:SECTOR + len(core)] = core


def install_grub(image_path: str, tmp: str, tool: str) -> None:
    """Install GRUB stage 1 and the core image using grub-bios-setup.

    The tool resolves -b and -c relative to -d, so the stage 1 image is staged
    beside the core image and -d points at that directory.
    """
    shutil.copy("/usr/lib/grub/i386-pc/boot.img", os.path.join(tmp, "boot.img"))
    run([tool, "-d", tmp, "-b", "boot.img", "-c", "core.img", image_path])


def make_partition(image_path: str, start: int, sectors: int) -> None:
    """Write an MBR partition table entry for a single FAT32 (0x0C) partition."""
    with open(image_path, "r+b") as fh:
        fh.seek(446)
        entry = bytearray(16)
        entry[0] = 0x80                              # bootable
        entry[1:4] = b"\x00\x02\x00"                 # CHS start (ignored)
        entry[4] = 0x0C                              # FAT32 LBA
        entry[5:8] = b"\xfe\xff\xff"                 # CHS end (ignored)
        entry[8:12] = struct.pack("<I", start)
        entry[12:16] = struct.pack("<I", sectors)
        fh.write(entry)
        fh.seek(510)
        fh.write(b"\x55\xaa")


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a bootable SidwaOS USB image")
    ap.add_argument("output", nargs="?", default="usb.img")
    ap.add_argument("--size-mb", type=int, default=64,
                    help="total image size in MiB (default 64)")
    args = ap.parse_args()

    grub_bios_setup = require("grub-bios-setup")
    for tool in ("grub-mkimage", "mformat", "mcopy"):
        require(tool)

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    kernel = os.path.join(root, "kernel.elf")
    if not os.path.exists(kernel):
        sys.stderr.write("kernel.elf not found; run make first\n")
        return 1

    total_sectors = args.size_mb * 1024 * 1024 // SECTOR
    part_sectors = total_sectors - PART_START
    if part_sectors < 8192:
        sys.stderr.write("image too small for a FAT32 partition\n")
        return 1

    tmp = tempfile.mkdtemp(prefix="sidwa-usb-")
    try:
        core = build_core(tmp)

        with open(args.output, "wb") as fh:
            fh.truncate(total_sectors * SECTOR)

        install_grub(args.output, tmp, grub_bios_setup)
        make_partition(args.output, PART_START, part_sectors)

        # Format the boot partition in place and copy the kernel and config.
        part = f"{args.output}@@{PART_START * SECTOR}"
        run(["mformat", "-i", part, "-F", "-v", "SIDWAOS", "::"])

        files = os.path.join(tmp, "files")
        os.makedirs(os.path.join(files, "boot", "grub"), exist_ok=True)
        shutil.copy(os.path.join(root, "iso", "boot", "grub", "grub.cfg"),
                    os.path.join(files, "boot", "grub", "grub.cfg"))
        shutil.copy(kernel, os.path.join(files, "boot", "kernel.elf"))

        for base, _dirs, names in os.walk(files):
            for name in names:
                full = os.path.join(base, name)
                rel = os.path.relpath(full, files).replace(os.sep, "/")
                run(["mcopy", "-i", part, "-s", full, f"::/{rel}"])

        print(f"wrote {args.output}: {total_sectors} sectors "
              f"({args.size_mb} MiB)")
        print(f"  boot partition: FAT32 at LBA {PART_START} "
              f"({part_sectors} sectors)")
        print(f"  .sidwa partition: LBA {KB_LBA}..{KB_LBA + KB_SECTORS}")
        print(f"  write to a pendrive with: "
              f"sudo dd if={args.output} of=/dev/sdX bs=4M status=progress")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
