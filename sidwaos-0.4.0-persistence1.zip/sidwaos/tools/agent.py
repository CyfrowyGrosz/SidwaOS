#!/usr/bin/env python3
"""Host-side AI agent for SidwaOS.

Runs the kernel in QEMU, watches the serial port, and answers the kernel's AI
bridge protocol:

    kernel -> host   "\x01AI <request>\n"
    host   -> kernel "\x01ACT <command> <arg>\n"   one or more actions
                     "\x01SAY <text>\n"           optional narration
                     "\x01END\n"                  end of reply

The planner has two backends:

  local  deterministic rules; no network, no credentials. Default.
  llm    an OpenAI-compatible chat completions endpoint, used when
         SIDWAOS_LLM_KEY is set. The model is asked to choose from the same
         action set the rules emit, so both backends are interchangeable.

Usage:
    python3 tools/agent.py                 # local planner, interactive
    python3 tools/agent.py "check the cache and run a cycle"
    SIDWAOS_LLM_KEY=... python3 tools/agent.py "why is the store refusing?"
"""

import json
import os
import pty
import re
import select
import subprocess
import sys
import time
import tty
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

AI_MARK = "\x01"

# The action set the kernel accepts, described so a model can choose from it.
ACTION_SPEC = """\
status              dump state-machine statistics
stats               sample memory, CPU, disk and link metrics
run                 loop 1: run fragments on the CPU
hold                loop 2: logic-test queued programs
store               loop 3: persist keyed programs to disk
cycle               run all three loops in order
cache               report CPU cache geometry and free L1
bitflow             run the bit-flow self tests
combine <a> <b>     combine two operations of the given bit widths
pack <count> <width>  pack N operations of the given width
debug               show faults seen and recovery statistics
debug test          run the fault classifier self test
version             show the OS name and version
"""


# --- Planners ---------------------------------------------------------------

def plan_local(request: str) -> list[str]:
    """Deterministic keyword planner. Mirrors the kernel's own fallback so the
    agent behaves identically whether or not a model is attached."""
    text = request.lower()
    actions = []

    if "cache" in text or "l1" in text or "memory" in text:
        actions.append("cache")
    if "stat" in text or "metric" in text or "load" in text or "speed" in text:
        actions.append("stats")
    if "fault" in text or "crash" in text or "debug" in text or "why" in text:
        actions.append("debug")
    if "test" in text or "logic" in text or "hold" in text:
        actions.append("hold")
    if "run" in text or "cpu" in text or "execute" in text:
        actions.append("run")
    if "store" in text or "save" in text or "disk" in text or "persist" in text:
        actions.append("store")
    if "all" in text or "cycle" in text or "everything" in text:
        actions.append("cycle")
    if "version" in text or "name" in text:
        actions.append("version")

    # Numbers in the request drive the combiner and the packer.
    nums = [int(n) for n in re.findall(r"\d+", text)]
    if ("pack" in text or "combine" in text) and len(nums) >= 2:
        verb = "pack" if "pack" in text else "combine"
        actions.append(f"{verb} {nums[0]} {nums[1]}")
    elif ("pack" in text or "combine" in text):
        actions.append("bitflow")

    if not actions:
        actions.append("status")
    return actions


def plan_llm(request: str) -> list[str]:
    """Ask a chat model to choose actions. Falls back to the rules on any error,
    so a missing or broken endpoint never leaves the kernel without an answer."""
    key = os.environ.get("SIDWAOS_LLM_KEY", "")
    base = os.environ.get("SIDWAOS_LLM_URL",
                          "https://api.openai.com/v1/chat/completions")
    model = os.environ.get("SIDWAOS_LLM_MODEL", "gpt-4o-mini")

    prompt = (
        "You control a small OS kernel. Choose one or more actions for the "
        "request. Reply with only action lines, nothing else.\n\n"
        f"Available actions:\n{ACTION_SPEC}\n"
        f"Request: {request}\n"
    )
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
    }).encode()

    req = urllib.request.Request(base, data=body, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.load(resp)
        text = data["choices"][0]["message"]["content"]
    except Exception as exc:                      # noqa: BLE001 - any failure
        print(f"[agent] model unavailable ({exc}); using local planner")
        return plan_local(request)

    known = {line.split()[0] for line in ACTION_SPEC.strip().splitlines()}
    actions = []
    for line in text.splitlines():
        line = line.strip().lstrip("-* ").strip()
        if not line:
            continue
        if line.split()[0] in known:
            actions.append(line)
    return actions or plan_local(request)


def plan(request: str) -> list[str]:
    if os.environ.get("SIDWAOS_LLM_KEY"):
        return plan_llm(request)
    return plan_local(request)


# --- QEMU session -----------------------------------------------------------

class Session:
    def __init__(self) -> None:
        self.master, slave = pty.openpty()
        # Raw mode on the pty pair: without it the line discipline buffers input
        # until a newline, echoes bytes back to the writer, and interprets
        # control characters -- all of which corrupt the \x01 protocol.
        tty.setraw(slave)
        tty.setraw(self.master)
        self.qemu = subprocess.Popen(
            ["qemu-system-i386", "-drive", "file=disk.img,format=raw,if=ide,index=0",
             "-netdev", "user,id=n0", "-device", "rtl8139,netdev=n0",
             "-serial", "stdio", "-display", "none",
             "-no-reboot", "-no-shutdown"],
            stdin=slave, stdout=slave, stderr=subprocess.DEVNULL,
            cwd=ROOT,
        )
        os.close(slave)
        self.buf = ""

    def read(self, timeout: float = 0.2) -> str:
        ready, _, _ = select.select([self.master], [], [], timeout)
        if not ready:
            return ""
        try:
            chunk = os.read(self.master, 4096)
        except OSError:
            return ""
        text = chunk.decode("latin-1")
        sys.stdout.write(text)
        sys.stdout.flush()
        return text

    def send(self, text: str) -> None:
        os.write(self.master, text.encode())

    def close(self) -> None:
        self.qemu.terminate()
        try:
            self.qemu.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.qemu.kill()
        os.close(self.master)


def answer_lookup(query: str) -> str | None:
    """Answer a kernel LOOKUP.

    The kernel has already missed its RAM and .sidwa tiers, so this is the last
    resort. With a network and a search key, search the web and return a short
    extract. Without one, fall back to the built-in facts so the protocol still
    works offline and in tests.
    """
    key = os.environ.get("SIDWAOS_SEARCH_KEY")
    if key:
        try:
            return search_web(query, key)
        except Exception as exc:                      # noqa: BLE001
            print(f"[agent] search failed: {exc}", file=sys.stderr)

    for needle, answer in LOCAL_FACTS.items():
        if needle in query.lower():
            return answer
    return None


def search_web(query: str, key: str) -> str | None:
    """Look the query up on the web and return a one-line extract.

    Tavily is used because it returns a ready-made answer rather than a page of
    links. The result is trimmed to a single line: the kernel stores it in a
    fixed-size record.
    """
    body = json.dumps({
        "api_key": key,
        "query": query,
        "max_results": 3,
        "include_answer": True,
    }).encode()

    req = urllib.request.Request(
        "https://api.tavily.com/search", data=body,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        payload = json.load(resp)

    text = payload.get("answer")
    if not text:
        results = payload.get("results") or []
        text = results[0].get("content") if results else None
    if not text:
        return None

    text = " ".join(str(text).split())
    return text[:200]


LOCAL_FACTS = {
    "3-state": "RUN executes on the CPU, HOLD validates queued data, "
               "STORE persists keyed programs to disk",
    "grade": "partition grades: 1 no compression, 2 light, 3 maximum; "
             "higher grade keeps more features but shorter records",
    "sidwa": "the .sidwa partition holds the learned model and cached facts",
    "bitflow": "bitflow combines two 4-bit flows into one 8-bit flow",
}


def run_session(requests: list[str], boot_wait: float = 6.0,
                verify: bool = False) -> int:
    session = Session()
    pending = ""      # bytes received but not yet split into complete lines

    try:
        deadline = time.time() + boot_wait
        while time.time() < deadline:
            pending += session.read(0.2)

        session.send("ai on\n")
        time.sleep(0.3)

        failures = 0
        for request in requests:
            # A `know` request exercises the knowledge tiers: the kernel misses
            # RAM and disk, asks the host, and holds the answer unverified.
            session.send(f"{request}\n" if request.startswith("know ")
                         else f"ask {request}\n")
            answered = False
            end = time.time() + 12.0
            reply = ""       # kernel output produced while handling this request

            while time.time() < end:
                text = session.read(0.2)
                pending += text

                # Only act on whole lines: the kernel writes the request in
                # several chunks, so a partial read would answer too early.
                while "\n" in pending:
                    line, pending = pending.split("\n", 1)

                    # A knowledge lookup: the kernel missed RAM and disk, so
                    # this is the web tier. Answer, or say there is nothing.
                    if line.startswith(AI_MARK + "LOOKUP "):
                        query = line[len(AI_MARK) + 7:].strip()
                        print(f"\n[agent] lookup: {query}")
                        fact = answer_lookup(query)
                        if fact:
                            print(f"[agent] answer: {fact}")
                            session.send(f"{AI_MARK}KNOW {fact}\n")
                        else:
                            print("[agent] nothing found")
                            session.send(f"{AI_MARK}NONE\n")
                        session.send(f"{AI_MARK}END\n")
                        answered = True
                        continue

                    if not line.startswith(AI_MARK + "AI "):
                        reply += line + "\n"
                        continue
                    req = line[len(AI_MARK) + 3:].strip()
                    print(f"\n[agent] request: {req}")
                    actions = plan(req)
                    print(f"[agent] plan: {actions}")
                    session.send(f"{AI_MARK}SAY planned {len(actions)} action(s)\n")
                    for action in actions:
                        session.send(f"{AI_MARK}ACT {action}\n")
                    session.send(f"{AI_MARK}END\n")
                    answered = True

                # Stop as soon as the kernel has finished handling this
                # request. A lookup answers on the [KNOW] channel, not [AI].
                done = "[AI]" if not request.startswith("know ") else "[KNOW]"
                if answered and done in reply:
                    break

            if not answered:
                print(f"[agent] no AI request seen for: {request!r}")
                failures += 1
            elif verify:
                # The kernel logs every action it runs; a plan with no such log
                # means the action never reached the machine. A `know` request
                # logs on the [KNOW] channel instead.
                marker = "[KNOW]" if request.startswith("know ") else "[AI]"
                if marker not in reply:
                    print(f"[agent] FAIL: no action ran for {request!r}")
                    failures += 1
                else:
                    print(f"[agent] PASS: {request!r} executed")

        session.send("halt\n")
        time.sleep(0.5)
        while session.read(0.2):
            pass
    finally:
        session.close()
    return 1 if failures else 0


def main() -> int:
    args = [a for a in sys.argv[1:] if a != "--check"]
    verify = "--check" in sys.argv
    requests = args or [
        "check the cache and run a cycle",
        "pack 10 operations of 6 bits each",
        "why did the store refuse something",
        "know what is the sidwa partition",
    ]
    print(f"[agent] planner: {'llm' if os.environ.get('SIDWAOS_LLM_KEY') else 'local'}")
    return run_session(requests, verify=verify)


if __name__ == "__main__":
    sys.exit(main())
