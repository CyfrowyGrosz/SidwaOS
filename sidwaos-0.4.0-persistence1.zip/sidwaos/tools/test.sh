#!/usr/bin/env bash
# Boot the kernel headless and assert the expected serial trace.
# Exits non-zero if a required line is missing or the kernel faults.
set -u

cd "$(dirname "$0")/.."

LOG=serial.log
rm -f "$LOG"

# The disk is self-booting: our own stage 1 and stage 2 read the kernel off it,
# so there is no CD-ROM and no GRUB in this path.
# -serial file: rather than stdio, so this works without a controlling tty.
timeout 30 qemu-system-i386 -drive file=disk.img,format=raw,if=ide,index=0 \
    -netdev user,id=n0 -device rtl8139,netdev=n0 \
    -serial "file:$LOG" -display none -no-reboot -no-shutdown || true

if [ ! -s "$LOG" ]; then
    echo "FAIL: no serial output captured"
    exit 1
fi

REQUIRED=(
    "multiboot hand-off ok"
    "bitflow combine selftest: ok"
    "bitflow process combine selftest: ok"
    "10 processes x 6 bit in one flow: ok"
    "10 processes x 8 bit (80 bit) refused: yes"
    "L1 free for kernel work"
    "primary master ready"
    "RUN -> HOLD"
    "HOLD -> STORE"
    "STORE -> RUN"
    "canary=CORRUPTED"
    "proc=qword+nibble"
    "logic test FAIL: bad checksum"
    "key REJECTED"
    "key OK, stored to LBA"
    "RUN -> DONE"
    "STORE written=1 refused=1"
    "local model: grade="
    "cache selftest: ok"
    "course selftest: ok"
    "MVC selftest: ok"
    "RE] course selftest: ok"
    "RESULT] selftest: ok"
    "METHOD] selftest: ok"
    "LAYOUT] disk base LBA"
    "OPTIM] selftest: ok"
    "OPTIM] the fast version is"
    "SYS] CPU: "
    "SYS] RAM: "
    "SYS] HDD: "
    "SYS] AI: "
    "NET] RTL8139 at "
    "NET] MAC "
    "NET] gateway selftest: ok"
    "OLLAMA] selftest: ok"
    "STATS] selftest: ok"
    "PEDANT] selftest: ok"
    "SYNTH] selftest: ok"
    "PEEPHOLE] selftest: ok"
)

# The partition line differs by disk state: a fresh image is formatted on first
# mount, an already-formatted one is mounted. Either proves the tier came up.
OPTIONAL_ANY=(
    "no valid .sidwa partition, formatting|mounted .sidwa"
)

fail=0
for line in "${REQUIRED[@]}"; do
    if grep -qF "$line" "$LOG"; then
        echo "PASS: $line"
    else
        echo "FAIL: $line"
        fail=1
    fi
done

for line in "${OPTIONAL_ANY[@]}"; do
    if grep -qE "$line" "$LOG"; then
        echo "PASS: $line"
    else
        echo "FAIL: $line"
        fail=1
    fi
done

if grep -q "\[FAULT\]" "$LOG"; then
    echo "FAIL: exception handler fired"
    grep "\[FAULT\]" "$LOG"
    fail=1
else
    echo "PASS: no CPU exceptions"
fi

exit $fail
