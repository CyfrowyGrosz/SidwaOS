#!/usr/bin/env python3
"""Read and write MBR and GPT partition tables, in pure Python.

The install wizard needs to inspect a disk, find free space, carve out a
SidwaOS partition and sometimes shrink an existing one. None of the usual
tools (sfdisk, parted, sgdisk) are assumed to exist, so the tables are read and
written here directly. Only the partition tables are touched; the filesystems
inside existing partitions are never rewritten.

Two table formats are supported:

  MBR   the classic four-entry table in LBA 0, with extended partitions for
        more than four entries
  GPT   the 128-entry table on a protective-MBR disk, for disks over 2 TiB or
        with more than four partitions

A disk is read whole with `read_table(path)`; the result is a `Table` whose
`partitions` can be inspected, and `plan_new_partition` computes where a new
one fits. `write_table` puts a modified table back.

Usage as a tool:
    python3 tools/parttool.py --list /dev/sdb
    python3 tools/parttool.py --free /dev/sdb
"""

from __future__ import annotations

import argparse
import os
import struct
import sys
from dataclasses import dataclass, field

SECTOR = 512

# MBR partition types we care about.
MBR_EMPTY = 0x00
MBR_EXTENDED = (0x05, 0x0F, 0x85)
MBR_GPT_PROTECTIVE = 0xEE
MBR_SIDWA = 0x7F                    # the type the wizard writes
MBR_LINUX = 0x83
MBR_FAT32 = 0x0C

# GPT
GPT_SIGNATURE = b"EFI PART"
GPT_ENTRY_SIZE = 128
GPT_ENTRY_COUNT = 128
GPT_ENTRY_LBA = 2
GPT_FIRST_USABLE = 34
# A fixed GUID so every SidwaOS partition is recognisable by type.
SIDWA_GPT_TYPE = bytes.fromhex("a5a5c0de1234beef9a5a534457414f53")
EFI_SYSTEM_TYPE = bytes.fromhex("c12a7328f81f11d2ba4b00a0c93ec93b")


def _guid_to_bytes(text: str) -> bytes:
    """Convert a canonical GUID string to the mixed-endian on-disk form."""
    parts = text.strip().strip("{}").split("-")
    if len(parts) != 5:
        raise ValueError(f"bad GUID: {text}")
    d1, d2, d3, d4, d5 = parts
    raw = bytes.fromhex(d1 + d2 + d3 + d4 + d5)
    return (raw[0:4][::-1] + raw[4:6][::-1] + raw[6:8][::-1] + raw[8:16])


def _bytes_to_guid(raw: bytes) -> str:
    return (f"{raw[0:4][::-1].hex()}-{raw[4:6][::-1].hex()}-"
            f"{raw[6:8][::-1].hex()}-{raw[8:10].hex()}-{raw[10:16].hex()}")


@dataclass
class Partition:
    index: int                      # 1-based slot number
    start: int                      # first LBA
    sectors: int
    type_id: int | None = None      # MBR type byte
    type_guid: bytes | None = None  # GPT type GUID
    bootable: bool = False
    name: str = ""

    @property
    def end(self) -> int:
        return self.start + self.sectors - 1


@dataclass
class Table:
    path: str
    style: str                      # "mbr" or "gpt"
    total_sectors: int
    partitions: list[Partition] = field(default_factory=list)
    mbr_bytes: bytearray = field(default_factory=bytearray)
    gpt_header: bytes = b""
    gpt_entries: bytearray = field(default_factory=bytearray)
    sector_size: int = SECTOR

    def free_gaps(self, alignment: int = 2048) -> list[tuple[int, int]]:
        """(start, sectors) of every free run, aligned and large enough to use."""
        used = sorted(self.partitions, key=lambda p: p.start)
        # Leave the first megabyte for boot code and the backup GPT at the end.
        first = max(GPT_FIRST_USABLE, 2048)
        last = self.total_sectors - 33
        gaps = []
        cursor = first
        for part in used:
            if part.start > cursor:
                gaps.append((cursor, part.start - cursor))
            cursor = max(cursor, part.end + 1)
        if cursor < last:
            gaps.append((cursor, last - cursor))

        aligned = []
        for start, length in gaps:
            aligned_start = (start + alignment - 1) // alignment * alignment
            if aligned_start + length > last:
                continue
            aligned_len = length - (aligned_start - start)
            if aligned_len >= alignment:
                aligned.append((aligned_start, aligned_len))
        return aligned

    def find_partition(self, index: int) -> Partition | None:
        for part in self.partitions:
            if part.index == index:
                return part
        return None


def _disk_sectors(path: str) -> int:
    """Total sectors of a block device or image file."""
    if os.path.exists(f"/sys/class/block/{os.path.basename(path)}/size"):
        with open(f"/sys/class/block/{os.path.basename(path)}/size") as fh:
            return int(fh.read().strip())
    return os.path.getsize(path) // SECTOR


def read_table(path: str) -> Table:
    """Read the partition table from a device or image file."""
    total = _disk_sectors(path)
    with open(path, "rb") as fh:
        mbr = bytearray(fh.read(SECTOR))

    if mbr[510:512] != b"\x55\xAA":
        return Table(path, "mbr", total, [], mbr)

    types = [mbr[446 + 16 * i + 4] for i in range(4)]
    if types[0] == MBR_GPT_PROTECTIVE:
        return _read_gpt(path, total, mbr)

    table = Table(path, "mbr", total, [], mbr)
    for i in range(4):
        base = 446 + 16 * i
        type_id = mbr[base + 4]
        if type_id == MBR_EMPTY:
            continue
        start = struct.unpack_from("<I", mbr, base + 8)[0]
        sectors = struct.unpack_from("<I", mbr, base + 12)[0]
        if sectors == 0:
            continue
        table.partitions.append(Partition(
            index=i + 1, start=start, sectors=sectors, type_id=type_id,
            bootable=bool(mbr[base] & 0x80)))
    return table


def _read_gpt(path: str, total: int, mbr: bytearray) -> Table:
    with open(path, "rb") as fh:
        fh.seek(SECTOR)
        header = fh.read(SECTOR)
        if header[0:8] != GPT_SIGNATURE:
            # Protective MBR with no readable GPT: treat as empty GPT.
            return Table(path, "gpt", total, [], mbr, header, bytearray())

        entries_lba = struct.unpack_from("<Q", header, 72)[0]
        count = struct.unpack_from("<I", header, 80)[0]
        size = struct.unpack_from("<I", header, 84)[0]
        fh.seek(entries_lba * SECTOR)
        entries = bytearray(fh.read(count * size))

    partitions = []
    for i in range(count):
        off = i * size
        type_guid = bytes(entries[off:off + 16])
        if type_guid == b"\x00" * 16:
            continue
        start = struct.unpack_from("<Q", entries, off + 32)[0]
        last = struct.unpack_from("<Q", entries, off + 40)[0]
        name_raw = bytes(entries[off + 56:off + 128])
        name = name_raw.decode("utf-16-le", "replace").split("\x00")[0]
        partitions.append(Partition(
            index=i + 1, start=start, sectors=last - start + 1,
            type_guid=type_guid, name=name))

    return Table(path, "gpt", total, partitions, mbr, header, entries)


def plan_new_partition(table: Table, sectors: int,
                       align: int = 2048) -> tuple[int, int]:
    """Find where a partition of `sectors` fits. Returns (start, sectors).

    Raises ValueError when no free run is large enough. The first gap that fits
    is used, so the new partition lands early on the disk.
    """
    for start, length in table.free_gaps(align):
        if length >= sectors:
            return start, sectors
    raise ValueError(f"no free run of {sectors} sectors "
                     f"({sectors * SECTOR // (1024 * 1024)} MiB)")


def shrink_partition(table: Table, index: int,
                     new_sectors: int) -> Partition:
    """Shrink a partition's table entry, keeping its start.

    This only changes the partition table; the filesystem inside must already
    have been resized to fit, which the wizard does first. Shrinking the entry
    before the filesystem would lose data, so callers must order it the other
    way round.
    """
    part = table.find_partition(index)
    if part is None:
        raise ValueError(f"no partition {index}")
    if new_sectors >= part.sectors:
        raise ValueError("shrink must make the partition smaller")
    if new_sectors < 2048:
        raise ValueError("refusing to shrink below 1 MiB")

    if table.style == "mbr":
        base = 446 + 16 * (index - 1)
        struct.pack_into("<I", table.mbr_bytes, base + 12, new_sectors)
    else:
        off = (index - 1) * GPT_ENTRY_SIZE
        struct.pack_into("<Q", table.gpt_entries, off + 40,
                         part.start + new_sectors - 1)

    part.sectors = new_sectors
    return part


def add_partition(table: Table, start: int, sectors: int,
                  name: str = "SidwaOS") -> Partition:
    """Add a SidwaOS partition to the table, in memory."""
    if table.style == "mbr":
        slot = None
        for i in range(4):
            if table.mbr_bytes[446 + 16 * i + 4] == MBR_EMPTY:
                slot = i
                break
        if slot is None:
            raise ValueError("the MBR has no free slot; convert to GPT "
                             "or remove a partition")
        part = Partition(index=slot + 1, start=start, sectors=sectors,
                         type_id=MBR_SIDWA)
        _write_mbr_entry(table.mbr_bytes, slot, part)
    else:
        slot = None
        for i in range(GPT_ENTRY_COUNT):
            off = i * GPT_ENTRY_SIZE
            if table.gpt_entries[off:off + 16] == b"\x00" * 16:
                slot = i
                break
        if slot is None:
            raise ValueError("the GPT is full")
        part = Partition(index=slot + 1, start=start, sectors=sectors,
                         type_guid=SIDWA_GPT_TYPE, name=name)
        _write_gpt_entry(table.gpt_entries, slot, part)

    table.partitions.append(part)
    return part


def _write_mbr_entry(mbr: bytearray, slot: int, part: Partition) -> None:
    base = 446 + 16 * slot
    entry = bytearray(16)
    entry[0] = 0x80 if part.bootable else 0x00
    entry[1:4] = b"\x00\x02\x00"
    entry[4] = part.type_id if part.type_id is not None else MBR_SIDWA
    entry[5:8] = b"\xfe\xff\xff"
    struct.pack_into("<I", entry, 8, part.start)
    struct.pack_into("<I", entry, 12, part.sectors)
    mbr[base:base + 16] = entry


def _write_gpt_entry(entries: bytearray, slot: int, part: Partition) -> None:
    off = slot * GPT_ENTRY_SIZE
    entry = bytearray(GPT_ENTRY_SIZE)
    entry[0:16] = part.type_guid or SIDWA_GPT_TYPE
    # A stable per-partition GUID derived from its position, so it does not
    # change between reads.
    entry[16:32] = bytes.fromhex("53445741") + bytes([slot]) + b"\x00" * 11
    struct.pack_into("<Q", entry, 32, part.start)
    struct.pack_into("<Q", entry, 40, part.start + part.sectors - 1)
    name = part.name.encode("utf-16-le")[:72]
    entry[56:56 + len(name)] = name
    entries[off:off + GPT_ENTRY_SIZE] = entry


def write_table(table: Table, path: str | None = None) -> None:
    """Write the in-memory table back to the disk or image."""
    target = path or table.path
    if table.style == "mbr":
        table.mbr_bytes[510] = 0x55
        table.mbr_bytes[511] = 0xAA
        with open(target, "r+b") as fh:
            fh.seek(0)
            fh.write(table.mbr_bytes)
        return

    # GPT: rewrite both the primary and the backup table.
    header = bytearray(table.gpt_header)
    header[0:8] = GPT_SIGNATURE
    struct.pack_into("<Q", header, 24, 1)                 # current LBA
    struct.pack_into("<Q", header, 32, table.total_sectors - 1)  # backup LBA
    struct.pack_into("<Q", header, 40, GPT_FIRST_USABLE)  # first usable
    struct.pack_into("<Q", header, 48, table.total_sectors - 34)  # last usable
    struct.pack_into("<Q", header, 72, GPT_ENTRY_LBA)
    struct.pack_into("<I", header, 80, GPT_ENTRY_COUNT)
    struct.pack_into("<I", header, 84, GPT_ENTRY_SIZE)
    crc = _crc32(table.gpt_entries)
    struct.pack_into("<I", header, 88, crc)
    struct.pack_into("<I", header, 16, 0)
    struct.pack_into("<I", header, 16, _crc32(bytes(header[:92])))

    backup_entries_lba = table.total_sectors - 33
    backup_header_lba = table.total_sectors - 1

    with open(target, "r+b") as fh:
        fh.seek(0)
        fh.write(table.mbr_bytes)
        fh.seek(SECTOR)
        fh.write(header)
        fh.seek(GPT_ENTRY_LBA * SECTOR)
        fh.write(table.gpt_entries)
        fh.seek(backup_entries_lba * SECTOR)
        fh.write(table.gpt_entries)

    # The backup header points at the backup entry array.
    backup = bytearray(header)
    struct.pack_into("<Q", backup, 24, backup_header_lba)
    struct.pack_into("<Q", backup, 32, 1)
    struct.pack_into("<I", backup, 16, 0)
    struct.pack_into("<I", backup, 16, _crc32(bytes(backup[:92])))
    with open(target, "r+b") as fh:
        fh.seek(backup_header_lba * SECTOR)
        fh.write(backup)


def _crc32(data: bytes) -> int:
    import binascii
    return binascii.crc32(data) & 0xFFFFFFFF


def describe(table: Table) -> str:
    lines = [f"{table.path}: {table.style.upper()}, "
             f"{table.total_sectors * SECTOR // (1024 * 1024)} MiB"]
    for part in table.partitions:
        kind = (f"type 0x{part.type_id:02X}" if part.type_id is not None
                else f"type {_bytes_to_guid(part.type_guid)}")
        name = f" '{part.name}'" if part.name else ""
        lines.append(f"  {part.index}: LBA {part.start}..{part.end} "
                     f"({part.sectors * SECTOR // (1024 * 1024)} MiB) "
                     f"{kind}{name}")
    for start, length in table.free_gaps():
        lines.append(f"  free: LBA {start}..{start + length - 1} "
                     f"({length * SECTOR // (1024 * 1024)} MiB)")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect a disk's partition table")
    ap.add_argument("device")
    ap.add_argument("--free", action="store_true", help="list free space only")
    args = ap.parse_args()

    table = read_table(args.device)
    if args.free:
        for start, length in table.free_gaps():
            print(f"LBA {start}..{start + length - 1}: "
                  f"{length * SECTOR // (1024 * 1024)} MiB free")
    else:
        print(describe(table))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
