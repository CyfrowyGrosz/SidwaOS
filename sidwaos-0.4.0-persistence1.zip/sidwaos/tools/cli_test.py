#!/usr/bin/env python3
"""Drive the kernel's serial command line and check the responses.

QEMU is run with `-serial stdio` under a pseudo-terminal so the kernel's serial
port is connected to a real byte stream. Commands are written with short pauses
between them; sending everything at once would overrun the 16-byte UART FIFO and
lose input.

Usage:
    python3 tools/cli_test.py
"""

import os
import pty
import select
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def training_count() -> int:
    """How many built-in examples the model is scored against.

    Read from `kernel/localai.c` rather than written down here, so adding an
    example to the training set does not leave a stale expectation behind. The
    accuracy in the assertion below is the part that should change only when
    the model's behaviour changes.
    """
    src = os.path.join(ROOT, "kernel", "localai.c")
    with open(src, encoding="utf-8") as fh:
        text = fh.read()

    marker = "training_set[] = {"
    start = text.index(marker) + len(marker)
    depth, i = 1, start
    while depth and i < len(text):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
        i += 1
    return text[start:i - 1].count("{")


BUILTIN = training_count()

# Each entry is a command to send and a line that must appear in the reply.
CASES = [
    ("help", "loop 3: persist keyed programs to disk"),
    ("cache", "L1 free for kernel work"),
    ("pack 10 6", "pack 10 processes x 6 bit = 60 bit"),
    ("pack 10 8", "refused (needs >64 bit)"),
    ("combine 40 32", "72 bit: refused, over the 64-bit limit"),
    ("combine 4 4", "combine 4+4 bit = 8 bit"),
    ("ask show me the cache", "L1d="),
    ("ask run the cpu loop", "fragment="),
    ("bitflow", "process combine selftest: ok"),
    ("status", "RUN fragments="),
    ("version", "SidwaOS 0.4.0"),
    ("debug test", "fault classifier selftest: ok"),
    ("debug fault 0", "AIDBG] cause: divide by zero"),
    ("debug fault 0", "recovered, kernel continues"),
    ("debug fault 0", "survived, quotient="),
    ("debug", "cause=divide by zero count="),
    ("debug", "episodes="),
    # .sidwa partition: grade, records and the grade trade-off.
    ("kb", "grade=1 (no compression)"),
    ("kb put hello from the test", "stored record"),
    ("kb list", "hello from the test"),
    ("kb grade 2", "grade set to 2 (light compression)"),
    ("kb", "grade=2 (light compression)"),
    ("kb grade 3", "grade set to 3 (max compression)"),
    ("kb", "slot=120 bytes"),
    ("kb grade 1", "grade set to 1 (no compression)"),
    # Local self-learning AI, and the grade deciding its precision.
    ("learn", "precision=8-bit features=8"),
    ("learn test", "local AI selftest: ok"),
    ("learn test", f"accuracy on built-in set: 15/{BUILTIN}"),
    ("learn save", "weights saved to .sidwa"),
    ("learn load", "weights loaded"),
    ("learn reset", "weights reset"),
    ("learn", "training steps=0"),
    # Knowledge cache: only verified facts reach the disk.
    ("know", "RAM cache:"),
    ("know verify never-seen", "nothing to verify"),
    ("know forget never-seen", "nothing held for"),
    ("know what is the sidwa partition", "bridge is off"),
    # The C course: list, select by number, find by word, and the AI teaching it.
    ("lesson", "C course: 10 lessons"),
    ("lesson", "Lesson 10: Hello World as a GUI"),
    ("lesson 2", "printf(\"Hello, World!"),
    ("lesson 2", "main is where every C program starts."),
    ("lesson 9", "Model, View, Controller"),
    ("lesson hello", "Lesson 10: Hello World as a GUI"),
    ("lesson 99", "no lesson 99: the course has 10"),
    ("lesson nonsense", "no lesson matching 'nonsense'"),
    ("ask teach me c", "C course: 10 lessons"),
    ("ask show me hello world", 'printf("Hello, World!'),
    ("help", "gui                  open the windowed GUI"),
    # The 5-loop programming method: goal to pseudo code.
    ("method", "programming method: 5 loops"),
    ("method", "Loop 1: What we want to achieve"),
    ("method", "Loop 5: Pseudo code"),
    ("method 3", "Program objects"),
    ("method pseudo", "Loop 5: Pseudo code"),
    ("method 9", "no loop 9: the method has 5"),
    # Reverse-engineering course.
    ("rev", "reverse-engineering course: 10 lessons"),
    ("rev 2", "Bytes and instructions"),
    ("rev", "mov eax, ebx   is two bytes: 89 d8"),
    ("rev stack", "The shape of a function"),
    ("rev 99", "no lesson 99: the course has 10"),
    # The optimisation course: decompile a slow program, write it fast.
    ("optim", "optimisation course: 6 lessons"),
    ("optim", "Start from a program that works"),
    ("optim 2", "Decompile it"),
    ("optim pair", "slow: per cell a bounds check and a cursor move"),
    ("optim bench", "the fast version is"),
    ("optim bench", "same picture: yes"),
    ("optim 99", "no lesson 99: the course has 6"),
    ("ask make it faster", "OPTIM"),
    # Disk layout and what the installer needs.
    ("layout", "base LBA"),
    ("install", "SidwaOS needs"),
    # Achieved results: the AI's record of which methods worked.
    ("results", "achieved results"),
    ("results save", "results saved to .sidwa"),
    ("results load", "results loaded from .sidwa"),
    # Live machine report.
    ("sysinfo", "CPU: "),
    ("sysinfo", "RAM: "),
    ("sysinfo", "HDD: "),
    ("sysinfo", "AI: "),
    # The Ollama client. The network-free parts run here: the selftest, and the
    # endpoint and model accessors. `ollama ask` needs a model server on the
    # host and is exercised by tools/ollama_teach.py, not by this suite, so the
    # suite stays runnable on a machine with nothing installed.
    ("ollama test", "selftest: pass"),
    ("ollama report", "endpoint http://10.0.2.2:11434/api/generate"),
    ("ollama report", "model qwen2.5:0.5b"),
    ("ollama model", "model is qwen2.5:0.5b"),
    ("ollama bogus", "ollama [ask|learn"),
    ("help", "ollama ask <q>"),
    # The statistics sampler. `stats test` checks the arithmetic with no hardware
    # involved; the full `stats` sample is exercised here too, since the disk and
    # the gateway are both present in this harness.
    ("stats test", "selftest: ok"),
    ("stats", "memory: kernel "),
    ("stats", "cpu load: "),
    ("stats", "disk .sidwa: read "),
    ("stats", "link: "),
    ("help", "stats                sample memory"),
    ("halt", "halted"),
]


def main() -> int:
    # Run on a scratch copy, never the canonical disk.img. The cases below
    # change the .sidwa grade, write records and save model weights, so the run
    # is not read-only; on the real image the second run would start from the
    # first run's leftovers and the grade assertions would fail. A fresh copy
    # each time makes the suite independent of what ran before it.
    work = os.path.join(ROOT, "cli_test.img")
    shutil.copyfile(os.path.join(ROOT, "disk.img"), work)

    master, slave = pty.openpty()

    qemu = subprocess.Popen(
        ["qemu-system-i386", "-drive", f"file={work},format=raw,if=ide,index=0",
         "-netdev", "user,id=n0", "-device", "rtl8139,netdev=n0",
         "-serial", "stdio", "-display", "none",
         "-no-reboot", "-no-shutdown"],
        stdin=slave, stdout=slave, stderr=subprocess.DEVNULL,
        cwd=ROOT,
    )
    os.close(slave)

    output = bytearray()

    def drain(seconds: float) -> None:
        end = time.time() + seconds
        while time.time() < end:
            ready, _, _ = select.select([master], [], [], 0.2)
            if ready:
                try:
                    chunk = os.read(master, 4096)
                except OSError:
                    return
                if not chunk:
                    return
                output.extend(chunk)

    try:
        # Wait for the boot sequence and the first prompt.
        drain(6.0)

        for command, expected in CASES:
            os.write(master, (command + "\n").encode())
            drain(1.5)
            if expected.encode() not in bytes(output):
                print(f"FAIL: '{command}' -> expected {expected!r}")
                text = bytes(output).decode("latin-1")
                print("--- last output ---")
                print("\n".join(text.splitlines()[-25:]))
                return 1
            print(f"PASS: '{command}' -> {expected}")
    finally:
        qemu.terminate()
        try:
            qemu.wait(timeout=5)
        except subprocess.TimeoutExpired:
            qemu.kill()
        os.close(master)
        try:
            os.unlink(work)
        except OSError:
            pass

    return 0


if __name__ == "__main__":
    sys.exit(main())
