#!/usr/bin/env python3
"""Build docs/sidwaos-cli.pdf, the command-line technical description.

The command list is parsed straight out of kernel/actions.c rather than kept in
a second place, so the PDF cannot drift from what the kernel actually prints
for `help`. Run it with `make pdf`.
"""

import os
import re
import sys

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ACTIONS = os.path.join(ROOT, "kernel", "actions.c")
OUT = os.path.join(ROOT, "docs", "sidwaos-cli.pdf")


def parse_commands(path):
    """Pull the "  verb args   description" lines out of the help text.

    They are the single source of truth for the command set, so the manual is
    generated from the same strings the kernel prints.
    """
    with open(path, encoding="utf-8") as fh:
        src = fh.read()

    # The help text is one serial_puts(...) call made of adjacent string
    # literals. Take the whole call, then join every quoted piece.
    block = re.search(r'void\s+actions_help\s*\([^)]*\)\s*\{(.*?)\n\}',
                      src, re.S)
    if not block:
        raise SystemExit("could not find actions_help in actions.c")

    pieces = re.findall(r'"((?:[^"\\]|\\.)*)"', block.group(1), re.S)
    if not pieces:
        raise SystemExit("no string literals inside actions_help")

    text = "".join(pieces)
    text = text.replace('\\n', "\n").replace('\\"', '"').replace("\\\\", "\\")

    commands = []
    for line in text.splitlines():
        line = line.rstrip()
        if not line.startswith("  ") or len(line.strip()) < 2:
            continue
        body = line[2:]
        # Split "verb args" from "description" on a run of two or more spaces.
        parts = re.split(r"\s{2,}", body, maxsplit=1)
        usage = parts[0].strip()
        desc = parts[1].strip() if len(parts) > 1 else ""
        commands.append((usage, desc))
    return commands


def group_commands(commands):
    """Group the flat list into the sections a reader expects.

    The help text is one flat list because the kernel prints it that way. For a
    manual, the same commands read better under headings.
    """
    groups = [
        ("System", ("help", "status", "version", "sysinfo", "layout", "install",
                    "debug", "halt")),
        ("The three loops", ("run", "hold", "store", "cycle", "cache")),
        ("Bit flow", ("bitflow", "combine", "pack")),
        ("AI and knowledge", ("ask", "ai", "learn", "know", "results")),
        ("Storage", ("kb",)),
        ("Teaching", ("lesson", "rev", "method", "optim", "hello")),
        ("Interface", ("gui",)),
    ]

    def head(usage):
        return usage.split()[0] if usage.split() else usage

    out = []
    seen = set()
    for title, verbs in groups:
        rows = [c for c in commands if head(c[0]) in verbs]
        for c in rows:
            seen.add(id(c))
        if rows:
            out.append((title, rows))
    rest = [c for c in commands if id(c) not in seen]
    if rest:
        out.append(("Other", rest))
    return out


def build_styles():
    styles = getSampleStyleSheet()
    body = ParagraphStyle(
        "body", parent=styles["BodyText"], fontName="Helvetica",
        fontSize=9.5, leading=13, spaceAfter=5, alignment=TA_LEFT,
    )
    return {
        "title": ParagraphStyle(
            "title", parent=styles["Title"], fontSize=22, leading=26,
            spaceAfter=4),
        "sub": ParagraphStyle(
            "sub", parent=styles["Normal"], fontSize=10.5, leading=14,
            textColor=colors.HexColor("#555555"), spaceAfter=14),
        "h1": ParagraphStyle(
            "h1", parent=styles["Heading1"], fontSize=14, leading=17,
            spaceBefore=14, spaceAfter=6,
            textColor=colors.HexColor("#1a3d6d")),
        "h2": ParagraphStyle(
            "h2", parent=styles["Heading2"], fontSize=11.5, leading=14,
            spaceBefore=10, spaceAfter=4,
            textColor=colors.HexColor("#333333")),
        "body": body,
        "code": ParagraphStyle(
            "code", parent=styles["Code"], fontName="Courier", fontSize=8,
            leading=10.5, backColor=colors.HexColor("#f4f4f4"),
            borderPadding=5, spaceBefore=4, spaceAfter=8),
        "cell": ParagraphStyle(
            "cell", parent=body, fontName="Courier", fontSize=8.5,
            leading=11, spaceAfter=0),
        "cellc": ParagraphStyle(
            "cellc", parent=body, fontName="Helvetica", fontSize=8.5,
            leading=11, spaceAfter=0),
    }


def make_pdf(commands, groups, styles, out_path):
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        leftMargin=20 * mm, rightMargin=18 * mm,
        topMargin=18 * mm, bottomMargin=16 * mm,
        title="SidwaOS command line", author="SidwaOS",
        subject="Command-line technical description",
    )
    S = styles
    flow = []

    flow.append(Paragraph("SidwaOS", S["title"]))
    flow.append(Paragraph(
        "Command-line technical description &mdash; the 3-state I/O machine, "
        "its custom bootloader, and the installer.", S["sub"]))

    flow.append(Paragraph("1. What this machine is", S["h1"]))
    flow.append(Paragraph(
        "SidwaOS is a small x86 kernel written in NASM and C. It boots from its "
        "own two-stage bootloader, with no GRUB, and runs three cooperative "
        "loops that move data through one machine:", S["body"]))
    flow.append(Paragraph(
        "<b>State 1 &mdash; RUN.</b> Fragments run on the CPU on a randomised "
        "stack base with a canary, so a fragment that overruns is caught and "
        "dropped instead of taking the kernel down. Loop 1, bit flow, combines "
        "two 4-bit processes into one byte.", S["body"]))
    flow.append(Paragraph(
        "<b>State 2 &mdash; HOLD.</b> Queued data is parked and validated by "
        "logic tests and a checksum before it is allowed any further.", S["body"]))
    flow.append(Paragraph(
        "<b>State 3 &mdash; STORE.</b> Programs that passed validation are "
        "written to the <font face='Courier'>.sidwa</font> partition.", S["body"]))
    flow.append(Paragraph(
        "The command line is the machine's front door. Every command below is "
        "what <font face='Courier'>help</font> prints at the prompt; this "
        "document is generated from that same text.", S["body"]))

    flow.append(Paragraph("2. Getting to a prompt", S["h1"]))
    flow.append(Paragraph(
        "Build the disk image, then boot it. The disk is self-booting: the "
        "bootloader is written into the image, so no CD or GRUB is needed.",
        S["body"]))
    flow.append(Preformatted(
        "make            # build the kernel and disk.img\n"
        "make run        # boot disk.img in QEMU\n"
        "make test       # boot and check the serial log\n"
        "make pdf        # rebuild this document\n",
        S["code"]))
    flow.append(Paragraph(
        "To install onto a real disk or a fresh image, use the wizard. It can "
        "take the whole disk, use free space, or shrink an existing partition:",
        S["body"]))
    flow.append(Preformatted(
        "python3 tools/install.py --create-image 64 \\\n"
        "        --device disk.img --mode whole --yes\n"
        "python3 tools/install.py --device /dev/sdX --mode free\n"
        "python3 tools/install.py --device /dev/sdX --mode shrink --shrink-index 1\n",
        S["code"]))

    flow.append(Paragraph("3. Commands", S["h1"]))
    flow.append(Paragraph(
        "Commands are read one line at a time at the <font face='Courier'>os&gt;"
        "</font> prompt. Arguments follow the command and are separated by "
        "spaces. A command with no argument prints its summary or its list.",
        S["body"]))

    for title, rows in groups:
        flow.append(Paragraph(title, S["h2"]))
        data = [[Paragraph("usage", S["cellc"]), Paragraph("what it does", S["cellc"])]]
        for usage, desc in rows:
            data.append([
                Paragraph(usage.replace("&", "&amp;").replace("<", "&lt;"),
                          S["cell"]),
                Paragraph(desc.replace("&", "&amp;").replace("<", "&lt;"),
                          S["cellc"]),
            ])
        table = Table(data, colWidths=[62 * mm, 92 * mm], hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3d6d")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#f7f9fc")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        flow.append(table)
        flow.append(Spacer(1, 4))

    flow.append(PageBreak())
    flow.append(Paragraph("4. Worked examples", S["h1"]))

    examples = [
        ("Run one full pass of the machine",
         "status          # where each loop stands\n"
         "cycle           # RUN, then HOLD, then STORE\n"
         "status"),
        ("Combine two operations into one byte",
         "bitflow         # the self tests, then the flow\n"
         "combine 10 01   # two 4-bit processes into one byte\n"
         "pack 8 4        # eight 4-bit operations, packed"),
        ("Teach and then check understanding",
         "lesson          # list the C course\n"
         "lesson hello    # find and teach one lesson\n"
         "rev 2           # a reverse-engineering lesson\n"
         "ask what is a pointer"),
        ("The optimisation course, measured not claimed",
         "optim           # the six lessons\n"
         "optim pair      # the slow and fast frame writers\n"
         "optim bench     # time both, check the pictures match"),
        ("Ask in plain words",
         "ask how do i write a loop\n"
         "ask make it faster\n"
         "ai on           # hand free text to the AI bridge"),
        ("Store a fact and keep it",
         "know what is the sidwa partition\n"
         "know verify what is the sidwa partition\n"
         "kb              # the partition grade and records"),
    ]
    for title, code in examples:
        flow.append(KeepTogether([
            Paragraph(title, S["h2"]),
            Preformatted(code, S["code"]),
        ]))

    flow.append(Paragraph("5. The optimisation lesson", S["h1"]))
    flow.append(Paragraph(
        "The first lesson of the course is the whole loop, run on this "
        "machine's own screen output. The VGA console is the &quot;beauty "
        "I/O&quot;: it is correct and easy to read, and it is slow because "
        "every character is written through a bounds check and then the "
        "hardware cursor is moved with four port writes. The slow frame "
        "writer does exactly that, once per cell.", S["body"]))
    flow.append(Preformatted(
        "/* slow: a check and a cursor move for every cell */\n"
        "for (y = 0; y < ROWS; y++)\n"
        "    for (x = 0; x < COLS; x++) {\n"
        "        vga_putc_at(x, y, ' ', attr);\n"
        "        vga_gotoxy(x, y);      /* four port writes */\n"
        "    }\n",
        S["code"]))
    flow.append(Paragraph(
        "Reading that code is the decompile step. The waste is the cursor "
        "move: the screen position changes once, not two thousand times. The "
        "fast writer stores the cell words directly and moves the cursor once:",
        S["body"]))
    flow.append(Preformatted(
        "/* fast: one store per cell, one cursor move per frame */\n"
        "for (i = 0; i < COLS * ROWS; i++)\n"
        "    cells[i] = blank;\n"
        "vga_gotoxy(0, 0);\n",
        S["code"]))
    flow.append(Paragraph(
        "Both writers draw the same picture, and the machine proves it: "
        "<font face='Courier'>optim bench</font> reads the cycle counter "
        "around each run, compares the two frames cell by cell, and reports "
        "the ratio. A fast program that draws a different picture is a bug, "
        "not an optimisation, so the check is part of the measurement.",
        S["body"]))
    flow.append(Paragraph(
        "On a typical QEMU run the fast frame is about two to three times "
        "quicker. The number is read from the machine, not asserted here.",
        S["body"]))

    flow.append(Paragraph("6. Where things live on disk", S["h1"]))
    flow.append(Paragraph(
        "The bootloader passes the kernel the base LBA of its own region, so "
        "the same kernel works on a whole disk and inside a partition. "
        "<font face='Courier'>layout</font> prints the map in use and "
        "<font face='Courier'>install</font> reports what the wizard needs.",
        S["body"]))
    flow.append(Preformatted(
        "LBA 0        stage 1 (MBR, 512 bytes)\n"
        "LBA 1        stage 2 (16 KiB, up to LBA 32)\n"
        "LBA 64       blobs\n"
        "LBA 256      .sidwa partition\n"
        "LBA 2048     kernel ELF\n",
        S["code"]))

    doc.build(flow)


def main():
    if not os.path.exists(ACTIONS):
        raise SystemExit("run this from the repository: %s not found" % ACTIONS)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    commands = parse_commands(ACTIONS)
    if not commands:
        raise SystemExit("no commands parsed from actions.c")
    groups = group_commands(commands)
    styles = build_styles()
    make_pdf(commands, groups, styles, OUT)
    print("wrote %s (%d commands)" % (OUT, len(commands)))


if __name__ == "__main__":
    main()
