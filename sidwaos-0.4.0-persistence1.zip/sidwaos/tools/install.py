#!/usr/bin/env python3
"""SidwaOS install wizard.

Puts SidwaOS on a disk or an image file: it prepares a partition, writes the
kernel and the bootloader into it, and leaves a .sidwa region the kernel can use
for its model and knowledge.

Three ways to make room, chosen at the prompt:

  whole   use the whole disk: one SidwaOS partition covering it
  free    use space that is already unpartitioned
  shrink  shrink an existing partition, then use the space that frees up

Shrinking only moves the partition boundary. The filesystem inside must be
resized first, and this tool does not do that, so it refuses to shrink a
partition it cannot verify is safe unless --force-shrink is given. That keeps
the common case -- installing beside a real filesystem -- from eating data.

The wizard works on a block device (/dev/sdb) or on an image file (usb.img).
Running it against a device needs root; against an image file it does not.

Usage:
    python3 tools/install.py                    # interactive
    python3 tools/install.py --device /dev/sdb --mode free --yes
    python3 tools/install.py --device out.img --create-image 64 --mode whole --yes
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parttool  # noqa: E402
import mkboot    # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SECTOR = 512

# The SidwaOS region, from the kernel's layout: the boot code, the kernel, the
# blobs and the .sidwa partition. One megabyte of slack is left in front so the
# partition starts on a conventional boundary.
REGION_SECTORS = mkboot.KERNEL_LBA + 512        # kernel area plus room to grow
MIN_SECTORS = REGION_SECTORS + 4096             # + 2 MiB of filesystem slack


class WizardError(Exception):
    pass


def human(sectors: int) -> str:
    mb = sectors * SECTOR / (1024 * 1024)
    if mb >= 1024:
        return f"{mb / 1024:.1f} GiB"
    return f"{mb:.0f} MiB"


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        reply = input(f"{prompt}{suffix}: ").strip()
    except EOFError:
        reply = ""
    return reply or default


def confirm(prompt: str, assume_yes: bool) -> bool:
    if assume_yes:
        return True
    reply = ask(f"{prompt} (yes/no)", "no").lower()
    return reply in ("y", "yes")


def list_candidate_disks() -> list[str]:
    """Block devices that look like whole disks, plus any images in the tree."""
    disks = []
    base = "/sys/class/block"
    if os.path.isdir(base):
        for name in sorted(os.listdir(base)):
            if name.startswith(("loop", "ram", "sr", "dm-", "md")):
                continue
            path = os.path.join(base, name)
            # A whole disk has a partition-table flag but no parent device.
            if not os.path.exists(os.path.join(path, "partition")):
                if os.path.exists(os.path.join(path, "size")):
                    disks.append(f"/dev/{name}")

    for name in ("usb.img", "disk.img"):
        candidate = os.path.join(ROOT, name)
        if os.path.exists(candidate):
            disks.append(candidate)
    return disks


def show_disk(path: str) -> parttool.Table:
    table = parttool.read_table(path)
    print(f"\n{path}: {table.style.upper()}, {human(table.total_sectors)}")
    for part in table.partitions:
        kind = (f"0x{part.type_id:02X}" if part.type_id is not None
                else "GPT")
        label = f" '{part.name}'" if part.name else ""
        print(f"  partition {part.index}: {human(part.sectors)} "
              f"at LBA {part.start} ({kind}){label}")
    for start, length in table.free_gaps():
        print(f"  free: {human(length)} at LBA {start}")
    if not table.partitions:
        print("  (no partitions)")
    return table


def create_image(path: str, size_mb: int) -> None:
    if os.path.exists(path):
        raise WizardError(f"{path} already exists")
    with open(path, "wb") as fh:
        fh.truncate(size_mb * 1024 * 1024)
    print(f"created {path}: {size_mb} MiB")


def plan_whole(table: parttool.Table) -> tuple[int, int]:
    """Use the whole disk: one partition from the first aligned LBA."""
    start = 2048
    sectors = table.total_sectors - start - 34
    if sectors < MIN_SECTORS:
        raise WizardError(
            f"disk is too small: {human(sectors)} free, "
            f"{human(MIN_SECTORS)} needed")
    return start, sectors


def plan_free(table: parttool.Table) -> tuple[int, int]:
    """Use existing free space, leaving a little room at the end."""
    gaps = table.free_gaps()
    if not gaps:
        raise WizardError("no free space on this disk")
    start, length = max(gaps, key=lambda g: g[1])
    sectors = min(length - 34, REGION_SECTORS + (length - REGION_SECTORS) // 4)
    if sectors < MIN_SECTORS:
        raise WizardError(
            f"largest free run is {human(length)}; "
            f"{human(MIN_SECTORS)} needed")
    return start, sectors


def plan_shrink(table: parttool.Table, index: int, keep_sectors: int,
                force: bool) -> tuple[int, int]:
    """Shrink a partition, then take the space that frees up."""
    part = table.find_partition(index)
    if part is None:
        raise WizardError(f"no partition {index}")

    if part.sectors <= keep_sectors:
        raise WizardError(
            f"partition {index} is only {human(part.sectors)}; "
            f"cannot keep {human(keep_sectors)}")

    if not force:
        print(f"\nAbout to shrink partition {index} "
              f"({human(part.sectors)} -> {human(keep_sectors)}).")
        print("This tool does not resize the filesystem inside it. Only "
              "continue if that filesystem has already been shrunk to fit, "
              "or is empty.")
        if not confirm("Shrink it anyway", assume_yes=False):
            raise WizardError("aborted at the shrink step")

    freed = part.sectors - keep_sectors
    parttool.shrink_partition(table, index, keep_sectors)
    start = part.start + keep_sectors
    start = (start + 2047) // 2048 * 2048
    sectors = freed - (start - (part.start + keep_sectors))
    if sectors < MIN_SECTORS:
        raise WizardError(
            f"shrinking frees only {human(sectors)}; "
            f"{human(MIN_SECTORS)} needed")
    return start, sectors


def write_sidwa(table: parttool.Table, start: int, sectors: int,
                device: str) -> None:
    """Write the partition table, then lay the boot code and kernel inside."""
    part = parttool.add_partition(table, start, sectors)
    parttool.write_table(table)
    print(f"partition {part.index}: {human(sectors)} at LBA {start}")

    # mkboot.py writes the boot code at the partition's own base LBA, so the
    # kernel's absolute addresses stay inside the partition. It never shrinks
    # an existing image, so the surrounding partitions are left alone.
    subprocess.run([sys.executable, os.path.join(ROOT, "tools", "mkboot.py"),
                    device, "--base-lba", str(start)],
                   check=True)


def install(device: str, mode: str, *, yes: bool = False,
            shrink_index: int | None = None,
            keep_mb: int | None = None, force_shrink: bool = False) -> int:
    table = show_disk(device)

    if not confirm(f"\nInstall SidwaOS to {device}", yes):
        print("aborted")
        return 1

    if mode == "whole":
        start, sectors = plan_whole(table)
    elif mode == "free":
        start, sectors = plan_free(table)
    elif mode == "shrink":
        if shrink_index is None:
            raise WizardError("--shrink-index is required for mode shrink")
        part = table.find_partition(shrink_index)
        if part is None:
            raise WizardError(f"no partition {shrink_index}")
        keep = (keep_mb * 1024 * 1024 // SECTOR) if keep_mb else \
            part.sectors - (REGION_SECTORS + 8192)
        start, sectors = plan_shrink(table, shrink_index, keep, force_shrink)
    else:
        raise WizardError(f"unknown mode: {mode}")

    write_sidwa(table, start, sectors, device)
    print(f"\nSidwaOS installed on {device} at LBA {start}.")
    print("Boot it with the machine set to start from this disk.")
    return 0


def interactive(device: str | None) -> int:
    print("SidwaOS install wizard\n")

    if device is None:
        disks = list_candidate_disks()
        if not disks:
            print("no disks found; pass --device")
            return 1
        print("Disks:")
        for i, path in enumerate(disks, 1):
            try:
                table = parttool.read_table(path)
                print(f"  {i}. {path} ({table.style.upper()}, "
                      f"{human(table.total_sectors)})")
            except OSError as exc:
                print(f"  {i}. {path} (unreadable: {exc})")
        choice = ask("Choose a disk", "1")
        try:
            device = disks[int(choice) - 1]
        except (ValueError, IndexError):
            print("not a valid choice")
            return 1

    table = show_disk(device)

    print("\nHow should space be made?")
    print("  1. whole  - use the whole disk")
    print("  2. free   - use unpartitioned space")
    print("  3. shrink - shrink a partition, then use the freed space")
    mode = ask("Choose", "2")
    mode = {"1": "whole", "2": "free", "3": "shrink"}.get(mode, mode)

    kwargs = {}
    if mode == "shrink":
        index = int(ask("Partition to shrink", "1"))
        keep = int(ask("MiB to keep in it",
                       str((table.find_partition(index).sectors * SECTOR
                            // (1024 * 1024)) // 2)))
        kwargs = {"shrink_index": index, "keep_mb": keep}

    try:
        return install(device, mode, yes=False, **kwargs)
    except WizardError as exc:
        print(f"\ncannot install: {exc}")
        return 1


def main() -> int:
    ap = argparse.ArgumentParser(description="Install SidwaOS to a disk")
    ap.add_argument("--device", default=None,
                    help="block device or image file")
    ap.add_argument("--mode", choices=["whole", "free", "shrink"], default=None)
    ap.add_argument("--shrink-index", type=int, default=None)
    ap.add_argument("--keep-mb", type=int, default=None)
    ap.add_argument("--force-shrink", action="store_true")
    ap.add_argument("--create-image", type=int, metavar="MB", default=None,
                    help="create the image file first, this many MiB")
    ap.add_argument("--yes", action="store_true", help="skip confirmations")
    args = ap.parse_args()

    if args.create_image:
        if not args.device:
            print("--create-image needs --device")
            return 1
        try:
            create_image(args.device, args.create_image)
        except WizardError as exc:
            print(exc)
            return 1

    if args.device and args.mode:
        try:
            return install(args.device, args.mode, yes=args.yes,
                           shrink_index=args.shrink_index,
                           keep_mb=args.keep_mb,
                           force_shrink=args.force_shrink)
        except WizardError as exc:
            print(f"cannot install: {exc}")
            return 1

    return interactive(args.device)


if __name__ == "__main__":
    raise SystemExit(main())
